<template>
  <div class="layout-logo" v-if="setShowLogo" @click="onThemeConfigChange">
    <span :style="{color:setFontColor}">{{ siteConfig.title }}</span>
  </div>
  <div class="layout-logo-size" v-else @click="onThemeConfigChange">
    <img :src="logoMini" class="layout-logo-size-img"/>
  </div>
</template>

<script setup lang="ts" name="layoutLogo">
import {useThemeConfig} from '/@/stores/themeConfig';
import {useSiteConfig} from '/@/stores/siteConfig';
import { useWindowSize } from '@vueuse/core';
import logoMini from '/@/assets/logo-mini.svg';

const {themeConfig} = storeToRefs(useThemeConfig());
const {siteConfig} = storeToRefs(useSiteConfig());
const { width: windowWidth } = useWindowSize();

const setShowLogo = computed(() => {
  const {isCollapse, layout} = themeConfig.value;
  return !isCollapse || layout === 'classic' || windowWidth.value < 1000;
});

const setFontColor = computed(() => {
  const {layout} = themeConfig.value;
  return layout === 'classic' || layout === 'transverse' ? `var(--next-bg-topBarColor)` : 'var(--el-color-primary)';
});

const onThemeConfigChange = () => {
  if (themeConfig.value.layout === 'transverse') return;
  themeConfig.value.isCollapse = !themeConfig.value.isCollapse;
};
</script>

<style scoped lang="scss">
.layout-logo {
  width: 220px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: rgb(0 21 41 / 2%) 0px 1px 4px;
  font-size: 16px;
  cursor: pointer;
  animation: logoAnimation 0.3s ease-in-out;

  span {
    white-space: nowrap;
    display: inline-block;
    font-size: 21.5px;
    font-weight: 700;
  }

  &:hover {
    span {
      color: var(--color-primary-light-2);
    }
  }
}

.layout-logo-size {
  width: 100%;
  height: 50px;
  display: flex;
  cursor: pointer;
  animation: logoAnimation 0.3s ease-in-out;

  &-img {
    width: 20px;
    margin: auto;
  }

  &:hover {
    img {
      animation: logoAnimation 0.3s ease-in-out;
    }
  }
}
</style>
