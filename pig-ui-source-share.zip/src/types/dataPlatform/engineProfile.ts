export type EngineType = 'DOLPHIN_SCHEDULER' | 'SEATUNNEL';

export type SeaTunnelRuntimeMode = 'LOCAL' | 'CLUSTER' | 'REST';

export interface EngineProfile {
	id: string;
	profileName: string;
	engineType: EngineType;
	enabled: boolean;
	baseUrl?: string | null;
	tokenConfigured?: boolean;
	runtimeMode?: SeaTunnelRuntimeMode;
	installHome?: string | null;
	configDir?: string | null;
	commandTemplate?: string | null;
	extraConfigJson?: string;
	updateTime?: string;
}

export interface EngineProfileQuery {
	engineType?: EngineType | '';
	enabled?: boolean;
}

export interface EngineProfileSaveRequest {
	profileName: string;
	engineType: EngineType | '';
	enabled: boolean;
	baseUrl?: string | null;
	apiToken?: string | null;
	runtimeMode?: SeaTunnelRuntimeMode;
	installHome?: string | null;
	configDir?: string | null;
	commandTemplate?: string | null;
	extraConfigJson?: string;
}

export interface EngineProfileTestResult {
	success: boolean;
	message: string;
}
