export type DataQueryCategory = 'RELATIONAL' | 'BIG_DATA';

export interface DataQueryDatasource {
	id: string;
	name: string;
	displayName?: string;
	dsType: string;
	databaseName?: string;
}

export interface DataQueryDatabase {
	name: string;
	defaultDatabase?: boolean;
}

export interface DataQueryTable {
	tableName: string;
	tableComment?: string | null;
	tableType?: string | null;
	schemaName?: string;
}

export interface DataQueryColumn {
	name?: string;
	columnName?: string;
	typeName?: string;
	dataType?: string;
	primaryKey?: boolean;
	nullable?: boolean;
	remarks?: string | null;
}

export interface DataQueryTableQuery {
	schema?: string;
	keyword?: string;
	current?: number;
	size?: number;
}

export interface DataQueryExecuteRequest {
	datasourceId: string;
	schema?: string;
	sql: string;
	maxRows?: number;
	timeoutSeconds?: number;
}

export interface DataQueryPageRequest {
	datasourceId: string;
	schema?: string;
	sql: string;
	page: number;
	pageSize: number;
	timeoutSeconds?: number;
}

export interface DataQueryResultColumn {
	name: string;
	type?: string;
}

export interface DataQueryExecuteResult {
	queryId?: string;
	columns: Array<DataQueryResultColumn | string>;
	rows: Array<Record<string, unknown>>;
	rowCount?: string | null;
	truncated?: boolean;
	elapsedMs?: number;
}

export interface DataQueryPageResult extends DataQueryExecuteResult {
	hasMore: boolean;
	page: number;
	pageSize: number;
}
