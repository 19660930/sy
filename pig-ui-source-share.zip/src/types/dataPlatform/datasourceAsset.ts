export type DatasourceAssetStatus = 'ENABLED' | 'DISABLED';

export interface DatasourceCapabilities {
	source: boolean;
	target: boolean;
	metadata: boolean;
	jdbc: boolean;
	document: boolean;
	odsCompatible: boolean;
}

export interface DatasourceReference {
	id: string;
	name: string;
	displayName?: string;
	dsType: string;
	dsName: string;
	datasourceCategory?: string;
	businessSystem?: string;
	metadataEnabled?: boolean;
	capabilities?: DatasourceCapabilities;
	updateTime?: string;
}

export interface DatasourceAssetSaveRequest {
	datasourceId: string;
	displayName: string;
	departmentId?: string;
	departmentName?: string;
	sectionId?: string;
	sectionName?: string;
	businessSystem?: string;
	datasourceCategory?: string;
	metadataEnabled: boolean;
	developerName?: string;
	developerPhone?: string;
	ownerName?: string;
	ownerPhone?: string;
	status: DatasourceAssetStatus;
	description?: string;
}

export interface DatasourceAsset extends DatasourceAssetSaveRequest {
	id: string;
	datasourceName?: string;
	datasourceType?: string;
	datasourceDatabase?: string;
	createTime?: string;
	updateTime?: string;
}

export interface DatasourceAssetQuery {
	displayName?: string;
	status?: DatasourceAssetStatus | '';
	current?: number;
	size?: number;
	descs?: string;
	ascs?: string;
}
