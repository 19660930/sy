export interface DwdOption {
	value: string;
	label: string;
}

export interface DwdOptions {
	sourceTypes: DwdOption[];
	joinTypes: DwdOption[];
	fieldRoles: DwdOption[];
	fieldSourceTypes: DwdOption[];
	statuses: DwdOption[];
	dataTypes: DwdOption[];
	partitionTypes: DwdOption[];
}

export interface DwdModelQuery {
	current: number;
	size: number;
	keyword?: string;
	businessSystemId?: string;
	businessDomainId?: string;
	sourceTableId?: string;
	status?: string;
}

export interface DwdModelSaveRequest {
	modelName: string;
	businessSystemId: string;
	businessDomainId: string;
	grain: string;
	owner: string;
	datasourceId: string;
	databaseName: string;
	physicalName: string;
	description?: string;
	status?: string;
	writeMode?: 'APPEND' | 'UPSERT';
	governanceEnabled?: boolean;
	warehouseLayer: 'DWD';
	expectedRevision?: string;
}

export interface DwdModel extends DwdModelSaveRequest {
	id: string;
	modelCode: string;
	rowCount?: string | null;
	targetTableStatus?: string;
	businessSystemName?: string;
	businessDomainName?: string;
	updateTime?: string;
	draftRevision?: string;
	lastFrozenRevision?: string | null;
	currentVersionNo?: string | null;
}

export interface DwdPage<T> {
	records: T[];
	total: number | string;
	current: number;
	size: number;
}

export interface DwdMetadataTable {
	id: string;
	datasourceId: string;
	catalogName?: string | null;
	schemaName?: string | null;
	tableName: string;
	warehouseLayer: string;
	tableType?: string | null;
	tableComment?: string | null;
}

export interface DwdSource {
	id?: string;
	modelId?: string | null;
	sourceType: 'ODS' | 'DIM';
	sourceTableId: string;
	sourceDatabase?: string;
	sourceTable: string;
	alias: string;
	isMain: boolean;
	joinType?: string;
	joinCondition?: string;
	joinKeys?: string;
	joinVersionMode?: string;
	sortOrder: number;
	status?: string;
}

export interface DwdField {
	targetColumn: string;
	targetType: string;
	targetComment?: string;
	sourceType: 'ODS_FIELD' | 'EXPRESSION' | 'CONSTANT';
	sourceExpr: string;
	role: string;
	seq: number;
	isPk?: boolean;
	isMasked?: boolean;
	transformRule?: string;
	transformType?: string;
	transformParams?: string;
	sourceAlias?: string;
	status?: string;
	sortOrder?: number;
}

export interface DwdPartition {
	partitionColumn: string;
	partitionGranularity: 'DAY' | 'NONE';
	incrementType: 'TIMESTAMP' | 'BUSINESS_DATE';
	incrementField: string;
	dataRange?: string;
	updateCycle?: string;
	lateDataLookback?: string;
	rerunStrategy?: string;
	status?: string;
}

export interface DwdSqlResult {
	sql: string;
	physicalName: string;
	databaseName: string;
}

export interface DwdVersion {
	id: string;
	modelId: string;
	versionNo: string;
	changelog?: string;
	isCurrent?: boolean;
	effectiveTime?: string;
	operator?: string;
	snapshotJson?: string;
	generatedSql?: string;
	draftRevision?: string;
	validationStatus?: string;
}

export interface DwdValidationResult {
	valid: boolean;
	issues: Array<{ path: string; code: string; message: string }>;
}

export interface DwdFrozenVersion {
	versionId: string;
	modelId: string;
	versionNo: string;
	plan: Record<string, unknown>;
}

export interface DwdModelReference {
	taskId: string;
	taskName: string;
	taskVersionId: string;
	status: string;
	enabled: boolean;
}
