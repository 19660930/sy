export type DimensionType = 'COMMON' | 'BUSINESS';

export type DimensionStatus = 'ENABLED' | 'DISABLED';

export interface DimensionOption {
	value: string;
	label: string;
	extra?: string | null;
}

export interface DimensionOptions {
	dimTypes: DimensionOption[];
	statuses: DimensionOption[];
	tableTypes?: DimensionOption[] | string[];
}

export interface DimensionSourceOption {
	id: string;
	label: string;
	refTableId?: string | null;
	objectCode?: string | null;
	objectName?: string | null;
	columnName?: string | null;
	columnComment?: string | null;
}

export interface DimensionModelQuery {
	current: number;
	size: number;
	keyword?: string;
	dimType?: DimensionType | '';
	businessSystemId?: string;
	businessDomainId?: string;
	status?: DimensionStatus | '';
}

export interface DimensionModel {
	id: string;
	modelCode: string;
	modelName: string;
	dimType: DimensionType;
	businessSystemId?: string | null;
	businessSystemName?: string | null;
	businessDomainId?: string | null;
	businessDomainName?: string | null;
	levelCount?: string | number | null;
	generatedTableName?: string | null;
	status: DimensionStatus;
	description?: string | null;
	createBy?: string | null;
	createTime?: string | null;
	updateTime?: string | null;
}

export interface DimensionModelPage {
	records: DimensionModel[];
	total: string;
	current: string;
	size: string;
	pages: string;
}

export interface DimensionModelGenerateView {
	id: string;
	modelName: string;
	enabled: boolean;
}

export interface DimensionModelGeneratePage {
	records: DimensionModelGenerateView[];
	total: string | number;
	current?: string | number;
	page?: string | number;
	size: string | number;
	pages?: string | number;
}

export interface DimensionModelSaveRequest {
	modelCode?: string;
	modelName: string;
	dimType: DimensionType | '';
	businessSystemId: string;
	businessDomainId: string;
	description: string;
}

export interface DimensionAttribute {
	id: string;
	attrCode: string;
	attrName: string;
	dataType: string;
	dataLength: number;
	dataScale: number;
	isPk: number;
	isRequired: number;
	defaultValue?: string | null;
	description?: string | null;
}

export interface DimensionAttributeSaveRequest {
	attrCode: string;
	attrName: string;
	dataType: string;
	dataLength: number;
	dataScale: number;
	isPk: number;
	isRequired: number;
	defaultValue: string;
	description: string;
}

export interface DimensionLevel {
	id: string;
	levelCode: string;
	levelName: string;
	parentLevelId?: string | null;
	codeField: string;
	sortOrder: number;
	description?: string | null;
}

export interface DimensionLevelSaveRequest {
	levelCode: string;
	levelName: string;
	parentLevelId: string | null;
	codeField: string;
	sortOrder: number;
	description: string;
}

export interface DimensionModelVersion {
	versionNo: string;
	changelog?: string | null;
	isCurrent: boolean;
	effectiveTime?: string | null;
	operator?: string | null;
}

export interface DimensionMapping {
	id: string;
	businessSystemId?: string | null;
	businessSystemName?: string | null;
	businessDomainId?: string | null;
	businessDomainName?: string | null;
	sourceTableId?: string | null;
	sourceColumnId?: string | null;
	sourceTableName?: string | null;
	sourceColumnName?: string | null;
	businessTable?: string | null;
	businessField?: string | null;
	dimField: string;
	matchType: string;
	status: DimensionStatus;
}

export interface DimensionMappingSaveRequest {
	businessSystemId: string;
	businessDomainId: string;
	sourceTableId: string;
	sourceColumnId: string;
	businessTable?: string;
	businessField?: string;
	dimField: string;
	matchType: string;
}

export interface DimensionStrategyQuery {
	current: number;
	size: number;
	keyword?: string;
	modelId?: string;
	dimTableId?: string;
	scdType?: string;
	status?: DimensionStatus | '';
}

export interface DimensionStrategy {
	id: string;
	strategyName: string;
	modelId: string;
	modelName?: string | null;
	dimTableId?: string | null;
	dimTableName?: string | null;
	scdType: string;
	naturalKey?: string | null;
	surrogateKey?: string | null;
	effectiveField?: string | null;
	expireField?: string | null;
	historyKeepMode: string;
	writeMode?: string | null;
	scheduleCron?: string | null;
	status: DimensionStatus;
}

export interface DimensionStrategyPage {
	records: DimensionStrategy[];
	total: string;
	current: string;
	size: string;
	pages: string;
}

export interface DimensionStrategySaveRequest {
	strategyName: string;
	modelId: string;
	scdType: string;
	naturalKey: string;
	surrogateKey: string;
	effectiveField: string;
	expireField: string;
	historyKeepMode: string;
	writeMode: string;
	scheduleCron: string;
}

export interface DimensionDatasourceOption extends DimensionOption {
	engineType?: string | null;
	category?: string | null;
}

export interface DimensionTableQuery {
	current: number;
	size: number;
	keyword?: string;
	tableType?: string;
	scdType?: string;
	modelId?: string;
	status?: DimensionStatus | '';
}

export interface DimensionTable {
	id: string;
	tableName: string;
	physicalName: string;
	tableType?: string | null;
	modelId: string;
	modelName?: string | null;
	businessSystemName?: string | null;
	businessDomainName?: string | null;
	datasourceId?: string | null;
	datasourceName?: string | null;
	databaseName?: string | null;
	scdType: string;
	structureVersion?: string | null;
	effectiveCount?: string | null;
	historyCount?: string | null;
	totalCount?: string | null;
	status: DimensionStatus;
	description?: string | null;
	lastSyncTime?: string | null;
	createTime?: string | null;
	updateTime?: string | null;
}

export interface DimensionTablePage {
	records: DimensionTable[];
	total: string;
	current: string;
	size: string;
	pages: string;
}

export interface DimensionTableSaveRequest {
	tableName: string;
	physicalName: string;
	tableType: 'ROLE_PLAYING';
	modelId: string;
	datasourceId: string;
	databaseName: string;
	description: string;
}

export interface DimensionDdlAttributeInput {
	attrCode: string;
	attrName: string;
	dataType: string;
	dataLength: number;
	dataScale: number;
	isPk: number;
	isRequired: number;
	defaultValue?: string | null;
	description?: string | null;
}

export interface DimensionTableGenerateRequest {
	modelId: string;
	datasourceId: string;
	databaseName: string;
	physicalName: string;
	tableName: string;
	scdType?: string;
	attributes: DimensionDdlAttributeInput[];
}

export interface DimensionTableGenerateResult {
	tableId: string;
	ddl: string;
	columns: Array<Record<string, unknown>>;
	executeDdl: boolean;
}

export interface DimensionTableVersion {
	versionNo: string;
	changelog?: string | null;
	isCurrent?: boolean;
	effectiveTime?: string | null;
	operator?: string | null;
}

export interface DimensionDeployResult {
	taskId: string;
	versionId: string;
}

export interface DimensionPhysicalColumn {
	name: string;
	type: string;
	nullable?: boolean | null;
}

export interface DimensionExpectedColumn {
	columnName: string;
	columnType: string;
	isPrimary?: boolean | number | null;
	nullable?: boolean | null;
	comment?: string | null;
}

export interface DimensionTablePhysicalStructure {
	columns: DimensionPhysicalColumn[];
	keyColumns?: string[];
	distribution?: unknown;
	bucket?: string | number | null;
	partition?: unknown;
	engineProperties?: Record<string, unknown> | null;
	endpointIdentity?: string | null;
}

export interface DimensionTableMaintenancePreview {
	tableId: string;
	qualifiedName: string;
	modelVersion?: string | number | null;
	currentStructure: DimensionTablePhysicalStructure;
	expectedColumns: DimensionExpectedColumn[];
	expectedKeyColumns?: string[];
	createDdl?: string | null;
	rowCount?: string | null;
	previewToken: string;
	canUpdateStructure: boolean;
	updateBlockedReason?: string | null;
	canDeleteRecord: boolean;
	deleteRecordBlockedReason?: string | null;
	canDeletePhysical: boolean;
	deletePhysicalBlockedReason?: string | null;
	referencedTaskIds?: string[];
	sharedTableIds?: string[];
}

export interface DimensionTableMaintenanceConfirmRequest {
	previewToken: string;
	confirmTableName: string;
}

export interface DimensionTableStructureUpdateResult {
	tableId: string;
	structureVersion: string;
	backupTableName: string;
}

export interface DimensionValueTreeNode {
	id: string;
	code: string;
	name: string;
	parentId?: string | null;
	levelId?: string | null;
	levelName?: string | null;
	children?: DimensionValueTreeNode[];
}

export interface DimensionValueQuery {
	modelId: string;
	parentId?: string;
	current: number;
	size: number;
}

export interface DimensionValue {
	id: string;
	modelId: string;
	tableId?: string | null;
	code: string;
	name: string;
	nameEn?: string | null;
	parentId?: string | null;
	parentCode?: string | null;
	levelId?: string | null;
	levelName?: string | null;
	effectiveDate?: string | null;
	expireDate?: string | null;
	isCurrent?: string | number | null;
	status: DimensionStatus;
	remark?: string | null;
	updateTime?: string | null;
	extJson?: Record<string, unknown> | string | null;
	attributeValues?: DimensionAttributeItem[] | null;
}

export interface DimensionAttributeItem {
	attrCode: string;
	attrName: string;
	dataType: string;
	value: unknown;
}

export interface DimensionValuePage {
	records: DimensionValue[];
	total: string;
	current: string;
	size: string;
	pages: string;
}

export interface MaterializedDimensionValueRecord {
	businessKey?: string | null;
	columns: Record<string, unknown>;
}

export interface MaterializedDimensionValuePage {
	records: MaterializedDimensionValueRecord[];
	total: string;
	current: string;
	size: string;
	pages: string;
}

export interface DimensionValueSaveRequest {
	modelId: string;
	tableId: string;
	parentId: string | null;
	code: string;
	name: string;
	nameEn: string;
	effectiveDate: string;
	status: DimensionStatus;
	remark: string;
	extJson: Record<string, unknown>;
}

export interface DimensionValueImportResult {
	successCount: string | number;
	failCount: string | number;
	errors: string[];
}
