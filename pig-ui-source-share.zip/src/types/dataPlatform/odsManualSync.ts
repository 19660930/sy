export type ManualSyncDatasourceKind = 'SOURCE' | 'TARGET';
export type ManualSyncStatus = 'SUBMITTED' | 'RUNNING' | 'SUCCESS' | 'PARTIAL_SUCCESS' | 'FAILURE';
export type ManualSyncItemStatus = 'SUBMITTED' | 'RUNNING' | 'SUCCESS' | 'FAILURE';

export interface ManualSyncDatasource {
	id: string;
	name: string;
	displayName?: string;
	dsType: string;
	dsName: string;
	updateTime?: string;
}

export interface ManualSyncSeaTunnelProfile {
	id: string;
	profileName: string;
	runtimeMode: 'LOCAL' | 'CLUSTER' | 'REST';
}

export interface ManualSyncSourceTable {
	catalog?: string | null;
	schema?: string | null;
	tableName: string;
	tableType: string;
	remarks?: string | null;
}

export interface ManualSyncSubmitRequest {
	sourceDatasourceId: string;
	targetDatasourceId: string;
	seatunnelProfileId?: string;
	tableNames: string[];
	targetPrefix?: string;
	batchSize?: number;
}

export interface ManualSyncBatchItem {
	id: string;
	sourceTable: string;
	targetTable: string;
	sourceTableComment?: string | null;
	sourceObjectType?: string | null;
	syncStatus: ManualSyncItemStatus;
	processExitCode?: number | null;
	rowsWritten?: string | null;
	startTime?: string | null;
	endTime?: string | null;
	errorSummary?: string | null;
}

export interface ManualSyncBatch {
	id: string;
	sourceDatasourceId: string;
	targetDatasourceId: string;
	seatunnelProfileId?: string | null;
	syncStatus: ManualSyncStatus;
	totalTables: number;
	successTables: number;
	failedTables: number;
	batchSize: number;
	startTime?: string | null;
	endTime?: string | null;
	errorSummary?: string | null;
	createTime?: string | null;
	items?: ManualSyncBatchItem[];
}

export interface ManualSyncBatchQuery {
	current?: number;
	size?: number;
	syncStatus?: ManualSyncStatus | '';
	sourceDatasourceId?: string;
	targetDatasourceId?: string;
	descs?: string;
	ascs?: string;
}
