export type OdsTableModelSyncStatus = 'SUBMITTED' | 'RUNNING' | 'SUCCESS' | 'FAILURE';

export interface OdsTableModel {
	id: string;
	sourceDatasourceId: string;
	targetDatasourceId: string;
	sourceTable: string;
	targetTable: string;
	tableComment?: string | null;
	objectType?: string | null;
	businessSystem?: string | null;
	businessDomain?: string | null;
	departmentId?: string | null;
	departmentName?: string | null;
	rowCount?: string | null;
	latestBatchId?: string | null;
	syncStatus: OdsTableModelSyncStatus;
	errorSummary?: string | null;
	lastSyncTime?: string | null;
	createTime?: string | null;
	updateTime?: string | null;
}

export interface OdsTableModelColumn {
	name: string;
	typeName: string;
	jdbcType: number;
	size?: number | null;
	scale?: number | null;
	nullable: boolean;
	primaryKey: boolean;
	remarks?: string | null;
	ordinalPosition?: number | null;
	defaultValue?: string | null;
	autoIncrement?: boolean | null;
}

export interface OdsTableModelQuery {
	current?: number;
	size?: number;
	keyword?: string;
	syncStatus?: OdsTableModelSyncStatus | '';
	targetDatasourceId?: string;
	descs?: string;
	ascs?: string;
}

export interface OdsTableDataPreviewQuery {
	limit?: number;
	timeoutSeconds?: number;
}

export interface OdsTableDataPreview {
	columns: string[];
	rows: Array<Record<string, unknown>>;
	truncated: boolean;
}

export interface OdsTableModelDeleteFailure {
	id?: string | number;
	targetTable?: string;
	message?: string;
	reason?: string;
	errorMessage?: string;
}

export interface OdsTableModelBatchDeleteResult {
	deletedIds: Array<string | number>;
	failedItems: OdsTableModelDeleteFailure[];
}
