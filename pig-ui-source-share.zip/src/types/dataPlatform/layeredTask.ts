import type { OdsTableModelSyncStatus } from './odsTableModel';

export type WarehouseLayer = 'ODS' | 'DIM' | 'DWD' | 'DWS' | 'ADS';

export type LayeredTaskStatus = 'DRAFT' | 'PUBLISHED' | 'OFFLINE';

export type LayeredTaskRunStatus = 'SUBMITTED' | 'RUNNING' | 'SUCCESS' | 'FAILURE' | 'STOPPED';

export type LayeredTaskType = 'SOURCE_SYNC' | 'DIM_BUILD' | 'DWD_PROCESS' | 'FACT_BUILD' | 'AGG_BUILD' | 'MODEL_BUILD' | 'MODEL_REFRESH';

export type SyncMode = 'FULL' | 'INCREMENTAL' | 'FULL_THEN_INCREMENTAL';

export type TargetTableMode = 'APPEND' | 'RECREATE_ON_PUBLISH';

export type IncrementalColumnType = 'TIMESTAMP' | 'DATETIME' | 'DATE' | 'TIME' | 'BIGINT' | 'INT' | 'DECIMAL' | 'STRING';

export interface IncrementalColumnConfig {
	name: string;
	type: IncrementalColumnType;
	order?: number;
	initialValue?: string;
	initialValuePlaceholder?: string;
}

export type IncrementalStrategy = 'APPEND' | 'UPSERT';

export type SourceDeleteStrategy = 'IGNORE' | 'MARK_DELETED';

export interface SyncEnumOption<T extends string = string> {
	value: T;
	label: string;
	description?: string;
}

export type WatermarkStorage = 'DATABASE' | 'FILE';

export type ScheduleType = 'MANUAL' | 'CRON';

export interface PageResult<T> {
	records: T[];
	total: string;
	current?: string;
	size?: string;
	pages?: string;
}

export interface LayeredTaskQuery {
	current: number;
	size: number;
	layer?: WarehouseLayer;
	keyword?: string;
	status?: LayeredTaskStatus | '';
	enabled?: boolean;
}

export interface LayeredTaskSummary {
	id: string;
	taskCode: string;
	taskName: string;
	warehouseLayer: WarehouseLayer;
	taskType: LayeredTaskType;
	businessSystemId?: string;
	businessDomainId?: string;
	businessSystemName?: string;
	businessDomainName?: string;
	relatedModelId?: string | null;
	relatedModelName?: string | null;
	dwdVersionId?: string | null;
	replicaDatabase?: string | null;
	entityTableId?: string | null;
	entityTableName?: string | null;
	databaseName?: string | null;
	physicalName?: string | null;
	scdType?: 'SCD0' | 'SCD1' | string | null;
	writeStrategy?: 'REPLACE' | string | null;
	sourceDatasourceId?: string;
	targetDatasourceId?: string;
	sourceDatasourceName?: string;
	targetDatasourceName?: string;
	sourceTable?: string;
	targetTable: string;
	targetTableMode?: TargetTableMode;
	status: LayeredTaskStatus;
	enabled: boolean;
	schedulePaused?: boolean;
	currentVersionNo?: number;
	currentVersionId?: string;
	versionStatus?: string;
	syncMode?: SyncMode;
	incrementalColumn?: string;
	incrementalColumns?: string | IncrementalColumnConfig[];
	incrementalColumnType?: string;
	incrementalStrategy?: IncrementalStrategy;
	incrementalStartValue?: string;
	sourceDeleteStrategy?: SourceDeleteStrategy;
	reconciliationIntervalMinutes?: number;
	reconciliationMaxDeleteRows?: number;
	lastReconciliationTime?: string;
	lastReconciliationAttemptTime?: string;
	watermarkStorage?: WatermarkStorage;
	scheduleType?: ScheduleType;
	cycleName?: string;
	cronExpression?: string;
	timezone?: string;
	batchSize?: number;
	retryTimes?: number;
	retryIntervalMinutes?: number;
	dsProfileId?: string;
	seatunnelProfileId?: string;
	publishedVersionId?: string;
	publishedVersionNo?: number | null;
	hasActiveRun?: boolean;
	activeRunId?: string | null;
	activeRunStatus?: LayeredTaskRunStatus | null;
	lastSuccessCheckpoint?: string;
	publishErrorSummary?: string;
	description?: string;
	processedRows?: string | null;
	createTime?: string;
	updateTime?: string;
}

export interface DimBuildSnapshotOutputBinding {
	tableId?: string;
	targetDatasourceId?: string;
	database?: string;
	physicalName?: string;
	physicalColumns?: unknown[];
	keyModel?: string;
	keyColumns?: string[];
}

export interface DimBuildSnapshotExecutionPolicy {
	syncMode?: 'FULL' | string;
	scdType?: 'SCD0' | 'SCD1' | string;
	writeStrategy?: 'REPLACE_INTO' | string;
	batchSize?: number;
}

export interface DimBuildSnapshot {
	schemaVersion?: string | number;
	snapshotIdentity?: string;
	modelId?: string;
	modelVersion?: string | number;
	outputBinding?: DimBuildSnapshotOutputBinding;
	executionPolicy?: DimBuildSnapshotExecutionPolicy;
	inputDataPolicy?: string;
}

export interface LayeredTaskDetail extends LayeredTaskSummary {
	incrementalColumnDetails?: IncrementalColumnConfig[];
	dsProfileName?: string;
	seatunnelProfileName?: string;
	dsProjectCode?: string;
	dsProcessDefinitionCode?: string;
	dsTaskDefinitionCode?: string;
	dependencyTaskIds?: string[];
	publishedSnapshot?: DimBuildSnapshot | null;
	publishedSnapshotError?: string | null;
}

export interface SyncTaskSaveRequest {
	warehouseLayer: WarehouseLayer;
	taskType: LayeredTaskType;
	dwdVersionId?: string;
	replicaDatabase?: string;
	businessSystemId?: string;
	businessDomainId?: string;
	relatedModelId?: string | null;
	description?: string;
	taskCode?: string;
	taskName: string;
	sourceDatasourceId?: string;
	targetDatasourceId: string;
	sourceTable?: string;
	targetTable: string;
	targetTableMode?: TargetTableMode;
	syncMode: SyncMode;
	incrementalColumn?: string;
	incrementalColumns?: IncrementalColumnConfig[];
	incrementalColumnType?: string;
	incrementalStrategy?: IncrementalStrategy;
	incrementalStartValue?: string;
	sourceDeleteStrategy?: SourceDeleteStrategy;
	reconciliationIntervalMinutes?: number;
	reconciliationMaxDeleteRows?: number;
	watermarkStorage?: WatermarkStorage;
	scheduleType: ScheduleType;
	cronExpression?: string;
	timezone: string;
	batchSize: number;
	retryTimes: number;
	retryIntervalMinutes: number;
	dsProfileId: string;
	seatunnelProfileId?: string;
	dependencyTaskIds: string[];
}

export interface DwdSyncTaskSaveRequest {
	taskName: string;
	taskCode?: string;
	description?: string;
	warehouseLayer: 'DWD';
	taskType: 'DWD_PROCESS';
	dwdVersionId: string;
	syncMode: 'FULL';
	scheduleType: ScheduleType;
	seatunnelProfileId: string;
	cronExpression?: string;
	timezone?: string;
	dsProfileId?: string;
	replicaDatabase?: string;
	batchSize?: number;
	retryTimes?: number;
	retryIntervalMinutes?: number;
	dependencyTaskIds?: string[];
}

export interface SyncTaskSaveResult {
	taskId: string;
	versionId: string;
}

export interface SchemaPrecheckRequest {
	sourceDatasourceId: string;
	sourceTable: string;
	targetDatasourceId: string;
	targetTable: string;
	targetTableMode: TargetTableMode;
}

export interface SchemaPrecheckIssue {
	code?: string;
	columnName?: string;
	message: string;
	suggestedAction?: string;
}

export type SchemaPrecheckAction = 'CREATE' | 'APPEND' | 'RECREATE' | 'BLOCK';

export interface SchemaPrecheckResult {
	canPublish?: boolean;
	targetTableExists: boolean;
	action: SchemaPrecheckAction;
	summary: string;
	plannedDdl?: string[];
	warnings?: string[];
	blockingIssues?: SchemaPrecheckIssue[];
}

export interface SyncTaskVersion {
	id?: string;
	versionId?: string;
	versionNo?: number;
	dwdVersionId?: string | null;
	status?: string;
	versionStatus?: string;
	publishErrorSummary?: string;
	createTime?: string;
	updateTime?: string;
}

export interface RelatedModel {
	id: string;
	sourceTable?: string | null;
	targetTable?: string | null;
	objectType?: string | null;
	syncStatus?: OdsTableModelSyncStatus | null;
	rowCount?: string | null;
}

export interface DatasourceMetadataTable {
	catalog?: string | null;
	schema?: string | null;
	tableName: string;
	remarks?: string | null;
	tableType?: string;
	configured?: boolean;
	taskBound?: boolean;
	taskId?: string | null;
	selectable?: boolean;
	disabledReason?: string | null;
}

export interface DatasourceMetadataColumn {
	columnName: string;
	columnType?: string;
	dataType?: string;
	remarks?: string | null;
	columnComment?: string | null;
	primaryKey?: boolean;
	indexed?: boolean;
	isPrimaryKey?: boolean;
	isIndexed?: boolean;
	isNullable?: boolean;
	incrementalEligible?: boolean;
	incrementalReason?: string;
	initialValuePlaceholder?: string;
	indexType?: string;
}

export interface LayeredTaskStatistics {
	total?: string | null;
	ods?: string | null;
	dim?: string | null;
	dwd?: string | null;
	dws?: string | null;
	ads?: string | null;
	odsCount?: string | null;
	dimCount?: string | null;
	dwdCount?: string | null;
	dwsCount?: string | null;
	adsCount?: string | null;
	ALL?: string | null;
	ODS?: string | null;
	DIM?: string | null;
	DWD?: string | null;
	DWS?: string | null;
	ADS?: string | null;
}

export interface SyncRunQuery {
	current: number;
	size: number;
	taskId?: string;
	runStatus?: LayeredTaskRunStatus | '';
}

export interface SyncRunRecord {
	id: string;
	taskId: string;
	taskCode?: string;
	taskName?: string;
	taskVersionId?: string;
	dsProcessInstanceId?: string;
	dsTaskInstanceId?: string;
	triggerType?: string;
	runStatus?: LayeredTaskRunStatus;
	checkpointBefore?: string;
	checkpointAfter?: string;
	startTime?: string;
	endTime?: string;
	rowsRead?: string | null;
	rowsWritten?: string | null;
	errorSummary?: string;
	logUrl?: string;
	createTime?: string;
}

export interface SyncRunLogs {
	logs: string;
	logUrl?: string;
}

export interface BusinessSystemOption {
	id: string;
	value?: string;
	code?: string;
	name: string;
	label?: string;
}

export interface BusinessDomainOption extends BusinessSystemOption {
	businessSystemId?: string;
}
