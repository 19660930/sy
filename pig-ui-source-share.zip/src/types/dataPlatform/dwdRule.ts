export type DwdRuleKind = 'clean' | 'transform' | 'mask' | 'quality';

export interface DwdRule {
	id: string;
	ruleCode: string;
	ruleName: string;
	ruleType?: string;
	maskType?: string;
	status?: string;
	description?: string;
	businessSystemId?: string | null;
	businessDomainId?: string | null;
	modelId?: string | null;
	targetColumn?: string;
	targetField?: string;
	conditionJson?: string;
	actionJson?: string;
	transformConfig?: string;
	strategyJson?: string;
	execOrder?: number | null;
	sqlExpression?: string;
	sourceFields?: string;
	sqlFunction?: string;
	threshold?: string;
	anomalyAction?: string;
	updateTime?: string;
}

export interface DwdRuleQuery {
	current: number;
	size: number;
	keyword?: string;
	status?: string;
	businessSystemId?: string;
	businessDomainId?: string;
	ruleType?: string;
	maskType?: string;
}

export type DwdRuleSaveRequest = Omit<DwdRule, 'id' | 'ruleCode' | 'updateTime'>;
