export interface DatasourceTableIdentifier {
	catalog?: string | null;
	schema?: string | null;
	tableName: string;
}

export interface DatasourceTableConfiguration extends DatasourceTableIdentifier {
	id?: string;
	tableType?: string;
	remarks?: string | null;
	configured?: boolean;
	taskBound?: boolean;
	taskId?: string | null;
	selectable?: boolean;
	disabledReason?: string | null;
}

export interface DatasourceTableConfigurationSaveRequest {
	tables: DatasourceTableIdentifier[];
}

export interface DatasourcePhysicalTableQuery {
	keyword?: string;
	current: number;
	size: number;
}

export interface DatasourcePhysicalTablePage {
	records: DatasourceTableConfiguration[];
	total: string;
	current?: string;
	size?: string;
}
