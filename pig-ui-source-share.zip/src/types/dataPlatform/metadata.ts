export type MetadataCategory = 'ALL' | 'TECHNICAL' | 'BUSINESS' | 'METRIC' | 'DIMENSION' | 'THEME' | 'API';

export type MetadataMatchMode = 'FUZZY' | 'EXACT';

export type MetadataMapView = 'GLOBAL' | 'BUSINESS' | 'MODEL' | 'LINEAGE';

export type MetadataGraphDirection = 'UPSTREAM' | 'DOWNSTREAM' | 'BOTH';

export interface MetadataOption {
	value: string;
	label: string;
	parentValue?: string;
	extra?: string | null;
	category?: string;
}

export interface MetadataOptions {
	businessSystems?: MetadataOption[];
	businessDomains?: MetadataOption[];
	warehouseLayers?: MetadataOption[];
	objectTypes?: MetadataOption[];
	statuses?: MetadataOption[];
}

export interface MetadataSearchQuery {
	current: number;
	size: number;
	keyword?: string;
	category?: MetadataCategory;
	matchMode?: MetadataMatchMode;
	businessSystemId?: string;
	businessDomainId?: string;
	warehouseLayer?: string;
	objectType?: string;
	status?: string;
}

export interface MetadataObjectSummary {
	id: string;
	objectCode: string;
	objectName: string;
	chineseName?: string;
	objectType: string;
	category?: string;
	warehouseLayer?: string;
	status?: string;
	description?: string;
	businessSystemId?: string;
	businessSystemName?: string;
	businessDomainId?: string;
	businessDomainName?: string;
	databaseName?: string;
	schemaName?: string;
	ownerName?: string;
	lastCollectionTime?: string;
	matchedFields?: string[];
	matchDescription?: string;
}

export interface MetadataObjectDetail extends MetadataObjectSummary {
	createTime?: string;
	technical?: MetadataTechnicalDetail | null;
}

export interface MetadataTechnicalDetail {
	refTableId: string;
	datasourceId: string;
	catalogName?: string;
	schemaName?: string;
	tableName: string;
	tableType?: string;
	rowCount?: string | null;
	versionNo?: number;
	metadataHash?: string;
	lastCollectedAt?: string;
}

export interface MetadataColumn {
	id: string;
	metadataTableId: string;
	columnName: string;
	ordinalPosition?: number;
	typeName?: string;
	jdbcType?: number;
	columnSize?: number;
	decimalDigits?: number | null;
	nullable?: boolean;
	primaryKey?: boolean;
	autoIncrement?: boolean;
	defaultValue?: string | null;
	columnComment?: string;
	characterSet?: string;
	collation?: string;
	createTime?: string;
	updateTime?: string;
}

export interface MetadataSearchResult {
	records: MetadataObjectSummary[];
	total: string;
	current?: string;
	size?: string;
	facets?: Partial<Record<MetadataCategory, string | null>>;
}

export interface MetadataSuggestion {
	id: string;
	objectCode: string;
	objectName: string;
	objectType: string;
	category?: string;
	value?: string;
	label?: string;
}

export interface MetadataGraphQuery {
	view: MetadataMapView;
	rootObjectId?: string;
	businessSystemId?: string;
	businessDomainId?: string;
	warehouseLayer?: string;
	objectType?: string;
	keyword?: string;
	direction?: MetadataGraphDirection;
	depth?: number;
}

export interface MetadataGraphNode extends MetadataObjectSummary {
	x?: number;
	y?: number;
}

export interface MetadataGraphEdge {
	id?: string;
	sourceId: string;
	targetId: string;
	relationType?: string;
	description?: string;
}

export interface MetadataGraphResult {
	nodes: MetadataGraphNode[];
	edges: MetadataGraphEdge[];
	truncated?: boolean;
	totalNodes?: string | null;
	totalEdges?: string | null;
}
