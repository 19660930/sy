/** 保留后端的十进制 ID 原文；仅兼容旧接口返回的安全整数。 */
export const isDwdId = (value: unknown): value is string => typeof value === 'string' && /^[1-9]\d*$/.test(value);

export function dwdId(value: unknown): string {
	if (isDwdId(value)) return value;
	if (typeof value === 'number' && Number.isSafeInteger(value) && value > 0) return String(value);
	throw new Error('接口返回的 ID 无效或已超出浏览器安全范围，请确认后端已部署字符串 ID 版本');
}

export function optionalDwdId(value: unknown): string {
	return value == null || value === '' ? '' : dwdId(value);
}

/** 草稿修订号可从 0 开始，也须保留 Long 字符串精度。 */
export function dwdRevision(value: unknown): string {
	if (typeof value === 'string' && /^(0|[1-9]\d*)$/.test(value)) return value;
	if (typeof value === 'number' && Number.isSafeInteger(value) && value >= 0) return String(value);
	throw new Error('接口返回的草稿修订号无效，请确认后端已部署字符串 Long 版本');
}
