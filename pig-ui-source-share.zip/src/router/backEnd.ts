import { RouteRecordRaw } from 'vue-router';
import pinia from '/@/stores/index';
import { useUserInfo } from '/@/stores/userInfo';
import { useRequestOldRoutes } from '/@/stores/requestOldRoutes';
import { Session } from '/@/utils/storage';
import { NextLoading } from '/@/utils/loading';
import { baseRoutes, notFoundAndNoPower, dynamicRoutes } from '/@/router/route';
import { formatTwoStageRoutes, formatFlatteningRoutes, router } from '/@/router/index';
import { useRoutesList } from '/@/stores/routesList';
import { useTagsViewRoutes } from '/@/stores/tagsViewRoutes';
import { useMenuApi } from '/@/api/admin/menu';
import { buildDataPlatformNavigation, dataPlatformPlaceholderRoutes, getDataPlatformEntryPath } from '/@/router/dataPlatform';

// 后端控制路由

// 引入 api 请求接口
const menuApi = useMenuApi();

/**
 * 获取目录下的 .vue、.tsx 全部文件
 * @method import.meta.glob
 * @link 参考：https://cn.vitejs.dev/guide/features.html#json
 */
const layouModules: any = import.meta.glob('../layout/routerView/*.{vue,tsx}');
const viewsModules: any = import.meta.glob('../views/**/*.{vue,tsx}');
const dynamicViewsModules: Record<string, Function> = Object.assign({}, { ...layouModules }, { ...viewsModules });

// 仅从前端导航中隐藏，保留后端菜单数据和路由访问能力
const HIDDEN_NAVIGATION_MENU_IDS = new Set(['2800', '4001', '4004']);
const HIDDEN_NAVIGATION_MENU_TITLES = new Set(['岗位管理', '文件管理', '敏感词管理', '行政区划', '数据中台']);
const HIDDEN_NAVIGATION_MENU_PATHS = new Set([
	'/admin/system/post/index',
	'/admin/post/index',
	'/admin/file/index',
	'/admin/sensitive/index',
	'/admin/sysArea/index',
	'/data-platform',
]);

function isHiddenNavigationRoute(route: any) {
	return (
		HIDDEN_NAVIGATION_MENU_IDS.has(String(route.id)) ||
		HIDDEN_NAVIGATION_MENU_TITLES.has(String(route.meta?.title)) ||
		HIDDEN_NAVIGATION_MENU_PATHS.has(String(route.path))
	);
}

function filterNavigationRoutes(routes: RouteRecordRaw[]): RouteRecordRaw[] {
	return routes
		.filter((route: any) => !isHiddenNavigationRoute(route))
		.map((route: any) => ({
			...route,
			children: route.children ? filterNavigationRoutes(route.children) : route.children,
		}));
}

/**
 * 后端控制路由：初始化方法，防止刷新时路由丢失
 * @method NextLoading 界面 loading 动画开始执行
 * @method useUserInfo().setUserInfos() 触发初始化用户信息 pinia
 * @method useRequestOldRoutes().setRequestOldRoutes() 存储接口原始路由（未处理component），根据需求选择使用
 * @method setAddRoute 添加动态路由
 * @method setFilterMenuAndCacheTagsViewRoutes 设置路由到 pinia routesList 中（已处理成多级嵌套路由）及缓存多级嵌套数组处理后的一维数组
 */
export async function initBackEndControlRoutes() {
	// 界面 loading 动画开始执行
	if (window.nextLoading === undefined) NextLoading.start();
	// 无 token 停止执行下一步
	if (!Session.getToken()) return false;
	// 触发初始化用户信息 pinia
	await useUserInfo().setUserInfos();
	// 获取路由菜单数据
	const res = await getBackEndControlRoutes();
	// 无登录权限时，添加判断
	// https://gitee.com/lyt-top/vue-next-admin/issues/I64HVO
	if ((res.data || []).length <= 0) return Promise.resolve(true);
	// 存储接口原始路由（未处理component），根据需求选择使用
	useRequestOldRoutes().setRequestOldRoutes(JSON.parse(JSON.stringify(res.data)));
	// 处理路由（component），替换 baseRoutes（/@/router/route）第一个顶级 children 的路由
	baseRoutes[0].children = [...dynamicRoutes, ...dataPlatformPlaceholderRoutes, ...(await backEndComponent(res.data))];
	// 添加动态路由
	await setAddRoute();
	// 设置路由到 pinia routesList 中（已处理成多级嵌套路由）及缓存多级嵌套数组处理后的一维数组
	await setFilterMenuAndCacheTagsViewRoutes();
}

/**
 * 设置路由到 pinia routesList 中（已处理成多级嵌套路由）及缓存多级嵌套数组处理后的一维数组
 * @description 用于左侧菜单、横向菜单的显示
 * @description 用于 tagsView、菜单搜索中：未过滤隐藏的(isHide)
 */
export async function setFilterMenuAndCacheTagsViewRoutes() {
	const storesRoutesList = useRoutesList(pinia);
	const navigationRoutes = buildDataPlatformNavigation(filterNavigationRoutes(baseRoutes[0].children as RouteRecordRaw[]));
	storesRoutesList.setRoutesList(navigationRoutes as any);
	setCacheTagsViewRoutes(navigationRoutes);
}

/**
 * 缓存多级嵌套数组处理后的一维数组
 * @description 用于 tagsView、菜单搜索中：未过滤隐藏的(isHide)
 */
export function setCacheTagsViewRoutes(routes: RouteRecordRaw[] = baseRoutes[0].children as RouteRecordRaw[]) {
	const storesTagsView = useTagsViewRoutes(pinia);
	const navigationBaseRoutes = [{ ...baseRoutes[0], children: routes }];
	storesTagsView.setTagsViewRoutes(formatTwoStageRoutes(formatFlatteningRoutes(navigationBaseRoutes))[0].children);
}

/**
 * 处理路由格式及添加捕获所有路由或 404 Not found 路由
 * @description 替换 baseRoutes（/@/router/route）第一个顶级 children 的路由
 * @returns 返回替换后的路由数组
 */
export function setFilterRouteEnd() {
	let filterRouteEnd: any = formatTwoStageRoutes(formatFlatteningRoutes(baseRoutes));
	// notFoundAndNoPower 防止 404、401 不在 layout 布局中，不设置的话，404、401 界面将全屏显示
	// 关联问题 No match found for location with path 'xxx'
	filterRouteEnd[0].children = [...filterRouteEnd[0].children, ...notFoundAndNoPower];
	return filterRouteEnd;
}

/**
 * 递归过滤 path 为空的路由（含嵌套 children），避免 addRoute 报错
 * @param routes 待过滤的路由数组
 * @returns 过滤后的路由数组
 */
function filterEmptyPathRoutes(routes: RouteRecordRaw[]): RouteRecordRaw[] {
	return routes
		.filter((route) => {
			if (!route.path) {
				console.error('[router] 跳过 path 为空的路由，请检查后端菜单配置:', route); // eslint-disable-line no-console
				return false;
			}
			return true;
		})
		.map((route) => {
			if (route.children?.length) route.children = filterEmptyPathRoutes(route.children);
			return route;
		});
}

/**
 * 添加动态路由
 * @method router.addRoute
 * @description 此处循环为 baseRoutes（/@/router/route）第一个顶级 children 的路由一维数组，非多级嵌套
 * @link 参考：https://next.router.vuejs.org/zh/api/#addroute
 */
export async function setAddRoute() {
	await filterEmptyPathRoutes(setFilterRouteEnd()).forEach((route: RouteRecordRaw) => {
		router.addRoute(route);
	});
}

/**
 * 请求后端路由菜单接口
 * @description isRequestRoutes 为 true，则开启后端控制路由
 * @returns 返回后端路由菜单数据
 */
export function getBackEndControlRoutes() {
	return menuApi.getAdminMenu();
}

/**
 * 重新请求后端路由菜单接口
 * @description 用于菜单管理界面刷新菜单（未进行测试）
 * @description 路径：/src/views/admin/menu/component/addMenu.vue
 */
export async function setBackEndControlRefreshRoutes() {
	await getBackEndControlRoutes();
}

/**
 * 后端路由 component 转换
 * @param routes 后端返回的路由表数组
 * @returns 返回处理成函数后的 component
 */
export function backEndComponent(routes: any) {
	if (!routes) return;
	return routes.map((item: any) => {
		if (item.path && item.path.startsWith('http')) {
			if (item.meta.isIframe) {
				item.component = () => import('/@/layout/routerView/iframes.vue');
			} else {
				item.component = () => import('/@/layout/routerView/link.vue');
			}
			item.path = '/iframes/' + window.btoa(item.path);
		} else if (item.componentPath) {
			// 支持动态路径  /a/1 ==> /a  ; /b/1 ==> /b
			item.component = dynamicImport(dynamicViewsModules, item.componentPath);
		} else {
			item.component = dynamicImport(dynamicViewsModules, item.path);
		}
		item.children && backEndComponent(item.children);
		if (String(item.id) === '9000' || item.path === '/gen') {
			item.redirect = getDataPlatformEntryPath;
		} else if (item.children?.length) {
			item.redirect = item.children[0].path;
		}
		// 设置 name (使用ID，避免 name 重复造成 404)
		item.name = item.id || item.name;
		return item;
	});
}

/**
 * 后端路由 component 转换函数
 * @param dynamicViewsModules 获取目录下的 .vue、.tsx 全部文件
 * @param component 当前要处理项 component
 * @returns 返回处理成函数后的 component
 */
export function dynamicImport(dynamicViewsModules: Record<string, Function>, component: string) {
	const keys = Object.keys(dynamicViewsModules);

	const matchKeys = keys.filter((key) => {
		const k = key.replace(/..\/views|../, '');
		return k.startsWith(`${component}.vue`);
	});
	if (matchKeys?.length === 1) {
		const matchKey = matchKeys[0];
		return dynamicViewsModules[matchKey];
	}
	if (matchKeys?.length > 1) {
		return false;
	}
}
