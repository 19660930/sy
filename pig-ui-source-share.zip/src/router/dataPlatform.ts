import type { RouteRecordRaw } from 'vue-router';
import { Session } from '/@/utils/storage';

export const DATA_PLATFORM_ENTRY_PATH = '/gen/welcome';
export const DATA_PLATFORM_LAST_ROUTE_KEY = 'data-platform-last-route';

export function getDataPlatformEntryPath(): string {
	const lastRoute = Session.get(DATA_PLATFORM_LAST_ROUTE_KEY);
	return typeof lastRoute === 'string' && lastRoute.startsWith('/gen/') ? lastRoute : DATA_PLATFORM_ENTRY_PATH;
}

type PlaceholderRoute = {
	path: string;
	name: string;
	title: string;
};

const placeholderRouteConfigs: PlaceholderRoute[] = [
	{ path: '/gen/warehouse/dim/model', name: 'dataPlatform.dimModel', title: '维度模型设计' },
	{ path: '/gen/warehouse/dim/table', name: 'dataPlatform.dimTable', title: '维度表管理' },
	{ path: '/gen/warehouse/dim/value', name: 'dataPlatform.dimValue', title: '维度值维护' },
	{ path: '/gen/warehouse/dim/strategy', name: 'dataPlatform.dimStrategy', title: '维度策略管理' },
	{ path: '/gen/warehouse/dwd/model', name: 'dataPlatform.dwdModel', title: '明细模型设计' },
	{ path: '/gen/warehouse/dwd/rule', name: 'dataPlatform.dwdRule', title: '明细规则配置' },
	{ path: '/gen/warehouse/dwd/operations', name: 'dataPlatform.dwdOperations', title: '明细数据运维' },
	{ path: '/gen/warehouse/dws/model', name: 'dataPlatform.dwsModel', title: '汇总模型设计' },
	{ path: '/gen/warehouse/dws/rule', name: 'dataPlatform.dwsRule', title: '聚合规则配置' },
	{ path: '/gen/warehouse/dws/operations', name: 'dataPlatform.dwsOperations', title: '汇总数据运维' },
	{ path: '/gen/warehouse/ads/domain', name: 'dataPlatform.adsDomain', title: '业务域管理' },
	{ path: '/gen/warehouse/ads/theme', name: 'dataPlatform.adsTheme', title: '应用主题模型' },
	{ path: '/gen/warehouse/ads/comparison', name: 'dataPlatform.adsComparison', title: '对比指标配置' },
	{ path: '/gen/warehouse/ads/api', name: 'dataPlatform.adsApi', title: '数据集API发布' },
	{ path: '/gen/warehouse/ads/schedule', name: 'dataPlatform.adsSchedule', title: 'ADS任务调度' },
	{ path: '/gen/indicator/basic', name: 'dataPlatform.basicIndicator', title: '基础指标' },
	{ path: '/gen/indicator/derived', name: 'dataPlatform.derivedIndicator', title: '衍生指标' },
	{ path: '/gen/indicator/composite', name: 'dataPlatform.compositeIndicator', title: '复合指标' },
	{ path: '/gen/indicator/comparison', name: 'dataPlatform.comparisonIndicator', title: '对比指标' },
	{ path: '/gen/indicator/category', name: 'dataPlatform.indicatorCategory', title: '指标分类' },
	{ path: '/gen/development/cycle/template', name: 'dataPlatform.cycleTemplate', title: '周期模板管理' },
	{ path: '/gen/development/dependency', name: 'dataPlatform.taskDependency', title: '任务依赖编排' },
	{ path: '/gen/development/partition', name: 'dataPlatform.partitionStrategy', title: '分区策略配置' },
	{ path: '/gen/development/monitor', name: 'dataPlatform.taskMonitor', title: '任务执行监控' },
	{ path: '/gen/development/alert/rule', name: 'dataPlatform.alertRule', title: '告警规则配置' },
	{ path: '/gen/development/alert/message', name: 'dataPlatform.alertMessage', title: '告警消息记录' },
	{ path: '/gen/metadata/business', name: 'dataPlatform.businessMetadata', title: '业务元数据' },
	{ path: '/gen/metadata/technical', name: 'dataPlatform.technicalMetadata', title: '技术元数据' },
	{ path: '/gen/metadata/collection/config', name: 'dataPlatform.collectionConfig', title: '采集名单配置' },
	{ path: '/gen/metadata/collection/task', name: 'dataPlatform.collectionTask', title: '采集任务' },
	{ path: '/gen/metadata/change/version', name: 'dataPlatform.metadataVersion', title: '版本管理' },
];

export const dataPlatformPlaceholderRoutes: RouteRecordRaw[] = placeholderRouteConfigs.map((item) => ({
	path: item.path,
	name: item.name,
	component:
		item.path === '/gen/warehouse/dim/model'
			? () => import('/@/views/gen/warehouse/dim/model/index.vue')
			: item.path === '/gen/warehouse/dwd/model'
			? () => import('/@/views/gen/warehouse/dwd/model/index.vue')
			: item.path === '/gen/warehouse/dwd/rule'
			? () => import('/@/views/gen/warehouse/dwd/rule/index.vue')
			: item.path === '/gen/warehouse/dwd/operations'
			? () => import('/@/views/gen/warehouse/dwd/operations/index.vue')
			: item.path === '/gen/warehouse/dim/strategy'
			? () => import('/@/views/gen/warehouse/dim/strategy/index.vue')
			: item.path === '/gen/warehouse/dim/table'
			? () => import('/@/views/gen/warehouse/dim/table/index.vue')
			: item.path === '/gen/warehouse/dim/value'
			? () => import('/@/views/gen/warehouse/dim/value/index.vue')
			: () => import('/@/views/gen/placeholder/index.vue'),
	meta: {
		title: item.title,
		isHide: true,
		isKeepAlive: false,
	},
}));

dataPlatformPlaceholderRoutes.push({
	path: '/gen/warehouse/dim/model/:id',
	name: 'dataPlatform.dimModelDetail',
	component: () => import('/@/views/gen/warehouse/dim/model/detail.vue'),
	meta: {
		title: '维度模型详情',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/warehouse/dwd/model/:id',
	name: 'dataPlatform.dwdModelDetail',
	component: () => import('/@/views/gen/warehouse/dwd/model/detail.vue'),
	meta: { title: '明细模型详情', isHide: true, isKeepAlive: false },
});

dataPlatformPlaceholderRoutes.push({
	path: DATA_PLATFORM_ENTRY_PATH,
	name: 'dataPlatform.welcome',
	component: () => import('/@/views/gen/welcome/index.vue'),
	meta: {
		title: '开发平台',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/development/engine-profile',
	name: 'dataPlatform.engineProfile',
	component: () => import('/@/views/gen/development/engineProfile/index.vue'),
	meta: {
		title: '调度引擎配置',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/development/layered-task',
	name: 'dataPlatform.layeredTask',
	component: () => import('/@/views/gen/development/layeredTask/index.vue'),
	meta: {
		title: '分层任务运维',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/metadata/map',
	name: 'dataPlatform.metadataMap',
	component: () => import('/@/views/gen/metadata/map/index.vue'),
	meta: {
		title: '数据地图',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/metadata/search',
	name: 'dataPlatform.metadataSearch',
	component: () => import('/@/views/gen/metadata/search/index.vue'),
	meta: {
		title: '元数据检索',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/warehouse/ods/datasource-assets',
	name: 'dataPlatform.datasourceAssets',
	component: () => import('/@/views/gen/warehouse/ods/datasourceAsset/index.vue'),
	meta: {
		title: '数据源资产管理',
		icon: '/menu-icons/datasource-asset.png',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/warehouse/ods/table-models',
	name: 'dataPlatform.odsTableModels',
	component: () => import('/@/views/gen/warehouse/ods/tableModel/index.vue'),
	meta: {
		title: '源表模型',
		icon: '/menu-icons/source-table-model.png',
		isHide: true,
		isKeepAlive: false,
	},
});

dataPlatformPlaceholderRoutes.push({
	path: '/gen/warehouse/ods/data-query',
	name: 'dataPlatform.odsDataQuery',
	component: () => import('/@/views/gen/warehouse/ods/dataQuery/index.vue'),
	meta: {
		title: '数据查看',
		icon: '/menu-icons/data-preview.png',
		isHide: true,
		isKeepAlive: false,
	},
});

function findRoute(routes: RouteRecordRaw[], matcher: (route: any) => boolean): RouteRecordRaw | undefined {
	for (const route of routes) {
		if (matcher(route)) return route;
		if (route.children?.length) {
			const matchedRoute = findRoute(route.children, matcher);
			if (matchedRoute) return matchedRoute;
		}
	}
}

export function isDataPlatformMenuPath(routes: RouteRecordRaw[], path: string): boolean {
	const platformRoute = findRoute(routes, (item) => String(item.id) === '9000' || item.path === '/gen');
	if (!platformRoute?.children?.length) return false;

	const matchedRoute = findRoute(platformRoute.children, (item) => item.path === path);
	return Boolean(matchedRoute && !matchedRoute.meta?.isHide && !matchedRoute.children?.length);
}

function createGroup(title: string, path: string, children: Array<RouteRecordRaw | undefined>, icon = ''): RouteRecordRaw {
	return {
		path,
		name: `dataPlatform.group.${path.replace(/\//g, '.')}`,
		meta: { title, icon, isKeepAlive: false },
		children: children.filter((item): item is RouteRecordRaw => Boolean(item)),
	};
}

function cloneExistingRoute(routes: RouteRecordRaw[], id: string, title?: string): RouteRecordRaw | undefined {
	const route = findRoute(routes, (item) => String(item.id) === id);
	if (!route) return undefined;
	return {
		...route,
		meta: { ...route.meta, ...(title ? { title } : {}) },
		children: undefined,
		redirect: undefined,
	};
}

function clonePlaceholderRoute(routes: RouteRecordRaw[], path: string): RouteRecordRaw | undefined {
	const route = findRoute(routes, (item) => item.path === path);
	if (!route) return undefined;
	return { ...route, meta: { ...route.meta, isHide: false } };
}

/**
 * 只重组前端“开发平台”导航树。实际路由和后端菜单数据保持不变。
 */
export function buildDataPlatformNavigation(routes: RouteRecordRaw[]): RouteRecordRaw[] {
	const platformRoute = findRoute(routes, (item) => String(item.id) === '9000' || item.path === '/gen');
	if (!platformRoute) return routes;
	const welcomeRoute = findRoute(routes, (item) => item.path === DATA_PLATFORM_ENTRY_PATH);

	const placeholder = (path: string) => clonePlaceholderRoute(routes, path);
	const existing = (id: string, title?: string) => cloneExistingRoute(routes, id, title);

	const warehouse = createGroup(
		'数仓建模',
		'/gen/warehouse',
		[
			createGroup('ODS贴源层', '/gen/warehouse/ods', [
				existing('9005'),
				placeholder('/gen/warehouse/ods/datasource-assets'),
				placeholder('/gen/warehouse/ods/table-models'),
				placeholder('/gen/warehouse/ods/data-query'),
			]),
			createGroup('DIM维度层', '/gen/warehouse/dim', [
				placeholder('/gen/warehouse/dim/model'),
				placeholder('/gen/warehouse/dim/table'),
				placeholder('/gen/warehouse/dim/value'),
				placeholder('/gen/warehouse/dim/strategy'),
			]),
			createGroup('DWD明细层', '/gen/warehouse/dwd', [
				placeholder('/gen/warehouse/dwd/model'),
				placeholder('/gen/warehouse/dwd/rule'),
				placeholder('/gen/warehouse/dwd/operations'),
			]),
			createGroup('DWS汇总层', '/gen/warehouse/dws', [
				placeholder('/gen/warehouse/dws/model'),
				placeholder('/gen/warehouse/dws/rule'),
				placeholder('/gen/warehouse/dws/operations'),
			]),
			createGroup('ADS应用层', '/gen/warehouse/ads', [
				placeholder('/gen/warehouse/ads/domain'),
				placeholder('/gen/warehouse/ads/theme'),
				placeholder('/gen/warehouse/ads/comparison'),
				placeholder('/gen/warehouse/ads/api'),
				placeholder('/gen/warehouse/ads/schedule'),
			]),
		],
		'iconfont icon-shuju'
	);

	const indicators = createGroup(
		'指标体系',
		'/gen/indicator',
		[
			createGroup('指标管理', '/gen/indicator/manage', [
				placeholder('/gen/indicator/basic'),
				placeholder('/gen/indicator/derived'),
				placeholder('/gen/indicator/composite'),
				placeholder('/gen/indicator/comparison'),
			]),
			placeholder('/gen/indicator/category'),
		],
		'iconfont icon-tubiao'
	);

	const development = createGroup(
		'数据开发',
		'/gen/development',
		[
			placeholder('/gen/development/engine-profile'),
			placeholder('/gen/development/layered-task'),
			createGroup('调度周期配置', '/gen/development/cycle', [placeholder('/gen/development/cycle/template')]),
			placeholder('/gen/development/dependency'),
			placeholder('/gen/development/partition'),
			placeholder('/gen/development/monitor'),
			createGroup('告警中心', '/gen/development/alert', [placeholder('/gen/development/alert/rule'), placeholder('/gen/development/alert/message')]),
		],
		'iconfont icon-DevOps'
	);

	const metadata = createGroup(
		'元数据中心',
		'/gen/metadata-center',
		[
			placeholder('/gen/metadata/map'),
			placeholder('/gen/metadata/search'),
			placeholder('/gen/metadata/business'),
			placeholder('/gen/metadata/technical'),
			createGroup('采集管理', '/gen/metadata/collection', [
				placeholder('/gen/metadata/collection/config'),
				placeholder('/gen/metadata/collection/task'),
			]),
			createGroup('元数据变更', '/gen/metadata/change', [placeholder('/gen/metadata/change/version')]),
			createGroup('代码生成管理', '/gen/metadata/code-generation', [
				existing('2300'),
				existing('9070', '数据表管理'),
				existing('9065'),
				existing('9051'),
				existing('9059'),
			]),
		],
		'iconfont icon-yuanshujuguanli'
	);

	platformRoute.children = [welcomeRoute, warehouse, indicators, development, metadata].filter((item): item is RouteRecordRaw => Boolean(item));
	platformRoute.redirect = getDataPlatformEntryPath;
	return routes.filter((item) => item.path !== DATA_PLATFORM_ENTRY_PATH);
}
