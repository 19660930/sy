<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<el-row shadow="hover" v-show="showSearch" class="ml10">
				<el-form :model="state.queryForm" ref="queryRef" :inline="true" @keyup.enter="getDataList">
					<el-form-item :label="$t('sysrole.roleName')" prop="roleName">
						<el-input :placeholder="$t('sysrole.inputRoleNameTip')" v-model="state.queryForm.roleName" />
					</el-form-item>
					<el-form-item>
						<el-button icon="search" type="primary" @click="getDataList">
							{{ $t('common.queryBtn') }}
						</el-button>
						<el-button icon="Refresh" @click="resetQuery">{{ $t('common.resetBtn') }}</el-button>
					</el-form-item>
				</el-form>
			</el-row>
			<el-row>
				<div class="mb8" style="width: 100%">
					<el-button icon="folder-add" type="primary" class="ml10" @click="roleDialogRef.openDialog()" v-auth="'sys_role_add'">
						{{ $t('common.addBtn') }}
					</el-button>
					<right-toolbar
						v-model:showSearch="showSearch"
						:export="'sys_role_export'"
						@exportExcel="exportExcel"
						class="ml10"
						style="float: right; margin-right: 20px"
						@queryTable="getDataList"
					></right-toolbar>
				</div>
			</el-row>
			<el-table
				:data="state.dataList"
				v-loading="state.loading"
				style="width: 100%"
				row-key="roleId"
				@selection-change="handleSelectionChange"
				border
				:cell-style="tableStyle.cellStyle"
				:header-cell-style="tableStyle.headerCellStyle"
			>
				<el-table-column type="selection" :selectable="handleSelectable" width="50" align="center" />
				<el-table-column type="index" :label="$t('sysrole.index')" width="80" />
				<el-table-column prop="roleName" :label="$t('sysrole.roleName')" show-overflow-tooltip></el-table-column>
				<el-table-column prop="roleCode" :label="$t('sysrole.roleCode')" show-overflow-tooltip></el-table-column>
				<el-table-column prop="roleDesc" :label="$t('sysrole.roleDesc')" show-overflow-tooltip></el-table-column>
				<el-table-column prop="createTime" :label="$t('sysrole.createTime')" show-overflow-tooltip></el-table-column>
				<el-table-column :label="$t('common.action')" width="320">
					<template #default="scope">
						<el-button text type="primary" icon="edit-pen" v-auth="'sys_role_edit'" @click="roleDialogRef.openDialog(scope.row.roleId)">{{
							$t('common.editBtn')
						}}</el-button>

						<el-button text type="primary" icon="turn-off" v-auth="'sys_role_perm'" @click="permessionRef.openDialog(scope.row)">{{
							$t('sysrole.permissionTip')
						}}</el-button>

						<el-button text type="primary" icon="setting" v-auth="'sys_role_edit'" @click="roleWidgetRef.open(scope.row.roleId, scope.row.roleName)">
							{{ $t('sysrole.homePage') }}
						</el-button>
					</template>
				</el-table-column>
			</el-table>
			<pagination @size-change="sizeChangeHandle" @current-change="currentChangeHandle" v-bind="state.pagination" />
		</div>

		<!-- 角色编辑、新增  -->
		<role-dialog ref="roleDialogRef" @refresh="getDataList()" />
		<!-- 授权 -->
		<permession ref="permessionRef" />
		<!-- 首页配置 -->
		<RoleWidgetConfig ref="roleWidgetRef" />
	</div>
</template>

<script setup lang="ts" name="systemRole">
import { BasicTableProps, useTable } from '/@/hooks/table';
import { pageList } from '/@/api/admin/role';

// 引入组件
const RoleDialog = defineAsyncComponent(() => import('./form.vue'));
const Permession = defineAsyncComponent(() => import('./permession.vue'));
import RoleWidgetConfig from './widget.vue';

// 定义变量内容
const roleDialogRef = ref();
const permessionRef = ref();
const roleWidgetRef = ref();
const queryRef = ref();
const showSearch = ref(true);

/**
 * 多选相关变量
 */
const selectObjs = ref([]) as any;

/**
 * 表格状态配置
 * @property {Object} queryForm - 查询表单
 * @property {string} queryForm.roleName - 角色名称
 * @property {Function} pageList - 分页查询API
 * @property {string[]} descs - 降序排序字段
 */
const state: BasicTableProps = reactive<BasicTableProps>({
	queryForm: {
		roleName: '',
	},
	pageList: pageList,
	descs: ['create_time'],
});

//  table hook
const { getDataList, currentChangeHandle, sizeChangeHandle, downBlobFile, tableStyle } = useTable(state);

/**
 * 重置搜索条件
 * @description 清空表单字段并重新加载数据
 */
const resetQuery = () => {
	queryRef.value.resetFields();
	getDataList();
};

/**
 * 导出角色数据为 Excel 文件
 */
const exportExcel = () => {
	downBlobFile('/admin/role/export', { ...state.queryForm, ids: selectObjs.value }, 'role.xlsx');
};

/**
 * 判断表格行是否可选择
 * @param {any} row - 表格行数据
 * @returns {boolean} 系统管理员角色（roleId='1'）不可选择
 */
const handleSelectable = (row: any) => {
	return row.roleId !== '1';
};

/**
 * 多选事件处理
 * @param {Array} objs - 选中的角色对象数组
 */
const handleSelectionChange = (objs: { roleId: string }[]) => {
	selectObjs.value = objs.map(({ roleId }) => roleId);
};
</script>
