<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<el-tabs v-model="activeName">
				<el-tab-pane lazy label="短信" name="sms">
					<template #label>
						<div class="ml-4 flex items-center gap-2">
							<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-4">
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									d="M10.5 1.5H8.25A2.25 2.25 0 0 0 6 3.75v16.5a2.25 2.25 0 0 0 2.25 2.25h7.5A2.25 2.25 0 0 0 18 20.25V3.75a2.25 2.25 0 0 0-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3"
								/>
							</svg>
							短信
						</div>
					</template>
					<sms-config />
				</el-tab-pane>
				<el-tab-pane lazy label="邮件" name="third">
					<template #label>
						<div class="flex items-center gap-2">
							<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-4">
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									d="M16.5 12a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0Zm0 0c0 1.657 1.007 3 2.25 3S21 13.657 21 12a9 9 0 1 0-2.636 6.364M16.5 12V8.25"
								/>
							</svg>
							邮件
						</div>
					</template>
					<email-config />
				</el-tab-pane>
			</el-tabs>
		</div>
	</div>
</template>

<script setup lang="ts" name="systemSysMessage">
const SmsConfig = defineAsyncComponent(() => import('./sms/index.vue'));
const EmailConfig = defineAsyncComponent(() => import('./email/index.vue'));

const activeName = ref('sms');
</script>
