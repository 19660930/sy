<template>
	<article class="metadata-object-card">
		<div class="object-icon" :class="categoryClass">{{ objectTypeShort }}</div>
		<div class="object-content">
			<div class="object-title-row">
				<button type="button" class="object-title" @click="emit('openDetail', record)">{{ displayName }}</button>
				<el-tag size="small" effect="plain">{{ record.objectType || '未知类型' }}</el-tag>
				<el-tag size="small" :type="statusTagType">{{ statusText }}</el-tag>
			</div>
			<div class="object-code">{{ record.objectCode || '--' }}</div>
			<p class="object-description">{{ record.matchDescription || record.description || '暂无对象说明' }}</p>
			<div v-if="record.matchedFields?.length" class="matched-fields">
				<span>命中字段</span>
				<el-tag v-for="field in record.matchedFields.slice(0, 4)" :key="field" size="small" type="warning" effect="plain">{{ field }}</el-tag>
			</div>
			<div class="object-meta">
				<span>{{ record.warehouseLayer || '未分层' }}</span>
				<span>{{ record.businessSystemName || '未归属业务系统' }}</span>
				<span>{{ record.businessDomainName || '未归属业务域' }}</span>
				<span>{{ sourceText }}</span>
				<span>采集时间 {{ record.lastCollectionTime || '--' }}</span>
			</div>
		</div>
		<div class="object-actions">
			<el-button text type="primary" @click="emit('openDetail', record)">查看详情</el-button>
			<el-button text type="primary" @click="emit('openFields', record)">查看字段</el-button>
			<el-button text type="primary" @click="emit('openMap', record)">查看血缘</el-button>
		</div>
	</article>
</template>

<script setup lang="ts" name="MetadataObjectCard">
import type { MetadataObjectSummary } from '/@/types/dataPlatform/metadata';

const props = defineProps<{ record: MetadataObjectSummary }>();
const emit = defineEmits<{
	openDetail: [record: MetadataObjectSummary];
	openFields: [record: MetadataObjectSummary];
	openMap: [record: MetadataObjectSummary];
}>();

const displayName = computed(() => props.record.chineseName || props.record.objectName || props.record.objectCode || '--');
const objectTypeShort = computed(() => {
	const type = String(props.record.objectType || '').toUpperCase();
	if (type.includes('FIELD') || type.includes('COLUMN')) return '字';
	if (type.includes('METRIC') || type.includes('INDICATOR')) return '指';
	if (type.includes('DIMENSION')) return '维';
	if (type.includes('API')) return '接';
	if (type.includes('THEME')) return '主';
	if (type.includes('BUSINESS')) return '业';
	return '表';
});
const categoryClass = computed(() => `type-${objectTypeShort.value}`);
const statusText = computed(() => {
	const status = String(props.record.status || '').toUpperCase();
	return (
		{ NORMAL: '正常', ENABLED: '正常', ACTIVE: '正常', PENDING_UPDATE: '待更新', FAILED: '采集失败', DISABLED: '已停用' }[status] ||
		props.record.status ||
		'正常'
	);
});
const statusTagType = computed(() => {
	const status = String(props.record.status || '').toUpperCase();
	if (['NORMAL', 'ENABLED', 'ACTIVE'].includes(status)) return 'success';
	if (status === 'FAILED') return 'danger';
	if (status === 'PENDING_UPDATE') return 'warning';
	return 'info';
});
const sourceText = computed(() => [props.record.databaseName, props.record.schemaName].filter(Boolean).join(' / ') || '来源未登记');
</script>

<style scoped>
.metadata-object-card {
	display: flex;
	align-items: flex-start;
	gap: 16px;
	padding: 20px;
	border: 1px solid var(--el-border-color-light);
	border-radius: 8px;
	background: var(--el-bg-color);
	transition: border-color 0.2s, box-shadow 0.2s;
}

.metadata-object-card:hover {
	border-color: var(--el-color-primary-light-5);
	box-shadow: 0 6px 20px rgb(31 56 88 / 8%);
}

.object-icon {
	display: flex;
	width: 52px;
	height: 52px;
	flex: none;
	align-items: center;
	justify-content: center;
	border-radius: 12px;
	background: var(--el-color-primary-light-9);
	color: var(--el-color-primary);
	font-size: 21px;
	font-weight: 600;
}

.type-业,
.type-主 {
	background: var(--el-color-success-light-9);
	color: var(--el-color-success);
}

.type-指,
.type-维 {
	background: var(--el-color-warning-light-9);
	color: var(--el-color-warning);
}

.type-接 {
	background: var(--el-color-danger-light-9);
	color: var(--el-color-danger);
}

.object-content {
	min-width: 0;
	flex: 1;
}

.object-title-row,
.matched-fields,
.object-meta {
	display: flex;
	align-items: center;
	gap: 8px;
}

.object-title {
	max-width: 520px;
	overflow: hidden;
	border: 0;
	background: transparent;
	color: var(--el-color-primary);
	font-size: 16px;
	font-weight: 600;
	text-overflow: ellipsis;
	white-space: nowrap;
	cursor: pointer;
}

.object-code {
	margin-top: 5px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.object-description {
	margin: 10px 0;
	color: var(--el-text-color-regular);
	line-height: 22px;
}

.matched-fields {
	margin-bottom: 10px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.object-meta {
	flex-wrap: wrap;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.object-meta span + span::before {
	margin-right: 8px;
	color: var(--el-border-color);
	content: '•';
}

.object-actions {
	display: flex;
	width: 98px;
	flex: none;
	flex-direction: column;
	align-items: flex-start;
}

@media (max-width: 900px) {
	.metadata-object-card {
		flex-wrap: wrap;
	}

	.object-actions {
		width: 100%;
		flex-direction: row;
		padding-left: 68px;
	}
}
</style>
