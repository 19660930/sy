<template>
	<el-drawer v-model="visible" title="元数据详情" size="760px" :close-on-click-modal="false">
		<div v-loading="loading" class="metadata-detail">
			<template v-if="detail">
				<div class="detail-heading">
					<div>
						<h2>{{ detail.chineseName || detail.objectName }}</h2>
						<p>{{ detail.objectCode }}</p>
					</div>
					<div class="detail-tags">
						<el-tag effect="plain">{{ detail.objectType || '未知类型' }}</el-tag>
						<el-tag v-if="detail.warehouseLayer" type="primary" effect="plain">{{ detail.warehouseLayer }}</el-tag>
					</div>
				</div>

				<el-tabs v-model="activeTab" @tab-change="handleTabChange">
					<el-tab-pane label="基本信息" name="basic">
						<el-descriptions :column="2" border>
							<el-descriptions-item label="对象名称">{{ detail.objectName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="中文名称">{{ detail.chineseName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="对象类型">{{ detail.objectType || '--' }}</el-descriptions-item>
							<el-descriptions-item label="数仓层级">{{ detail.warehouseLayer || '--' }}</el-descriptions-item>
							<el-descriptions-item label="业务系统">{{ detail.businessSystemName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="业务域">{{ detail.businessDomainName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="数据源 ID">{{ detail.technical?.datasourceId || '--' }}</el-descriptions-item>
							<el-descriptions-item label="Catalog / Schema">{{ databasePath }}</el-descriptions-item>
							<el-descriptions-item label="负责人">{{ detail.ownerName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="物理表名">{{ detail.technical?.tableName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="数据行数">{{ detail.technical?.rowCount ?? '--' }}</el-descriptions-item>
							<el-descriptions-item label="元数据版本">{{ detail.technical?.versionNo ?? '--' }}</el-descriptions-item>
							<el-descriptions-item label="最近采集时间">{{ detail.technical?.lastCollectedAt || '--' }}</el-descriptions-item>
							<el-descriptions-item label="更新时间">{{ detail.updateTime || '--' }}</el-descriptions-item>
							<el-descriptions-item label="对象说明" :span="2">{{ detail.description || '--' }}</el-descriptions-item>
						</el-descriptions>
					</el-tab-pane>
					<el-tab-pane label="字段信息" name="columns">
						<el-table v-loading="columnLoading" :data="columns" border max-height="520" empty-text="暂无字段元数据">
							<el-table-column type="index" label="#" width="55" />
							<el-table-column prop="columnName" label="字段名" min-width="150" show-overflow-tooltip />
							<el-table-column prop="typeName" label="字段类型" width="140" show-overflow-tooltip />
							<el-table-column label="主键" width="75">
								<template #default="{ row }">{{ row.primaryKey ? '是' : '否' }}</template>
							</el-table-column>
							<el-table-column label="允许为空" width="95">
								<template #default="{ row }">{{ row.nullable ? '是' : '否' }}</template>
							</el-table-column>
							<el-table-column prop="columnComment" label="字段说明" min-width="180" show-overflow-tooltip />
						</el-table>
					</el-tab-pane>
				</el-tabs>
			</template>
		</div>

		<template #footer>
			<el-button @click="visible = false">关闭</el-button>
			<el-button type="primary" @click="openMap">查看数据地图</el-button>
		</template>
	</el-drawer>
</template>

<script setup lang="ts" name="MetadataDetailDrawer">
import { fetchMetadataObjectColumns, getMetadataObject } from '/@/api/dataPlatform/metadata';
import { useMessage } from '/@/hooks/message';
import type { MetadataColumn, MetadataObjectDetail, MetadataObjectSummary } from '/@/types/dataPlatform/metadata';

const emit = defineEmits<{ openMap: [record: MetadataObjectDetail] }>();
const visible = ref(false);
const loading = ref(false);
const columnLoading = ref(false);
const activeTab = ref('basic');
const detail = ref<MetadataObjectDetail>();
const columns = ref<MetadataColumn[]>([]);
const columnsLoaded = ref(false);

const databasePath = computed(() => [detail.value?.technical?.catalogName, detail.value?.technical?.schemaName].filter(Boolean).join(' / ') || '--');

const normalizeObject = (item: MetadataObjectDetail | MetadataObjectSummary): MetadataObjectDetail => ({
	...item,
	id: String(item.id),
	objectCode: item.objectCode || '--',
	objectName: item.objectName || item.chineseName || item.objectCode || '--',
	objectType: item.objectType || '--',
});

const loadColumns = async () => {
	if (!detail.value?.id || columnsLoaded.value) return;
	try {
		columnLoading.value = true;
		const res = await fetchMetadataObjectColumns(detail.value.id);
		columns.value = Array.isArray(res.data) ? res.data : [];
		columnsLoaded.value = true;
	} catch (error: any) {
		columns.value = [];
		useMessage().error(error?.msg || '加载字段元数据失败');
	} finally {
		columnLoading.value = false;
	}
};

const handleTabChange = (name: string | number) => {
	if (name === 'columns') loadColumns();
};

const openDrawer = async (record: MetadataObjectSummary, initialTab = 'basic') => {
	visible.value = true;
	activeTab.value = initialTab;
	detail.value = normalizeObject(record);
	columns.value = [];
	columnsLoaded.value = false;
	try {
		loading.value = true;
		const res = await getMetadataObject(String(record.id));
		detail.value = normalizeObject(res.data as MetadataObjectDetail);
		if (initialTab === 'columns') loadColumns();
	} catch (error: any) {
		useMessage().error(error?.msg || '加载元数据详情失败');
	} finally {
		loading.value = false;
	}
};

const openMap = () => {
	if (detail.value) emit('openMap', detail.value);
};

defineExpose({ openDrawer });
</script>

<style scoped>
.metadata-detail {
	min-height: 260px;
}

.detail-heading {
	display: flex;
	align-items: flex-start;
	justify-content: space-between;
	padding: 0 2px 16px;
}

.detail-heading h2 {
	margin: 0;
	font-size: 19px;
}

.detail-heading p {
	margin: 7px 0 0;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.detail-tags {
	display: flex;
	gap: 8px;
}
</style>
