<template>
	<div class="metadata-map-page layout-padding">
		<el-card shadow="never" class="map-card">
			<div class="page-heading">
				<div>
					<div class="page-title">数据地图</div>
					<div class="page-description">展示数据从源系统进入数仓各层并流向应用资产的完整链路。</div>
				</div>
				<el-button type="primary" plain icon="Search" @click="goToSearch">元数据检索</el-button>
			</div>

			<nav class="view-tabs" aria-label="地图视图">
				<button
					v-for="item in viewOptions"
					:key="item.value"
					type="button"
					:class="{ active: query.view === item.value }"
					@click="handleViewChange(item.value)"
				>
					{{ item.label }}
				</button>
			</nav>

			<div class="filter-panel">
				<el-form :model="query" inline @submit.prevent>
					<el-form-item label="业务系统">
						<el-select v-model="query.businessSystemId" clearable filterable placeholder="全部" style="width: 150px" @change="handleSystemChange">
							<el-option v-for="item in options.businessSystems" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="业务域">
						<el-select v-model="query.businessDomainId" clearable filterable placeholder="全部" style="width: 150px">
							<el-option v-for="item in availableDomains" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="数仓层级">
						<el-select v-model="query.warehouseLayer" clearable placeholder="全部" style="width: 140px">
							<el-option v-for="item in options.warehouseLayers" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="对象类型">
						<el-select v-model="query.objectType" clearable placeholder="全部" style="width: 150px">
							<el-option v-for="item in options.objectTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="对象名称">
						<el-input v-model="query.keyword" clearable placeholder="请输入对象名称" style="width: 190px" @keyup.enter="loadGraph" />
					</el-form-item>
					<template v-if="query.view === 'LINEAGE'">
						<el-form-item label="血缘方向">
							<el-select v-model="query.direction" style="width: 120px">
								<el-option label="上下游" value="BOTH" />
								<el-option label="仅上游" value="UPSTREAM" />
								<el-option label="仅下游" value="DOWNSTREAM" />
							</el-select>
						</el-form-item>
						<el-form-item label="展开层级">
							<el-input-number v-model="query.depth" :min="1" :max="3" controls-position="right" style="width: 100px" />
						</el-form-item>
					</template>
					<el-form-item>
						<el-button type="primary" icon="Search" @click="loadGraph">查询</el-button>
						<el-button icon="Refresh" @click="resetFilters">重置</el-button>
					</el-form-item>
				</el-form>
			</div>

			<div v-if="requiresRoot" class="root-object-bar">
				<div>
					<span>中心对象</span>
					<strong v-if="rootNode">{{ rootNode.chineseName || rootNode.objectName }}</strong>
					<code v-if="rootNode">{{ rootNode.objectCode }}</code>
					<em v-else>尚未选择</em>
				</div>
				<el-button size="small" type="primary" plain icon="Search" @click="goToSearch">选择中心对象</el-button>
			</div>

			<div class="graph-summary">
				<div>
					<strong>{{ displayGraph.nodes.length }}</strong> 个可见节点
					<span class="summary-divider">/</span>
					<strong>{{ displayGraph.edges.length }}</strong> 条可见关系
					<span v-if="isOverviewView" class="graph-total">（原始 {{ graph.nodes.length }} 个节点 / {{ graph.edges.length }} 条关系）</span>
					<el-tag v-if="graph.truncated" type="warning" effect="plain" class="truncate-tag">仅展示部分关系</el-tag>
				</div>
				<div class="graph-actions">
					<el-button icon="Aim" @click="resetViewport">适应画布</el-button>
					<el-button icon="Refresh" :loading="loading" @click="loadGraph">刷新布局</el-button>
					<el-button icon="FullScreen" @click="toggleFullscreen">全屏</el-button>
				</div>
			</div>
			<div v-if="isOverviewView && displayGraph.nodes.length" class="scope-toolbar">
				<span>{{ currentScopeText }}</span>
				<div>
					<el-button v-if="focusedBusinessGroupId" size="small" @click="backToBusinessOverview">返回业务概览</el-button>
					<el-button v-if="expandedLayer" size="small" @click="collapseLayer">收起{{ layerLabelMap[expandedLayer] || expandedLayer }}</el-button>
					<template v-if="query.view === 'BUSINESS' && !focusedBusinessGroupId && businessGroupPageCount > 1">
						<el-button size="small" :disabled="businessGroupPage === 1" @click="changeBusinessGroupPage(-1)">上一组分组</el-button>
						<span>分组 {{ businessGroupPage }} / {{ businessGroupPageCount }}</span>
						<el-button size="small" :disabled="businessGroupPage === businessGroupPageCount" @click="changeBusinessGroupPage(1)"
							>下一组分组</el-button
						>
					</template>
					<template v-if="expandedLayer && expandedPageCount > 1">
						<el-button size="small" :disabled="expandedPage === 1" @click="changeExpandedPage(-1)">上一组</el-button>
						<span>第 {{ expandedPage }} / {{ expandedPageCount }} 组</span>
						<el-button size="small" :disabled="expandedPage === expandedPageCount" @click="changeExpandedPage(1)">下一组</el-button>
					</template>
				</div>
			</div>

			<div
				ref="graphPanelRef"
				v-loading="loading"
				class="graph-panel"
				:class="{ 'is-interactive': graphInteractionActive }"
				tabindex="0"
				@click="activateGraphInteraction"
				@blur="deactivateGraphInteraction"
				@keydown.esc="deactivateGraphInteraction"
				@wheel.capture="handleCanvasWheelCapture"
			>
				<div v-if="displayGraph.nodes.length" class="canvas-heading">
					<strong>{{ currentViewTitle }}</strong>
					<span>{{ isOverviewView ? '点击分组或层级查看资产，点击资产查看直接关系。' : currentViewDescription }}</span>
				</div>
				<div v-if="displayGraph.nodes.length" class="layer-legend">
					<span v-for="item in visibleLegend" :key="item.value"><i :style="{ backgroundColor: item.color }"></i>{{ item.label }}</span>
				</div>
				<v-chart
					v-if="displayGraph.nodes.length"
					:key="chartKey"
					class="graph-chart"
					:option="chartOption"
					autoresize
					@graphroam="handleGraphRoam"
					@click="handleNodeClick"
					@dblclick="handleNodeDoubleClick"
				/>
				<div v-else-if="!loading && requiresRoot && !query.rootObjectId" class="root-empty">
					<el-icon><Share /></el-icon>
					<h3>请先选择一个中心对象</h3>
					<p>{{ query.view === 'MODEL' ? '模型链路用于查看该对象直接关联的一跳上下游。' : '上下游关系用于追踪该对象指定深度内的完整血缘。' }}</p>
					<el-button type="primary" @click="goToSearch">前往元数据检索选择</el-button>
				</div>
				<el-empty v-else-if="!loading" description="暂无可展示的元数据关系，请调整筛选条件或等待元数据采集完成" :image-size="110" />

				<div v-if="selectedNode" class="selected-node-card">
					<button type="button" aria-label="关闭" @click="selectedNode = undefined">×</button>
					<el-tag size="small" effect="plain">{{ layerText(selectedNode) }}</el-tag>
					<h3>{{ selectedNode.chineseName || selectedNode.objectName }}</h3>
					<p>{{ selectedNode.objectCode }}</p>
					<div><span>对象类型</span>{{ objectTypeText(selectedNode.objectType) }}</div>
					<div><span>业务系统</span>{{ selectedNode.businessSystemName || '--' }}</div>
					<div><span>业务域</span>{{ selectedNode.businessDomainName || '--' }}</div>
					<div class="selected-actions">
						<el-button size="small" type="primary" @click="openDetail(selectedNode)">查看详情</el-button>
						<el-button size="small" @click="focusModel(selectedNode)">模型链路</el-button>
						<el-button size="small" @click="focusLineage(selectedNode)">上下游</el-button>
					</div>
				</div>
				<div v-if="displayGraph.nodes.length" class="zoom-activation-tip" :class="{ active: graphInteractionActive }">
					{{ graphInteractionActive ? '画布已激活：滚轮缩放，Esc 退出' : '点击画布后使用滚轮缩放' }}
				</div>
			</div>
			<div class="interaction-tip">点击画布激活缩放 · 拖动画布 · 单击节点查看摘要 · 双击节点追踪上下游</div>
		</el-card>

		<MetadataDetailDrawer ref="detailDrawerRef" @open-map="focusLineage" />
	</div>
</template>

<script setup lang="ts" name="DataPlatformMetadataMap">
import { GraphChart } from 'echarts/charts';
import { TooltipComponent } from 'echarts/components';
import { use } from 'echarts/core';
import { CanvasRenderer } from 'echarts/renderers';
import VChart from 'vue-echarts';
import { fetchMetadataGraph, fetchMetadataOptions } from '/@/api/dataPlatform/metadata';
import { useMessage } from '/@/hooks/message';
import type {
	MetadataGraphDirection,
	MetadataGraphEdge,
	MetadataGraphNode,
	MetadataGraphQuery,
	MetadataGraphResult,
	MetadataMapView,
	MetadataObjectSummary,
	MetadataOptions,
} from '/@/types/dataPlatform/metadata';
import MetadataDetailDrawer from '../components/MetadataDetailDrawer.vue';

use([GraphChart, TooltipComponent, CanvasRenderer]);

interface GraphEvent {
	dataType?: string;
	data?: { id?: string };
}

interface GraphRoamEvent {
	zoom?: number;
}

interface PositionedNode extends MetadataGraphNode {
	x: number;
	y: number;
}

interface DisplayNode extends MetadataGraphNode {
	viewKind?: 'businessGroup' | 'layerSummary';
	summaryLayer?: string;
	summaryCount?: number;
}

interface DisplayEdge extends MetadataGraphEdge {
	relationCount?: number;
}

interface DisplayGraph {
	nodes: DisplayNode[];
	edges: DisplayEdge[];
}

const route = useRoute();
const router = useRouter();
const graphPanelRef = ref<HTMLElement>();
const detailDrawerRef = ref<InstanceType<typeof MetadataDetailDrawer>>();
const loading = ref(false);
const chartKey = ref(0);
const defaultGraphZoom = 1;
const graphZoom = ref(defaultGraphZoom);
const graphInteractionActive = ref(false);
const selectedNode = ref<MetadataGraphNode>();
const graph = reactive<MetadataGraphResult>({ nodes: [], edges: [] });
const focusedBusinessGroupId = ref('');
const businessGroupPage = ref(1);
const expandedLayer = ref('');
const expandedPage = ref(1);
const expandedPageSize = 6;

const viewOptions = [
	{ value: 'GLOBAL' as const, label: '全局地图', title: '全局数据流向', description: '按数仓层级展示已建立血缘关系的数据资产。' },
	{ value: 'BUSINESS' as const, label: '业务链路', title: '业务系统数据链路', description: '从业务系统分组查看所属数据资产及其数据流向。' },
	{ value: 'MODEL' as const, label: '模型链路', title: '模型直接关联链路', description: '展示中心对象的直接上游、中心模型和直接下游。' },
	{ value: 'LINEAGE' as const, label: '上下游关系', title: '上下游血缘关系', description: '按指定方向和深度追踪中心对象的完整影响范围。' },
];

const layerLegend = [
	{ value: 'GROUP', label: '业务分组', color: '#334155' },
	{ value: 'SOURCE', label: '源系统', color: '#64748b' },
	{ value: 'ODS', label: 'ODS', color: '#3b82f6' },
	{ value: 'DIM', label: 'DIM', color: '#14b8a6' },
	{ value: 'DWD', label: 'DWD', color: '#8b5cf6' },
	{ value: 'DWS', label: 'DWS', color: '#f59e0b' },
	{ value: 'ADS', label: 'ADS', color: '#ec4899' },
	{ value: 'OTHER', label: '其他', color: '#94a3b8' },
];
const layerOrder = layerLegend.map((item) => item.value);
const layerColorMap = Object.fromEntries(layerLegend.map((item) => [item.value, item.color]));
const layerLabelMap = Object.fromEntries(layerLegend.map((item) => [item.value, item.label]));

const defaultOptions = (): MetadataOptions => ({
	businessSystems: [],
	businessDomains: [],
	warehouseLayers: layerLegend.filter((item) => !['GROUP', 'OTHER'].includes(item.value)).map(({ value, label }) => ({ value, label })),
	objectTypes: [],
	statuses: [],
});
const options = reactive<MetadataOptions>(defaultOptions());
const query = reactive<MetadataGraphQuery>({
	view: 'GLOBAL',
	rootObjectId: undefined,
	businessSystemId: undefined,
	businessDomainId: undefined,
	warehouseLayer: undefined,
	objectType: undefined,
	keyword: undefined,
	direction: 'BOTH',
	depth: 2,
});

const requiresRoot = computed(() => query.view === 'MODEL' || query.view === 'LINEAGE');
const isOverviewView = computed(() => query.view === 'GLOBAL' || query.view === 'BUSINESS');
const currentView = computed(() => viewOptions.find((item) => item.value === query.view) || viewOptions[0]);
const currentViewTitle = computed(() => currentView.value.title);
const currentViewDescription = computed(() => currentView.value.description);
const rootNode = computed(() => graph.nodes.find((node) => node.id === query.rootObjectId));
const availableDomains = computed(() => {
	if (!query.businessSystemId) return options.businessDomains || [];
	return (options.businessDomains || []).filter((item) => !item.parentValue || String(item.parentValue) === String(query.businessSystemId));
});

const normalizeNode = (item: Record<string, unknown>): MetadataGraphNode => ({
	...(item as unknown as MetadataGraphNode),
	id: String(item.id ?? item.objectId ?? ''),
	objectCode: String(item.objectCode ?? item.code ?? item.tableName ?? '--'),
	objectName: String(item.objectName ?? item.name ?? item.chineseName ?? item.objectCode ?? item.tableName ?? '--'),
	objectType: String(item.objectType ?? item.type ?? 'TABLE'),
	warehouseLayer: item.warehouseLayer ? String(item.warehouseLayer).toUpperCase() : undefined,
});

const normalizeEdge = (item: Record<string, unknown>): MetadataGraphEdge => ({
	id: item.id ? String(item.id) : undefined,
	sourceId: String(item.sourceId ?? item.source ?? item.fromObjectId ?? ''),
	targetId: String(item.targetId ?? item.target ?? item.toObjectId ?? ''),
	relationType: item.relationType ? String(item.relationType) : undefined,
	description: item.description ? String(item.description) : undefined,
});

const categoryForNode = (node: MetadataGraphNode) => {
	if (node.objectType === 'GROUP') return 'GROUP';
	const layer = (node.warehouseLayer || '').toUpperCase();
	return layerOrder.includes(layer) ? layer : 'OTHER';
};

const meaningfulText = (value: unknown) => {
	const text = String(value ?? '').trim();
	return text && text !== '--' && text !== '-' && text !== 'null' ? text : '';
};

const nodeLabel = (node: MetadataGraphNode) => {
	if (node.objectType === 'GROUP') {
		const option = (options.businessSystems || []).find((item) => String(item.value) === String(node.businessSystemId || node.id));
		const memberIds = new Set(
			graph.edges.filter((edge) => edge.relationType === 'BELONGS_TO' && edge.sourceId === node.id).map((edge) => edge.targetId)
		);
		const memberNames = [
			...new Set(
				graph.nodes
					.filter((item) => memberIds.has(item.id))
					.map((item) => meaningfulText(item.businessSystemName))
					.filter(Boolean)
			),
		];
		return (
			meaningfulText(node.chineseName) ||
			meaningfulText(node.objectName) ||
			meaningfulText(node.businessSystemName) ||
			meaningfulText(option?.label) ||
			(memberNames.length === 1 ? memberNames[0] : '') ||
			meaningfulText(node.objectCode) ||
			`业务分组 ${node.id}`
		);
	}
	return meaningfulText(node.objectCode) || meaningfulText(node.objectName) || `对象 ${node.id}`;
};

const scopedGraph = computed(() => {
	const dataFlowEdges = graph.edges.filter((edge) => edge.relationType === 'DATA_FLOW');
	const dataFlowNodeIds = new Set(dataFlowEdges.flatMap((edge) => [edge.sourceId, edge.targetId]));
	const assetNodes = graph.nodes.filter((node) => dataFlowNodeIds.has(node.id) && node.objectType !== 'GROUP');
	if (query.view !== 'BUSINESS') return { nodes: assetNodes, edges: dataFlowEdges };

	const businessEdges = graph.edges.filter((edge) => edge.relationType === 'BELONGS_TO' && dataFlowNodeIds.has(edge.targetId));
	const businessGroupIds = new Set(businessEdges.map((edge) => edge.sourceId));
	const groupNodes = graph.nodes.filter((node) => businessGroupIds.has(node.id));
	if (!focusedBusinessGroupId.value) return { nodes: [...groupNodes, ...assetNodes], edges: [...businessEdges, ...dataFlowEdges] };

	const directEdges = businessEdges.filter((edge) => edge.sourceId === focusedBusinessGroupId.value);
	const relatedIds = new Set(directEdges.map((edge) => edge.targetId));
	for (let index = 0; index < assetNodes.length; index += 1) {
		let changed = false;
		dataFlowEdges.forEach((edge) => {
			if (relatedIds.has(edge.sourceId) && !relatedIds.has(edge.targetId)) {
				relatedIds.add(edge.targetId);
				changed = true;
			}
		});
		if (!changed) break;
	}
	return {
		nodes: [...groupNodes.filter((node) => node.id === focusedBusinessGroupId.value), ...assetNodes.filter((node) => relatedIds.has(node.id))],
		edges: [...directEdges, ...dataFlowEdges.filter((edge) => relatedIds.has(edge.sourceId) && relatedIds.has(edge.targetId))],
	};
});

const expandedLayerNodes = computed(() =>
	scopedGraph.value.nodes.filter((node) => node.objectType !== 'GROUP' && categoryForNode(node) === expandedLayer.value)
);
const expandedPageCount = computed(() => Math.ceil(expandedLayerNodes.value.length / expandedPageSize));
const businessGroupPageCount = computed(() =>
	Math.ceil(scopedGraph.value.nodes.filter((node) => node.objectType === 'GROUP').length / expandedPageSize)
);
const currentScopeText = computed(() => {
	if (focusedBusinessGroupId.value) {
		const group = graph.nodes.find((node) => node.id === focusedBusinessGroupId.value);
		return `当前业务分组：${group ? nodeLabel(group) : focusedBusinessGroupId.value}${
			expandedLayer.value ? ` · ${layerLabelMap[expandedLayer.value] || expandedLayer.value}` : ''
		}`;
	}
	return expandedLayer.value ? `当前层级：${layerLabelMap[expandedLayer.value] || expandedLayer.value}` : '概览：点击分组或层级展开具体资产';
});

const displayGraph = computed<DisplayGraph>(() => {
	if (!isOverviewView.value) return { nodes: graph.nodes, edges: graph.edges };
	const nodes = scopedGraph.value.nodes;
	const assetsByLayer = new Map<string, MetadataGraphNode[]>();
	nodes.forEach((node) => {
		if (node.objectType === 'GROUP') return;
		const layer = categoryForNode(node);
		assetsByLayer.set(layer, [...(assetsByLayer.get(layer) || []), node]);
	});

	const visibleAssetIds = new Set(
		[...(assetsByLayer.get(expandedLayer.value) || [])]
			.sort((left, right) => nodeLabel(left).localeCompare(nodeLabel(right)))
			.slice((expandedPage.value - 1) * expandedPageSize, expandedPage.value * expandedPageSize)
			.map((node) => node.id)
	);
	const visibleGroups = nodes
		.filter((node) => node.objectType === 'GROUP')
		.sort((left, right) => nodeLabel(left).localeCompare(nodeLabel(right)))
		.slice((businessGroupPage.value - 1) * expandedPageSize, businessGroupPage.value * expandedPageSize);
	const visibleGroupIds = new Set(visibleGroups.map((node) => node.id));
	const displayNodes: DisplayNode[] = visibleGroups.map((node) => ({
		...node,
		viewKind: 'businessGroup',
		summaryCount: scopedGraph.value.edges.filter((edge) => edge.relationType === 'BELONGS_TO' && edge.sourceId === node.id).length,
	}));
	assetsByLayer.forEach((items, layer) => {
		if (layer === expandedLayer.value) {
			displayNodes.push(...items.filter((node) => visibleAssetIds.has(node.id)));
			return;
		}
		displayNodes.push({
			id: `__layer__:${layer}`,
			objectCode: `${layerLabelMap[layer] || layer} · ${items.length} 个资产`,
			objectName: layerLabelMap[layer] || layer,
			objectType: 'GROUP_SUMMARY',
			warehouseLayer: layer,
			viewKind: 'layerSummary',
			summaryLayer: layer,
			summaryCount: items.length,
		});
	});

	const byId = new Map(nodes.map((node) => [node.id, node]));
	const representative = (id: string) => {
		const node = byId.get(id);
		if (!node) return undefined;
		if (node.objectType === 'GROUP') return visibleGroupIds.has(node.id) ? node.id : undefined;
		const layer = categoryForNode(node);
		return layer === expandedLayer.value ? (visibleAssetIds.has(id) ? id : undefined) : `__layer__:${layer}`;
	};
	const displayEdges = new Map<string, DisplayEdge>();
	scopedGraph.value.edges.forEach((edge) => {
		const sourceId = representative(edge.sourceId);
		const targetId = representative(edge.targetId);
		if (!sourceId || !targetId || sourceId === targetId) return;
		const key = `${sourceId}|${targetId}|${edge.relationType || ''}`;
		const existing = displayEdges.get(key);
		if (existing) existing.relationCount = (existing.relationCount || 1) + 1;
		else displayEdges.set(key, { sourceId, targetId, relationType: edge.relationType, relationCount: 1 });
	});
	return { nodes: displayNodes, edges: [...displayEdges.values()] };
});

const visibleLegend = computed(() => {
	const categories = new Set(displayGraph.value.nodes.map(categoryForNode));
	return layerLegend.filter((item) => categories.has(item.value));
});

const layerText = (node: MetadataGraphNode) => layerLabelMap[categoryForNode(node)] || node.warehouseLayer || '其他';
const objectTypeText = (type?: string) =>
	({
		TABLE: '数据表',
		VIEW: '视图',
		BUSINESS_OBJECT: '业务对象',
		METRIC: '指标',
		DIMENSION: '维度',
		THEME: '应用主题',
		QUERY_SET: '查询集',
		API_DATASET: 'API数据集',
		GROUP: '分组',
	}[type || ''] ||
	type ||
	'--');

const positionByLayer = (nodes: MetadataGraphNode[]): PositionedNode[] => {
	const groups = new Map<string, MetadataGraphNode[]>();
	nodes.forEach((node) => {
		const layer = categoryForNode(node);
		groups.set(layer, [...(groups.get(layer) || []), node]);
	});
	const usedLayers = layerOrder.filter((layer) => groups.has(layer));
	const maxItemsInLayer = Math.max(0, ...[...groups.values()].map((items) => items.length));
	const verticalSpan = Math.max(470, (maxItemsInLayer + 1) * 88);
	return usedLayers.flatMap((layer, layerIndex) => {
		const items = groups.get(layer) || [];
		return items.map((node, itemIndex) => ({
			...node,
			x: usedLayers.length === 1 ? 500 : 90 + (layerIndex * 820) / (usedLayers.length - 1),
			y: 130 + ((itemIndex + 1) * verticalSpan) / (items.length + 1),
		}));
	});
};

const lineageDepths = (nodes: MetadataGraphNode[], edges: MetadataGraphEdge[]) => {
	const depths = new Map<string, number>();
	const rootId = query.rootObjectId && nodes.some((node) => node.id === query.rootObjectId) ? query.rootObjectId : nodes[0]?.id;
	if (!rootId) return depths;
	depths.set(rootId, 0);
	for (let round = 0; round < nodes.length; round += 1) {
		let changed = false;
		edges.forEach((edge) => {
			const sourceDepth = depths.get(edge.sourceId);
			const targetDepth = depths.get(edge.targetId);
			if (targetDepth !== undefined && sourceDepth === undefined) {
				depths.set(edge.sourceId, targetDepth - 1);
				changed = true;
			}
			if (sourceDepth !== undefined && targetDepth === undefined) {
				depths.set(edge.targetId, sourceDepth + 1);
				changed = true;
			}
		});
		if (!changed) break;
	}
	nodes.forEach((node) => {
		if (!depths.has(node.id)) depths.set(node.id, 0);
	});
	return depths;
};

const positionLineage = (nodes: MetadataGraphNode[], edges: MetadataGraphEdge[]): PositionedNode[] => {
	const depths = lineageDepths(nodes, edges);
	const values = [...depths.values()];
	const minDepth = Math.min(...values, 0);
	const maxDepth = Math.max(...values, 0);
	const groups = new Map<number, MetadataGraphNode[]>();
	nodes.forEach((node) => {
		const depth = depths.get(node.id) || 0;
		groups.set(depth, [...(groups.get(depth) || []), node]);
	});
	return nodes.map((node) => {
		const depth = depths.get(node.id) || 0;
		const items = groups.get(depth) || [];
		const index = items.findIndex((item) => item.id === node.id);
		return {
			...node,
			x: minDepth === maxDepth ? 500 : 90 + ((depth - minDepth) * 820) / (maxDepth - minDepth),
			y: 130 + ((index + 1) * 470) / (items.length + 1),
		};
	});
};

const truncate = (value: string, length: number) => (value.length > length ? `${value.slice(0, length)}…` : value);
const escapeHtml = (value: unknown) =>
	String(value ?? '--')
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#039;');

const chartOption = computed(() => {
	const nodes = displayGraph.value.nodes;
	const edges = displayGraph.value.edges;
	const positionedNodes = query.view === 'LINEAGE' || query.view === 'MODEL' ? positionLineage(nodes, edges) : positionByLayer(nodes);
	const selectedId = selectedNode.value?.id;
	const labelScale = graphZoom.value;
	const connectedIds = new Set<string>([selectedId || '']);
	if (selectedId) {
		edges.forEach((edge) => {
			if (edge.sourceId === selectedId) connectedIds.add(edge.targetId);
			if (edge.targetId === selectedId) connectedIds.add(edge.sourceId);
		});
	}
	return {
		animationDurationUpdate: 350,
		tooltip: {
			trigger: 'item',
			formatter: (params: { dataType?: string; data?: DisplayNode & DisplayEdge }) => {
				if (params.dataType === 'edge')
					return `关系：${escapeHtml(params.data?.relationType || '数据流转')}${
						params.data?.relationCount && params.data.relationCount > 1 ? `（汇总 ${params.data.relationCount} 条）` : ''
					}`;
				const node = params.data;
				if (node?.viewKind === 'layerSummary') return `<b>${escapeHtml(node.objectName)}</b><br/>${node.summaryCount || 0} 个资产<br/>点击展开`;
				if (node?.viewKind === 'businessGroup')
					return `<b>${escapeHtml(nodeLabel(node))}</b><br/>${node.summaryCount || 0} 个直接关联资产<br/>点击查看该业务链路`;
				return [
					`<b>${escapeHtml(node ? nodeLabel(node) : '--')}</b>`,
					escapeHtml(node?.objectCode),
					`类型：${escapeHtml(objectTypeText(node?.objectType))}`,
					`层级：${escapeHtml(node ? layerText(node) : '--')}`,
				].join('<br/>');
			},
		},
		series: [
			{
				type: 'graph',
				layout: 'none',
				roam: true,
				draggable: true,
				zoom: graphZoom.value,
				scaleLimit: { min: 0.3, max: 2 },
				symbol: 'rect',
				symbolSize: [190, 64],
				label: {
					show: true,
					position: 'inside',
					align: 'center',
					verticalAlign: 'middle',
					width: Math.round(164 * labelScale),
					overflow: 'truncate',
					color: '#0f172a',
					fontSize: Math.max(6, Math.min(24, 12 * labelScale)),
					fontWeight: 600,
					formatter: (params: { data: DisplayNode }) =>
						truncate(
							params.data.viewKind === 'businessGroup' ? `${nodeLabel(params.data)} · ${params.data.summaryCount || 0}` : nodeLabel(params.data),
							24
						),
				},
				edgeSymbol: ['none', 'arrow'],
				edgeSymbolSize: [0, 9],
				emphasis: { focus: 'adjacency', lineStyle: { width: 2.5 }, itemStyle: { shadowBlur: 14 } },
				lineStyle: { color: '#8ba1bd', width: 1.4, curveness: 0, opacity: 0.42 },
				data: positionedNodes.map((node) => {
					const category = categoryForNode(node);
					const isRoot = node.id === query.rootObjectId;
					const isSummary = Boolean((node as DisplayNode).viewKind);
					return {
						...node,
						name: nodeLabel(node),
						symbolSize: isRoot || isSummary ? [210, 70] : [190, 64],
						itemStyle: {
							color: isSummary ? '#f1f5ff' : '#ffffff',
							borderColor: layerColorMap[category],
							borderWidth: isRoot ? 3 : isSummary ? 2 : 1.5,
							borderRadius: 4,
							opacity: selectedId && !connectedIds.has(node.id) ? 0.25 : 1,
							shadowBlur: isRoot || selectedId === node.id ? 12 : 3,
							shadowColor: `${layerColorMap[category]}44`,
						},
					};
				}),
				links: edges.map((edge) => ({
					source: edge.sourceId,
					target: edge.targetId,
					relationType: edge.relationType,
					relationCount: edge.relationCount,
					lineStyle: { opacity: selectedId ? (edge.sourceId === selectedId || edge.targetId === selectedId ? 0.9 : 0.08) : 0.42 },
				})),
			},
		],
	};
});

const buildParams = (): MetadataGraphQuery => ({
	view: query.view,
	rootObjectId: requiresRoot.value ? query.rootObjectId : undefined,
	businessSystemId: query.businessSystemId || undefined,
	businessDomainId: query.businessDomainId || undefined,
	warehouseLayer: query.warehouseLayer || undefined,
	objectType: query.objectType || undefined,
	keyword: query.keyword?.trim() || undefined,
	direction: query.view === 'LINEAGE' ? query.direction : undefined,
	depth: query.view === 'LINEAGE' ? query.depth : undefined,
});

const updateRouteQuery = () => {
	router.replace({
		path: route.path,
		query: {
			view: query.view !== 'GLOBAL' ? query.view : undefined,
			rootObjectId: requiresRoot.value ? query.rootObjectId : undefined,
			businessSystemId: query.businessSystemId || undefined,
			businessDomainId: query.businessDomainId || undefined,
			warehouseLayer: query.warehouseLayer || undefined,
			objectType: query.objectType || undefined,
			keyword: query.keyword?.trim() || undefined,
			direction: query.view === 'LINEAGE' && query.direction !== 'BOTH' ? query.direction : undefined,
			depth: query.view === 'LINEAGE' && query.depth !== 2 ? String(query.depth) : undefined,
		},
	});
};

const clearGraph = () => {
	graph.nodes = [];
	graph.edges = [];
	graph.truncated = false;
	selectedNode.value = undefined;
	graphInteractionActive.value = false;
};

const resetOverviewScope = () => {
	focusedBusinessGroupId.value = '';
	businessGroupPage.value = 1;
	expandedLayer.value = '';
	expandedPage.value = 1;
};

const loadGraph = async () => {
	if (requiresRoot.value && !query.rootObjectId) {
		clearGraph();
		updateRouteQuery();
		useMessage().warning('请先从元数据检索或地图节点中选择中心对象');
		return;
	}
	try {
		loading.value = true;
		selectedNode.value = undefined;
		const res = await fetchMetadataGraph(buildParams());
		const data = res.data;
		const rawNodes = Array.isArray(data?.nodes) ? data.nodes : [];
		const rawEdges = Array.isArray(data?.edges) ? data.edges : [];
		graph.nodes = rawNodes.map((item) => normalizeNode(item as Record<string, unknown>)).filter((item) => item.id);
		graph.edges = rawEdges.map((item) => normalizeEdge(item as Record<string, unknown>)).filter((item) => item.sourceId && item.targetId);
		graph.truncated = Boolean(data?.truncated);
		resetOverviewScope();
		graphZoom.value = defaultGraphZoom;
		chartKey.value += 1;
		updateRouteQuery();
	} catch (error: unknown) {
		clearGraph();
		const message = error && typeof error === 'object' && 'msg' in error ? String((error as { msg?: string }).msg || '') : '';
		useMessage().error(message || '加载数据地图失败，请确认后端图谱接口是否已就绪');
	} finally {
		loading.value = false;
	}
};

const loadOptions = async () => {
	try {
		const res = await fetchMetadataOptions();
		const data = res.data || {};
		Object.assign(options, {
			...defaultOptions(),
			...data,
			warehouseLayers: data.warehouseLayers?.length ? data.warehouseLayers : defaultOptions().warehouseLayers,
		});
	} catch {
		Object.assign(options, defaultOptions());
	}
};

const handleViewChange = (view: MetadataMapView) => {
	query.view = view;
	if (view === 'GLOBAL' || view === 'BUSINESS') query.rootObjectId = undefined;
	if ((view === 'MODEL' || view === 'LINEAGE') && !query.rootObjectId) {
		clearGraph();
		updateRouteQuery();
		return;
	}
	loadGraph();
};

const handleSystemChange = () => {
	query.businessDomainId = undefined;
};

const resetFilters = () => {
	query.businessSystemId = undefined;
	query.businessDomainId = undefined;
	query.warehouseLayer = undefined;
	query.objectType = undefined;
	query.keyword = undefined;
	query.direction = 'BOTH';
	query.depth = 2;
	if (requiresRoot.value && !query.rootObjectId) {
		clearGraph();
		updateRouteQuery();
		return;
	}
	loadGraph();
};

const findDisplayNode = (event: GraphEvent) => {
	if (event.dataType !== 'node' || !event.data?.id) return undefined;
	return displayGraph.value.nodes.find((item) => item.id === String(event.data?.id));
};

const handleNodeClick = (event: GraphEvent) => {
	const node = findDisplayNode(event);
	if (!node) return;
	if (node.viewKind === 'businessGroup') {
		focusedBusinessGroupId.value = node.id;
		businessGroupPage.value = 1;
		expandedLayer.value = '';
		expandedPage.value = 1;
		selectedNode.value = undefined;
		resetViewport();
		return;
	}
	if (node.viewKind === 'layerSummary') {
		expandedLayer.value = node.summaryLayer || '';
		expandedPage.value = 1;
		selectedNode.value = undefined;
		resetViewport();
		return;
	}
	selectedNode.value = selectedNode.value?.id === node.id ? undefined : node;
};

const handleNodeDoubleClick = (event: GraphEvent) => {
	const node = findDisplayNode(event);
	if (node && !node.viewKind) focusLineage(node);
};

const backToBusinessOverview = () => {
	resetOverviewScope();
	selectedNode.value = undefined;
	resetViewport();
};

const collapseLayer = () => {
	expandedLayer.value = '';
	expandedPage.value = 1;
	selectedNode.value = undefined;
	resetViewport();
};

const changeExpandedPage = (step: number) => {
	expandedPage.value = Math.max(1, Math.min(expandedPageCount.value, expandedPage.value + step));
	selectedNode.value = undefined;
	resetViewport();
};

const changeBusinessGroupPage = (step: number) => {
	businessGroupPage.value = Math.max(1, Math.min(businessGroupPageCount.value, businessGroupPage.value + step));
	selectedNode.value = undefined;
	resetViewport();
};

const focusModel = (node: MetadataObjectSummary) => {
	query.view = 'MODEL';
	query.rootObjectId = String(node.id);
	query.keyword = undefined;
	loadGraph();
};

const focusLineage = (node: MetadataObjectSummary) => {
	query.view = 'LINEAGE';
	query.rootObjectId = String(node.id);
	query.keyword = undefined;
	loadGraph();
};

const openDetail = (node: MetadataGraphNode) => {
	detailDrawerRef.value?.openDrawer(node, 'basic');
};

const resetViewport = () => {
	graphZoom.value = defaultGraphZoom;
	chartKey.value += 1;
};

const activateGraphInteraction = () => {
	graphInteractionActive.value = true;
	graphPanelRef.value?.focus({ preventScroll: true });
};

const deactivateGraphInteraction = () => {
	graphInteractionActive.value = false;
};

const handleCanvasWheelCapture = (event: WheelEvent) => {
	if (graphInteractionActive.value) {
		event.preventDefault();
		return;
	}
	event.stopPropagation();
};

const handleGraphRoam = (event: GraphRoamEvent) => {
	if (typeof event.zoom !== 'number') return;
	graphZoom.value = Math.max(0.3, Math.min(2, graphZoom.value * event.zoom));
};

const toggleFullscreen = async () => {
	if (!graphPanelRef.value) return;
	try {
		if (document.fullscreenElement) await document.exitFullscreen();
		else await graphPanelRef.value.requestFullscreen();
	} catch {
		useMessage().warning('当前浏览器不支持页面全屏');
	}
};

const goToSearch = () => router.push('/gen/metadata/search');

onMounted(async () => {
	const routeView = typeof route.query.view === 'string' ? route.query.view.toUpperCase() : 'GLOBAL';
	if (viewOptions.some((item) => item.value === routeView)) query.view = routeView as MetadataMapView;
	query.rootObjectId = typeof route.query.rootObjectId === 'string' ? route.query.rootObjectId : undefined;
	query.businessSystemId = typeof route.query.businessSystemId === 'string' ? route.query.businessSystemId : undefined;
	query.businessDomainId = typeof route.query.businessDomainId === 'string' ? route.query.businessDomainId : undefined;
	query.warehouseLayer = typeof route.query.warehouseLayer === 'string' ? route.query.warehouseLayer : undefined;
	query.objectType = typeof route.query.objectType === 'string' ? route.query.objectType : undefined;
	query.keyword = typeof route.query.keyword === 'string' ? route.query.keyword : undefined;
	query.direction = ['UPSTREAM', 'DOWNSTREAM', 'BOTH'].includes(String(route.query.direction).toUpperCase())
		? (String(route.query.direction).toUpperCase() as MetadataGraphDirection)
		: 'BOTH';
	const routeDepth = Number(route.query.depth);
	query.depth = routeDepth >= 1 && routeDepth <= 3 ? routeDepth : 2;
	await loadOptions();
	if (requiresRoot.value && !query.rootObjectId) {
		updateRouteQuery();
		return;
	}
	loadGraph();
});
</script>

<style scoped>
.map-card {
	min-height: calc(100vh - 125px);
}

.page-heading,
.graph-summary,
.root-object-bar {
	display: flex;
	align-items: center;
	justify-content: space-between;
}

.page-heading {
	padding: 0 2px 18px 14px;
	border-bottom: 1px solid var(--el-border-color-lighter);
	border-left: 3px solid var(--el-color-primary);
}

.page-title {
	font-size: 20px;
	font-weight: 600;
}

.page-description {
	margin-top: 6px;
	color: var(--el-text-color-secondary);
}

.view-tabs {
	display: flex;
	gap: 8px;
	border-bottom: 1px solid var(--el-border-color-light);
}

.view-tabs button {
	padding: 15px 28px 13px;
	border: 0;
	border-bottom: 2px solid transparent;
	background: transparent;
	color: var(--el-text-color-regular);
	cursor: pointer;
}

.view-tabs button:hover,
.view-tabs button.active {
	border-bottom-color: var(--el-color-primary);
	color: var(--el-color-primary);
}

.filter-panel {
	padding: 17px 17px 0;
	border-bottom: 1px solid var(--el-border-color-lighter);
	background: var(--el-fill-color-extra-light);
}

.root-object-bar {
	padding: 10px 14px;
	border-bottom: 1px solid var(--el-border-color-lighter);
	background: var(--el-color-primary-light-9);
	font-size: 13px;
}

.root-object-bar > div {
	display: flex;
	align-items: center;
	gap: 12px;
}

.root-object-bar span,
.root-object-bar em {
	color: var(--el-text-color-secondary);
	font-style: normal;
}

.root-object-bar code {
	color: var(--el-color-primary);
}

.graph-summary {
	min-height: 58px;
	color: var(--el-text-color-regular);
}

.graph-summary strong {
	color: var(--el-color-primary);
}

.graph-total {
	margin-left: 8px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.scope-toolbar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 12px;
	min-height: 42px;
	padding: 6px 12px;
	border-top: 1px solid var(--el-border-color-lighter);
	background: var(--el-fill-color-extra-light);
	color: var(--el-text-color-regular);
	font-size: 12px;
}

.scope-toolbar > div {
	display: flex;
	align-items: center;
	gap: 6px;
}

.summary-divider {
	margin: 0 7px;
	color: var(--el-border-color);
}

.truncate-tag {
	margin-left: 14px;
}

.graph-actions {
	display: flex;
}

.graph-panel {
	position: relative;
	height: calc(100vh - 395px);
	min-height: 500px;
	overflow: hidden;
	border: 1px solid #cbd8e8;
	background-color: #f8fbff;
	background-image: linear-gradient(#e8eff7 1px, transparent 1px), linear-gradient(90deg, #e8eff7 1px, transparent 1px);
	background-size: 24px 24px;
	outline: none;
	transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.graph-panel.is-interactive {
	border-color: var(--el-color-primary);
	box-shadow: inset 0 0 0 1px var(--el-color-primary-light-7);
}

.graph-panel:fullscreen {
	height: 100vh;
	border: 0;
}

.canvas-heading {
	position: absolute;
	z-index: 3;
	top: 28px;
	left: 24px;
	right: 24px;
	display: flex;
	align-items: center;
	gap: 16px;
	padding: 13px 15px;
	border-left: 3px solid var(--el-color-primary);
	background: rgba(255, 255, 255, 0.92);
	box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
}

.canvas-heading span {
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.graph-chart {
	width: 100%;
	height: 100%;
}

.layer-legend {
	position: absolute;
	z-index: 4;
	top: 92px;
	right: 20px;
	display: flex;
	flex-wrap: wrap;
	gap: 13px;
	padding: 8px 11px;
	border: 1px solid var(--el-border-color-lighter);
	border-radius: 4px;
	background: rgba(255, 255, 255, 0.94);
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.layer-legend span {
	display: flex;
	align-items: center;
	gap: 5px;
}

.layer-legend i {
	display: inline-block;
	width: 8px;
	height: 8px;
	border-radius: 50%;
}

.root-empty {
	display: flex;
	height: 100%;
	align-items: center;
	justify-content: center;
	flex-direction: column;
	color: var(--el-text-color-secondary);
}

.root-empty .el-icon {
	color: var(--el-color-primary-light-5);
	font-size: 54px;
}

.root-empty h3 {
	margin: 14px 0 7px;
	color: var(--el-text-color-primary);
}

.root-empty p {
	margin: 0 0 18px;
}

.selected-node-card {
	position: absolute;
	z-index: 5;
	top: 136px;
	right: 20px;
	width: 294px;
	padding: 16px;
	border: 1px solid var(--el-color-primary-light-7);
	border-radius: 6px;
	background: #ffffff;
	box-shadow: 0 12px 28px rgba(15, 23, 42, 0.12);
}

.selected-node-card > button {
	position: absolute;
	top: 8px;
	right: 10px;
	border: 0;
	background: transparent;
	color: var(--el-text-color-secondary);
	font-size: 20px;
	cursor: pointer;
}

.selected-node-card h3 {
	margin: 11px 0 4px;
	font-size: 16px;
}

.selected-node-card p {
	margin: 0 0 13px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.selected-node-card > div:not(.selected-actions) {
	display: grid;
	grid-template-columns: 72px 1fr;
	margin-top: 8px;
	font-size: 13px;
}

.selected-node-card > div span {
	color: var(--el-text-color-secondary);
}

.selected-actions {
	display: flex;
	margin-top: 16px;
}

.interaction-tip {
	padding-top: 9px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.zoom-activation-tip {
	position: absolute;
	z-index: 4;
	right: 18px;
	bottom: 16px;
	padding: 6px 10px;
	border: 1px solid var(--el-border-color-light);
	border-radius: 4px;
	background: rgba(255, 255, 255, 0.9);
	color: var(--el-text-color-secondary);
	font-size: 12px;
	pointer-events: none;
}

.zoom-activation-tip.active {
	border-color: var(--el-color-primary-light-7);
	background: var(--el-color-primary-light-9);
	color: var(--el-color-primary);
}

@media (max-width: 1000px) {
	.view-tabs button {
		padding-right: 16px;
		padding-left: 16px;
	}

	.graph-summary {
		align-items: flex-start;
		flex-direction: column;
		gap: 10px;
		padding: 12px 0;
	}

	.scope-toolbar {
		align-items: flex-start;
		flex-direction: column;
	}

	.canvas-heading {
		align-items: flex-start;
		flex-direction: column;
		gap: 4px;
	}
}
</style>
