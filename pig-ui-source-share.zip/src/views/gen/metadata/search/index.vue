<template>
	<div class="metadata-search-page layout-padding">
		<el-card shadow="never" class="page-card">
			<div class="page-heading">
				<div>
					<div class="page-title">元数据检索</div>
					<div class="page-description">统一查找技术元数据、业务对象、指标、维度、应用主题和 API。</div>
				</div>
			</div>

			<section v-if="!hasSearched" class="search-home">
				<div class="search-hero">
					<h1>统一查找数据资产</h1>
					<p>输入表名、字段名、中文名称、指标或 API 名称</p>
					<div class="home-search-box">
						<el-autocomplete
							v-model="query.keyword"
							:fetch-suggestions="loadSuggestions"
							placeholder="请输入检索内容"
							clearable
							class="search-input"
							@keyup.enter="handleSearch()"
							@select="handleSuggestionSelect"
						/>
						<el-button type="primary" icon="Search" class="search-button" @click="handleSearch()">搜索</el-button>
					</div>
					<div class="hot-searches">
						<span>热门搜索：</span>
						<button v-for="word in hotSearches" :key="word" type="button" @click="searchKeyword(word)">{{ word }}</button>
					</div>
				</div>

				<div class="home-section">
					<h2>常用分类</h2>
					<div class="category-grid">
						<button v-for="item in searchableCategories" :key="item.value" type="button" class="category-card" @click="searchCategory(item.value)">
							<span class="category-icon">{{ item.short }}</span>
							<span class="category-name">{{ item.label }}</span>
							<span class="category-description">{{ item.description }}</span>
						</button>
					</div>
				</div>

				<div class="home-section">
					<div class="section-heading">
						<h2>最近访问</h2>
						<el-button v-if="recentObjects.length" text type="primary" @click="clearRecentObjects">清空</el-button>
					</div>
					<div v-if="recentObjects.length" class="recent-list">
						<button v-for="item in recentObjects" :key="item.id" type="button" @click="openDetail(item)">
							<span>{{ item.chineseName || item.objectName }}</span>
							<small>{{ item.objectType }} · {{ item.objectCode }}</small>
						</button>
					</div>
					<el-empty v-else description="暂无最近访问记录" :image-size="70" />
				</div>
			</section>

			<section v-else class="search-results">
				<div class="result-search-row">
					<el-button text type="primary" icon="ArrowLeft" @click="backToHome">返回检索首页</el-button>
					<div class="result-search-box">
						<el-autocomplete
							v-model="query.keyword"
							:fetch-suggestions="loadSuggestions"
							placeholder="在元数据中搜索"
							clearable
							class="search-input"
							@keyup.enter="handleSearch()"
							@select="handleSuggestionSelect"
						/>
						<el-button type="primary" icon="Search" @click="handleSearch()">搜索</el-button>
					</div>
				</div>

				<div class="category-tabs">
					<button
						v-for="item in categories"
						:key="item.value"
						type="button"
						:class="{ active: query.category === item.value }"
						@click="handleCategoryChange(item.value)"
					>
						{{ item.label }} <span>{{ facetCount(item.value) }}</span>
					</button>
				</div>

				<div class="filter-panel">
					<el-form :model="query" inline @submit.prevent>
						<el-form-item label="匹配方式">
							<el-radio-group v-model="query.matchMode" @change="handleSearch()">
								<el-radio-button value="FUZZY">模糊查询</el-radio-button>
								<el-radio-button value="EXACT">精确查询</el-radio-button>
							</el-radio-group>
						</el-form-item>
						<el-form-item label="业务系统">
							<el-select
								v-model="query.businessSystemId"
								clearable
								filterable
								placeholder="全部系统"
								style="width: 150px"
								@change="handleBusinessSystemChange"
							>
								<el-option v-for="item in options.businessSystems" :key="item.value" :label="item.label" :value="item.value" />
							</el-select>
						</el-form-item>
						<el-form-item label="业务域">
							<el-select v-model="query.businessDomainId" clearable filterable placeholder="全部业务域" style="width: 150px">
								<el-option v-for="item in availableBusinessDomains" :key="item.value" :label="item.label" :value="item.value" />
							</el-select>
						</el-form-item>
						<el-form-item label="数仓层级">
							<el-select v-model="query.warehouseLayer" clearable placeholder="全部层级" style="width: 130px">
								<el-option v-for="item in options.warehouseLayers" :key="item.value" :label="item.label" :value="item.value" />
							</el-select>
						</el-form-item>
						<el-form-item label="对象类型">
							<el-select v-model="query.objectType" clearable placeholder="全部类型" style="width: 150px">
								<el-option v-for="item in options.objectTypes" :key="item.value" :label="item.label" :value="item.value" />
							</el-select>
						</el-form-item>
						<el-form-item label="状态">
							<el-select v-model="query.status" clearable placeholder="全部状态" style="width: 130px">
								<el-option v-for="item in options.statuses" :key="item.value" :label="item.label" :value="item.value" />
							</el-select>
						</el-form-item>
						<el-form-item>
							<el-button type="primary" icon="Search" @click="handleSearch()">查询</el-button>
							<el-button icon="Refresh" @click="resetFilters">重置</el-button>
						</el-form-item>
					</el-form>
				</div>

				<div class="result-summary">
					<span
						>共找到 <strong>{{ page.total }}</strong> 条相关元数据</span
					>
					<el-button icon="Refresh" :loading="loading" @click="loadResults">刷新</el-button>
				</div>

				<div v-loading="loading" class="result-list">
					<MetadataObjectCard
						v-for="item in records"
						:key="item.id"
						:record="item"
						@open-detail="openDetail"
						@open-fields="openFields"
						@open-map="openMap"
					/>
					<el-empty v-if="!loading && !records.length" description="没有找到符合条件的元数据，请调整关键词或筛选条件" />
				</div>

				<pagination
					v-if="hasResults"
					:current="page.current"
					:size="page.size"
					:total="page.total"
					@current-change="handleCurrentChange"
					@size-change="handleSizeChange"
				/>
			</section>
		</el-card>

		<MetadataDetailDrawer ref="detailDrawerRef" @open-map="openMap" />
	</div>
</template>

<script setup lang="ts" name="DataPlatformMetadataSearch">
import { fetchMetadataOptions, fetchMetadataSearchPage, fetchMetadataSearchSuggestions } from '/@/api/dataPlatform/metadata';
import { useMessage } from '/@/hooks/message';
import type {
	MetadataCategory,
	MetadataObjectSummary,
	MetadataOptions,
	MetadataSearchQuery,
	MetadataSearchResult,
	MetadataSuggestion,
} from '/@/types/dataPlatform/metadata';
import { Local } from '/@/utils/storage';
import MetadataDetailDrawer from '../components/MetadataDetailDrawer.vue';
import MetadataObjectCard from '../components/MetadataObjectCard.vue';

const route = useRoute();
const router = useRouter();
const detailDrawerRef = ref<InstanceType<typeof MetadataDetailDrawer>>();
const loading = ref(false);
const hasSearched = ref(false);
const records = ref<MetadataObjectSummary[]>([]);
const facets = ref<Partial<Record<MetadataCategory, string | null>>>({});
const recentObjects = ref<MetadataObjectSummary[]>([]);
const page = reactive({ current: 1, size: 10, total: '0' });
const recentStorageKey = 'metadata-search-recent-objects';
const hasResults = computed(() => page.total !== '0' && page.total !== '--');

const categories = [
	{ value: 'ALL' as const, label: '全部', short: '全', description: '全部元数据资产' },
	{ value: 'TECHNICAL' as const, label: '技术元数据', short: '技', description: '表、字段和数仓模型' },
	{ value: 'BUSINESS' as const, label: '业务元数据', short: '业', description: '业务对象与业务释义' },
	{ value: 'METRIC' as const, label: '指标', short: '指', description: '正式指标和计算口径' },
	{ value: 'DIMENSION' as const, label: '维度', short: '维', description: '公共维度和业务维度' },
	{ value: 'THEME' as const, label: '应用主题', short: '主', description: '报表与数据查询主题' },
	{ value: 'API' as const, label: 'API', short: '接', description: '数据集服务接口' },
];
const searchableCategories = categories.filter((item) => item.value !== 'ALL');
const hotSearches = ['酒店订单', '供应商', '支付金额', '更新时间', 'ODS', '经营日报'];

const defaultOptions = (): MetadataOptions => ({
	businessSystems: [],
	businessDomains: [],
	warehouseLayers: ['ODS', 'DIM', 'DWD', 'DWS', 'ADS'].map((value) => ({ value, label: value })),
	objectTypes: [],
	statuses: [
		{ value: 'NORMAL', label: '正常' },
		{ value: 'PENDING', label: '待更新' },
		{ value: 'FAILED', label: '采集失败' },
		{ value: 'DISABLED', label: '已停用' },
	],
});
const options = reactive<MetadataOptions>(defaultOptions());
const query = reactive<MetadataSearchQuery>({
	current: 1,
	size: 10,
	keyword: '',
	category: 'ALL',
	matchMode: 'FUZZY',
	businessSystemId: '',
	businessDomainId: '',
	warehouseLayer: '',
	objectType: '',
	status: '',
});

const availableBusinessDomains = computed(() => {
	if (!query.businessSystemId) return options.businessDomains || [];
	return (options.businessDomains || []).filter((item) => !item.parentValue || String(item.parentValue) === String(query.businessSystemId));
});

const normalizeOptions = (data: MetadataOptions): MetadataOptions => ({
	businessSystems: data.businessSystems || [],
	businessDomains: data.businessDomains || [],
	warehouseLayers: data.warehouseLayers?.length ? data.warehouseLayers : defaultOptions().warehouseLayers,
	objectTypes: data.objectTypes || [],
	statuses: data.statuses?.length ? data.statuses : defaultOptions().statuses,
});

const normalizeRecord = (item: any): MetadataObjectSummary => ({
	...item,
	id: String(item.id ?? item.objectId),
	objectCode: item.objectCode || item.code || '--',
	objectName: item.objectName || item.name || item.chineseName || item.objectCode || '--',
	objectType: item.objectType || item.type || '--',
	matchedFields: Array.isArray(item.matchedFields) ? item.matchedFields : [],
});

const loadOptions = async () => {
	try {
		const res = await fetchMetadataOptions();
		Object.assign(options, normalizeOptions((res.data || {}) as MetadataOptions));
	} catch {
		Object.assign(options, defaultOptions());
	}
};

const loadSuggestions = async (keyword: string, callback: (items: MetadataSuggestion[]) => void) => {
	if (!keyword.trim()) {
		callback([]);
		return;
	}
	try {
		const res = await fetchMetadataSearchSuggestions(keyword.trim());
		const data = Array.isArray(res.data) ? res.data : [];
		callback(
			data.slice(0, 10).map((item) => ({
				...item,
				value: item.objectCode,
				label: item.objectName,
			}))
		);
	} catch {
		callback([]);
	}
};

const buildSearchParams = (): MetadataSearchQuery => ({
	current: page.current,
	size: page.size,
	keyword: query.keyword?.trim() || undefined,
	category: query.category === 'ALL' ? undefined : query.category,
	matchMode: query.matchMode,
	businessSystemId: query.businessSystemId || undefined,
	businessDomainId: query.businessDomainId || undefined,
	warehouseLayer: query.warehouseLayer || undefined,
	objectType: query.objectType || undefined,
	status: query.status || undefined,
});

const updateRouteQuery = () => {
	router.replace({
		path: route.path,
		query: {
			keyword: query.keyword?.trim() || undefined,
			category: query.category !== 'ALL' ? query.category : undefined,
			matchMode: query.matchMode !== 'FUZZY' ? query.matchMode : undefined,
			businessSystemId: query.businessSystemId || undefined,
			businessDomainId: query.businessDomainId || undefined,
			warehouseLayer: query.warehouseLayer || undefined,
			objectType: query.objectType || undefined,
			status: query.status || undefined,
		},
	});
};

const loadResults = async () => {
	hasSearched.value = true;
	try {
		loading.value = true;
		const res = await fetchMetadataSearchPage(buildSearchParams());
		const result = (res.data || {}) as MetadataSearchResult;
		records.value = (result.records || []).map(normalizeRecord);
		page.total = result.total ?? '--';
		facets.value = result.facets || {};
		updateRouteQuery();
	} catch (error: any) {
		records.value = [];
		page.total = '0';
		facets.value = {};
		useMessage().error(error?.msg || '元数据检索失败，请确认后端检索接口是否已就绪');
	} finally {
		loading.value = false;
	}
};

const handleSearch = (resetPage = true) => {
	if (!query.keyword?.trim() && query.category === 'ALL') {
		useMessage().warning('请输入检索内容，或选择一个元数据分类');
		return;
	}
	if (resetPage) page.current = 1;
	loadResults();
};

const handleSuggestionSelect = (item: MetadataSuggestion) => {
	query.keyword = item.objectCode;
	handleSearch();
};

const searchKeyword = (keyword: string) => {
	query.keyword = keyword;
	query.category = 'ALL';
	handleSearch();
};

const searchCategory = (category: MetadataCategory) => {
	query.category = category;
	handleSearch();
};

const handleCategoryChange = (category: MetadataCategory) => {
	query.category = category;
	handleSearch();
};

const handleBusinessSystemChange = () => {
	query.businessDomainId = '';
};

const resetFilters = () => {
	query.businessSystemId = '';
	query.businessDomainId = '';
	query.warehouseLayer = '';
	query.objectType = '';
	query.status = '';
	query.matchMode = 'FUZZY';
	handleSearch();
};

const facetCount = (category: MetadataCategory) => {
	if (facets.value[category] !== undefined) return facets.value[category] ?? '--';
	return category === 'ALL' ? page.total : '0';
};

const saveRecentObject = (record: MetadataObjectSummary) => {
	const list = [record, ...recentObjects.value.filter((item) => item.id !== record.id)].slice(0, 5);
	recentObjects.value = list;
	Local.set(recentStorageKey, list);
};

const openDetail = (record: MetadataObjectSummary) => {
	saveRecentObject(record);
	detailDrawerRef.value?.openDrawer(record, 'basic');
};

const openFields = (record: MetadataObjectSummary) => {
	saveRecentObject(record);
	detailDrawerRef.value?.openDrawer(record, 'columns');
};

const openMap = (record: MetadataObjectSummary) => {
	saveRecentObject(record);
	router.push({ path: '/gen/metadata/map', query: { rootObjectId: record.id, view: 'LINEAGE' } });
};

const clearRecentObjects = () => {
	recentObjects.value = [];
	Local.remove(recentStorageKey);
};

const backToHome = () => {
	hasSearched.value = false;
	records.value = [];
	page.total = '0';
	facets.value = {};
	router.replace({ path: route.path });
};

const handleCurrentChange = (current: number) => {
	page.current = current;
	loadResults();
};

const handleSizeChange = (size: number) => {
	page.size = size;
	page.current = 1;
	loadResults();
};

onMounted(async () => {
	const storedRecent = Local.get(recentStorageKey);
	recentObjects.value = Array.isArray(storedRecent) ? storedRecent.map(normalizeRecord).slice(0, 5) : [];
	await loadOptions();
	query.keyword = typeof route.query.keyword === 'string' ? route.query.keyword : '';
	const routeCategory = typeof route.query.category === 'string' ? route.query.category : 'ALL';
	if (categories.some((item) => item.value === routeCategory)) query.category = routeCategory as MetadataCategory;
	query.matchMode = route.query.matchMode === 'EXACT' ? 'EXACT' : 'FUZZY';
	query.businessSystemId = typeof route.query.businessSystemId === 'string' ? route.query.businessSystemId : '';
	query.businessDomainId = typeof route.query.businessDomainId === 'string' ? route.query.businessDomainId : '';
	query.warehouseLayer = typeof route.query.warehouseLayer === 'string' ? route.query.warehouseLayer : '';
	query.objectType = typeof route.query.objectType === 'string' ? route.query.objectType : '';
	query.status = typeof route.query.status === 'string' ? route.query.status : '';
	if (query.keyword || query.category !== 'ALL') loadResults();
});
</script>

<style scoped>
.page-card {
	min-height: calc(100vh - 125px);
}

.page-heading {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding-bottom: 18px;
	border-bottom: 1px solid var(--el-border-color-lighter);
}

.page-title {
	font-size: 20px;
	font-weight: 600;
}

.page-description {
	margin-top: 6px;
	color: var(--el-text-color-secondary);
}

.search-home {
	max-width: 1180px;
	margin: 0 auto;
}

.search-hero {
	padding: 64px 30px 50px;
	text-align: center;
}

.search-hero h1 {
	margin: 0;
	color: var(--el-color-primary);
	font-size: 30px;
}

.search-hero > p {
	margin: 12px 0 28px;
	color: var(--el-text-color-secondary);
}

.home-search-box,
.result-search-box {
	display: flex;
	width: min(760px, 100%);
	margin: 0 auto;
}

.search-input {
	flex: 1;
}

.home-search-box :deep(.el-input__wrapper),
.home-search-box .search-button {
	height: 48px;
}

.home-search-box .search-button {
	padding: 0 30px;
	margin-left: 10px;
}

.hot-searches {
	display: flex;
	max-width: 760px;
	align-items: center;
	justify-content: center;
	gap: 9px;
	margin: 18px auto 0;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.hot-searches button {
	padding: 4px 9px;
	border: 1px solid var(--el-border-color-light);
	border-radius: 4px;
	background: var(--el-fill-color-lighter);
	color: var(--el-text-color-regular);
	cursor: pointer;
}

.home-section {
	padding: 24px;
	margin-bottom: 20px;
	border: 1px solid var(--el-border-color-lighter);
	border-radius: 8px;
}

.home-section h2 {
	margin: 0 0 20px;
	font-size: 16px;
}

.section-heading {
	display: flex;
	align-items: center;
	justify-content: space-between;
}

.category-grid {
	display: grid;
	grid-template-columns: repeat(3, minmax(0, 1fr));
	gap: 14px;
}

.category-card {
	display: grid;
	grid-template-columns: 46px 1fr;
	grid-template-rows: auto auto;
	column-gap: 13px;
	padding: 18px;
	border: 1px solid var(--el-border-color-light);
	border-radius: 7px;
	background: var(--el-bg-color);
	text-align: left;
	cursor: pointer;
}

.category-card:hover {
	border-color: var(--el-color-primary-light-5);
	background: var(--el-color-primary-light-9);
}

.category-icon {
	display: flex;
	grid-row: 1 / 3;
	width: 46px;
	height: 46px;
	align-items: center;
	justify-content: center;
	border-radius: 10px;
	background: var(--el-color-primary-light-8);
	color: var(--el-color-primary);
	font-size: 18px;
	font-weight: 600;
}

.category-name {
	font-weight: 600;
}

.category-description {
	margin-top: 5px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.recent-list {
	display: flex;
	flex-wrap: wrap;
	gap: 10px;
}

.recent-list button {
	display: flex;
	min-width: 190px;
	flex: 1;
	flex-direction: column;
	gap: 5px;
	padding: 12px 15px;
	border: 1px solid var(--el-border-color-lighter);
	border-radius: 6px;
	background: var(--el-fill-color-extra-light);
	text-align: left;
	cursor: pointer;
}

.recent-list small {
	color: var(--el-text-color-secondary);
}

.result-search-row {
	display: flex;
	align-items: center;
	padding: 22px 0;
}

.result-search-box {
	margin-left: 40px;
}

.result-search-box .el-button {
	margin-left: 10px;
}

.category-tabs {
	display: flex;
	gap: 4px;
	border-bottom: 1px solid var(--el-border-color-light);
}

.category-tabs button {
	padding: 12px 17px;
	border: 0;
	border-bottom: 2px solid transparent;
	background: transparent;
	color: var(--el-text-color-regular);
	cursor: pointer;
}

.category-tabs button.active {
	border-bottom-color: var(--el-color-primary);
	color: var(--el-color-primary);
	font-weight: 600;
}

.category-tabs span {
	margin-left: 4px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.filter-panel {
	padding: 18px 18px 0;
	margin-top: 16px;
	border: 1px solid var(--el-border-color-lighter);
	border-radius: 7px;
	background: var(--el-fill-color-extra-light);
}

.result-summary {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 18px 2px 12px;
}

.result-summary strong {
	color: var(--el-color-primary);
}

.result-list {
	display: flex;
	min-height: 220px;
	flex-direction: column;
	gap: 12px;
}

@media (max-width: 1000px) {
	.category-grid {
		grid-template-columns: repeat(2, minmax(0, 1fr));
	}

	.result-search-row {
		align-items: flex-start;
		flex-direction: column;
		gap: 12px;
	}

	.result-search-box {
		width: 100%;
		margin-left: 0;
	}
}
</style>
