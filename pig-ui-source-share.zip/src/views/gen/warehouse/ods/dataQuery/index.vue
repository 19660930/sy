<template>
	<data-query-workbench v-if="useDataQueryWorkbench" />
	<div v-else class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<el-alert
				title="选择已同步的ODS源表模型进行受限数据预览，本页面不支持执行SQL或修改目标表数据。"
				type="info"
				show-icon
				:closable="false"
				class="page-alert"
			/>

			<el-row v-show="showSearch" class="ml10">
				<el-form ref="queryRef" :inline="true" :model="state.queryForm" @keyup.enter="getDataList">
					<el-form-item label="模型检索" prop="keyword">
						<el-input v-model="state.queryForm.keyword" clearable placeholder="源表、目标表或表注释" style="width: 230px" />
					</el-form-item>
					<el-form-item label="目标数据源" prop="targetDatasourceId">
						<el-select v-model="state.queryForm.targetDatasourceId" clearable filterable placeholder="全部PostgreSQL目标" style="width: 240px">
							<el-option v-for="item in targetDatasources" :key="item.id" :label="datasourceLabel(item)" :value="item.id" />
						</el-select>
					</el-form-item>
					<el-form-item>
						<el-button type="primary" icon="Search" @click="getDataList">查询</el-button>
						<el-button icon="Refresh" @click="resetQuery">重置</el-button>
					</el-form-item>
				</el-form>
			</el-row>

			<el-row>
				<div class="mb8" style="width: 100%">
					<el-button
						v-if="showDeleteActions"
						v-auth="'dp_ods_model_delete'"
						class="ml10"
						type="danger"
						plain
						icon="Delete"
						:disabled="selectedRows.length === 0 || deleting"
						:loading="deleting"
						@click="handleDelete(selectedRows)"
					>
						批量删除
					</el-button>
					<right-toolbar v-model:showSearch="showSearch" class="ml10" style="float: right; margin-right: 20px" @queryTable="getDataList(false)" />
				</div>
			</el-row>

			<el-table
				ref="tableRef"
				v-loading="state.loading"
				:data="state.dataList"
				row-key="id"
				border
				style="width: 100%"
				:cell-style="tableStyle.cellStyle"
				:header-cell-style="tableStyle.headerCellStyle"
				@selection-change="handleSelectionChange"
			>
				<el-table-column v-if="showDeleteActions" type="selection" width="46" />
				<el-table-column type="index" label="#" width="55" />
				<el-table-column prop="sourceTable" label="源表名称" min-width="170" show-overflow-tooltip />
				<el-table-column prop="targetTable" label="ODS目标表" min-width="180" show-overflow-tooltip />
				<el-table-column prop="tableComment" label="表注释" min-width="180" show-overflow-tooltip>
					<template #default="{ row }">{{ row.tableComment || '--' }}</template>
				</el-table-column>
				<el-table-column label="目标数据源" min-width="180" show-overflow-tooltip>
					<template #default="{ row }">{{ datasourceName(row.targetDatasourceId) }}</template>
				</el-table-column>
				<el-table-column prop="businessSystem" label="业务系统" min-width="130" show-overflow-tooltip>
					<template #default="{ row }">{{ row.businessSystem || '--' }}</template>
				</el-table-column>
				<el-table-column prop="departmentName" label="所属部门" min-width="130" show-overflow-tooltip>
					<template #default="{ row }">{{ row.departmentName || '--' }}</template>
				</el-table-column>
				<el-table-column prop="rowCount" label="数据行数" width="110">
					<template #default="{ row }">{{ row.rowCount ?? '--' }}</template>
				</el-table-column>
				<el-table-column prop="lastSyncTime" label="最近同步时间" width="180">
					<template #default="{ row }">{{ row.lastSyncTime || '--' }}</template>
				</el-table-column>
				<el-table-column label="操作" :width="showDeleteActions ? 190 : 110" fixed="right">
					<template #default="{ row }">
						<el-button text type="primary" icon="View" @click="dataPreviewRef.openDrawer(row)">查看数据</el-button>
						<el-button
							v-if="showDeleteActions"
							v-auth="'dp_ods_model_delete'"
							text
							type="danger"
							icon="Delete"
							:disabled="deleting"
							@click="handleDelete([row])"
						>
							删除
						</el-button>
					</template>
				</el-table-column>
			</el-table>

			<pagination v-bind="state.pagination" @current-change="currentChangeHandle" @size-change="sizeChangeHandle" />
		</div>

		<data-preview ref="dataPreviewRef" />
	</div>
</template>

<script setup lang="ts" name="DataPlatformOdsDataQuery">
import type { FormInstance, TableInstance } from 'element-plus';
import { fetchManualSyncDatasources } from '/@/api/dataPlatform/odsManualSync';
import { deleteOdsTableModels, fetchOdsTableModelPage } from '/@/api/dataPlatform/odsTableModel';
import { type BasicTableProps, useTable } from '/@/hooks/table';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type { ManualSyncDatasource } from '/@/types/dataPlatform/odsManualSync';
import type { OdsTableModel, OdsTableModelDeleteFailure } from '/@/types/dataPlatform/odsTableModel';

const DataPreview = defineAsyncComponent(() => import('./dataPreview.vue'));
const DataQueryWorkbench = defineAsyncComponent(() => import('./workbench.vue'));
const useDataQueryWorkbench = true;
const dataPreviewRef = ref();
const tableRef = ref<TableInstance>();
const queryRef = ref<FormInstance>();
const showSearch = ref(true);
const showDeleteActions = false;
const targetDatasources = ref<ManualSyncDatasource[]>([]);
const selectedRows = ref<OdsTableModel[]>([]);
const deleting = ref(false);

const state: BasicTableProps = reactive<BasicTableProps>({
	queryForm: {
		keyword: '',
		syncStatus: 'SUCCESS',
		targetDatasourceId: '',
	},
	pageList: fetchOdsTableModelPage,
	descs: ['update_time'],
});

const { getDataList, currentChangeHandle, sizeChangeHandle, tableStyle } = useTable(state);

const datasourceLabel = (item: ManualSyncDatasource) => item.displayName || item.name;
const datasourceName = (id: string) => {
	const item = targetDatasources.value.find((source) => source.id === id);
	return item?.displayName || item?.name || id;
};

const loadDatasourceOptions = async () => {
	try {
		const response = await fetchManualSyncDatasources('TARGET');
		targetDatasources.value = response.data || [];
	} catch (error: any) {
		useMessage().error(error?.msg || '加载目标数据源选项失败');
	}
};

const resetQuery = () => {
	queryRef.value?.resetFields();
	state.queryForm.syncStatus = 'SUCCESS';
	getDataList();
};

const handleSelectionChange = (rows: OdsTableModel[]) => {
	selectedRows.value = rows;
};

const getFailureMessage = (item: OdsTableModelDeleteFailure) =>
	item.message || item.reason || item.errorMessage || '删除失败';

const handleDelete = async (rows: OdsTableModel[]) => {
	if (rows.length === 0) return;
	if (rows.length > 100) {
		useMessage().error('单次最多删除100张表');
		return;
	}

	const targetDescription = rows.length === 1 ? `目标表“${rows[0].targetTable}”` : `选中的${rows.length}张目标表`;
	try {
		await useMessageBox().confirm(`将删除${targetDescription}、ODS元数据及模型记录；MySQL源表和同步历史不会被删除，是否继续？`);
	} catch {
		return;
	}

	try {
		deleting.value = true;
		const response = await deleteOdsTableModels(rows.map((row) => row.id));
		const deletedIds = response.data?.deletedIds || [];
		const failedItems = response.data?.failedItems || [];

		if (deletedIds.length > 0 && failedItems.length === 0) {
			useMessage().success(`成功删除${deletedIds.length}张表`);
		} else if (deletedIds.length > 0) {
			useMessage().warning(`成功删除${deletedIds.length}张表，${failedItems.length}张删除失败：${getFailureMessage(failedItems[0])}`);
		} else if (failedItems.length > 0) {
			useMessage().error(`删除失败：${getFailureMessage(failedItems[0])}`);
		} else {
			useMessage().warning('未删除任何表');
		}

		if (deletedIds.length > 0) {
			tableRef.value?.clearSelection();
			await getDataList();
		}
	} catch (error: any) {
		useMessage().error(error?.msg || '删除ODS表失败');
	} finally {
		deleting.value = false;
	}
};

onMounted(() => {
	if (!useDataQueryWorkbench) loadDatasourceOptions();
});
</script>

<style scoped>
.page-alert {
	margin: 0 10px 18px;
}
</style>
