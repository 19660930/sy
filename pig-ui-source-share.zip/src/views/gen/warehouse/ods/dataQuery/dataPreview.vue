<template>
	<el-drawer v-model="visible" title="ODS数据预览" size="82%" destroy-on-close>
		<el-descriptions v-if="model" :column="3" border class="preview-summary">
			<el-descriptions-item label="源表名称">{{ model.sourceTable }}</el-descriptions-item>
			<el-descriptions-item label="ODS目标表">{{ model.targetTable }}</el-descriptions-item>
			<el-descriptions-item label="数据行数">{{ model.rowCount ?? '--' }}</el-descriptions-item>
		</el-descriptions>

		<el-form :inline="true" class="preview-options">
			<el-form-item label="预览条数">
				<el-select v-model="query.limit" style="width: 120px">
					<el-option v-for="item in limitOptions" :key="item" :label="`${item} 条`" :value="item" />
				</el-select>
			</el-form-item>
			<el-form-item label="超时时间" class="timeout-form-item">
				<div class="timeout-control">
					<el-input-number v-model="query.timeoutSeconds" :min="1" :max="10" controls-position="right" />
					<span class="unit-text">秒</span>
				</div>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" icon="Refresh" :loading="loading" @click="loadData">重新加载</el-button>
			</el-form-item>
		</el-form>

		<el-alert
			v-if="preview.truncated"
			title="当前仅展示前若干条数据，目标表中还有更多数据。"
			type="warning"
			show-icon
			:closable="false"
			class="truncated-alert"
		/>

		<el-table v-loading="loading" :data="preview.rows" border height="calc(100vh - 310px)" empty-text="暂无可预览数据">
			<el-table-column type="index" label="#" width="55" fixed="left" />
			<el-table-column v-for="column in preview.columns" :key="column" :prop="column" :label="column" min-width="160" show-overflow-tooltip>
				<template #default="{ row }">{{ formatCell(row[column]) }}</template>
			</el-table-column>
		</el-table>
	</el-drawer>
</template>

<script setup lang="ts" name="OdsDataPreview">
import { fetchOdsTableModelData } from '/@/api/dataPlatform/odsTableModel';
import { useMessage } from '/@/hooks/message';
import type { OdsTableDataPreview, OdsTableModel } from '/@/types/dataPlatform/odsTableModel';

const visible = ref(false);
const loading = ref(false);
const model = ref<OdsTableModel>();
const limitOptions = [20, 50, 100];
const query = reactive({
	limit: 20,
	timeoutSeconds: 5,
});
const preview = reactive<OdsTableDataPreview>({
	columns: [],
	rows: [],
	truncated: false,
});

const formatCell = (value: unknown) => {
	if (value === null || value === undefined) return '--';
	if (typeof value === 'object') return JSON.stringify(value);
	return String(value);
};

const loadData = async () => {
	if (!model.value) return;
	try {
		loading.value = true;
		const response = await fetchOdsTableModelData(model.value.id, query);
		const data = response.data as OdsTableDataPreview;
		preview.columns = data?.columns || [];
		preview.rows = data?.rows || [];
		preview.truncated = Boolean(data?.truncated);
	} catch (error: any) {
		preview.columns = [];
		preview.rows = [];
		preview.truncated = false;
		useMessage().error(error?.msg || '加载ODS表数据失败');
	} finally {
		loading.value = false;
	}
};

const openDrawer = (row: OdsTableModel) => {
	model.value = row;
	query.limit = 20;
	query.timeoutSeconds = 5;
	preview.columns = [];
	preview.rows = [];
	preview.truncated = false;
	visible.value = true;
	loadData();
};

defineExpose({ openDrawer });
</script>

<style scoped>
.preview-summary {
	margin-bottom: 18px;
}

.preview-options {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	gap: 0 12px;
	margin-bottom: 2px;
}

.timeout-form-item {
	white-space: nowrap;
}

.timeout-control {
	display: inline-flex;
	align-items: center;
	gap: 8px;
	white-space: nowrap;
}

.timeout-control :deep(.el-input-number) {
	width: 110px;
}

.unit-text {
	color: var(--el-text-color-secondary);
}

.truncated-alert {
	margin-bottom: 14px;
}
</style>
