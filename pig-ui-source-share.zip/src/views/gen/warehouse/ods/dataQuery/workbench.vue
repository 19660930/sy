<template>
	<div ref="workbenchRef" class="data-query-workbench layout-padding">
		<div class="layout-padding-auto layout-padding-view workbench-shell">
			<el-tabs v-model="category" class="category-tabs">
				<el-tab-pane label="关系型数据类" name="RELATIONAL" />
				<el-tab-pane label="大数据类" name="BIG_DATA" />
			</el-tabs>

			<div v-if="category === 'BIG_DATA'" class="big-data-placeholder">
				<el-empty :image-size="110">
					<template #description>
						<div class="empty-description">
							<div>当前暂未接入大数据类数据源。</div>
							<small>后续可根据实际需要接入 Hive、Kafka、HBase 等数据源。</small>
						</div>
					</template>
				</el-empty>
			</div>

			<template v-else>
				<div class="selector-panel">
					<el-form :inline="true" label-position="left" class="selector-form">
						<el-form-item label="数据源类型" required>
							<el-select v-model="datasourceType" placeholder="请选择数据源类型" style="width: 190px" @change="handleDatasourceTypeChange">
								<el-option v-for="item in datasourceTypes" :key="item" :label="datasourceTypeLabel(item)" :value="item" />
							</el-select>
						</el-form-item>
						<el-form-item label="数据源连接名" required>
							<el-select
								v-model="datasourceId"
								filterable
								placeholder="请选择数据源连接"
								style="width: 240px"
								@change="handleDatasourceChange"
							>
								<el-option v-for="item in filteredDatasources" :key="item.id" :label="datasourceLabel(item)" :value="item.id" />
							</el-select>
						</el-form-item>
						<el-form-item label="数据库名称" required>
							<el-select
								v-model="databaseName"
								filterable
								placeholder="请选择数据库"
								style="width: 220px"
								:loading="databaseLoading"
								@change="handleDatabaseChange"
							>
								<el-option v-for="item in databases" :key="item.name" :label="item.name" :value="item.name" />
							</el-select>
						</el-form-item>
					</el-form>
				</div>

				<div class="query-main">
					<aside class="table-explorer">
						<div class="explorer-title">数据表/视图：{{ tables.length }}个</div>
						<el-input v-model="tableKeyword" clearable placeholder="中文注释/表名称" @keyup.enter="loadTables">
							<template #append>
								<el-button icon="Search" @click="loadTables" />
							</template>
						</el-input>

						<el-scrollbar v-loading="tableLoading" always class="table-list">
							<el-empty v-if="!datasourceId || !databaseName" :image-size="72" description="请选择数据源和数据库" />
							<el-empty v-else-if="tables.length === 0" :image-size="72" description="暂无数据表或视图" />
							<div v-for="table in tables" v-else :key="table.tableName" class="table-node">
								<div class="table-node__header" @click="selectTable(table)">
									<el-button
										text
										:icon="expandedTables.has(table.tableName) ? 'ArrowDown' : 'ArrowRight'"
										@click.stop="toggleTable(table)"
									/>
									<div class="table-node__name">
										<span>{{ table.tableComment || table.tableName }}</span>
										<small>{{ table.tableName }}</small>
									</div>
								</div>
								<div v-if="expandedTables.has(table.tableName)" class="column-list">
									<div v-if="columnLoadingTable === table.tableName" class="column-status">字段加载中...</div>
									<div v-else-if="!(tableColumns[table.tableName] || []).length" class="column-status">暂无字段信息</div>
									<div v-for="column in tableColumns[table.tableName] || []" v-else :key="columnName(column)" class="column-item">
										<span>{{ columnName(column) }}</span>
										<small>{{ column.typeName || column.dataType || '--' }}</small>
									</div>
								</div>
							</div>
						</el-scrollbar>
					</aside>

					<section class="query-console">
						<div class="query-tabs-toolbar">
							<el-tabs v-model="activeTabId" type="card" closable class="query-tabs" @tab-remove="removeQueryTab">
								<el-tab-pane v-for="tab in queryTabs" :key="tab.id" :label="tab.title" :name="tab.id" />
							</el-tabs>
							<el-button icon="Plus" title="新增查询" @click="addQueryTab" />
							<el-button type="primary" icon="VideoPlay" :loading="executing" @click="runQuery">运行</el-button>
						</div>

						<code-editor
							v-if="activeQuery"
							:model-value="activeQuery.sql"
							mode="text/x-sql"
							theme="idea"
							:height="210"
							@update:model-value="updateActiveSql"
						/>

						<div class="result-toolbar">
							<div class="result-toolbar__left">
								<el-button text icon="FullScreen" @click="toggleFullscreen">{{ isFullscreen ? '退出全屏' : '全屏' }}</el-button>
								<el-button text icon="Download" :disabled="!hasResult" :loading="exporting" @click="handleExport">导出结果</el-button>
							</div>
							<div v-if="hasResult" class="result-summary">
								第 {{ currentPage }} 页，本页 {{ resultRowCount }} 行<span v-if="queryResult.elapsedMs !== undefined"
									>，耗时 {{ queryResult.elapsedMs }} ms</span
								>
								<span v-if="hasMore">（还有更多数据）</span>
							</div>
							<div v-if="hasResult" class="result-pagination">
								<el-button :disabled="currentPage <= 1 || executing" @click="changePage(currentPage - 1)">上一页</el-button>
								<span>第 {{ currentPage }} 页</span>
								<el-button :disabled="!hasMore || executing" @click="changePage(currentPage + 1)">下一页</el-button>
							</div>
							<el-button type="primary" plain disabled>高级搜索</el-button>
						</div>

						<div class="result-panel">
							<el-alert v-if="queryError" :title="queryError" type="error" show-icon :closable="false" class="result-error" />
							<el-auto-resizer v-else-if="hasResult" @resize="handleVirtualResize">
								<template #default="{ width, height }">
									<el-table-v2
										v-if="width > 0 && height > 0"
										v-loading="executing"
										:columns="virtualColumns"
										:data="virtualRows"
										:width="width"
										:height="height"
										:row-height="40"
										:header-height="44"
										row-key="__rowKey"
										fixed
										scrollbar-always-on
										@scroll="handleVirtualScroll"
									/>
								</template>
							</el-auto-resizer>
							<el-empty v-else :description="executing ? '查询执行中...' : '暂无数据'" />
						</div>
					</section>
				</div>
			</template>
		</div>
	</div>
</template>

<script setup lang="ts" name="DataPlatformDataQueryWorkbench">
import { h } from 'vue';
import type { Column } from 'element-plus';
import type {
	DataQueryColumn,
	DataQueryDatabase,
	DataQueryDatasource,
	DataQueryExecuteResult,
	DataQueryExecuteRequest,
	DataQueryPageRequest,
	DataQueryResultColumn,
	DataQueryTable,
} from '/@/types/dataPlatform/dataQuery';
import {
	executeDataQueryPage,
	exportDataQuery,
	fetchDataQueryColumns,
	fetchDataQueryDatabases,
	fetchDataQueryDatasources,
	fetchDataQueryTables,
} from '/@/api/dataPlatform/dataQuery';
import { useMessage } from '/@/hooks/message';
import { handleBlobFile } from '/@/utils/other';

interface QueryTab {
	id: string;
	title: string;
	sql: string;
}

const CodeEditor = defineAsyncComponent(() => import('/@/components/CodeEditor/index.vue'));
const workbenchRef = ref<HTMLElement>();
const category = ref<'RELATIONAL' | 'BIG_DATA'>('RELATIONAL');
const datasources = ref<DataQueryDatasource[]>([]);
const datasourceType = ref('');
const datasourceId = ref('');
const databaseName = ref('');
const databases = ref<DataQueryDatabase[]>([]);
const databaseLoading = ref(false);
const tableKeyword = ref('');
const tableLoading = ref(false);
const tables = ref<DataQueryTable[]>([]);
const expandedTables = ref(new Set<string>());
const tableColumns = reactive<Record<string, DataQueryColumn[]>>({});
const columnLoadingTable = ref('');
const queryTabs = ref<QueryTab[]>([{ id: 'query-1', title: '查询1', sql: '' }]);
const activeTabId = ref('query-1');
const querySequence = ref(1);
const executing = ref(false);
const exporting = ref(false);
const queryError = ref('');
const isFullscreen = ref(false);
const queryResult = shallowRef<DataQueryExecuteResult>({ columns: [], rows: [] });
const currentPage = ref(1);
const pageSize = 50;
const hasMore = ref(false);
const querySnapshot = ref<Omit<DataQueryPageRequest, 'page' | 'pageSize'> | null>(null);
const resultColumnWidth = 160;
const resultIndexWidth = 60;
const columnOverscan = 2;
const tableViewportWidth = ref(0);
const horizontalScrollLeft = ref(0);
const visibleColumnStart = ref(0);

const datasourceTypes = computed(() => [...new Set(datasources.value.map((item) => item.dsType).filter(Boolean))]);
const filteredDatasources = computed(() => datasources.value.filter((item) => item.dsType === datasourceType.value));
const selectedDatasource = computed(() => datasources.value.find((item) => item.id === datasourceId.value));
const querySchema = computed(() => {
	const type = selectedDatasource.value?.dsType?.toLowerCase();
	return type === 'mysql' || type === 'doris' ? databaseName.value : undefined;
});
const activeQuery = computed(() => queryTabs.value.find((item) => item.id === activeTabId.value));
const resultColumns = computed<DataQueryResultColumn[]>(() =>
	(queryResult.value.columns || []).map((column) => (typeof column === 'string' ? { name: column } : column))
);
const hasResult = computed(() => queryResult.value.columns.length > 0 || queryResult.value.rows.length > 0);
const resultRowCount = computed(() => queryResult.value.rowCount ?? queryResult.value.rows.length);
const virtualRows = computed(() =>
	queryResult.value.rows.map((row, index) => ({
		...row,
		__rowKey: `${currentPage.value}-${index}`,
	}))
);

const formatCellValue = (value: unknown) => {
	if (value === null || value === undefined) return '';
	if (typeof value === 'object') {
		try {
			return JSON.stringify(value);
		} catch {
			return String(value);
		}
	}
	return String(value);
};

const createCell = (value: unknown, className = 'virtual-cell') => {
	const text = formatCellValue(value);
	return h('div', { class: className, title: text }, text);
};

const visibleColumnCount = computed(() => {
	const availableWidth = Math.max(resultColumnWidth, tableViewportWidth.value - resultIndexWidth);
	return Math.ceil(availableWidth / resultColumnWidth) + columnOverscan * 2;
});

const updateVisibleColumnStart = (scrollLeft: number) => {
	const nextStart = Math.max(0, Math.floor(scrollLeft / resultColumnWidth) - columnOverscan);
	if (nextStart !== visibleColumnStart.value) visibleColumnStart.value = nextStart;
};

const handleVirtualResize = ({ width }: { width: number; height: number }) => {
	tableViewportWidth.value = width;
	updateVisibleColumnStart(horizontalScrollLeft.value);
};

const handleVirtualScroll = ({ scrollLeft }: { scrollLeft: number; scrollTop: number }) => {
	horizontalScrollLeft.value = scrollLeft;
	updateVisibleColumnStart(scrollLeft);
};

const virtualColumns = computed<Column<Record<string, unknown>>[]>(() => {
	const start = Math.min(visibleColumnStart.value, Math.max(0, resultColumns.value.length - 1));
	const end = Math.min(resultColumns.value.length, start + visibleColumnCount.value);
	const leftSpacerWidth = start * resultColumnWidth;
	const rightSpacerWidth = (resultColumns.value.length - end) * resultColumnWidth;
	const columns: Column<Record<string, unknown>>[] = [{
		key: '__index',
		dataKey: '__index',
		title: '#',
		width: resultIndexWidth,
		fixed: 'left',
		align: 'center',
		cellRenderer: ({ rowIndex }) => createCell(resultIndex(rowIndex), 'virtual-cell virtual-cell--index'),
	}];
	if (leftSpacerWidth > 0) {
		columns.push({ key: '__leftSpacer', dataKey: '__leftSpacer', title: '', width: leftSpacerWidth, cellRenderer: () => null });
	}
	columns.push(
		...resultColumns.value.slice(start, end).map((column) => ({
			key: column.name,
			dataKey: column.name,
			title: column.name,
			width: resultColumnWidth,
			minWidth: 150,
			cellRenderer: ({ cellData }: { cellData: unknown }) => createCell(cellData),
		}))
	);
	if (rightSpacerWidth > 0) {
		columns.push({ key: '__rightSpacer', dataKey: '__rightSpacer', title: '', width: rightSpacerWidth, cellRenderer: () => null });
	}
	return columns;
});

const datasourceTypeLabel = (type: string) => {
	const labels: Record<string, string> = { mysql: 'MySQL', pg: 'PostgreSQL', doris: 'Doris', oracle: 'Oracle', mssql: 'SQL Server' };
	return labels[type.toLowerCase()] || type;
};

const datasourceLabel = (item: DataQueryDatasource) => item.displayName || item.name;
const columnName = (column: DataQueryColumn) => column.columnName || column.name || '--';

const clearQuerySession = () => {
	queryResult.value = { columns: [], rows: [] };
	queryError.value = '';
	currentPage.value = 1;
	hasMore.value = false;
	querySnapshot.value = null;
};

watch(activeTabId, clearQuerySession);

const clearTableMetadata = () => {
	tables.value = [];
	expandedTables.value = new Set<string>();
	Object.keys(tableColumns).forEach((key) => delete tableColumns[key]);
};

const clearExplorer = () => {
	databaseName.value = '';
	databases.value = [];
	clearTableMetadata();
};

const loadDatasources = async () => {
	try {
		const response = await fetchDataQueryDatasources();
		const data = response.data as unknown as DataQueryDatasource[] | { records?: DataQueryDatasource[] };
		const records = Array.isArray(data) ? data : data?.records || [];
		datasources.value = records.map((item) => ({ ...item, id: String(item.id) }));
		if (datasourceTypes.value.length > 0) {
			datasourceType.value = datasourceTypes.value[0];
			datasourceId.value = filteredDatasources.value[0]?.id || '';
			if (datasourceId.value) await loadDatabases();
		}
	} catch (error: any) {
		useMessage().error(error?.msg || '加载关系型数据源失败');
	}
};

const handleDatasourceTypeChange = () => {
	datasourceId.value = '';
	clearExplorer();
	clearQuerySession();
};

const handleDatasourceChange = async () => {
	clearExplorer();
	clearQuerySession();
	await loadDatabases();
};

const loadDatabases = async () => {
	if (!datasourceId.value) return;
	try {
		databaseLoading.value = true;
		const response = await fetchDataQueryDatabases(datasourceId.value);
		const data = response.data as unknown as DataQueryDatabase[];
		databases.value = Array.isArray(data) ? data.filter((item) => item?.name) : [];
		databaseName.value = databases.value.find((item) => item.defaultDatabase)?.name || databases.value[0]?.name || '';
		if (databaseName.value) await loadTables();
	} catch (error: any) {
		useMessage().error(error?.msg || '加载数据库失败');
	} finally {
		databaseLoading.value = false;
	}
};

const loadTables = async () => {
	if (!datasourceId.value || !databaseName.value) {
		tables.value = [];
		return;
	}
	try {
		tableLoading.value = true;
		const response = await fetchDataQueryTables(datasourceId.value, {
			schema: querySchema.value,
			keyword: tableKeyword.value.trim(),
			current: 1,
			size: 500,
		});
		const data = response.data as unknown as DataQueryTable[] | { records?: DataQueryTable[] };
		tables.value = Array.isArray(data) ? data : data?.records || [];
		expandedTables.value = new Set<string>();
	} catch (error: any) {
		useMessage().error(error?.msg || '加载数据表失败');
	} finally {
		tableLoading.value = false;
	}
};

const handleDatabaseChange = async () => {
	clearTableMetadata();
	clearQuerySession();
	await loadTables();
};

const toggleTable = async (table: DataQueryTable) => {
	const next = new Set(expandedTables.value);
	if (next.has(table.tableName)) {
		next.delete(table.tableName);
		expandedTables.value = next;
		return;
	}
	next.add(table.tableName);
	expandedTables.value = next;
	if (tableColumns[table.tableName]) return;
	try {
		columnLoadingTable.value = table.tableName;
		const response = await fetchDataQueryColumns(datasourceId.value, querySchema.value, table.tableName);
		tableColumns[table.tableName] = response.data || [];
	} catch (error: any) {
		useMessage().error(error?.msg || '加载字段结构失败');
		tableColumns[table.tableName] = [];
	} finally {
		columnLoadingTable.value = '';
	}
};

const loadTableColumns = async (table: DataQueryTable) => {
	if (tableColumns[table.tableName]) return tableColumns[table.tableName];
	try {
		columnLoadingTable.value = table.tableName;
		const response = await fetchDataQueryColumns(datasourceId.value, querySchema.value, table.tableName);
		tableColumns[table.tableName] = response.data || [];
		return tableColumns[table.tableName];
	} catch (error: any) {
		useMessage().error(error?.msg || '加载字段结构失败');
		tableColumns[table.tableName] = [];
		return [];
	} finally {
		columnLoadingTable.value = '';
	}
};

const selectTable = async (table: DataQueryTable) => {
	if (!activeQuery.value) return;
	const columns = await loadTableColumns(table);
	const primaryKeys = columns.filter((column) => column.primaryKey === true || Number(column.primaryKey) === 1).map(columnName);
	const orderBy = primaryKeys.length > 0 ? `\nORDER BY ${primaryKeys.join(', ')}` : '';
	const tableReference = querySchema.value ? `${querySchema.value}.${table.tableName}` : table.tableName;
	activeQuery.value.sql = `SELECT *\nFROM ${tableReference}${orderBy};`;
	clearQuerySession();
	if (primaryKeys.length === 0) useMessage().warning('该表未检测到主键，请补充稳定的 ORDER BY 后再进行分页查询');
};

const addQueryTab = () => {
	querySequence.value += 1;
	const id = `query-${Date.now()}`;
	queryTabs.value.push({ id, title: `查询${querySequence.value}`, sql: '' });
	activeTabId.value = id;
};

const removeQueryTab = (id: string | number) => {
	const tabId = String(id);
	if (queryTabs.value.length === 1) {
		queryTabs.value[0].sql = '';
		return;
	}
	const index = queryTabs.value.findIndex((item) => item.id === tabId);
	queryTabs.value = queryTabs.value.filter((item) => item.id !== tabId);
	if (activeTabId.value === tabId) {
		activeTabId.value = queryTabs.value[Math.max(0, index - 1)]?.id || queryTabs.value[0].id;
	}
};

const updateActiveSql = (sql: string) => {
	if (activeQuery.value) {
		activeQuery.value.sql = sql;
		clearQuerySession();
	}
};

const buildQuerySnapshot = (): Omit<DataQueryPageRequest, 'page' | 'pageSize'> => {
	const payload: Omit<DataQueryPageRequest, 'page' | 'pageSize'> = {
		datasourceId: String(datasourceId.value),
		sql: activeQuery.value?.sql.trim() || '',
		timeoutSeconds: 30,
	};
	if (querySchema.value) payload.schema = querySchema.value;
	return payload;
};

const validateQuery = () => {
	if (!datasourceId.value || !databaseName.value) {
		useMessage().warning('请先选择数据源和数据库');
		return false;
	}
	if (!activeQuery.value?.sql.trim()) {
		useMessage().warning('请输入需要执行的查询语句');
		return false;
	}
	return true;
};

const requestQueryPage = async (page: number, resetResult = false) => {
	if (!querySnapshot.value || executing.value) return;
	try {
		executing.value = true;
		queryError.value = '';
		const response = await executeDataQueryPage({ ...querySnapshot.value, page, pageSize });
		queryResult.value = { columns: [], rows: [], ...(response.data || {}) };
		currentPage.value = response.data?.page || page;
		hasMore.value = Boolean(response.data?.hasMore);
	} catch (error: any) {
		const message = error?.msg || '查询执行失败';
		if (resetResult) {
			queryResult.value = { columns: [], rows: [] };
			queryError.value = message;
		} else {
			useMessage().error(message);
		}
	} finally {
		executing.value = false;
	}
};

const runQuery = async () => {
	if (!validateQuery()) return;
	const snapshot = buildQuerySnapshot();
	if (!/\border\s+by\b/i.test(snapshot.sql)) useMessage().warning('当前 SQL 未包含稳定的 ORDER BY，翻页时可能出现重复或遗漏数据');
	querySnapshot.value = snapshot;
	currentPage.value = 1;
	hasMore.value = false;
	await requestQueryPage(1, true);
};

const changePage = async (page: number) => {
	if (page < 1 || (page > currentPage.value && !hasMore.value)) return;
	await requestQueryPage(page);
};

const resultIndex = (index: number) => (currentPage.value - 1) * pageSize + index + 1;

const handleExport = async () => {
	if (!querySnapshot.value || !hasResult.value) return;
	try {
		exporting.value = true;
		const exportPayload: DataQueryExecuteRequest = { ...querySnapshot.value, maxRows: 1000 };
		const response = await exportDataQuery(exportPayload);
		handleBlobFile(response, `query-result-${Date.now()}.csv`);
	} catch (error: any) {
		useMessage().error(error?.msg || '导出查询结果失败');
	} finally {
		exporting.value = false;
	}
};

const handleFullscreenChange = () => {
	isFullscreen.value = document.fullscreenElement === workbenchRef.value;
};

const toggleFullscreen = async () => {
	if (!workbenchRef.value) return;
	if (document.fullscreenElement) {
		await document.exitFullscreen();
	} else {
		await workbenchRef.value.requestFullscreen();
	}
};

onMounted(() => {
	document.addEventListener('fullscreenchange', handleFullscreenChange);
	loadDatasources();
});

onBeforeUnmount(() => document.removeEventListener('fullscreenchange', handleFullscreenChange));
</script>

<style scoped>
.data-query-workbench {
	height: 100%;
}

.workbench-shell {
	display: flex;
	flex-direction: column;
	height: calc(100vh - 122px);
	min-height: 0;
	overflow: hidden;
}

.category-tabs {
	margin: -10px 0 0;
}

.category-tabs :deep(.el-tabs__header) {
	margin-bottom: 16px;
}

.category-tabs :deep(.el-tabs__content) {
	display: none;
}

.selector-panel {
	padding: 18px 20px 0;
	margin-bottom: 16px;
	border: 1px solid var(--el-border-color-light);
	border-radius: var(--border-radius-md);
	background: var(--el-bg-color);
}

.selector-form :deep(.el-form-item) {
	margin-right: 28px;
}

.big-data-placeholder {
	display: flex;
	flex: 1;
	align-items: center;
	justify-content: center;
	min-height: 560px;
	border: 1px solid var(--el-border-color-light);
	border-radius: var(--border-radius-md);
}

.empty-description {
	font-size: 16px;
	color: var(--el-text-color-regular);
}

.empty-description small {
	display: block;
	margin-top: 14px;
	font-size: 13px;
	color: var(--el-text-color-secondary);
}

.query-main {
	display: grid;
	grid-template-columns: 280px minmax(0, 1fr);
	flex: 1;
	min-height: 0;
	border: 1px solid var(--el-border-color-light);
	border-radius: var(--border-radius-md);
	overflow: hidden;
}

.table-explorer {
	display: flex;
	flex-direction: column;
	gap: 12px;
	padding: 16px 12px;
	border-right: 1px solid var(--el-border-color-light);
	background: var(--el-bg-color);
	min-width: 0;
	min-height: 0;
	overflow: hidden;
}

.explorer-title {
	font-weight: 600;
	color: var(--el-text-color-primary);
}

.table-list {
	flex: 1 1 0;
	height: 0;
	min-height: 0;
}

.table-node {
	border-bottom: 1px solid var(--el-border-color-lighter);
}

.table-node__header {
	display: flex;
	align-items: center;
	min-height: 54px;
	padding-right: 8px;
	cursor: pointer;
}

.table-node__header:hover {
	background: var(--el-fill-color-light);
}

.table-node__name {
	display: flex;
	flex: 1;
	flex-direction: column;
	min-width: 0;
}

.table-node__name span,
.table-node__name small {
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}

.table-node__name span {
	color: var(--el-color-primary);
}

.table-node__name small {
	margin-top: 3px;
	color: var(--el-text-color-secondary);
}

.column-list {
	padding: 4px 12px 10px 38px;
	background: var(--el-fill-color-extra-light);
}

.column-item {
	display: flex;
	justify-content: space-between;
	gap: 8px;
	padding: 5px 0;
	font-size: 12px;
}

.column-item small,
.column-status {
	color: var(--el-text-color-secondary);
}

.column-status {
	padding: 8px 0;
	font-size: 12px;
}

.query-console {
	display: flex;
	flex-direction: column;
	min-width: 0;
	min-height: 0;
	overflow: hidden;
	background: var(--el-bg-color);
}

.query-tabs-toolbar {
	display: flex;
	align-items: flex-start;
	gap: 8px;
	padding: 10px 12px 0;
}

.query-tabs {
	flex: 1;
	min-width: 0;
}

.query-tabs :deep(.el-tabs__header) {
	margin-bottom: 0;
}

.query-tabs :deep(.el-tabs__content) {
	display: none;
}

.query-console :deep(.code-editor) {
	flex: none;
	height: 210px !important;
	min-height: 210px;
	max-height: 210px;
	overflow: hidden;
	border-right: none;
	border-left: none;
}

.query-console :deep(.CodeMirror) {
	height: 210px !important;
}

.result-toolbar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 12px;
	min-height: 54px;
	padding: 0 14px;
	border-bottom: 1px solid var(--el-border-color-light);
}

.result-toolbar__left {
	display: flex;
	align-items: center;
}

.result-summary {
	flex: 1;
	text-align: center;
	font-size: 13px;
	color: var(--el-text-color-secondary);
}

.result-panel {
	flex: 1 1 0;
	min-height: 140px;
	overflow: hidden;
}

.result-panel :deep(.el-auto-resizer),
.result-panel :deep(.el-table-v2) {
	width: 100%;
	height: 100%;
}

.result-panel :deep(.el-table-v2__root) {
	border: 1px solid var(--el-table-border-color);
}

.result-panel :deep(.el-table-v2__header-cell),
.result-panel :deep(.el-table-v2__row-cell) {
	border-right: 1px solid var(--el-table-border-color);
}

.result-panel :deep(.virtual-cell) {
	width: 100%;
	overflow: hidden;
	text-overflow: ellipsis;
	white-space: nowrap;
}

.result-panel :deep(.virtual-cell--index) {
	text-align: center;
}

.result-pagination {
	display: flex;
	flex: none;
	align-items: center;
	gap: 12px;
	white-space: nowrap;
}

.result-panel > .el-empty {
	height: 100%;
}

.result-error {
	margin: 16px;
}

.data-query-workbench:fullscreen {
	padding: 16px;
	background: var(--el-bg-color-page);
}

.data-query-workbench:fullscreen .workbench-shell {
	height: calc(100vh - 32px);
	min-height: 0;
}

@media (max-width: 1100px) {
	.query-main {
		grid-template-columns: 240px minmax(0, 1fr);
	}

	.selector-form :deep(.el-form-item) {
		margin-right: 12px;
	}
}

@media (max-height: 850px) {
	.query-console :deep(.code-editor),
	.query-console :deep(.CodeMirror) {
		height: 160px !important;
		min-height: 160px;
		max-height: 160px;
	}

	.result-toolbar {
		min-height: 48px;
	}
}
</style>
