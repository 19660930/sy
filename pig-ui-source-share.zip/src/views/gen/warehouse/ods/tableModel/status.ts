import type { ManualSyncItemStatus, ManualSyncStatus } from '/@/types/dataPlatform/odsManualSync';

const statusLabels: Record<ManualSyncStatus | ManualSyncItemStatus, string> = {
	SUBMITTED: '已入队',
	RUNNING: '执行中',
	SUCCESS: '成功',
	PARTIAL_SUCCESS: '部分成功',
	FAILURE: '失败',
};

export const terminalBatchStatuses: ManualSyncStatus[] = ['SUCCESS', 'PARTIAL_SUCCESS', 'FAILURE'];

export const syncStatusLabel = (status: ManualSyncStatus | ManualSyncItemStatus) => statusLabels[status] || status;

export const syncStatusTagType = (status: ManualSyncStatus | ManualSyncItemStatus) => {
	if (status === 'SUCCESS') return 'success';
	if (status === 'FAILURE') return 'danger';
	if (status === 'PARTIAL_SUCCESS') return 'warning';
	if (status === 'RUNNING') return 'primary';
	return 'info';
};
