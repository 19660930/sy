<template>
	<el-drawer v-model="visible" title="同步批次详情" size="78%" destroy-on-close @closed="stopPolling">
		<div v-loading="loading" class="batch-detail">
			<template v-if="batch">
				<el-descriptions :column="4" border class="mb20">
					<el-descriptions-item label="批次ID">{{ batch.id }}</el-descriptions-item>
					<el-descriptions-item label="批次状态">
						<el-tag :type="syncStatusTagType(batch.syncStatus)">{{ syncStatusLabel(batch.syncStatus) }}</el-tag>
					</el-descriptions-item>
					<el-descriptions-item label="源数据源">{{ datasourceName(batch.sourceDatasourceId, 'SOURCE') }}</el-descriptions-item>
					<el-descriptions-item label="目标数据源">{{ datasourceName(batch.targetDatasourceId, 'TARGET') }}</el-descriptions-item>
					<el-descriptions-item label="表总数">{{ batch.totalTables }}</el-descriptions-item>
					<el-descriptions-item label="成功/失败">{{ batch.successTables }} / {{ batch.failedTables }}</el-descriptions-item>
					<el-descriptions-item label="开始时间">{{ batch.startTime || '--' }}</el-descriptions-item>
					<el-descriptions-item label="结束时间">{{ batch.endTime || '--' }}</el-descriptions-item>
				</el-descriptions>

				<el-alert v-if="batch.errorSummary" :title="batch.errorSummary" type="error" show-icon :closable="false" class="mb20" />

				<el-table :data="batch.items || []" border>
					<el-table-column type="index" label="#" width="55" />
					<el-table-column prop="sourceTable" label="源表" min-width="170" show-overflow-tooltip />
					<el-table-column prop="targetTable" label="目标表" min-width="180" show-overflow-tooltip />
					<el-table-column prop="sourceTableComment" label="表注释" min-width="160" show-overflow-tooltip>
						<template #default="{ row }">{{ row.sourceTableComment || '--' }}</template>
					</el-table-column>
					<el-table-column label="状态" width="110">
						<template #default="{ row }">
							<el-tag :type="syncStatusTagType(row.syncStatus)">{{ syncStatusLabel(row.syncStatus) }}</el-tag>
						</template>
					</el-table-column>
					<el-table-column label="写入行数" width="120">
						<template #default="{ row }">{{ row.rowsWritten ?? '--' }}</template>
					</el-table-column>
					<el-table-column prop="startTime" label="开始时间" width="180">
						<template #default="{ row }">{{ row.startTime || '--' }}</template>
					</el-table-column>
					<el-table-column prop="endTime" label="结束时间" width="180">
						<template #default="{ row }">{{ row.endTime || '--' }}</template>
					</el-table-column>
					<el-table-column prop="errorSummary" label="错误信息" min-width="260" show-overflow-tooltip>
						<template #default="{ row }">
							<span :class="{ 'error-text': row.errorSummary }">{{ row.errorSummary || '--' }}</span>
						</template>
					</el-table-column>
				</el-table>

				<div v-if="isPolling" class="polling-tip">
					<el-icon class="is-loading"><Loading /></el-icon>
					状态每2秒自动刷新
				</div>
			</template>
		</div>
	</el-drawer>
</template>

<script setup lang="ts" name="OdsManualSyncBatchDetail">
import { getManualSyncBatch } from '/@/api/dataPlatform/odsManualSync';
import { useMessage } from '/@/hooks/message';
import type { ManualSyncBatch, ManualSyncDatasource, ManualSyncDatasourceKind } from '/@/types/dataPlatform/odsManualSync';
import { syncStatusLabel, syncStatusTagType, terminalBatchStatuses } from './status';

const props = defineProps<{
	sourceDatasources: ManualSyncDatasource[];
	targetDatasources: ManualSyncDatasource[];
}>();
const emit = defineEmits<{ terminal: [] }>();
const visible = ref(false);
const loading = ref(false);
const batch = ref<ManualSyncBatch>();
const batchId = ref('');
const timer = ref<ReturnType<typeof setTimeout>>();
const isPolling = ref(false);

const datasourceName = (id: string, kind: ManualSyncDatasourceKind) => {
	const options = kind === 'SOURCE' ? props.sourceDatasources : props.targetDatasources;
	const item = options.find((source) => source.id === id);
	return item?.displayName || item?.name || id;
};

const stopPolling = () => {
	if (timer.value) clearTimeout(timer.value);
	timer.value = undefined;
	isPolling.value = false;
};

const schedulePolling = () => {
	stopPolling();
	if (!visible.value || !batch.value || terminalBatchStatuses.includes(batch.value.syncStatus)) return;
	isPolling.value = true;
	timer.value = setTimeout(() => loadBatch(false), 2000);
};

const loadBatch = async (showLoading = true) => {
	if (!batchId.value) return;
	try {
		if (showLoading) loading.value = true;
		const previousStatus = batch.value?.syncStatus;
		const res = await getManualSyncBatch(batchId.value);
		batch.value = res.data as ManualSyncBatch;
		if (terminalBatchStatuses.includes(batch.value.syncStatus)) {
			stopPolling();
			if (previousStatus && !terminalBatchStatuses.includes(previousStatus)) emit('terminal');
		} else {
			schedulePolling();
		}
	} catch (error: any) {
		stopPolling();
		useMessage().error(error?.msg || '获取同步批次详情失败');
	} finally {
		loading.value = false;
	}
};

const openDrawer = async (id: string) => {
	stopPolling();
	batchId.value = id;
	batch.value = undefined;
	visible.value = true;
	await loadBatch();
};

onBeforeUnmount(stopPolling);

defineExpose({ openDrawer });
</script>

<style scoped>
.batch-detail {
	min-height: 240px;
}

.polling-tip {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 6px;
	margin-top: 16px;
	color: var(--el-text-color-secondary);
}

.error-text {
	color: var(--el-color-danger);
}
</style>
