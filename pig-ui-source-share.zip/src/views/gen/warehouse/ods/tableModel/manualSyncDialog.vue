<template>
	<el-dialog v-model="visible" title="ODS手动同步" width="1100px" :close-on-click-modal="false" draggable destroy-on-close>
		<el-alert
			title="当前为全量覆盖同步：后端将重建已纳管的 PostgreSQL 目标表并写入完整源表数据。"
			type="warning"
			show-icon
			:closable="false"
			class="mb20"
		/>

		<el-form ref="dataFormRef" v-loading="loading" :model="form" :rules="dataRules" label-width="130px" class="sync-form">
			<el-row :gutter="36" class="sync-config-grid">
				<el-col :span="12" class="mb20">
					<el-form-item label="MySQL源" prop="sourceDatasourceId">
						<el-select
							v-model="form.sourceDatasourceId"
							filterable
							placeholder="请选择MySQL源数据源"
							style="width: 100%"
							@change="handleSourceChange"
						>
							<el-option v-for="item in sourceDatasources" :key="item.id" :value="item.id" :label="datasourceLabel(item)" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="PostgreSQL目标" prop="targetDatasourceId">
						<el-select v-model="form.targetDatasourceId" filterable placeholder="请选择PostgreSQL目标数据源" style="width: 100%">
							<el-option v-for="item in targetDatasources" :key="item.id" :value="item.id" :label="datasourceLabel(item)" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="SeaTunnel档案" prop="seatunnelProfileId">
						<el-select v-model="form.seatunnelProfileId" placeholder="请选择SeaTunnel档案" style="width: 100%">
							<el-option v-for="item in seatunnelProfiles" :key="item.id" :value="item.id" :label="`${item.profileName}（${item.runtimeMode}）`" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="目标表前缀" prop="targetPrefix">
						<el-input v-model="form.targetPrefix" maxlength="16" placeholder="ods_" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="批次大小" prop="batchSize">
						<el-input-number v-model="form.batchSize" :min="100" :max="100000" :step="100" controls-position="right" style="width: 100%" />
					</el-form-item>
				</el-col>
			</el-row>

			<el-form-item label="选择源表" prop="tableNames">
				<div class="source-table-panel">
					<div class="source-table-toolbar">
						<el-input v-model="tableKeyword" clearable placeholder="输入表名搜索" style="width: 280px" @keyup.enter="loadSourceTables">
							<template #append>
								<el-button icon="Search" @click="loadSourceTables" />
							</template>
						</el-input>
						<span>已选择 {{ form.tableNames.length }} / 50 张表</span>
					</div>
					<el-table
						ref="sourceTableRef"
						v-loading="tableLoading"
						:data="sourceTables"
						row-key="tableName"
						border
						height="340"
						empty-text="请选择MySQL源数据源后加载源表"
						@selection-change="handleTableSelection"
					>
						<el-table-column type="selection" width="50" :selectable="tableSelectable" />
						<el-table-column prop="tableName" label="源表名称" min-width="220" show-overflow-tooltip />
						<el-table-column prop="remarks" label="表注释" min-width="220" show-overflow-tooltip>
							<template #default="{ row }">{{ row.remarks || '--' }}</template>
						</el-table-column>
						<el-table-column prop="tableType" label="对象类型" width="130" />
						<el-table-column label="目标表" min-width="220" show-overflow-tooltip>
							<template #default="{ row }">{{ `${form.targetPrefix || ''}${row.tableName}`.toLowerCase() }}</template>
						</el-table-column>
					</el-table>
				</div>
			</el-form-item>
		</el-form>

		<template #footer>
			<el-button @click="visible = false">{{ $t('common.cancelButtonText') }}</el-button>
			<el-button type="primary" :loading="submitting" @click="onSubmit">提交同步</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="OdsManualSyncDialog">
import type { FormInstance, FormRules, TableInstance } from 'element-plus';
import {
	fetchManualSyncDatasources,
	fetchManualSyncSeaTunnelProfiles,
	fetchManualSyncSourceTables,
	submitManualSync,
} from '/@/api/dataPlatform/odsManualSync';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type {
	ManualSyncDatasource,
	ManualSyncSeaTunnelProfile,
	ManualSyncSourceTable,
	ManualSyncSubmitRequest,
} from '/@/types/dataPlatform/odsManualSync';

const emit = defineEmits<{ submitted: [batchId: string] }>();
const visible = ref(false);
const loading = ref(false);
const tableLoading = ref(false);
const submitting = ref(false);
const dataFormRef = ref<FormInstance>();
const sourceTableRef = ref<TableInstance>();
const sourceDatasources = ref<ManualSyncDatasource[]>([]);
const targetDatasources = ref<ManualSyncDatasource[]>([]);
const seatunnelProfiles = ref<ManualSyncSeaTunnelProfile[]>([]);
const sourceTables = ref<ManualSyncSourceTable[]>([]);
const tableKeyword = ref('');

const form = reactive<ManualSyncSubmitRequest>({
	sourceDatasourceId: '',
	targetDatasourceId: '',
	seatunnelProfileId: '',
	tableNames: [],
	targetPrefix: 'ods_',
	batchSize: 5000,
});

const validateSeaTunnelProfile = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (seatunnelProfiles.value.length === 0) return callback(new Error('暂无可用于手动同步的SeaTunnel档案'));
	if (seatunnelProfiles.value.length > 1 && !value) return callback(new Error('请选择SeaTunnel档案'));
	callback();
};

const validateTargetPrefix = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (!value || /^[A-Za-z][A-Za-z0-9_]{0,15}$/.test(value)) return callback();
	callback(new Error('前缀必须以字母开头，且只能包含字母、数字和下划线'));
};

const dataRules: FormRules = {
	sourceDatasourceId: [{ required: true, message: '请选择MySQL源数据源', trigger: 'change' }],
	targetDatasourceId: [{ required: true, message: '请选择PostgreSQL目标数据源', trigger: 'change' }],
	seatunnelProfileId: [{ validator: validateSeaTunnelProfile, trigger: 'change' }],
	tableNames: [{ type: 'array', required: true, min: 1, max: 50, message: '请选择1至50张源表', trigger: 'change' }],
	targetPrefix: [{ validator: validateTargetPrefix, trigger: 'blur' }],
	batchSize: [
		{ required: true, message: '请输入批次大小', trigger: 'change' },
		{ type: 'number', min: 100, max: 100000, message: '批次大小范围为100至100000', trigger: 'change' },
	],
};

const datasourceLabel = (item: ManualSyncDatasource) => `${item.displayName || item.name}（${item.dsType} / ${item.dsName}）`;

const loadOptions = async () => {
	try {
		loading.value = true;
		const [sourceRes, targetRes, profileRes] = await Promise.all([
			fetchManualSyncDatasources('SOURCE'),
			fetchManualSyncDatasources('TARGET'),
			fetchManualSyncSeaTunnelProfiles(),
		]);
		sourceDatasources.value = sourceRes.data || [];
		targetDatasources.value = targetRes.data || [];
		seatunnelProfiles.value = profileRes.data || [];
		if (seatunnelProfiles.value.length === 1) form.seatunnelProfileId = seatunnelProfiles.value[0].id;
	} catch (error: any) {
		useMessage().error(error?.msg || '加载手动同步配置失败');
	} finally {
		loading.value = false;
	}
};

const loadSourceTables = async () => {
	form.tableNames = [];
	sourceTableRef.value?.clearSelection();
	if (!form.sourceDatasourceId) {
		sourceTables.value = [];
		return;
	}
	try {
		tableLoading.value = true;
		const res = await fetchManualSyncSourceTables(form.sourceDatasourceId, tableKeyword.value.trim() || undefined);
		sourceTables.value = res.data || [];
	} catch (error: any) {
		sourceTables.value = [];
		useMessage().error(error?.msg || '加载源表失败');
	} finally {
		tableLoading.value = false;
	}
};

const handleSourceChange = () => {
	tableKeyword.value = '';
	loadSourceTables();
};

const handleTableSelection = (selection: ManualSyncSourceTable[]) => {
	form.tableNames = selection.map((item) => item.tableName);
	dataFormRef.value?.validateField('tableNames').catch(() => undefined);
};

const tableSelectable = (row: ManualSyncSourceTable) => form.tableNames.includes(row.tableName) || form.tableNames.length < 50;

const openDialog = async () => {
	visible.value = true;
	Object.assign(form, {
		sourceDatasourceId: '',
		targetDatasourceId: '',
		seatunnelProfileId: '',
		tableNames: [],
		targetPrefix: 'ods_',
		batchSize: 5000,
	});
	tableKeyword.value = '';
	sourceTables.value = [];
	await nextTick();
	dataFormRef.value?.clearValidate();
	await loadOptions();
};

const onSubmit = async () => {
	const valid = await dataFormRef.value?.validate().catch(() => false);
	if (!valid) return;
	try {
		await useMessageBox().confirm(`本次将全量覆盖同步${form.tableNames.length}张表，确认继续吗？`);
	} catch {
		return;
	}

	try {
		submitting.value = true;
		const payload: ManualSyncSubmitRequest = {
			...form,
			tableNames: [...form.tableNames],
			targetPrefix: form.targetPrefix || 'ods_',
		};
		if (!payload.seatunnelProfileId) delete payload.seatunnelProfileId;
		const res = await submitManualSync(payload);
		const batchId = String(res.data);
		useMessage().success('同步任务已提交，正在后台执行');
		visible.value = false;
		emit('submitted', batchId);
	} catch (error: any) {
		useMessage().error(error?.msg || '提交手动同步失败');
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>

<style scoped>
.sync-form :deep(.el-form-item__label) {
	white-space: nowrap;
}

.source-table-panel {
	width: 100%;
}

.source-table-toolbar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin-bottom: 12px;
	color: var(--el-text-color-secondary);
}
</style>
