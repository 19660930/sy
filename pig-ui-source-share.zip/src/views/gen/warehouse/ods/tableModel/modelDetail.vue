<template>
	<el-drawer v-model="visible" title="ODS源表模型" size="72%" destroy-on-close>
		<div v-loading="loading" class="model-detail">
			<template v-if="model">
				<el-tabs v-model="activeTab">
					<el-tab-pane label="模型详情" name="detail">
						<el-descriptions :column="2" border>
							<el-descriptions-item label="源表名称">{{ model.sourceTable }}</el-descriptions-item>
							<el-descriptions-item label="ODS目标表">{{ model.targetTable }}</el-descriptions-item>
							<el-descriptions-item label="源数据源">{{ datasourceName(model.sourceDatasourceId, 'SOURCE') }}</el-descriptions-item>
							<el-descriptions-item label="目标数据源">{{ datasourceName(model.targetDatasourceId, 'TARGET') }}</el-descriptions-item>
							<el-descriptions-item label="表注释">{{ model.tableComment || '--' }}</el-descriptions-item>
							<el-descriptions-item label="对象类型">{{ model.objectType || '--' }}</el-descriptions-item>
							<el-descriptions-item label="业务系统">{{ model.businessSystem || '--' }}</el-descriptions-item>
							<el-descriptions-item label="业务域">{{ model.businessDomain || '--' }}</el-descriptions-item>
							<el-descriptions-item label="所属部门">{{ model.departmentName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="数据行数">{{ model.rowCount ?? '--' }}</el-descriptions-item>
							<el-descriptions-item label="同步状态">
								<el-tag :type="syncStatusTagType(model.syncStatus)">{{ syncStatusLabel(model.syncStatus) }}</el-tag>
							</el-descriptions-item>
							<el-descriptions-item label="最近同步时间">{{ model.lastSyncTime || '--' }}</el-descriptions-item>
							<el-descriptions-item label="最近批次ID">{{ model.latestBatchId || '--' }}</el-descriptions-item>
							<el-descriptions-item label="更新时间">{{ model.updateTime || '--' }}</el-descriptions-item>
							<el-descriptions-item label="错误摘要" :span="2">
								<span :class="{ 'error-text': model.errorSummary }">{{ model.errorSummary || '--' }}</span>
							</el-descriptions-item>
						</el-descriptions>
					</el-tab-pane>

					<el-tab-pane label="目标表结构" name="columns">
						<el-table :data="sortedColumns" border empty-text="暂无字段结构">
							<el-table-column label="#" width="55">
								<template #default="{ row, $index }">{{ row.ordinalPosition ?? $index + 1 }}</template>
							</el-table-column>
							<el-table-column prop="name" label="字段名称" min-width="160" show-overflow-tooltip />
							<el-table-column prop="typeName" label="数据类型" min-width="140" show-overflow-tooltip />
							<el-table-column label="长度/精度" width="130">
								<template #default="{ row }">{{ columnSize(row) }}</template>
							</el-table-column>
							<el-table-column label="允许为空" width="100">
								<template #default="{ row }">
									<el-tag :type="row.nullable ? 'info' : 'warning'">{{ row.nullable ? '是' : '否' }}</el-tag>
								</template>
							</el-table-column>
							<el-table-column label="主键" width="90">
								<template #default="{ row }">
									<el-tag v-if="row.primaryKey" type="success">主键</el-tag>
									<span v-else>--</span>
								</template>
							</el-table-column>
							<el-table-column label="自动递增" width="100">
								<template #default="{ row }">
									<el-tag v-if="row.autoIncrement" type="success">是</el-tag>
									<span v-else>否</span>
								</template>
							</el-table-column>
							<el-table-column prop="defaultValue" label="默认值" min-width="130" show-overflow-tooltip>
								<template #default="{ row }">{{ row.defaultValue ?? '--' }}</template>
							</el-table-column>
							<el-table-column prop="remarks" label="字段注释" min-width="220" show-overflow-tooltip>
								<template #default="{ row }">{{ row.remarks || '--' }}</template>
							</el-table-column>
						</el-table>
					</el-tab-pane>
				</el-tabs>
			</template>
		</div>
	</el-drawer>
</template>

<script setup lang="ts" name="OdsTableModelDetail">
import { fetchOdsTableModelColumns, getOdsTableModel } from '/@/api/dataPlatform/odsTableModel';
import { useMessage } from '/@/hooks/message';
import type { ManualSyncDatasource, ManualSyncDatasourceKind } from '/@/types/dataPlatform/odsManualSync';
import type { OdsTableModel, OdsTableModelColumn } from '/@/types/dataPlatform/odsTableModel';
import { syncStatusLabel, syncStatusTagType } from './status';

const props = defineProps<{
	sourceDatasources: ManualSyncDatasource[];
	targetDatasources: ManualSyncDatasource[];
}>();
const visible = ref(false);
const loading = ref(false);
const activeTab = ref('detail');
const model = ref<OdsTableModel>();
const columns = ref<OdsTableModelColumn[]>([]);
const sortedColumns = computed(() =>
	[...columns.value].sort((left, right) => (left.ordinalPosition ?? Number.MAX_SAFE_INTEGER) - (right.ordinalPosition ?? Number.MAX_SAFE_INTEGER))
);

const datasourceName = (id: string, kind: ManualSyncDatasourceKind) => {
	const options = kind === 'SOURCE' ? props.sourceDatasources : props.targetDatasources;
	const item = options.find((source) => source.id === id);
	return item?.displayName || item?.name || id;
};

const columnSize = (column: OdsTableModelColumn) => {
	if (column.size == null) return '--';
	return column.scale != null && column.scale > 0 ? `${column.size}, ${column.scale}` : String(column.size);
};

const openDrawer = async (id: string, tab: 'detail' | 'columns' = 'detail') => {
	visible.value = true;
	activeTab.value = tab;
	model.value = undefined;
	columns.value = [];
	try {
		loading.value = true;
		const [modelRes, columnRes] = await Promise.all([getOdsTableModel(id), fetchOdsTableModelColumns(id)]);
		model.value = modelRes.data as OdsTableModel;
		columns.value = (columnRes.data || []) as OdsTableModelColumn[];
	} catch (error: any) {
		visible.value = false;
		useMessage().error(error?.msg || '加载ODS源表模型失败');
	} finally {
		loading.value = false;
	}
};

defineExpose({ openDrawer });
</script>

<style scoped>
.model-detail {
	min-height: 240px;
}

.error-text {
	color: var(--el-color-danger);
}
</style>
