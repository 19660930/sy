<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<el-alert
				title="ODS源表模型由分层任务发布并执行成功后自动生成，可查看模型详情、目标表结构及同步记录。"
				type="info"
				show-icon
				:closable="false"
				class="page-alert"
			/>

			<el-tabs v-model="activeTab" class="page-tabs">
				<el-tab-pane label="源表模型" name="models">
					<el-row v-show="modelShowSearch" class="ml10">
						<el-form ref="modelQueryRef" :inline="true" :model="modelState.queryForm" @keyup.enter="getModelList">
							<el-form-item label="模型检索" prop="keyword">
								<el-input v-model="modelState.queryForm.keyword" clearable placeholder="源表、目标表或表注释" style="width: 220px" />
							</el-form-item>
							<el-form-item label="同步状态" prop="syncStatus">
								<el-select v-model="modelState.queryForm.syncStatus" clearable placeholder="全部状态" style="width: 150px">
									<el-option v-for="item in modelStatusOptions" :key="item.value" :label="item.label" :value="item.value" />
								</el-select>
							</el-form-item>
							<el-form-item label="目标数据源" prop="targetDatasourceId">
								<el-select
									v-model="modelState.queryForm.targetDatasourceId"
									clearable
									filterable
									placeholder="全部PostgreSQL目标"
									style="width: 230px"
								>
									<el-option v-for="item in targetDatasources" :key="item.id" :label="datasourceLabel(item)" :value="item.id" />
								</el-select>
							</el-form-item>
							<el-form-item>
								<el-button type="primary" icon="Search" @click="getModelList">查询</el-button>
								<el-button icon="Refresh" @click="resetModelQuery">重置</el-button>
							</el-form-item>
						</el-form>
					</el-row>

					<el-row>
						<div class="mb8" style="width: 100%">
							<el-button
								v-if="canDeleteModels"
								class="ml10"
								type="danger"
								plain
								icon="Delete"
								:disabled="selectedModels.length === 0 || deleting"
								:loading="deleting"
								@click="handleDeleteModels(selectedModels)"
							>
								批量删除
							</el-button>
							<right-toolbar
								v-model:showSearch="modelShowSearch"
								class="ml10"
								style="float: right; margin-right: 20px"
								@queryTable="getModelList(false)"
							/>
						</div>
					</el-row>

					<el-table
						ref="modelTableRef"
						v-loading="modelState.loading"
						:data="modelState.dataList"
						row-key="id"
						border
						height="calc(100vh - 350px)"
						scrollbar-always-on
						style="width: 100%"
						:cell-style="modelTableStyle.cellStyle"
						:header-cell-style="modelTableStyle.headerCellStyle"
						@selection-change="handleModelSelectionChange"
					>
						<el-table-column v-if="canDeleteModels" type="selection" width="46" />
						<el-table-column type="index" label="#" width="55" />
						<el-table-column prop="sourceTable" label="源表名称" min-width="200" show-overflow-tooltip />
						<el-table-column prop="targetTable" label="ODS目标表" min-width="220" show-overflow-tooltip />
						<el-table-column prop="tableComment" label="表注释" min-width="220" show-overflow-tooltip>
							<template #default="{ row }">{{ row.tableComment || '--' }}</template>
						</el-table-column>
						<el-table-column prop="businessSystem" label="业务系统" min-width="150" show-overflow-tooltip>
							<template #default="{ row }">{{ row.businessSystem || '--' }}</template>
						</el-table-column>
						<el-table-column prop="departmentName" label="所属部门" min-width="150" show-overflow-tooltip>
							<template #default="{ row }">{{ row.departmentName || '--' }}</template>
						</el-table-column>
						<el-table-column prop="rowCount" label="数据行数" width="110">
							<template #default="{ row }">{{ row.rowCount ?? '--' }}</template>
						</el-table-column>
						<el-table-column label="同步状态" width="110">
							<template #default="{ row }">
								<el-tag :type="syncStatusTagType(row.syncStatus)">{{ syncStatusLabel(row.syncStatus) }}</el-tag>
							</template>
						</el-table-column>
						<el-table-column prop="lastSyncTime" label="最近同步时间" width="180">
							<template #default="{ row }">{{ row.lastSyncTime || '--' }}</template>
						</el-table-column>
						<el-table-column prop="errorSummary" label="错误摘要" min-width="240" show-overflow-tooltip>
							<template #default="{ row }">
								<span :class="{ 'error-text': row.errorSummary }">{{ row.errorSummary || '--' }}</span>
							</template>
						</el-table-column>
						<el-table-column label="操作" :width="canDeleteModels ? 210 : 150" fixed="right">
							<template #default="{ row }">
								<el-button text type="primary" icon="View" @click="modelDetailRef.openDrawer(row.id, 'detail')">详情</el-button>
								<el-button text type="primary" icon="Tickets" @click="modelDetailRef.openDrawer(row.id, 'columns')">表结构</el-button>
								<el-button
									v-if="canDeleteModels"
									text
									type="danger"
									icon="Delete"
									:disabled="deleting"
									@click="handleDeleteModels([row])"
								>
									删除
								</el-button>
							</template>
						</el-table-column>
					</el-table>

					<pagination v-bind="modelState.pagination" @current-change="modelCurrentChange" @size-change="modelSizeChange" />
				</el-tab-pane>

				<el-tab-pane label="同步记录" name="batches">
					<el-row v-show="batchShowSearch" class="ml10">
						<el-form ref="batchQueryRef" :inline="true" :model="batchState.queryForm" @keyup.enter="getBatchList">
							<el-form-item label="批次状态" prop="syncStatus">
								<el-select v-model="batchState.queryForm.syncStatus" clearable placeholder="全部状态" style="width: 160px">
									<el-option v-for="item in batchStatusOptions" :key="item.value" :label="item.label" :value="item.value" />
								</el-select>
							</el-form-item>
							<el-form-item label="源数据源" prop="sourceDatasourceId">
								<el-select v-model="batchState.queryForm.sourceDatasourceId" clearable filterable placeholder="全部MySQL源" style="width: 210px">
									<el-option v-for="item in sourceDatasources" :key="item.id" :label="datasourceLabel(item)" :value="item.id" />
								</el-select>
							</el-form-item>
							<el-form-item label="目标数据源" prop="targetDatasourceId">
								<el-select
									v-model="batchState.queryForm.targetDatasourceId"
									clearable
									filterable
									placeholder="全部PostgreSQL目标"
									style="width: 230px"
								>
									<el-option v-for="item in targetDatasources" :key="item.id" :label="datasourceLabel(item)" :value="item.id" />
								</el-select>
							</el-form-item>
							<el-form-item>
								<el-button type="primary" icon="Search" @click="getBatchList">查询</el-button>
								<el-button icon="Refresh" @click="resetBatchQuery">重置</el-button>
							</el-form-item>
						</el-form>
					</el-row>

					<el-row>
						<div class="mb8" style="width: 100%">
							<right-toolbar
								v-model:showSearch="batchShowSearch"
								class="ml10"
								style="float: right; margin-right: 20px"
								@queryTable="getBatchList(false)"
							/>
						</div>
					</el-row>

					<el-table
						v-loading="batchState.loading"
						:data="batchState.dataList"
						border
						height="calc(100vh - 350px)"
						scrollbar-always-on
						style="width: 100%"
						:cell-style="batchTableStyle.cellStyle"
						:header-cell-style="batchTableStyle.headerCellStyle"
					>
						<el-table-column type="index" label="#" width="55" />
						<el-table-column prop="id" label="批次ID" min-width="190" show-overflow-tooltip />
						<el-table-column label="源数据源" min-width="160" show-overflow-tooltip>
							<template #default="{ row }">{{ datasourceName(row.sourceDatasourceId, 'SOURCE') }}</template>
						</el-table-column>
						<el-table-column label="目标数据源" min-width="170" show-overflow-tooltip>
							<template #default="{ row }">{{ datasourceName(row.targetDatasourceId, 'TARGET') }}</template>
						</el-table-column>
						<el-table-column label="状态" width="110">
							<template #default="{ row }">
								<el-tag :type="syncStatusTagType(row.syncStatus)">{{ syncStatusLabel(row.syncStatus) }}</el-tag>
							</template>
						</el-table-column>
						<el-table-column label="表进度" width="170">
							<template #default="{ row }">{{ row.successTables }}成功 / {{ row.failedTables }}失败 / 共{{ row.totalTables }}张</template>
						</el-table-column>
						<el-table-column prop="batchSize" label="批次大小" width="110" />
						<el-table-column prop="startTime" label="开始时间" width="180">
							<template #default="{ row }">{{ row.startTime || '--' }}</template>
						</el-table-column>
						<el-table-column prop="endTime" label="结束时间" width="180">
							<template #default="{ row }">{{ row.endTime || '--' }}</template>
						</el-table-column>
						<el-table-column prop="errorSummary" label="错误摘要" min-width="220" show-overflow-tooltip>
							<template #default="{ row }">
								<span :class="{ 'error-text': row.errorSummary }">{{ row.errorSummary || '--' }}</span>
							</template>
						</el-table-column>
						<el-table-column label="操作" width="100" fixed="right">
							<template #default="{ row }">
								<el-button text type="primary" icon="View" @click="batchDetailRef.openDrawer(row.id)">详情</el-button>
							</template>
						</el-table-column>
					</el-table>

					<pagination v-bind="batchState.pagination" @current-change="batchCurrentChange" @size-change="batchSizeChange" />
				</el-tab-pane>
			</el-tabs>
		</div>

		<model-detail ref="modelDetailRef" :source-datasources="sourceDatasources" :target-datasources="targetDatasources" />
		<batch-detail
			ref="batchDetailRef"
			:source-datasources="sourceDatasources"
			:target-datasources="targetDatasources"
			@terminal="handleBatchTerminal"
		/>
	</div>
</template>

<script setup lang="ts" name="DataPlatformOdsTableModel">
import type { FormInstance, TableInstance } from 'element-plus';
import { fetchManualSyncBatchPage, fetchManualSyncDatasources } from '/@/api/dataPlatform/odsManualSync';
import { deleteOdsTableModels, fetchOdsTableModelPage } from '/@/api/dataPlatform/odsTableModel';
import { type BasicTableProps, useTable } from '/@/hooks/table';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type { ManualSyncDatasource, ManualSyncDatasourceKind, ManualSyncStatus } from '/@/types/dataPlatform/odsManualSync';
import type { OdsTableModel, OdsTableModelDeleteFailure, OdsTableModelSyncStatus } from '/@/types/dataPlatform/odsTableModel';
import { auth } from '/@/utils/authFunction';
import { syncStatusLabel, syncStatusTagType } from './status';

const ModelDetail = defineAsyncComponent(() => import('./modelDetail.vue'));
const BatchDetail = defineAsyncComponent(() => import('./batchDetail.vue'));
const modelDetailRef = ref();
const batchDetailRef = ref();
const modelTableRef = ref<TableInstance>();
const modelQueryRef = ref<FormInstance>();
const batchQueryRef = ref<FormInstance>();
const activeTab = ref('models');
const modelShowSearch = ref(true);
const batchShowSearch = ref(true);
const sourceDatasources = ref<ManualSyncDatasource[]>([]);
const targetDatasources = ref<ManualSyncDatasource[]>([]);
const selectedModels = ref<OdsTableModel[]>([]);
const deleting = ref(false);
const canDeleteModels = computed(() => auth('dp_ods_model_delete'));

const modelStatusOptions: Array<{ label: string; value: OdsTableModelSyncStatus }> = [
	{ label: '已入队', value: 'SUBMITTED' },
	{ label: '执行中', value: 'RUNNING' },
	{ label: '成功', value: 'SUCCESS' },
	{ label: '失败', value: 'FAILURE' },
];

const batchStatusOptions: Array<{ label: string; value: ManualSyncStatus }> = [
	{ label: '已入队', value: 'SUBMITTED' },
	{ label: '执行中', value: 'RUNNING' },
	{ label: '成功', value: 'SUCCESS' },
	{ label: '部分成功', value: 'PARTIAL_SUCCESS' },
	{ label: '失败', value: 'FAILURE' },
];

const modelState: BasicTableProps = reactive<BasicTableProps>({
	queryForm: {
		keyword: '',
		syncStatus: '',
		targetDatasourceId: '',
	},
	pageList: fetchOdsTableModelPage,
	descs: ['update_time'],
});

const batchState: BasicTableProps = reactive<BasicTableProps>({
	queryForm: {
		syncStatus: '',
		sourceDatasourceId: '',
		targetDatasourceId: '',
	},
	pageList: fetchManualSyncBatchPage,
	descs: ['create_time'],
});

const {
	getDataList: getModelList,
	currentChangeHandle: modelCurrentChange,
	sizeChangeHandle: modelSizeChange,
	tableStyle: modelTableStyle,
} = useTable(modelState);
const {
	getDataList: getBatchList,
	currentChangeHandle: batchCurrentChange,
	sizeChangeHandle: batchSizeChange,
	tableStyle: batchTableStyle,
} = useTable(batchState);

const datasourceLabel = (item: ManualSyncDatasource) => item.displayName || item.name;
const datasourceName = (id: string, kind: ManualSyncDatasourceKind) => {
	const options = kind === 'SOURCE' ? sourceDatasources.value : targetDatasources.value;
	const item = options.find((source) => source.id === id);
	return item?.displayName || item?.name || id;
};

const loadDatasourceOptions = async () => {
	try {
		const [sourceRes, targetRes] = await Promise.all([fetchManualSyncDatasources('SOURCE'), fetchManualSyncDatasources('TARGET')]);
		sourceDatasources.value = sourceRes.data || [];
		targetDatasources.value = targetRes.data || [];
	} catch (error: any) {
		useMessage().error(error?.msg || '加载数据源选项失败');
	}
};

const resetModelQuery = () => {
	modelQueryRef.value?.resetFields();
	getModelList();
};

const resetBatchQuery = () => {
	batchQueryRef.value?.resetFields();
	getBatchList();
};

const handleModelSelectionChange = (rows: OdsTableModel[]) => {
	selectedModels.value = rows;
};

const getDeleteFailureMessage = (item: OdsTableModelDeleteFailure) => item.message || item.reason || item.errorMessage || '删除失败';

const handleDeleteModels = async (rows: OdsTableModel[]) => {
	if (rows.length === 0) return;
	if (rows.length > 100) {
		useMessage().error('单次最多删除100张表');
		return;
	}

	const targetDescription = rows.length === 1 ? `目标表“${rows[0].targetTable}”` : `选中的${rows.length}张目标表`;
	try {
		await useMessageBox().confirm(`将删除${targetDescription}、ODS元数据及模型记录；源表和同步历史不会被删除，是否继续？`);
	} catch {
		return;
	}

	try {
		deleting.value = true;
		const response = await deleteOdsTableModels(rows.map((row) => row.id));
		const deletedIds = response.data?.deletedIds || [];
		const failedItems = response.data?.failedItems || [];

		if (deletedIds.length > 0 && failedItems.length === 0) {
			useMessage().success(`成功删除${deletedIds.length}张表`);
		} else if (deletedIds.length > 0) {
			useMessage().warning(`成功删除${deletedIds.length}张表，${failedItems.length}张删除失败：${getDeleteFailureMessage(failedItems[0])}`);
		} else if (failedItems.length > 0) {
			useMessage().error(`删除失败：${getDeleteFailureMessage(failedItems[0])}`);
		} else {
			useMessage().warning('未删除任何表');
		}

		if (deletedIds.length > 0) {
			modelTableRef.value?.clearSelection();
			await getModelList();
		}
	} catch (error: any) {
		useMessage().error(error?.msg || '删除ODS表失败');
	} finally {
		deleting.value = false;
	}
};

const handleBatchTerminal = () => {
	getBatchList(false);
	getModelList(false);
};

onMounted(loadDatasourceOptions);
</script>

<style scoped>
.page-alert {
	margin: 0 10px 12px;
}

.page-tabs {
	padding: 0 10px;
}

.error-text {
	color: var(--el-color-danger);
}
</style>
