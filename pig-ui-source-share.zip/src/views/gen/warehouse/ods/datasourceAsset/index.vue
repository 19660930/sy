<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<el-row v-show="showSearch" class="ml10">
				<el-form ref="queryRef" :inline="true" :model="state.queryForm" @keyup.enter="getDataList">
					<el-form-item label="资产名称" prop="displayName">
						<el-input v-model="state.queryForm.displayName" clearable placeholder="请输入资产名称" />
					</el-form-item>
					<el-form-item label="资产状态" prop="status">
						<el-select v-model="state.queryForm.status" clearable placeholder="全部状态" style="width: 160px">
							<el-option label="已启用" value="ENABLED" />
							<el-option label="已禁用" value="DISABLED" />
						</el-select>
					</el-form-item>
					<el-form-item>
						<el-button type="primary" icon="search" @click="getDataList">查询</el-button>
						<el-button icon="Refresh" @click="resetQuery">重置</el-button>
					</el-form-item>
				</el-form>
			</el-row>

			<el-row>
				<div class="mb8" style="width: 100%">
					<el-button class="ml10" type="primary" icon="folder-add" @click="formDialogRef.openDialog()">新增</el-button>
					<right-toolbar v-model:showSearch="showSearch" class="ml10" style="float: right; margin-right: 20px" @queryTable="getDataList(false)" />
				</div>
			</el-row>

			<el-table
				v-loading="state.loading"
				:data="state.dataList"
				border
				style="width: 100%"
				:cell-style="tableStyle.cellStyle"
				:header-cell-style="tableStyle.headerCellStyle"
			>
				<el-table-column type="index" label="#" width="55" />
				<el-table-column prop="displayName" label="资产名称" min-width="160" show-overflow-tooltip />
				<el-table-column label="关联数据源" min-width="180" show-overflow-tooltip>
					<template #default="{ row }">{{ row.datasourceName || row.datasourceId }}</template>
				</el-table-column>
				<el-table-column prop="businessSystem" label="业务系统" min-width="140" show-overflow-tooltip>
					<template #default="{ row }">{{ row.businessSystem || '--' }}</template>
				</el-table-column>
				<el-table-column prop="datasourceCategory" label="数据源分类" min-width="130" show-overflow-tooltip>
					<template #default="{ row }">{{ row.datasourceCategory || '--' }}</template>
				</el-table-column>
				<el-table-column label="所属部门/科室" min-width="180" show-overflow-tooltip>
					<template #default="{ row }">{{ organizationText(row) }}</template>
				</el-table-column>
				<el-table-column label="负责人" min-width="170" show-overflow-tooltip>
					<template #default="{ row }">{{ ownerText(row) }}</template>
				</el-table-column>
				<el-table-column label="元数据采集" width="110">
					<template #default="{ row }">
						<el-tag :type="row.metadataEnabled ? 'success' : 'info'">{{ row.metadataEnabled ? '已启用' : '已关闭' }}</el-tag>
					</template>
				</el-table-column>
				<el-table-column label="资产状态" width="120">
					<template #default="{ row }">
						<el-switch
							:model-value="row.status === 'ENABLED'"
							:loading="statusLoadingId === row.id"
							inline-prompt
							active-text="启用"
							inactive-text="禁用"
							@change="handleStatusChange(row, $event)"
						/>
					</template>
				</el-table-column>
				<el-table-column prop="updateTime" label="更新时间" width="180" show-overflow-tooltip />
				<el-table-column label="操作" width="100" fixed="right">
					<template #default="{ row }">
						<el-button text type="primary" icon="Edit" @click="formDialogRef.openDialog(row.id)">修改</el-button>
					</template>
				</el-table-column>
			</el-table>

			<pagination v-bind="state.pagination" @current-change="currentChangeHandle" @size-change="sizeChangeHandle" />
		</div>

		<form-dialog ref="formDialogRef" @refresh="getDataList(false)" />
	</div>
</template>

<script setup lang="ts" name="DataPlatformDatasourceAsset">
import type { FormInstance } from 'element-plus';
import { fetchDatasourceAssetPage, getDatasourceAsset, updateDatasourceAsset } from '/@/api/dataPlatform/datasourceAsset';
import { type BasicTableProps, useTable } from '/@/hooks/table';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type { DatasourceAsset, DatasourceAssetSaveRequest, DatasourceAssetStatus } from '/@/types/dataPlatform/datasourceAsset';

const FormDialog = defineAsyncComponent(() => import('./form.vue'));
const formDialogRef = ref();
const queryRef = ref<FormInstance>();
const showSearch = ref(true);
const statusLoadingId = ref('');

const state: BasicTableProps = reactive<BasicTableProps>({
	queryForm: {
		displayName: '',
		status: '',
	},
	pageList: fetchDatasourceAssetPage,
	descs: ['update_time'],
});

const { getDataList, currentChangeHandle, sizeChangeHandle, tableStyle } = useTable(state);

const organizationText = (asset: DatasourceAsset) => [asset.departmentName, asset.sectionName].filter(Boolean).join(' / ') || '--';
const ownerText = (asset: DatasourceAsset) => asset.ownerName || asset.developerName || '--';

const resetQuery = () => {
	queryRef.value?.resetFields();
	getDataList();
};

const toSaveRequest = (asset: DatasourceAsset, status: DatasourceAssetStatus): DatasourceAssetSaveRequest => ({
	datasourceId: asset.datasourceId,
	displayName: asset.displayName,
	departmentId: asset.departmentId || '',
	departmentName: asset.departmentName || '',
	sectionId: asset.sectionId || '',
	sectionName: asset.sectionName || '',
	businessSystem: asset.businessSystem || '',
	datasourceCategory: asset.datasourceCategory || '',
	metadataEnabled: asset.metadataEnabled,
	developerName: asset.developerName || '',
	developerPhone: asset.developerPhone || '',
	ownerName: asset.ownerName || '',
	ownerPhone: asset.ownerPhone || '',
	status,
	description: asset.description || '',
});

const handleStatusChange = async (row: DatasourceAsset, enabled: string | number | boolean) => {
	const targetStatus: DatasourceAssetStatus = enabled ? 'ENABLED' : 'DISABLED';
	try {
		await useMessageBox().confirm(`确认${enabled ? '启用' : '禁用'}数据源资产“${row.displayName}”吗？`);
	} catch {
		return;
	}

	try {
		statusLoadingId.value = row.id;
		const detailRes = await getDatasourceAsset(row.id);
		await updateDatasourceAsset(row.id, toSaveRequest(detailRes.data as DatasourceAsset, targetStatus));
		useMessage().success(`${enabled ? '启用' : '禁用'}成功`);
		getDataList(false);
	} catch (error: any) {
		useMessage().error(error?.msg || `${enabled ? '启用' : '禁用'}失败`);
	} finally {
		statusLoadingId.value = '';
	}
};
</script>
