<template>
	<el-dialog v-model="visible" :title="assetId ? '修改数据源资产' : '新增数据源资产'" width="980px" :close-on-click-modal="false" draggable>
		<el-form ref="dataFormRef" v-loading="loading" :model="form" :rules="dataRules" label-width="115px" class="asset-form">
			<el-row :gutter="36">
				<el-col :span="12" class="mb20">
					<el-form-item label="关联数据源" prop="datasourceId">
						<el-select v-model="form.datasourceId" filterable placeholder="请选择已有数据源" style="width: 100%" @change="handleReferenceChange">
							<el-option v-for="item in references" :key="item.id" :value="item.id" :label="referenceLabel(item)">
								<div class="reference-option">
									<span>{{ item.displayName || item.name }}</span>
									<small>{{ item.dsType }} · {{ item.dsName }}</small>
								</div>
							</el-option>
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="资产名称" prop="displayName">
						<el-input v-model="form.displayName" maxlength="128" show-word-limit placeholder="请输入业务展示名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="所属部门" prop="departmentId">
						<el-tree-select
							v-model="form.departmentId"
							:data="departmentTree"
							:props="treeProps"
							check-strictly
							clearable
							filterable
							placeholder="请选择所属部门"
							style="width: 100%"
							@change="handleDepartmentChange"
						/>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="所属科室" prop="sectionId">
						<el-tree-select
							v-model="form.sectionId"
							:data="departmentTree"
							:props="treeProps"
							check-strictly
							clearable
							filterable
							placeholder="请选择所属科室"
							style="width: 100%"
							@change="handleSectionChange"
						/>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="业务系统" prop="businessSystem">
						<el-input v-model="form.businessSystem" maxlength="128" placeholder="例如：ORDER_CENTER" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="数据源分类" prop="datasourceCategory">
						<el-input v-model="form.datasourceCategory" maxlength="64" placeholder="例如：业务数据库" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="开发负责人" prop="developerName">
						<el-input v-model="form.developerName" maxlength="64" placeholder="请输入开发负责人" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="联系电话" prop="developerPhone">
						<el-input v-model="form.developerPhone" maxlength="32" placeholder="请输入开发负责人电话" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="业务负责人" prop="ownerName">
						<el-input v-model="form.ownerName" maxlength="64" placeholder="请输入业务负责人" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="联系电话" prop="ownerPhone">
						<el-input v-model="form.ownerPhone" maxlength="32" placeholder="请输入业务负责人电话" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="元数据采集" prop="metadataEnabled">
						<el-switch v-model="form.metadataEnabled" inline-prompt active-text="启用" inactive-text="关闭" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item label="资产状态" prop="status">
						<el-radio-group v-model="form.status">
							<el-radio value="ENABLED" border>启用</el-radio>
							<el-radio value="DISABLED" border>禁用</el-radio>
						</el-radio-group>
					</el-form-item>
				</el-col>
				<el-col :span="24" class="mb20">
					<el-form-item label="资产描述" prop="description">
						<el-input v-model="form.description" type="textarea" :rows="4" maxlength="500" show-word-limit placeholder="请输入资产说明" />
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>

		<template #footer>
			<el-button @click="visible = false">{{ $t('common.cancelButtonText') }}</el-button>
			<el-button type="primary" :loading="loading" @click="onSubmit">{{ $t('common.confirmButtonText') }}</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DataPlatformDatasourceAssetDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { deptTree } from '/@/api/admin/dept';
import { addDatasourceAsset, fetchDatasourceReferences, getDatasourceAsset, updateDatasourceAsset } from '/@/api/dataPlatform/datasourceAsset';
import { useMessage } from '/@/hooks/message';
import type { DatasourceAsset, DatasourceAssetSaveRequest, DatasourceReference } from '/@/types/dataPlatform/datasourceAsset';

interface DepartmentNode {
	id?: string;
	deptId?: string;
	name: string;
	children?: DepartmentNode[];
}

const emit = defineEmits<{ refresh: [] }>();
const dataFormRef = ref<FormInstance>();
const visible = ref(false);
const loading = ref(false);
const assetId = ref('');
const references = ref<DatasourceReference[]>([]);
const departmentTree = ref<DepartmentNode[]>([]);
const treeProps = { value: 'id', label: 'name', children: 'children' };

const createDefaultForm = (): DatasourceAssetSaveRequest => ({
	datasourceId: '',
	displayName: '',
	departmentId: '',
	departmentName: '',
	sectionId: '',
	sectionName: '',
	businessSystem: '',
	datasourceCategory: '',
	metadataEnabled: true,
	developerName: '',
	developerPhone: '',
	ownerName: '',
	ownerPhone: '',
	status: 'ENABLED',
	description: '',
});

const form = reactive<DatasourceAssetSaveRequest>(createDefaultForm());

const validatePhone = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (!value || /^(?:1\d{10}|[\d+()\s-]{6,32})$/.test(value)) return callback();
	callback(new Error('联系电话格式不正确'));
};

const dataRules: FormRules = {
	datasourceId: [{ required: true, message: '请选择关联数据源', trigger: 'change' }],
	displayName: [{ required: true, message: '请输入资产名称', trigger: 'blur' }],
	status: [{ required: true, message: '请选择资产状态', trigger: 'change' }],
	developerPhone: [{ validator: validatePhone, trigger: 'blur' }],
	ownerPhone: [{ validator: validatePhone, trigger: 'blur' }],
};

const normalizeDepartmentTree = (nodes: DepartmentNode[]): DepartmentNode[] =>
	(nodes || []).map((node) => ({
		...node,
		id: String(node.id ?? node.deptId ?? ''),
		children: node.children ? normalizeDepartmentTree(node.children) : undefined,
	}));

const findDepartment = (nodes: DepartmentNode[], id?: string): DepartmentNode | undefined => {
	for (const node of nodes) {
		if (String(node.id) === String(id)) return node;
		const matched = node.children?.length ? findDepartment(node.children, id) : undefined;
		if (matched) return matched;
	}
};

const handleDepartmentChange = (id?: string) => {
	form.departmentName = findDepartment(departmentTree.value, id)?.name || '';
};

const handleSectionChange = (id?: string) => {
	form.sectionName = findDepartment(departmentTree.value, id)?.name || '';
};

const referenceLabel = (reference: DatasourceReference) => `${reference.displayName || reference.name}（${reference.dsType} / ${reference.dsName}）`;

const handleReferenceChange = (id: string) => {
	if (assetId.value || form.displayName) return;
	const reference = references.value.find((item) => item.id === id);
	form.displayName = reference?.displayName || reference?.name || '';
};

const buildPayload = (): DatasourceAssetSaveRequest => ({
	datasourceId: form.datasourceId,
	displayName: form.displayName.trim(),
	departmentId: form.departmentId || '',
	departmentName: form.departmentName?.trim() || '',
	sectionId: form.sectionId || '',
	sectionName: form.sectionName?.trim() || '',
	businessSystem: form.businessSystem?.trim() || '',
	datasourceCategory: form.datasourceCategory?.trim() || '',
	metadataEnabled: form.metadataEnabled,
	developerName: form.developerName?.trim() || '',
	developerPhone: form.developerPhone?.trim() || '',
	ownerName: form.ownerName?.trim() || '',
	ownerPhone: form.ownerPhone?.trim() || '',
	status: form.status,
	description: form.description?.trim() || '',
});

const ensureCurrentReference = (asset: DatasourceAsset) => {
	if (references.value.some((item) => item.id === asset.datasourceId)) return;
	references.value.push({
		id: asset.datasourceId,
		name: asset.datasourceName || asset.datasourceId,
		displayName: asset.displayName,
		dsType: asset.datasourceType || '未知类型',
		dsName: asset.datasourceDatabase || '当前配置',
	});
};

const openDialog = async (id?: string) => {
	visible.value = true;
	assetId.value = id || '';
	Object.assign(form, createDefaultForm());
	await nextTick();
	dataFormRef.value?.clearValidate();

	try {
		loading.value = true;
		const [referenceRes, departmentRes, assetRes] = await Promise.all([
			fetchDatasourceReferences(),
			deptTree(),
			id ? getDatasourceAsset(id) : Promise.resolve(undefined),
		]);
		references.value = (referenceRes.data || []) as DatasourceReference[];
		departmentTree.value = normalizeDepartmentTree(departmentRes.data || []);
		if (assetRes?.data) {
			const asset = assetRes.data as DatasourceAsset;
			ensureCurrentReference(asset);
			Object.assign(form, createDefaultForm(), asset);
		}
	} catch (error: any) {
		visible.value = false;
		useMessage().error(error?.msg || '加载数据源资产失败');
	} finally {
		loading.value = false;
	}
};

const onSubmit = async () => {
	const valid = await dataFormRef.value?.validate().catch(() => false);
	if (!valid) return;
	try {
		loading.value = true;
		const payload = buildPayload();
		assetId.value ? await updateDatasourceAsset(assetId.value, payload) : await addDatasourceAsset(payload);
		useMessage().success(assetId.value ? '修改成功' : '新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || '保存数据源资产失败');
	} finally {
		loading.value = false;
	}
};

defineExpose({ openDialog });
</script>

<style scoped>
.asset-form :deep(.el-form-item__label) {
	white-space: nowrap;
}

.reference-option {
	display: flex;
	justify-content: space-between;
	gap: 16px;
}

.reference-option small {
	color: var(--el-text-color-secondary);
}
</style>
