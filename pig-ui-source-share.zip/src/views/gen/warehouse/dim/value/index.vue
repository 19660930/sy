<template>
	<div class="dimension-value-page layout-padding">
		<el-card shadow="never" class="page-card">
			<div class="page-heading">
				<div>
					<div class="page-title">维度值维护</div>
					<div class="page-description">按模型层级维护维度成员及扩展属性，启停可恢复，删除后不可在普通列表恢复。</div>
				</div>
				<div class="heading-actions">
					<el-button v-auth="'dp_dim_value_import'" icon="Upload" :disabled="!selectedTableId" @click="openImport">导入</el-button>
					<el-button v-auth="'dp_dim_value_export'" icon="Download" :disabled="!selectedTableId" :loading="exporting" @click="handleExport">
						导出
					</el-button>
					<el-button v-auth="'dp_dim_value_add'" type="primary" icon="Plus" :disabled="!selectedTableId" @click="openAdd">新增维度值</el-button>
				</div>
			</div>

			<div class="filter-panel">
				<el-form :inline="true">
					<el-form-item label="维度模型">
						<el-select v-model="selectedModelId" filterable placeholder="请选择维度模型" style="width: 230px" @change="handleModelChange">
							<el-option v-for="item in modelOptions" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="物化维表">
						<el-select
							v-model="selectedTableId"
							filterable
							clearable
							:disabled="!selectedModelId"
							placeholder="请选择维度表"
							style="width: 230px"
							@change="handleTableChange"
						>
							<el-option v-for="item in tableOptions" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item>
						<span class="filter-tip">维度值仅维护一套，不按结构版本拆分；所属层级由父节点链路推导。</span>
					</el-form-item>
				</el-form>
			</div>

			<div v-if="selectedModelId" class="content-layout">
				<aside class="tree-panel">
					<div class="panel-heading">
						<div>
							<div class="panel-title">维度层级树</div>
							<div class="panel-subtitle">点击节点查看其直接下级</div>
						</div>
						<el-button text icon="Refresh" :loading="treeLoading" @click="loadTree" />
					</div>
					<div :class="['root-node', { active: !selectedParentId }]" @click="selectRoot">
						<el-icon><FolderOpened /></el-icon>
						<span>全部根级维度值</span>
						<el-tag size="small" type="info">根级</el-tag>
					</div>
					<el-scrollbar class="tree-scrollbar">
						<el-tree
							ref="treeRef"
							v-loading="treeLoading"
							:data="treeData"
							node-key="id"
							:props="treeProps"
							:expand-on-click-node="false"
							highlight-current
							default-expand-all
							@node-click="handleNodeClick"
						>
							<template #default="{ data }">
								<div class="tree-node">
									<span class="tree-node-name">{{ data.name }}</span>
									<span class="tree-node-code">{{ data.code }}</span>
								</div>
							</template>
						</el-tree>
						<el-empty v-if="!treeLoading && !treeData.length" description="暂无维度值" :image-size="70" />
					</el-scrollbar>
				</aside>

				<section class="list-panel">
					<div class="panel-heading list-heading">
						<div>
							<div class="panel-title">
								{{ materializedMode ? '已物化维度值（只读）' : selectedParentName ? `${selectedParentName} · 直接下级` : '根级维度值' }}
							</div>
							<div class="panel-subtitle">
								{{ materializedMode ? `共 ${page.total} 条，展示物理维表真实字段` : `共 ${page.total} 条，列表不递归展示孙级节点` }}
							</div>
						</div>
						<div class="list-actions">
							<el-button v-if="materializedMode" icon="Back" @click="loadValues">返回维护数据</el-button>
							<el-button v-else-if="selectedParentId" icon="Back" @click="selectRoot">返回根级</el-button>
							<el-button icon="Refresh" :loading="listLoading" @click="loadMaterializedValues">刷新</el-button>
						</div>
					</div>

					<el-table v-if="materializedMode" v-loading="listLoading" :data="materializedValues" border row-key="_rowKey" empty-text="暂无已物化维度值">
						<el-table-column v-for="column in materializedColumns" :key="column" :label="column" :min-width="160" show-overflow-tooltip>
							<template #default="{ row }">{{ formatMaterializedCell(row.columns[column]) }}</template>
						</el-table-column>
					</el-table>

					<el-table v-else v-loading="listLoading" :data="values" border row-key="id" empty-text="当前层级暂无维度值">
						<el-table-column prop="code" label="维度值编码" min-width="150" show-overflow-tooltip />
						<el-table-column prop="name" label="中文名称" min-width="150" show-overflow-tooltip />
						<el-table-column prop="nameEn" label="英文名称" min-width="150" show-overflow-tooltip>
							<template #default="{ row }">{{ row.nameEn || '--' }}</template>
						</el-table-column>
						<el-table-column prop="levelName" label="所属层级" width="130">
							<template #default="{ row }">{{ row.levelName || '--' }}</template>
						</el-table-column>
						<el-table-column prop="effectiveDate" label="生效日期" width="125">
							<template #default="{ row }">{{ row.effectiveDate || '--' }}</template>
						</el-table-column>
						<el-table-column label="是否当前" width="100" align="center">
							<template #default="{ row }">{{ row.isCurrent == null ? '--' : Number(row.isCurrent) === 1 ? '是' : '否' }}</template>
						</el-table-column>
						<el-table-column label="状态" width="100" align="center">
							<template #default="{ row }">
								<el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">{{ statusLabel(row.status) }}</el-tag>
							</template>
						</el-table-column>
						<el-table-column prop="updateTime" label="更新时间" width="175">
							<template #default="{ row }">{{ row.updateTime || '--' }}</template>
						</el-table-column>
						<el-table-column label="操作" width="330" fixed="right">
							<template #default="{ row }">
								<div class="row-actions">
									<el-button v-auth="'dp_dim_value_view'" text type="primary" icon="View" @click="openView(row)">查看</el-button>
									<el-button v-auth="'dp_dim_value_add'" text type="primary" icon="Plus" @click="openAddChild(row)">新增下级</el-button>
									<el-button v-auth="'dp_dim_value_edit'" text type="primary" icon="Edit" @click="openEdit(row)">编辑</el-button>
									<el-button
										v-auth="'dp_dim_value_edit'"
										text
										:type="row.status === 'ENABLED' ? 'warning' : 'success'"
										:loading="changingId === row.id"
										@click="handleToggle(row)"
									>
										{{ row.status === 'ENABLED' ? '停用' : '启用' }}
									</el-button>
									<el-button v-auth="'dp_dim_value_delete'" text type="danger" icon="Delete" @click="handleDelete(row)">删除</el-button>
								</div>
							</template>
						</el-table-column>
					</el-table>

					<pagination
						v-if="page.total !== '0'"
						:current="page.current"
						:size="page.size"
						:total="page.total"
						@current-change="handleCurrentChange"
						@size-change="handleSizeChange"
					/>
				</section>
			</div>
			<el-empty v-else description="请先选择维度模型" />
		</el-card>

		<ValueFormDialog ref="formDialogRef" @refresh="handleDataChanged" />
		<ImportDialog ref="importDialogRef" @refresh="handleDataChanged" />
	</div>
</template>

<script setup lang="ts" name="DimensionValueMaintenance">
import type { ElTree } from 'element-plus';
import {
	deleteDimensionValue,
	exportDimensionValues,
	fetchMaterializedDimensionValuePage,
	fetchDimensionModelOptions,
	fetchDimensionOptions,
	fetchDimensionTableOptions,
	fetchDimensionValuePage,
	fetchDimensionValueTree,
	setDimensionValueEnabled,
} from '/@/api/dataPlatform/dimension';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type {
	DimensionOption,
	DimensionValue,
	DimensionValuePage,
	DimensionValueTreeNode,
	MaterializedDimensionValuePage,
	MaterializedDimensionValueRecord,
} from '/@/types/dataPlatform/dimension';
import { handleBlobFile } from '/@/utils/other';
import ImportDialog from './importDialog.vue';
import ValueFormDialog from './formDialog.vue';

const treeRef = ref<InstanceType<typeof ElTree>>();
const formDialogRef = ref<InstanceType<typeof ValueFormDialog>>();
const importDialogRef = ref<InstanceType<typeof ImportDialog>>();
const treeLoading = ref(false);
const listLoading = ref(false);
const exporting = ref(false);
const changingId = ref('');
const modelOptions = ref<DimensionOption[]>([]);
const tableOptions = ref<DimensionOption[]>([]);
const statusOptions = ref<DimensionOption[]>([]);
const selectedModelId = ref('');
const selectedTableId = ref('');
const selectedParentId = ref('');
const selectedParentName = ref('');
const treeData = ref<DimensionValueTreeNode[]>([]);
const values = ref<DimensionValue[]>([]);
const materializedMode = ref(false);
const materializedValues = ref<Array<MaterializedDimensionValueRecord & { _rowKey: string }>>([]);
const page = reactive({ current: 1, size: 10, total: '0' });
const treeProps = { children: 'children', label: 'name' };

const materializedColumns = computed(() => {
	const columns: string[] = [];
	const seen = new Set<string>();
	materializedValues.value.forEach((row) => {
		Object.keys(row.columns || {}).forEach((column) => {
			if (seen.has(column)) return;
			seen.add(column);
			columns.push(column);
		});
	});
	return columns;
});

const formatMaterializedCell = (value: unknown) => {
	if (value == null || value === '') return '--';
	if (typeof value === 'object') return JSON.stringify(value);
	return String(value);
};

const statusLabel = (value: string) => statusOptions.value.find((item) => item.value === value)?.label || value || '--';
const normalizeTreeNode = (item: Record<string, unknown>): DimensionValueTreeNode => ({
	...(item as unknown as DimensionValueTreeNode),
	id: String(item.id),
	parentId: item.parentId == null ? null : String(item.parentId),
	levelId: item.levelId == null ? null : String(item.levelId),
	children: Array.isArray(item.children) ? item.children.map((child) => normalizeTreeNode(child as Record<string, unknown>)) : [],
});
const normalizeValue = (item: Record<string, unknown>): DimensionValue => ({
	...(item as unknown as DimensionValue),
	id: String(item.id),
	modelId: String(item.modelId ?? selectedModelId.value),
	tableId: item.tableId == null ? selectedTableId.value || null : String(item.tableId),
	parentId: item.parentId == null ? null : String(item.parentId),
	levelId: item.levelId == null ? null : String(item.levelId),
});

const loadOptions = async () => {
	const [modelRes, tableRes, optionRes] = await Promise.all([fetchDimensionModelOptions(), fetchDimensionTableOptions(), fetchDimensionOptions()]);
	modelOptions.value = Array.isArray(modelRes.data) ? (modelRes.data as DimensionOption[]) : [];
	tableOptions.value = Array.isArray(tableRes.data) ? (tableRes.data as DimensionOption[]) : [];
	statusOptions.value = ((optionRes.data || {}) as { statuses?: DimensionOption[] }).statuses || [];
	if (!selectedModelId.value && modelOptions.value.length) selectedModelId.value = modelOptions.value[0].value;
};

const loadTree = async () => {
	if (!selectedModelId.value) {
		treeData.value = [];
		return;
	}
	try {
		treeLoading.value = true;
		const res = await fetchDimensionValueTree(selectedModelId.value, selectedTableId.value);
		treeData.value = Array.isArray(res.data) ? res.data.map((item) => normalizeTreeNode(item as Record<string, unknown>)) : [];
		await nextTick();
		if (selectedParentId.value) treeRef.value?.setCurrentKey(selectedParentId.value);
	} catch (error: unknown) {
		treeData.value = [];
		useMessage().error((error as { msg?: string })?.msg || '加载维度值树失败');
	} finally {
		treeLoading.value = false;
	}
};

const loadValues = async () => {
	if (!selectedModelId.value) {
		values.value = [];
		materializedMode.value = false;
		page.total = '0';
		return;
	}
	try {
		listLoading.value = true;
		const res = await fetchDimensionValuePage({
			modelId: selectedModelId.value,
			...(selectedParentId.value ? { parentId: selectedParentId.value } : {}),
			current: page.current,
			size: page.size,
		});
		const data = (res.data || {}) as DimensionValuePage;
		values.value = Array.isArray(data.records) ? data.records.map((item) => normalizeValue(item as unknown as Record<string, unknown>)) : [];
		page.total = String(data.total ?? '0');
		materializedMode.value = false;
	} catch (error: unknown) {
		values.value = [];
		page.total = '0';
		useMessage().error((error as { msg?: string })?.msg || '加载维度值列表失败');
	} finally {
		listLoading.value = false;
	}
};

const loadMaterializedValues = async () => {
	if (!selectedModelId.value) return;
	try {
		listLoading.value = true;
		const res = await fetchMaterializedDimensionValuePage({
			modelId: selectedModelId.value,
			current: page.current,
			size: page.size,
		});
		const data = (res.data || {}) as MaterializedDimensionValuePage;
		materializedValues.value = Array.isArray(data.records)
			? data.records.map((item, index) => ({
					...item,
					columns: item.columns && typeof item.columns === 'object' ? item.columns : {},
					_rowKey: String(item.businessKey ?? `${page.current}-${index}`),
			  }))
			: [];
		page.total = String(data.total ?? '0');
		materializedMode.value = true;
	} catch (error: unknown) {
		useMessage().error((error as { msg?: string })?.msg || '加载已物化维度值失败');
	} finally {
		listLoading.value = false;
	}
};

const reloadAll = async () => Promise.all([loadTree(), loadValues()]);
const handleModelChange = async () => {
	selectedTableId.value = '';
	selectedParentId.value = '';
	selectedParentName.value = '';
	page.current = 1;
	await reloadAll();
};
const handleTableChange = async () => {
	selectedParentId.value = '';
	selectedParentName.value = '';
	page.current = 1;
	await reloadAll();
};
const selectRoot = async () => {
	selectedParentId.value = '';
	selectedParentName.value = '';
	treeRef.value?.setCurrentKey(undefined);
	page.current = 1;
	await loadValues();
};
const handleNodeClick = async (node: DimensionValueTreeNode) => {
	selectedParentId.value = node.id;
	selectedParentName.value = node.name;
	page.current = 1;
	await loadValues();
};
const handleCurrentChange = (current: number) => {
	page.current = current;
	if (materializedMode.value) loadMaterializedValues();
	else loadValues();
};
const handleSizeChange = (size: number) => {
	page.current = 1;
	page.size = size;
	if (materializedMode.value) loadMaterializedValues();
	else loadValues();
};

const ensureTableSelected = () => {
	if (selectedTableId.value) return true;
	useMessage().warning('请先选择需要维护的物化维表');
	return false;
};
const openAdd = () => {
	if (!ensureTableSelected()) return;
	formDialogRef.value?.openDialog({
		mode: 'add',
		modelId: selectedModelId.value,
		tableId: selectedTableId.value,
		parentId: selectedParentId.value,
		parentName: selectedParentName.value,
	});
};
const openAddChild = (row: DimensionValue) => {
	if (!ensureTableSelected()) return;
	formDialogRef.value?.openDialog({
		mode: 'add',
		modelId: selectedModelId.value,
		tableId: selectedTableId.value,
		parentId: row.id,
		parentName: row.name,
	});
};
const openEdit = (row: DimensionValue) => {
	if (!ensureTableSelected()) return;
	formDialogRef.value?.openDialog({
		mode: 'edit',
		modelId: selectedModelId.value,
		tableId: selectedTableId.value,
		valueId: row.id,
		parentId: row.parentId || undefined,
		parentName: selectedParentName.value,
	});
};
const openView = (row: DimensionValue) => {
	formDialogRef.value?.openDialog({
		mode: 'view',
		modelId: selectedModelId.value,
		tableId: selectedTableId.value,
		valueId: row.id,
		parentId: row.parentId || undefined,
		parentName: selectedParentName.value,
	});
};

const handleToggle = async (row: DimensionValue) => {
	const enabled = row.status !== 'ENABLED';
	try {
		await useMessageBox().confirm(`确认${enabled ? '启用' : '停用'}维度值“${row.name}”吗？${enabled ? '' : '停用后仍会保留，可再次启用。'}`);
	} catch {
		return;
	}
	try {
		changingId.value = row.id;
		await setDimensionValueEnabled(row.id, enabled);
		useMessage().success(`${enabled ? '启用' : '停用'}成功`);
		await handleDataChanged();
	} catch (error: unknown) {
		useMessage().error((error as { msg?: string })?.msg || `${enabled ? '启用' : '停用'}维度值失败`);
	} finally {
		changingId.value = '';
	}
};

const handleDelete = async (row: DimensionValue) => {
	try {
		await useMessageBox().confirm(`确认删除维度值“${row.name}”吗？删除后普通列表不可见且无法直接恢复。`);
	} catch {
		return;
	}
	try {
		await deleteDimensionValue(row.id);
		useMessage().success('删除成功');
		await handleDataChanged();
	} catch (error: unknown) {
		useMessage().error((error as { msg?: string })?.msg || '删除维度值失败');
	}
};

const openImport = () => {
	if (!ensureTableSelected()) return;
	importDialogRef.value?.openDialog({
		modelId: selectedModelId.value,
		tableId: selectedTableId.value,
		parentId: selectedParentId.value,
		parentName: selectedParentName.value,
	});
};
const handleExport = async () => {
	if (!ensureTableSelected()) return;
	try {
		exporting.value = true;
		const res = await exportDimensionValues({
			modelId: selectedModelId.value,
			tableId: selectedTableId.value,
			...(selectedParentId.value ? { parentId: selectedParentId.value } : {}),
		});
		handleBlobFile(res, `维度值_${new Date().toISOString().slice(0, 10)}.xlsx`);
	} catch (error: unknown) {
		useMessage().error((error as { msg?: string })?.msg || '导出维度值失败');
	} finally {
		exporting.value = false;
	}
};

async function handleDataChanged() {
	await reloadAll();
}

onMounted(async () => {
	try {
		await loadOptions();
	} catch (error: unknown) {
		useMessage().error((error as { msg?: string })?.msg || '加载维度值选项失败');
	}
	await reloadAll();
});
</script>

<style scoped lang="scss">
.dimension-value-page {
	.page-card {
		min-height: calc(100vh - 115px);
	}

	.page-heading,
	.heading-actions,
	.panel-heading,
	.list-actions,
	.row-actions,
	.root-node,
	.tree-node {
		display: flex;
		align-items: center;
	}

	.page-heading,
	.panel-heading {
		justify-content: space-between;
	}

	.page-heading {
		align-items: flex-start;
		padding-bottom: 18px;
		border-bottom: 1px solid var(--el-border-color-lighter);
	}

	.page-title {
		font-size: 20px;
		font-weight: 600;
	}

	.page-description,
	.panel-subtitle,
	.filter-tip,
	.tree-node-code {
		color: var(--el-text-color-secondary);
	}

	.page-description {
		margin-top: 8px;
	}

	.heading-actions,
	.list-actions {
		gap: 8px;
	}

	.filter-panel {
		padding: 16px 16px 0;
		margin-top: 16px;
		background: var(--el-fill-color-lighter);
		border: 1px solid var(--el-border-color-lighter);
		border-radius: 4px;
	}

	.filter-tip {
		font-size: 13px;
	}

	.content-layout {
		display: grid;
		grid-template-columns: 290px minmax(0, 1fr);
		min-height: 560px;
		margin-top: 16px;
		border: 1px solid var(--el-border-color-lighter);
	}

	.tree-panel {
		padding: 16px 12px;
		background: var(--el-fill-color-extra-light);
		border-right: 1px solid var(--el-border-color-lighter);
	}

	.list-panel {
		min-width: 0;
		padding: 16px;
	}

	.panel-heading {
		min-height: 42px;
		margin-bottom: 12px;
	}

	.panel-title {
		font-size: 16px;
		font-weight: 600;
	}

	.panel-subtitle {
		margin-top: 5px;
		font-size: 12px;
	}

	.root-node {
		gap: 8px;
		padding: 10px 9px;
		margin-bottom: 4px;
		cursor: pointer;
		border-radius: 4px;

		span:nth-child(2) {
			flex: 1;
		}

		&.active,
		&:hover {
			color: var(--el-color-primary);
			background: var(--el-color-primary-light-9);
		}
	}

	.tree-scrollbar {
		height: 480px;
	}

	.tree-node {
		width: calc(100% - 4px);
		min-width: 0;
	}

	.tree-node-name {
		min-width: 0;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.tree-node-code {
		margin-left: 6px;
		font-size: 12px;
	}

	.row-actions {
		white-space: nowrap;

		:deep(.el-button + .el-button) {
			margin-left: 2px;
		}
	}
}
</style>
