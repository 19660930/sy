<template>
	<el-dialog v-model="visible" title="导入维度值" width="620px" :close-on-click-modal="false" draggable>
		<el-alert
			:title="parentName ? `导入数据将写入“${parentName}”的下级。` : '导入数据将写入根层级。'"
			type="info"
			show-icon
			:closable="false"
			class="import-alert"
		/>
		<el-upload v-model:file-list="fileList" drag :auto-upload="false" :limit="1" accept=".xlsx" :on-exceed="handleExceed">
			<el-icon class="el-icon--upload"><UploadFilled /></el-icon>
			<div class="el-upload__text">将 Excel 文件拖到此处，或<em>点击选择</em></div>
			<template #tip>
				<div class="el-upload__tip">仅支持 .xlsx。基础列按 code、name、nameEn、status、remark 匹配，自定义属性按属性英文名匹配。</div>
			</template>
		</el-upload>
		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" :loading="submitting" @click="handleSubmit">开始导入</el-button>
		</template>
	</el-dialog>

	<el-dialog v-model="resultVisible" title="导入结果" width="680px" draggable>
		<el-descriptions :column="2" border>
			<el-descriptions-item label="成功条数">{{ result.successCount }}</el-descriptions-item>
			<el-descriptions-item label="失败条数">{{ result.failCount }}</el-descriptions-item>
		</el-descriptions>
		<el-alert v-if="result.errors.length" title="以下数据未导入" type="warning" show-icon :closable="false" class="result-alert" />
		<el-scrollbar v-if="result.errors.length" max-height="300px" class="error-list">
			<div v-for="(error, index) in result.errors" :key="`${index}-${error}`" class="error-item">{{ error }}</div>
		</el-scrollbar>
		<el-empty v-else description="全部数据导入成功" :image-size="70" />
		<template #footer><el-button type="primary" @click="resultVisible = false">知道了</el-button></template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionValueImportDialog">
import type { UploadFiles, UploadUserFile } from 'element-plus';
import { importDimensionValues } from '/@/api/dataPlatform/dimension';
import { useMessage } from '/@/hooks/message';
import type { DimensionValueImportResult } from '/@/types/dataPlatform/dimension';

type OpenOptions = { modelId: string; tableId: string; parentId?: string; parentName?: string };
const emit = defineEmits<{ refresh: [] }>();
const visible = ref(false);
const resultVisible = ref(false);
const submitting = ref(false);
const fileList = ref<UploadUserFile[]>([]);
const context = reactive({ modelId: '', tableId: '', parentId: '' });
const parentName = ref('');
const result = reactive<DimensionValueImportResult>({ successCount: 0, failCount: 0, errors: [] });

const openDialog = (options: OpenOptions) => {
	context.modelId = options.modelId;
	context.tableId = options.tableId;
	context.parentId = options.parentId || '';
	parentName.value = options.parentName || '';
	fileList.value = [];
	visible.value = true;
};

const handleExceed = (_files: File[], uploadFiles: UploadFiles) => {
	fileList.value = uploadFiles.slice(-1);
	useMessage().warning('每次只能导入一个文件');
};

const handleSubmit = async () => {
	const file = fileList.value[0]?.raw;
	if (!file) {
		useMessage().warning('请选择需要导入的 Excel 文件');
		return;
	}
	try {
		submitting.value = true;
		const res = await importDimensionValues(file, context.modelId, context.tableId, context.parentId);
		const data = (res.data || {}) as DimensionValueImportResult;
		result.successCount = data.successCount ?? 0;
		result.failCount = data.failCount ?? 0;
		result.errors = Array.isArray(data.errors) ? data.errors : [];
		visible.value = false;
		resultVisible.value = true;
		emit('refresh');
	} catch (error: unknown) {
		useMessage().error((error as { msg?: string })?.msg || '导入维度值失败');
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>

<style scoped>
.import-alert,
.result-alert {
	margin-bottom: 18px;
}

.result-alert {
	margin-top: 18px;
}

.error-list {
	padding: 10px 14px;
	background: var(--el-fill-color-lighter);
	border: 1px solid var(--el-border-color-lighter);
}

.error-item {
	padding: 7px 0;
	color: var(--el-color-danger);
	border-bottom: 1px dashed var(--el-border-color-lighter);
}
</style>
