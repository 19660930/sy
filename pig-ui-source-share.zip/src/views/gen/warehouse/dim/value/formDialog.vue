<template>
	<el-dialog v-model="visible" :title="dialogTitle" width="860px" :close-on-click-modal="false" draggable>
		<el-form ref="formRef" v-loading="loading" :model="form" :rules="rules" label-width="110px" :disabled="mode === 'view'">
			<el-alert
				:title="parentName ? `将在“${parentName}”下维护下级维度值，所属层级由系统自动推导。` : '当前维护根级维度值，所属层级由系统自动推导。'"
				type="info"
				show-icon
				:closable="false"
				class="dialog-alert"
			/>
			<el-divider content-position="left">基础信息</el-divider>
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item label="维度值编码" prop="code">
						<el-input v-model="form.code" maxlength="128" placeholder="同一上级下编码唯一" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="中文名称" prop="name">
						<el-input v-model="form.name" maxlength="128" placeholder="请输入中文名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="英文名称" prop="nameEn">
						<el-input v-model="form.nameEn" maxlength="128" placeholder="请输入英文名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="所属层级">
						<el-input :model-value="levelName || '保存后由系统自动推导'" disabled />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="生效日期" prop="effectiveDate">
						<el-date-picker v-model="form.effectiveDate" type="date" value-format="YYYY-MM-DD" placeholder="请选择生效日期" style="width: 100%" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="状态" prop="status">
						<el-radio-group v-model="form.status">
							<el-radio value="ENABLED">启用</el-radio>
							<el-radio value="DISABLED">停用</el-radio>
						</el-radio-group>
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="备注" prop="remark">
						<el-input v-model="form.remark" type="textarea" :rows="2" maxlength="500" show-word-limit placeholder="请输入备注" />
					</el-form-item>
				</el-col>
			</el-row>

			<template v-if="mode === 'view' && viewAttributeValues.length">
				<el-divider content-position="left">模型扩展属性</el-divider>
				<el-descriptions :column="2" border class="attribute-descriptions">
					<el-descriptions-item v-for="attribute in viewAttributeValues" :key="attribute.attrCode" :label="attribute.attrName">
						{{ formatAttributeValue(attribute.value) }}
					</el-descriptions-item>
				</el-descriptions>
			</template>

			<template v-else-if="attributes.length">
				<el-divider content-position="left">模型扩展属性</el-divider>
				<el-row :gutter="20">
					<el-col v-for="attribute in attributes" :key="attribute.id" :span="12">
						<el-form-item :label="attribute.attrName" :prop="`extJson.${attribute.attrCode}`" :required="attribute.isRequired === 1">
							<el-date-picker
								v-if="attribute.dataType === 'DATE'"
								v-model="form.extJson[attribute.attrCode]"
								type="date"
								value-format="YYYY-MM-DD"
								:placeholder="attribute.defaultValue || `请选择${attribute.attrName}`"
								style="width: 100%"
							/>
							<el-input
								v-else
								v-model="form.extJson[attribute.attrCode]"
								:placeholder="attribute.defaultValue || `请输入${attribute.attrName}`"
								:maxlength="attribute.dataLength || 255"
							/>
							<div v-if="attribute.description" class="field-tip">{{ attribute.description }}</div>
						</el-form-item>
					</el-col>
				</el-row>
			</template>
		</el-form>
		<template #footer>
			<el-button @click="visible = false">{{ mode === 'view' ? '关闭' : '取消' }}</el-button>
			<el-button v-if="mode !== 'view'" type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionValueFormDialog">
import type { FormInstance, FormRules } from 'element-plus';
import {
	createDimensionValue,
	fetchDimensionAttributes,
	getDimensionValue,
	updateDimensionValue,
} from '/@/api/dataPlatform/dimension';
import { useMessage } from '/@/hooks/message';
import type {
	DimensionAttribute,
	DimensionAttributeItem,
	DimensionStatus,
	DimensionValue,
	DimensionValueSaveRequest,
} from '/@/types/dataPlatform/dimension';

type DialogMode = 'add' | 'edit' | 'view';
type OpenOptions = {
	mode: DialogMode;
	modelId: string;
	tableId: string;
	valueId?: string;
	parentId?: string;
	parentName?: string;
};

const emit = defineEmits<{ refresh: [] }>();
const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const formRef = ref<FormInstance>();
const mode = ref<DialogMode>('add');
const valueId = ref('');
const parentName = ref('');
const levelName = ref('');
const attributes = ref<DimensionAttribute[]>([]);
const detailAttributeValues = ref<DimensionAttributeItem[]>([]);

const createDefaultForm = (): DimensionValueSaveRequest => ({
	modelId: '',
	tableId: '',
	parentId: null,
	code: '',
	name: '',
	nameEn: '',
	effectiveDate: '',
	status: 'ENABLED',
	remark: '',
	extJson: {},
});
const form = reactive<DimensionValueSaveRequest>(createDefaultForm());
const rules = reactive<FormRules>({
	code: [{ required: true, message: '请输入维度值编码', trigger: 'blur' }],
	name: [{ required: true, message: '请输入中文名称', trigger: 'blur' }],
	status: [{ required: true, message: '请选择状态', trigger: 'change' }],
});

const dialogTitle = computed(() => ({ add: '新增维度值', edit: '编辑维度值', view: '查看维度值' })[mode.value]);

const viewAttributeValues = computed<DimensionAttributeItem[]>(() => {
	if (detailAttributeValues.value.length) return detailAttributeValues.value;
	return attributes.value.map((attribute) => ({
		attrCode: attribute.attrCode,
		attrName: attribute.attrName,
		dataType: attribute.dataType,
		value: form.extJson[attribute.attrCode],
	}));
});

const formatAttributeValue = (value: unknown) => {
	if (value == null || value === '') return '--';
	if (typeof value === 'object') return JSON.stringify(value);
	return String(value);
};

const normalizeExtJson = (value: DimensionValue['extJson']): Record<string, unknown> => {
	if (!value) return {};
	if (typeof value === 'object') return { ...value };
	try {
		const parsed = JSON.parse(value);
		return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
	} catch {
		return {};
	}
};

const normalizeValue = (item: Record<string, unknown>): DimensionValue => ({
	...(item as unknown as DimensionValue),
	id: String(item.id),
	modelId: String(item.modelId),
	tableId: item.tableId == null ? null : String(item.tableId),
	parentId: item.parentId == null ? null : String(item.parentId),
	levelId: item.levelId == null ? null : String(item.levelId),
});

const loadAttributes = async (modelId: string) => {
	const res = await fetchDimensionAttributes(modelId);
	attributes.value = Array.isArray(res.data) ? (res.data as DimensionAttribute[]) : [];
	attributes.value.forEach((attribute) => {
		if (!(attribute.attrCode in form.extJson)) form.extJson[attribute.attrCode] = '';
		const ruleKey = `extJson.${attribute.attrCode}`;
		if (attribute.isRequired === 1) {
			rules[ruleKey] = [{ required: true, message: `请输入${attribute.attrName}`, trigger: ['blur', 'change'] }];
		} else delete rules[ruleKey];
	});
};

const openDialog = async (options: OpenOptions) => {
	visible.value = true;
	loading.value = true;
	mode.value = options.mode;
	valueId.value = options.valueId || '';
	parentName.value = options.parentName || '';
	levelName.value = '';
	attributes.value = [];
	detailAttributeValues.value = [];
	Object.assign(form, createDefaultForm(), {
		modelId: options.modelId,
		tableId: options.tableId,
		parentId: options.parentId || null,
	});
	try {
		await loadAttributes(options.modelId);
		if (options.valueId) {
			const res = await getDimensionValue(options.valueId);
			const detail = normalizeValue((res.data || {}) as Record<string, unknown>);
			detailAttributeValues.value = Array.isArray(detail.attributeValues) ? detail.attributeValues : [];
			const extJson = normalizeExtJson(detail.extJson);
			detailAttributeValues.value.forEach((attribute) => {
				if (!(attribute.attrCode in extJson)) extJson[attribute.attrCode] = attribute.value;
			});
			Object.assign(form, {
				modelId: detail.modelId || options.modelId,
				tableId: detail.tableId || options.tableId,
				parentId: detail.parentId || null,
				code: detail.code || '',
				name: detail.name || '',
				nameEn: detail.nameEn || '',
				effectiveDate: detail.effectiveDate || '',
				status: (detail.status || 'ENABLED') as DimensionStatus,
				remark: detail.remark || '',
				extJson,
			});
			levelName.value = detail.levelName || '';
			attributes.value.forEach((attribute) => {
				if (!(attribute.attrCode in form.extJson)) form.extJson[attribute.attrCode] = '';
			});
		}
	} catch (error: unknown) {
		visible.value = false;
		useMessage().error((error as { msg?: string })?.msg || '加载维度值信息失败');
	} finally {
		loading.value = false;
	}
	await nextTick();
	formRef.value?.clearValidate();
};

const handleSubmit = async () => {
	const valid = await formRef.value?.validate().catch(() => false);
	if (!valid) return;
	const payload: DimensionValueSaveRequest = {
		modelId: String(form.modelId),
		tableId: String(form.tableId),
		parentId: form.parentId ? String(form.parentId) : null,
		code: form.code.trim(),
		name: form.name.trim(),
		nameEn: form.nameEn.trim(),
		effectiveDate: form.effectiveDate,
		status: form.status,
		remark: form.remark.trim(),
		extJson: { ...form.extJson },
	};
	try {
		submitting.value = true;
		if (valueId.value) await updateDimensionValue(valueId.value, payload);
		else await createDimensionValue(payload);
		useMessage().success(valueId.value ? '维度值修改成功' : '维度值新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: unknown) {
		useMessage().error((error as { msg?: string })?.msg || (valueId.value ? '修改维度值失败' : '新增维度值失败'));
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>

<style scoped>
.dialog-alert {
	margin-bottom: 18px;
}

.attribute-descriptions {
	margin-bottom: 4px;
}

.field-tip {
	font-size: 12px;
	line-height: 20px;
	color: var(--el-text-color-secondary);
}
</style>
