<template>
  <el-dialog
    v-model="visible"
    :title="mode === 'GENERATE' ? '生成实体维表' : '新建角色扮演维表'"
    width="760px"
    :close-on-click-modal="false"
    draggable
  >
    <el-form
      ref="formRef"
      v-loading="loading"
      :model="form"
      :rules="rules"
      label-width="110px"
    >
      <el-alert
        v-if="mode === 'GENERATE'"
        title="将根据模型属性和当前启用策略，在 Doris 中创建 UNIQUE 实体维表。一个模型只能生成一张实体维表。"
        type="info"
        show-icon
        :closable="false"
        class="dialog-alert"
      />
      <el-alert
        v-else
        title="列表页只允许新建角色扮演维表；实体维表请从模型详情中生成。"
        type="info"
        show-icon
        :closable="false"
        class="dialog-alert"
      />
      <el-row :gutter="20">
        <el-col :span="12">
          <el-form-item label="维表中文名" prop="tableName">
            <el-input
              v-model="form.tableName"
              maxlength="128"
              placeholder="请输入维表中文名称"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="物理表名" prop="physicalName">
            <el-input
              v-model="form.physicalName"
              maxlength="128"
              placeholder="例如：dim_org"
            />
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="关联模型" prop="modelId">
            <el-select
              v-model="form.modelId"
              filterable
              :disabled="Boolean(fixedModelId)"
              placeholder="请选择维度模型"
              style="width: 100%"
            >
              <el-option
                v-for="item in modelOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="Doris数据源" prop="datasourceId">
            <el-select
              v-model="form.datasourceId"
              filterable
              placeholder="请选择 Doris 数据源"
              style="width: 100%"
              @change="handleDatasourceChange"
            >
              <el-option
                v-for="item in datasourceOptions"
                :key="item.id"
                :label="datasourceLabel(item)"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="数据库" prop="databaseName">
            <el-select
              v-model="form.databaseName"
              filterable
              :disabled="!form.datasourceId"
              :loading="databaseLoading"
              placeholder="请选择数据库"
              style="width: 100%"
            >
              <el-option
                v-for="item in databaseOptions"
                :key="item.name"
                :label="item.name"
                :value="item.name"
              />
            </el-select>
          </el-form-item>
        </el-col>
        <el-col v-if="mode === 'ROLE_PLAYING'" :span="12">
          <el-form-item label="表类型">
            <el-input model-value="角色扮演维表" disabled />
          </el-form-item>
        </el-col>
        <el-col v-if="mode === 'ROLE_PLAYING'" :span="24">
          <el-form-item label="描述" prop="description">
            <el-input
              v-model="form.description"
              type="textarea"
              :rows="3"
              maxlength="500"
              show-word-limit
              placeholder="请输入维表描述"
            />
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" :loading="submitting" @click="handleSubmit">{{
        mode === "GENERATE" ? "生成维表" : "确定"
      }}</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts" name="DimensionTableFormDialog">
import type { FormInstance, FormRules } from "element-plus";
import { fetchDatasourceReferences } from "/@/api/dataPlatform/datasourceAsset";
import {
  createDimensionTable,
  fetchDimensionAttributes,
  fetchDimensionDatabaseOptions,
  fetchDimensionModelOptions,
  generateDimensionTable,
} from "/@/api/dataPlatform/dimension";
import { useMessage } from "/@/hooks/message";
import type { DatasourceReference } from "/@/types/dataPlatform/datasourceAsset";
import type { DataQueryDatabase } from "/@/types/dataPlatform/dataQuery";
import type {
  DimensionAttribute,
  DimensionDdlAttributeInput,
  DimensionOption,
  DimensionTableGenerateRequest,
  DimensionTableGenerateResult,
  DimensionTableSaveRequest,
} from "/@/types/dataPlatform/dimension";

type DialogMode = "ROLE_PLAYING" | "GENERATE";
const emit = defineEmits<{ refresh: [] }>();
const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const databaseLoading = ref(false);
const mode = ref<DialogMode>("ROLE_PLAYING");
const fixedModelId = ref("");
const formRef = ref<FormInstance>();
const modelOptions = ref<DimensionOption[]>([]);
const datasourceOptions = ref<DatasourceReference[]>([]);
const databaseOptions = ref<DataQueryDatabase[]>([]);

const createDefaultForm = () => ({
  tableName: "",
  physicalName: "",
  modelId: "",
  datasourceId: "",
  databaseName: "",
  description: "",
});
const form = reactive(createDefaultForm());
const rules: FormRules = {
  tableName: [
    { required: true, message: "请输入维表中文名称", trigger: "blur" },
  ],
  physicalName: [
    { required: true, message: "请输入物理表名", trigger: "blur" },
  ],
  modelId: [{ required: true, message: "请选择维度模型", trigger: "change" }],
  datasourceId: [
    { required: true, message: "请选择 Doris 数据源", trigger: "change" },
  ],
  databaseName: [
    { required: true, message: "请选择数据库", trigger: "change" },
  ],
};

const datasourceLabel = (item: DatasourceReference) =>
  item.displayName || item.name;

const loadModelOptions = async () => {
  try {
    const response = await fetchDimensionModelOptions();
    modelOptions.value = (Array.isArray(response.data)
      ? (response.data as DimensionOption[])
      : []
    ).map((item) => ({
      ...item,
      value: String(item.value),
    }));
  } catch (error: any) {
    modelOptions.value = [];
    useMessage().error(error?.msg || "加载启用的维度模型失败");
  }
};

const isForbidden = (error: any) => {
  const status = Number(error?.status ?? error?.statusCode ?? error?.code);
  return (
    status === 403 ||
    /403|无权|权限/.test(String(error?.msg || error?.message || ""))
  );
};

const loadDatasourceOptions = async () => {
  try {
    const response = await fetchDatasourceReferences();
    const references = Array.isArray(response.data)
      ? (response.data as DatasourceReference[])
      : [];
    datasourceOptions.value = references
      .map((item) => ({ ...item, id: String(item.id) }))
      .filter((item) => item.dsType?.toUpperCase() === "DORIS");
  } catch (error: any) {
    datasourceOptions.value = [];
    useMessage().error(
      isForbidden(error)
        ? "无权查看数据源，请联系管理员授予 dp_datasource_view 权限"
        : error?.msg || "加载 Doris 数据源失败"
    );
  }
};

const loadOptions = async () => {
  await Promise.all([loadModelOptions(), loadDatasourceOptions()]);
};

const loadDatabases = async (datasourceId: string) => {
  databaseOptions.value = [];
  if (!datasourceId) return;
  try {
    databaseLoading.value = true;
    const res = await fetchDimensionDatabaseOptions(datasourceId);
    databaseOptions.value = (
      Array.isArray(res.data) ? (res.data as DataQueryDatabase[]) : []
    ).filter((item) => Boolean(item?.name));
    form.databaseName =
      databaseOptions.value.find((item) => item.defaultDatabase)?.name || "";
  } catch (error: any) {
    useMessage().error(error?.msg || "加载 Doris 数据库失败");
  } finally {
    databaseLoading.value = false;
  }
};

const toDdlAttribute = (
  attribute: DimensionAttribute
): DimensionDdlAttributeInput => ({
  attrCode: attribute.attrCode,
  attrName: attribute.attrName,
  dataType: attribute.dataType,
  dataLength: attribute.dataLength,
  dataScale: attribute.dataScale,
  isPk: Number(attribute.isPk),
  isRequired: Number(attribute.isRequired),
  defaultValue: attribute.defaultValue ?? null,
  description: attribute.description ?? null,
});

const loadGenerateAttributes = async (modelId: string) => {
  const response = await fetchDimensionAttributes(modelId);
  const attributes = Array.isArray(response.data)
    ? (response.data as DimensionAttribute[])
    : [];
  return attributes.map(toDdlAttribute);
};

const handleDatasourceChange = async (datasourceId: string) => {
  form.databaseName = "";
  await loadDatabases(datasourceId);
};

const openDialog = async (dialogMode: DialogMode, modelId = "") => {
  visible.value = true;
  loading.value = true;
  mode.value = dialogMode;
  fixedModelId.value = modelId;
  databaseOptions.value = [];
  Object.assign(form, createDefaultForm(), { modelId });
  try {
    await loadOptions();
  } catch (error: any) {
    visible.value = false;
    useMessage().error(error?.msg || "加载维表选项失败");
  } finally {
    loading.value = false;
  }
  await nextTick();
  formRef.value?.clearValidate();
};

const handleSubmit = async () => {
  const valid = await formRef.value?.validate().catch(() => false);
  if (!valid) return;
  try {
    submitting.value = true;
    if (mode.value === "GENERATE") {
      const attributes = await loadGenerateAttributes(String(form.modelId));
      if (!attributes.length) {
        useMessage().warning("关联模型暂无属性，无法生成维表");
        return;
      }
      const payload: DimensionTableGenerateRequest = {
        modelId: String(form.modelId),
        datasourceId: String(form.datasourceId),
        databaseName: form.databaseName,
        physicalName: form.physicalName.trim(),
        tableName: form.tableName.trim(),
        scdType: "SCD1",
        attributes,
      };
      const response = await generateDimensionTable(payload);
      const result = response.data as DimensionTableGenerateResult;
      const tableId = result?.tableId == null ? "" : String(result.tableId);
      useMessage().success(tableId ? `实体维表生成成功，维表 ID：${tableId}` : "实体维表生成成功");
    } else {
      const payload: DimensionTableSaveRequest = {
        tableName: form.tableName.trim(),
        physicalName: form.physicalName.trim(),
        tableType: "ROLE_PLAYING",
        modelId: String(form.modelId),
        datasourceId: String(form.datasourceId),
        databaseName: form.databaseName,
        description: form.description.trim(),
      };
      await createDimensionTable(payload);
      useMessage().success("角色扮演维表新增成功");
    }
    visible.value = false;
    emit("refresh");
  } catch (error: any) {
    useMessage().error(
      error?.msg ||
        (mode.value === "GENERATE"
          ? "生成实体维表失败"
          : "新建角色扮演维表失败")
    );
  } finally {
    submitting.value = false;
  }
};

defineExpose({ openDialog });
</script>

<style scoped>
.dialog-alert {
  margin-bottom: 18px;
}
</style>
