<template>
	<el-dialog v-model="visible" title="维度表详情" width="860px" :close-on-click-modal="false" draggable>
		<el-tabs v-model="activeTab">
			<el-tab-pane label="基本信息" name="detail">
				<div v-loading="loading" class="detail-grid">
					<div>
						<span>维度表名称</span><strong>{{ detail?.tableName || '--' }}</strong>
					</div>
					<div>
						<span>物理表名</span><strong>{{ detail?.physicalName || '--' }}</strong>
					</div>
					<div>
						<span>表类型</span><strong>{{ optionLabel(tableTypes, detail?.tableType) }}</strong>
					</div>
					<div>
						<span>关联维度模型</span><strong>{{ detail?.modelName || '--' }}</strong>
					</div>
					<div>
						<span>业务系统</span><strong>{{ detail?.businessSystemName || '--' }}</strong>
					</div>
					<div>
						<span>业务域</span><strong>{{ detail?.businessDomainName || '--' }}</strong>
					</div>
					<div>
						<span>数据源</span><strong>{{ detail?.datasourceName || '--' }}</strong>
					</div>
					<div>
						<span>数据库</span><strong>{{ detail?.databaseName || '--' }}</strong>
					</div>
					<div>
						<span>当前结构版本</span><strong>{{ detail?.structureVersion || '--' }}</strong>
					</div>
					<div>
						<span>SCD 类型</span><strong>{{ detail?.scdType || '--' }}</strong>
					</div>
					<div>
						<span>当前有效记录数</span><strong>{{ displayCount(detail?.effectiveCount) }}</strong>
					</div>
					<div>
						<span>历史版本记录数</span><strong>{{ displayCount(detail?.historyCount) }}</strong>
					</div>
					<div>
						<span>总记录数</span><strong>{{ displayCount(detail?.totalCount) }}</strong>
					</div>
					<div>
						<span>最近物化时间</span><strong>{{ detail?.lastSyncTime || '--' }}</strong>
					</div>
					<div>
						<span>状态</span><strong>{{ optionLabel(statuses, detail?.status) }}</strong>
					</div>
					<div>
						<span>更新时间</span><strong>{{ detail?.updateTime || '--' }}</strong>
					</div>
					<div class="wide">
						<span>描述</span><strong>{{ detail?.description || '--' }}</strong>
					</div>
				</div>
			</el-tab-pane>
			<el-tab-pane label="结构版本" name="versions">
				<el-table v-loading="versionLoading" :data="versions" border empty-text="暂无结构版本记录">
					<el-table-column prop="versionNo" label="版本号" width="120" />
					<el-table-column prop="changelog" label="变更内容" min-width="280" show-overflow-tooltip>
						<template #default="{ row }">{{ row.changelog || '--' }}</template>
					</el-table-column>
					<el-table-column label="版本状态" width="120" align="center">
						<template #default="{ row }"
							><el-tag :type="row.isCurrent ? 'success' : 'info'">{{ row.isCurrent ? '当前版本' : '历史版本' }}</el-tag></template
						>
					</el-table-column>
					<el-table-column prop="effectiveTime" label="生效时间" width="180">
						<template #default="{ row }">{{ row.effectiveTime || '--' }}</template>
					</el-table-column>
					<el-table-column prop="operator" label="操作人" width="130">
						<template #default="{ row }">{{ row.operator || '--' }}</template>
					</el-table-column>
				</el-table>
			</el-tab-pane>
		</el-tabs>
		<template #footer>
			<el-button
				v-if="detail?.tableType === 'ENTITY'"
				v-auth="'dp_dim_table_generate'"
				type="primary"
				icon="Refresh"
				@click="emit('maintain', detail.id, 'STRUCTURE_UPDATE')"
			>
				更新表结构
			</el-button>
			<el-button @click="visible = false">关闭</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionTableDetailDialog">
import { fetchDimensionTableVersions, getDimensionTable } from '/@/api/dataPlatform/dimension';
import { useMessage } from '/@/hooks/message';
import type { DimensionOption, DimensionTable, DimensionTableVersion } from '/@/types/dataPlatform/dimension';

const emit = defineEmits<{ maintain: [tableId: string, mode: 'STRUCTURE_UPDATE'] }>();
defineProps<{ tableTypes: DimensionOption[]; statuses: DimensionOption[] }>();
const visible = ref(false);
const loading = ref(false);
const versionLoading = ref(false);
const activeTab = ref('detail');
const currentTableId = ref('');
const detail = ref<DimensionTable | null>(null);
const versions = ref<DimensionTableVersion[]>([]);

const optionLabel = (options: DimensionOption[], value?: string | null) => options.find((item) => item.value === value)?.label || value || '--';
const displayCount = (value?: string | null) => (value == null || value === '' ? '--' : value);

const openDialog = async (id: string, tab: 'detail' | 'versions' = 'detail') => {
	currentTableId.value = String(id);
	visible.value = true;
	activeTab.value = tab;
	detail.value = null;
	versions.value = [];
	try {
		loading.value = true;
		versionLoading.value = true;
		const [detailRes, versionRes] = await Promise.all([getDimensionTable(id), fetchDimensionTableVersions(id)]);
		const table = detailRes.data as DimensionTable;
		detail.value = {
			...table,
			id: String(table.id),
			modelId: String(table.modelId),
			datasourceId: table.datasourceId == null ? null : String(table.datasourceId),
		};
		versions.value = Array.isArray(versionRes.data) ? (versionRes.data as DimensionTableVersion[]) : [];
	} catch (error: any) {
		useMessage().error(error?.msg || '加载维度表详情失败');
	} finally {
		loading.value = false;
		versionLoading.value = false;
	}
};

const refreshCurrent = async (id?: string) => {
	if (!visible.value || !currentTableId.value || (id && String(id) !== currentTableId.value)) return;
	await openDialog(currentTableId.value, activeTab.value as 'detail' | 'versions');
};

defineExpose({ openDialog, refreshCurrent });
</script>

<style scoped lang="scss">
.detail-grid {
	display: grid;
	grid-template-columns: repeat(3, minmax(0, 1fr));
	gap: 1px;
	background: var(--el-border-color-lighter);
	border: 1px solid var(--el-border-color-lighter);

	> div {
		min-height: 72px;
		padding: 13px 16px;
		background: var(--el-bg-color);

		span,
		strong {
			display: block;
		}

		span {
			margin-bottom: 7px;
			font-size: 12px;
			color: var(--el-text-color-secondary);
		}

		strong {
			font-weight: 500;
			word-break: break-word;
		}
	}

	.wide {
		grid-column: span 3;
	}
}
</style>
