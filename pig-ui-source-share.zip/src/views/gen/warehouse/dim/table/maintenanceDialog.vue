<template>
	<el-dialog v-model="visible" :title="dialogTitle" width="980px" :close-on-click-modal="false" draggable>
		<div v-loading="loading" class="maintenance-dialog">
			<template v-if="successResult">
				<el-result icon="success" title="维表结构更新成功" sub-title="原表已保留为备份，请重新配置并发布新的 DIM 任务版本后再执行物化。">
					<template #extra>
						<el-descriptions :column="1" border class="success-detail">
							<el-descriptions-item label="结构版本">{{ successResult.structureVersion }}</el-descriptions-item>
							<el-descriptions-item label="备份表">{{ successResult.backupTableName }}</el-descriptions-item>
						</el-descriptions>
					</template>
				</el-result>
			</template>

			<template v-else-if="preview">
				<el-alert
					:title="
						mode === 'STRUCTURE_UPDATE'
							? '仅空表支持自动更新；成功后旧表会作为备份保留，必须重新发布 DIM 任务。'
							: '彻底删除会删除 Doris 物理表及全部数据，且无法由平台事务回滚。'
					"
					:type="mode === 'STRUCTURE_UPDATE' ? 'warning' : 'error'"
					:closable="false"
					show-icon
					class="mb16"
				/>

				<el-descriptions :column="3" border>
					<el-descriptions-item label="维表ID">{{ preview.tableId }}</el-descriptions-item>
					<el-descriptions-item label="完整物理表名">{{ preview.qualifiedName }}</el-descriptions-item>
					<el-descriptions-item label="模型审计版本">{{ preview.modelVersion ?? '--' }}</el-descriptions-item>
					<el-descriptions-item label="Doris实时行数">{{ displayValue(preview.rowCount) }}</el-descriptions-item>
					<el-descriptions-item label="数据源/地址">{{ preview.currentStructure?.endpointIdentity || '--' }}</el-descriptions-item>
					<el-descriptions-item label="数据库">{{ qualifiedDatabase }}</el-descriptions-item>
					<el-descriptions-item label="物理表">{{ qualifiedPhysicalName }}</el-descriptions-item>
					<el-descriptions-item label="共享维表">{{ idListText(preview.sharedTableIds) }}</el-descriptions-item>
					<el-descriptions-item label="引用任务" :span="3">{{ idListText(preview.referencedTaskIds) }}</el-descriptions-item>
				</el-descriptions>

				<el-alert v-if="blockedReason" :title="blockedReason" type="error" :closable="false" show-icon class="mt16" />
				<el-alert v-if="submitError" :title="submitError" type="error" :closable="false" show-icon class="mt16" />

				<template v-if="mode === 'STRUCTURE_UPDATE'">
					<div class="section-title">字段差异</div>
					<el-table :data="columnDiffs" border max-height="300" empty-text="当前结构与期望结构没有字段差异">
						<el-table-column prop="name" label="字段" min-width="150" show-overflow-tooltip />
						<el-table-column prop="currentType" label="当前类型" min-width="145" show-overflow-tooltip />
						<el-table-column prop="expectedType" label="期望类型" min-width="145" show-overflow-tooltip />
						<el-table-column prop="currentNullable" label="当前可空" width="100" />
						<el-table-column prop="expectedNullable" label="期望可空" width="100" />
						<el-table-column label="变化" min-width="180">
							<template #default="{ row }">
								<el-tag v-for="item in row.changes" :key="item" :type="item === '无变化' ? 'info' : 'warning'" class="change-tag">{{ item }}</el-tag>
							</template>
						</el-table-column>
					</el-table>

					<el-descriptions :column="2" border class="mt16">
						<el-descriptions-item label="当前KEY">{{ keyText(preview.currentStructure?.keyColumns) }}</el-descriptions-item>
						<el-descriptions-item label="期望KEY">{{ keyText(preview.expectedKeyColumns) }}</el-descriptions-item>
						<el-descriptions-item label="KEY变化" :span="2">{{ keyChanged ? 'KEY列或顺序发生变化' : '无变化' }}</el-descriptions-item>
						<el-descriptions-item label="当前分布策略">{{ formatJson(preview.currentStructure?.distribution) }}</el-descriptions-item>
						<el-descriptions-item label="当前分桶数">{{ preview.currentStructure?.bucket ?? '--' }}</el-descriptions-item>
						<el-descriptions-item label="当前分区策略">{{ formatJson(preview.currentStructure?.partition) }}</el-descriptions-item>
						<el-descriptions-item label="当前引擎属性">{{ formatJson(preview.currentStructure?.engineProperties) }}</el-descriptions-item>
					</el-descriptions>

					<div class="section-title">服务端生成的期望DDL</div>
					<pre class="ddl-preview">{{ preview.createDdl || '--' }}</pre>
				</template>

				<div class="section-title">安全确认</div>
				<el-form label-width="150px">
					<el-form-item label="输入完整物理表名" required>
						<el-input v-model="confirmTableName" :placeholder="`请输入 ${preview.qualifiedName}`" autocomplete="off" />
						<div class="confirm-tip">为避免误操作，请手动输入完整表名；系统不会自动填入。</div>
					</el-form-item>
				</el-form>
			</template>

			<el-empty v-else-if="!loading" description="维护预览加载失败，请手动重新预览" />
		</div>

		<template #footer>
			<el-button :disabled="loading || submitting" @click="visible = false">{{ successResult ? '关闭' : '取消' }}</el-button>
			<el-button v-if="!successResult" :loading="loading" :disabled="submitting" @click="loadPreview">重新预览</el-button>
			<el-button
				v-if="!successResult"
				:type="mode === 'STRUCTURE_UPDATE' ? 'primary' : 'danger'"
				:loading="submitting"
				:disabled="confirmDisabled"
				@click="handleConfirm"
			>
				{{ mode === 'STRUCTURE_UPDATE' ? '确认更新结构' : '确认彻底删除' }}
			</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionTableMaintenanceDialog">
import { deleteDimensionTablePhysical, previewDimensionTableMaintenance, updateDimensionTableStructure } from '/@/api/dataPlatform/dimension';
import { useMessage } from '/@/hooks/message';
import type {
	DimensionExpectedColumn,
	DimensionPhysicalColumn,
	DimensionTableMaintenancePreview,
	DimensionTableStructureUpdateResult,
} from '/@/types/dataPlatform/dimension';

type MaintenanceMode = 'STRUCTURE_UPDATE' | 'PHYSICAL_DELETE';

interface ColumnDiffRow {
	name: string;
	currentType: string;
	expectedType: string;
	currentNullable: string;
	expectedNullable: string;
	changes: string[];
}

const emit = defineEmits<{ success: [tableId: string, mode: MaintenanceMode] }>();
const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const tableId = ref('');
const mode = ref<MaintenanceMode>('STRUCTURE_UPDATE');
const preview = ref<DimensionTableMaintenancePreview>();
const confirmTableName = ref('');
const submitError = ref('');
const previewStale = ref(false);
const successResult = ref<DimensionTableStructureUpdateResult>();

const dialogTitle = computed(() => (mode.value === 'STRUCTURE_UPDATE' ? '更新维表结构' : '彻底删除维表'));
const allowed = computed(() =>
	mode.value === 'STRUCTURE_UPDATE' ? preview.value?.canUpdateStructure === true : preview.value?.canDeletePhysical === true
);
const blockedReason = computed(() =>
	mode.value === 'STRUCTURE_UPDATE' ? preview.value?.updateBlockedReason : preview.value?.deletePhysicalBlockedReason
);
const confirmDisabled = computed(
	() =>
		loading.value ||
		submitting.value ||
		!preview.value ||
		!allowed.value ||
		previewStale.value ||
		confirmTableName.value.trim() !== preview.value.qualifiedName
);
const keyChanged = computed(() => {
	const current = preview.value?.currentStructure?.keyColumns || [];
	const expected = preview.value?.expectedKeyColumns || [];
	return JSON.stringify(current) !== JSON.stringify(expected);
});
const qualifiedNameParts = computed(() => preview.value?.qualifiedName?.split('.').filter(Boolean) || []);
const qualifiedPhysicalName = computed(() => qualifiedNameParts.value[qualifiedNameParts.value.length - 1] || '--');
const qualifiedDatabase = computed(() => (qualifiedNameParts.value.length > 1 ? qualifiedNameParts.value.slice(0, -1).join('.') : '--'));

const nullableText = (value?: boolean | null) => (value === true ? '是' : value === false ? '否' : '--');
const normalizedType = (value?: string) =>
	String(value || '')
		.replace(/\s+/g, '')
		.toUpperCase();
const isPrimary = (column?: DimensionExpectedColumn) => column?.isPrimary === true || column?.isPrimary === 1;
const columnDiffs = computed<ColumnDiffRow[]>(() => {
	const currentColumns = preview.value?.currentStructure?.columns || [];
	const expectedColumns = preview.value?.expectedColumns || [];
	const currentMap = new Map(currentColumns.map((item) => [item.name.toLowerCase(), item]));
	const expectedMap = new Map(expectedColumns.map((item) => [item.columnName.toLowerCase(), item]));
	const names = [
		...expectedColumns.map((item) => item.columnName),
		...currentColumns.filter((item) => !expectedMap.has(item.name.toLowerCase())).map((item) => item.name),
	];
	return names.map((name) => {
		const current = currentMap.get(name.toLowerCase()) as DimensionPhysicalColumn | undefined;
		const expected = expectedMap.get(name.toLowerCase());
		const changes: string[] = [];
		if (!current) changes.push('新增');
		if (!expected) changes.push('移除');
		if (current && expected && normalizedType(current.type) !== normalizedType(expected.columnType)) changes.push('类型变化');
		if (current && expected && expected.nullable != null && current.nullable !== expected.nullable) changes.push('NULL变化');
		if (expected && isPrimary(expected)) changes.push('KEY列');
		return {
			name,
			currentType: current?.type || '--',
			expectedType: expected?.columnType || '--',
			currentNullable: nullableText(current?.nullable),
			expectedNullable: expected?.nullable == null && isPrimary(expected) ? '否' : nullableText(expected?.nullable),
			changes: changes.length ? changes : ['无变化'],
		};
	});
});

const displayValue = (value?: string | null) => (value == null || value === '' ? '--' : value);
const idListText = (ids?: string[]) => (ids?.length ? ids.join(', ') : '无');
const keyText = (keys?: string[]) => (keys?.length ? keys.join(' → ') : '--');
const formatJson = (value: unknown) => {
	if (value == null || value === '') return '--';
	if (typeof value === 'string') return value;
	try {
		return JSON.stringify(value);
	} catch {
		return String(value);
	}
};

const loadPreview = async () => {
	if (!tableId.value) return;
	try {
		loading.value = true;
		preview.value = undefined;
		confirmTableName.value = '';
		submitError.value = '';
		previewStale.value = false;
		const response = await previewDimensionTableMaintenance(tableId.value);
		preview.value = response.data as DimensionTableMaintenancePreview;
	} catch (error: any) {
		useMessage().error(error?.msg || '加载维表维护预览失败');
	} finally {
		loading.value = false;
	}
};

const handleConfirm = async () => {
	if (confirmDisabled.value || !preview.value) return;
	try {
		submitting.value = true;
		submitError.value = '';
		const payload = {
			previewToken: preview.value.previewToken,
			confirmTableName: confirmTableName.value.trim(),
		};
		if (mode.value === 'STRUCTURE_UPDATE') {
			const response = await updateDimensionTableStructure(tableId.value, payload);
			successResult.value = response.data as DimensionTableStructureUpdateResult;
			useMessage().success('维表结构更新成功');
		} else {
			await deleteDimensionTablePhysical(tableId.value, payload);
			useMessage().success('维表及 Doris 物理数据已彻底删除');
			visible.value = false;
		}
		emit('success', tableId.value, mode.value);
	} catch (error: any) {
		submitError.value = error?.msg || '维护条件或预览已发生变化，请重新预览后确认';
		previewStale.value = true;
		useMessage().error(submitError.value);
	} finally {
		submitting.value = false;
	}
};

const openDialog = (id: string, maintenanceMode: MaintenanceMode) => {
	tableId.value = String(id);
	mode.value = maintenanceMode;
	visible.value = true;
	preview.value = undefined;
	confirmTableName.value = '';
	submitError.value = '';
	previewStale.value = false;
	successResult.value = undefined;
	loadPreview();
};

defineExpose({ openDialog });
</script>

<style scoped lang="scss">
.maintenance-dialog {
	min-height: 240px;
}

.section-title {
	margin: 22px 0 10px;
	font-size: 15px;
	font-weight: 600;
}

.ddl-preview {
	max-height: 240px;
	padding: 14px;
	overflow: auto;
	font-family: Consolas, monospace;
	line-height: 1.6;
	white-space: pre-wrap;
	background: var(--el-fill-color-lighter);
	border: 1px solid var(--el-border-color-lighter);
	border-radius: 4px;
}

.change-tag {
	margin: 2px 4px 2px 0;
}

.confirm-tip {
	font-size: 12px;
	color: var(--el-text-color-secondary);
}

.success-detail {
	width: 620px;
	max-width: 100%;
	text-align: left;
}

.mt16 {
	margin-top: 16px;
}

.mb16 {
	margin-bottom: 16px;
}
</style>
