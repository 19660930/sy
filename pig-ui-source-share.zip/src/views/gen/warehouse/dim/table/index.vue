<template>
	<div class="dimension-table-page layout-padding">
		<el-card shadow="never" class="page-card">
			<div class="page-heading">
				<div>
					<div class="page-title">维度表管理</div>
					<div class="page-description">管理根据维度模型生成的实体维表、角色扮演维表、结构版本和物化任务。</div>
				</div>
				<el-button v-auth="'dp_dim_table_add'" type="primary" icon="Plus" @click="tableFormRef?.openDialog('ROLE_PLAYING')">
					新建角色扮演维表
				</el-button>
			</div>

			<div class="filter-panel">
				<el-form ref="queryRef" :inline="true" :model="query" @keyup.enter="handleSearch">
					<el-form-item label="维表检索" prop="keyword">
						<el-input v-model="query.keyword" clearable placeholder="中文名称或物理表名" style="width: 210px" />
					</el-form-item>
					<el-form-item label="关联维度" prop="modelId">
						<el-select v-model="query.modelId" clearable filterable placeholder="全部维度" style="width: 180px">
							<el-option v-for="item in modelOptions" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="表类型" prop="tableType">
						<el-select v-model="query.tableType" clearable placeholder="全部类型" style="width: 160px">
							<el-option v-for="item in dimensionOptions.tableTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="SCD类型" prop="scdType">
						<el-select v-model="query.scdType" clearable placeholder="全部类型" style="width: 130px">
							<el-option v-for="item in dimensionOptions.scdTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="状态" prop="status">
						<el-select v-model="query.status" clearable placeholder="全部状态" style="width: 130px">
							<el-option v-for="item in dimensionOptions.statuses" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item>
						<el-button type="primary" icon="Search" @click="handleSearch">查询</el-button>
						<el-button icon="Refresh" @click="resetQuery">重置</el-button>
					</el-form-item>
				</el-form>
			</div>

			<div class="table-heading">
				<div class="table-title">
					维度表列表 <span>（{{ page.total }}）</span>
				</div>
				<el-button icon="Refresh" :loading="loading" @click="loadTables">刷新</el-button>
			</div>

			<el-table v-loading="loading" :data="tables" border row-key="id" empty-text="暂无维度表">
				<el-table-column prop="tableName" label="维度表名称" min-width="160" show-overflow-tooltip />
				<el-table-column prop="physicalName" label="物理表名" min-width="170" show-overflow-tooltip />
				<el-table-column label="表类型" width="130">
					<template #default="{ row }">{{ optionLabel(dimensionOptions.tableTypes, row.tableType) }}</template>
				</el-table-column>
				<el-table-column prop="modelName" label="关联维度" min-width="150" show-overflow-tooltip>
					<template #default="{ row }">{{ row.modelName || optionLabel(modelOptions, row.modelId) }}</template>
				</el-table-column>
				<el-table-column prop="businessSystemName" label="业务系统" min-width="120">
					<template #default="{ row }">{{ row.businessSystemName || '--' }}</template>
				</el-table-column>
				<el-table-column prop="businessDomainName" label="业务域" min-width="120">
					<template #default="{ row }">{{ row.businessDomainName || '--' }}</template>
				</el-table-column>
				<el-table-column prop="structureVersion" label="当前版本" width="110">
					<template #default="{ row }">{{ row.structureVersion || '--' }}</template>
				</el-table-column>
				<el-table-column prop="scdType" label="SCD类型" width="100" align="center" />
				<el-table-column prop="totalCount" label="总记录数" width="120" align="right">
					<template #default="{ row }">{{ displayCount(row.totalCount) }}</template>
				</el-table-column>
				<el-table-column label="状态" width="100" align="center">
					<template #default="{ row }">
						<el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">{{ optionLabel(dimensionOptions.statuses, row.status) }}</el-tag>
					</template>
				</el-table-column>
				<el-table-column prop="updateTime" label="更新时间" width="180">
					<template #default="{ row }">{{ row.updateTime || '--' }}</template>
				</el-table-column>
				<el-table-column label="操作" width="500" fixed="right">
					<template #default="{ row }">
						<div class="row-actions">
							<el-button v-auth="'dp_dim_table_view'" text type="primary" icon="View" @click="detailDialogRef?.openDialog(row.id, 'detail')"
								>查看</el-button
							>
							<el-button v-auth="'dp_dim_table_view'" text type="primary" icon="Tickets" @click="detailDialogRef?.openDialog(row.id, 'versions')">
								版本
							</el-button>
							<el-button
								v-auth="'dp_dim_table_publish'"
								text
								type="primary"
								icon="Promotion"
								:loading="deployingId === row.id"
								@click="handleDeploy(row)"
							>
								部署
							</el-button>
							<el-button
								v-auth="'dp_dim_table_edit'"
								text
								:type="row.status === 'ENABLED' ? 'warning' : 'success'"
								:loading="changingId === row.id"
								@click="handleToggle(row)"
							>
								{{ row.status === 'ENABLED' ? '停用' : '启用' }}
							</el-button>
							<el-button
								v-auth="'dp_dim_table_generate'"
								text
								type="primary"
								icon="Refresh"
								@click="maintenanceDialogRef?.openDialog(row.id, 'STRUCTURE_UPDATE')"
							>
								更新表结构
							</el-button>
							<el-button
								v-auth="'dp_dim_table_edit'"
								text
								type="danger"
								icon="WarningFilled"
								@click="maintenanceDialogRef?.openDialog(row.id, 'PHYSICAL_DELETE')"
							>
								彻底删除
							</el-button>
						</div>
					</template>
				</el-table-column>
			</el-table>

			<pagination
				v-if="page.total !== '0'"
				:current="page.current"
				:size="page.size"
				:total="page.total"
				@current-change="handleCurrentChange"
				@size-change="handleSizeChange"
			/>
		</el-card>

		<TableFormDialog ref="tableFormRef" @refresh="loadTables" />
		<DetailDialog
			ref="detailDialogRef"
			:table-types="dimensionOptions.tableTypes"
			:statuses="dimensionOptions.statuses"
			@maintain="openMaintenance"
		/>
		<MaintenanceDialog ref="maintenanceDialogRef" @success="handleMaintenanceSuccess" />
	</div>
</template>

<script setup lang="ts" name="DimensionTableList">
import type { FormInstance } from 'element-plus';
import {
	deployDimensionTable,
	fetchDimensionModelOptions,
	fetchDimensionOptions,
	fetchDimensionTablePage,
	setDimensionTableEnabled,
} from '/@/api/dataPlatform/dimension';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type {
	DimensionDeployResult,
	DimensionOption,
	DimensionTable,
	DimensionTablePage,
	DimensionTableQuery,
} from '/@/types/dataPlatform/dimension';
import DetailDialog from './detailDialog.vue';
import MaintenanceDialog from './maintenanceDialog.vue';
import TableFormDialog from './tableFormDialog.vue';

const router = useRouter();
const queryRef = ref<FormInstance>();
const tableFormRef = ref<InstanceType<typeof TableFormDialog>>();
const detailDialogRef = ref<InstanceType<typeof DetailDialog>>();
const maintenanceDialogRef = ref<InstanceType<typeof MaintenanceDialog>>();
const loading = ref(false);
const changingId = ref('');
const deployingId = ref('');
const tables = ref<DimensionTable[]>([]);
const modelOptions = ref<DimensionOption[]>([]);
const page = reactive({ current: 1, size: 10, total: '0' });
const dimensionOptions = reactive<{ tableTypes: DimensionOption[]; scdTypes: DimensionOption[]; statuses: DimensionOption[] }>({
	tableTypes: [],
	scdTypes: [],
	statuses: [],
});
const query = reactive<DimensionTableQuery>({
	current: 1,
	size: 10,
	keyword: '',
	tableType: '',
	scdType: '',
	modelId: '',
	status: '',
});

const optionLabel = (options: DimensionOption[], value?: string | null) => options.find((item) => item.value === value)?.label || value || '--';
const displayCount = (value?: string | null) => (value == null || value === '' ? '--' : value);
const normalizeTable = (item: any): DimensionTable => ({
	...item,
	id: String(item.id),
	modelId: String(item.modelId),
	datasourceId: item.datasourceId == null ? null : String(item.datasourceId),
});

const buildQuery = (): DimensionTableQuery => {
	const params: DimensionTableQuery = { current: page.current, size: page.size };
	if (query.keyword?.trim()) params.keyword = query.keyword.trim();
	if (query.tableType) params.tableType = query.tableType;
	if (query.scdType) params.scdType = query.scdType;
	if (query.modelId) params.modelId = query.modelId;
	if (query.status) params.status = query.status;
	return params;
};

const loadTables = async () => {
	try {
		loading.value = true;
		const res = await fetchDimensionTablePage(buildQuery());
		const data = (res.data || {}) as DimensionTablePage;
		tables.value = Array.isArray(data.records) ? data.records.map(normalizeTable) : [];
		page.total = String(data.total ?? '0');
	} catch (error: any) {
		tables.value = [];
		page.total = '0';
		useMessage().error(error?.msg || '查询维度表失败');
	} finally {
		loading.value = false;
	}
};

const loadOptions = async () => {
	const [dimensionRes, modelRes] = await Promise.all([fetchDimensionOptions(), fetchDimensionModelOptions()]);
	const data = (dimensionRes.data || {}) as any;
	dimensionOptions.tableTypes = data.tableTypes || [];
	dimensionOptions.scdTypes = data.scdTypes || [];
	dimensionOptions.statuses = data.statuses || [];
	modelOptions.value = Array.isArray(modelRes.data) ? (modelRes.data as DimensionOption[]) : [];
};

const handleSearch = () => {
	page.current = 1;
	loadTables();
};
const resetQuery = () => {
	queryRef.value?.resetFields();
	page.current = 1;
	loadTables();
};
const handleCurrentChange = (current: number) => {
	page.current = current;
	loadTables();
};
const handleSizeChange = (size: number) => {
	page.current = 1;
	page.size = size;
	loadTables();
};

const handleToggle = async (table: DimensionTable) => {
	const enabled = table.status !== 'ENABLED';
	try {
		await useMessageBox().confirm(`确认${enabled ? '启用' : '停用'}维度表“${table.tableName}”吗？`);
	} catch {
		return;
	}
	try {
		changingId.value = table.id;
		await setDimensionTableEnabled(table.id, enabled);
		useMessage().success(`${enabled ? '启用' : '停用'}成功`);
		await loadTables();
	} catch (error: any) {
		useMessage().error(error?.msg || `${enabled ? '启用' : '停用'}维度表失败`);
	} finally {
		changingId.value = '';
	}
};

const handleDeploy = async (table: DimensionTable) => {
	try {
		await useMessageBox().confirm(`确认按维度表“${table.tableName}”生成新的 DIM_BUILD 任务版本吗？`);
	} catch {
		return;
	}
	try {
		deployingId.value = table.id;
		const res = await deployDimensionTable(table.id, '');
		const result = res.data as DimensionDeployResult;
		useMessage().success(`DIM 构建任务已生成，任务 ID：${result.taskId}`);
		try {
			await useMessageBox().confirm('是否前往“分层任务运维”继续发布或执行？');
			router.push('/gen/development/layered-task');
		} catch {
			// 用户选择留在当前页面。
		}
	} catch (error: any) {
		useMessage().error(error?.msg || '生成 DIM 构建任务失败');
	} finally {
		deployingId.value = '';
	}
};

const openMaintenance = (id: string, mode: 'STRUCTURE_UPDATE' | 'PHYSICAL_DELETE') => {
	maintenanceDialogRef.value?.openDialog(id, mode);
};

const handleMaintenanceSuccess = async (id: string) => {
	await loadTables();
	await detailDialogRef.value?.refreshCurrent(id);
};

onMounted(async () => {
	try {
		await loadOptions();
	} catch (error: any) {
		useMessage().error(error?.msg || '加载维度表选项失败');
	}
	await loadTables();
});
</script>

<style scoped lang="scss">
.dimension-table-page {
	.page-card {
		min-height: calc(100vh - 115px);
	}

	.page-heading,
	.table-heading,
	.row-actions {
		display: flex;
		align-items: center;
	}

	.page-heading,
	.table-heading {
		justify-content: space-between;
	}

	.page-heading {
		align-items: flex-start;
		padding-bottom: 18px;
		border-bottom: 1px solid var(--el-border-color-lighter);
	}

	.page-title {
		font-size: 20px;
		font-weight: 600;
	}

	.page-description {
		margin-top: 8px;
		color: var(--el-text-color-secondary);
	}

	.filter-panel {
		padding: 16px 16px 0;
		margin-top: 16px;
		background: var(--el-fill-color-lighter);
		border: 1px solid var(--el-border-color-lighter);
		border-radius: 4px;
	}

	.table-heading {
		margin: 18px 0 10px;
	}

	.table-title {
		font-size: 16px;
		font-weight: 600;

		span {
			color: var(--el-text-color-secondary);
		}
	}

	.row-actions {
		white-space: nowrap;

		:deep(.el-button + .el-button) {
			margin-left: 4px;
		}
	}
}
</style>
