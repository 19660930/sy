<template>
	<div class="dimension-strategy-page layout-padding">
		<el-card shadow="never" class="page-card">
			<div class="page-heading">
				<div>
					<div class="page-title">维度策略管理</div>
					<div class="page-description">配置维度成员变化时的覆盖方式和历史保留规则。</div>
				</div>
				<el-button v-auth="'dp_dim_strategy_add'" type="primary" icon="Plus" @click="formDialogRef?.openDialog()">新增策略</el-button>
			</div>

			<div class="filter-panel">
				<el-form ref="queryRef" :inline="true" :model="query" @keyup.enter="handleSearch">
					<el-form-item label="策略名称" prop="keyword">
						<el-input v-model="query.keyword" clearable placeholder="请输入策略名称" style="width: 190px" />
					</el-form-item>
					<el-form-item label="维度模型" prop="modelId">
						<el-select v-model="query.modelId" clearable filterable placeholder="全部模型" style="width: 180px">
							<el-option v-for="item in modelOptions" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="维度表" prop="dimTableId">
						<el-select v-model="query.dimTableId" clearable filterable placeholder="全部维表" style="width: 180px">
							<el-option v-for="item in tableOptions" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="SCD类型" prop="scdType">
						<el-select v-model="query.scdType" clearable placeholder="全部类型" style="width: 130px">
							<el-option v-for="item in dimensionOptions.scdTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="状态" prop="status">
						<el-select v-model="query.status" clearable placeholder="全部状态" style="width: 130px">
							<el-option v-for="item in dimensionOptions.statuses" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item>
						<el-button type="primary" icon="Search" @click="handleSearch">查询</el-button>
						<el-button icon="Refresh" @click="resetQuery">重置</el-button>
					</el-form-item>
				</el-form>
			</div>

			<div class="table-heading">
				<div class="table-title">策略列表 <span>（{{ page.total }}）</span></div>
				<el-button icon="Refresh" :loading="loading" @click="loadStrategies">刷新</el-button>
			</div>

			<el-table v-loading="loading" :data="strategies" border row-key="id" empty-text="暂无维度策略">
				<el-table-column prop="strategyName" label="策略名称" min-width="190" show-overflow-tooltip />
				<el-table-column prop="modelName" label="维度模型" min-width="150" show-overflow-tooltip>
					<template #default="{ row }">{{ row.modelName || optionLabel(modelOptions, row.modelId) }}</template>
				</el-table-column>
				<el-table-column prop="dimTableName" label="维度表" min-width="160" show-overflow-tooltip>
					<template #default="{ row }">{{ row.dimTableName || optionLabel(tableOptions, row.dimTableId) }}</template>
				</el-table-column>
				<el-table-column prop="scdType" label="SCD类型" width="100" align="center" />
				<el-table-column prop="naturalKey" label="自然键" min-width="150" show-overflow-tooltip>
					<template #default="{ row }">{{ row.naturalKey || '--' }}</template>
				</el-table-column>
				<el-table-column prop="surrogateKey" label="代理键" min-width="130" show-overflow-tooltip>
					<template #default="{ row }">{{ row.surrogateKey || '--' }}</template>
				</el-table-column>
				<el-table-column label="历史保留方式" width="140">
					<template #default="{ row }">{{ optionLabel(dimensionOptions.historyKeepModes, row.historyKeepMode) }}</template>
				</el-table-column>
				<el-table-column prop="scheduleCron" label="执行周期" min-width="150" show-overflow-tooltip>
					<template #default="{ row }">{{ row.scheduleCron || '未配置' }}</template>
				</el-table-column>
				<el-table-column label="状态" width="100" align="center">
					<template #default="{ row }">
						<el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">{{ optionLabel(dimensionOptions.statuses, row.status) }}</el-tag>
					</template>
				</el-table-column>
				<el-table-column label="操作" width="250" fixed="right">
					<template #default="{ row }">
						<div class="row-actions">
							<el-tooltip v-if="unsupportedScd(row.scdType)" content="SCD2/SCD3 为后续版本支持，当前不可配置" placement="top">
								<span><el-button v-auth="'dp_dim_strategy_edit'" text type="primary" icon="Edit" disabled>配置</el-button></span>
							</el-tooltip>
							<el-button v-else v-auth="'dp_dim_strategy_edit'" text type="primary" icon="Edit" @click="formDialogRef?.openDialog(row)">配置</el-button>
							<el-button
								v-auth="'dp_dim_strategy_edit'"
								text
								:type="row.status === 'ENABLED' ? 'warning' : 'success'"
								:loading="changingId === row.id"
								@click="handleToggle(row)"
							>
								{{ row.status === 'ENABLED' ? '停用' : '启用' }}
							</el-button>
							<el-button
								v-auth="'dp_dim_strategy_delete'"
								text
								type="danger"
								icon="Delete"
								:loading="deletingId === row.id"
								@click="handleDelete(row)"
							>
								删除
							</el-button>
						</div>
					</template>
				</el-table-column>
			</el-table>

			<pagination
				v-if="page.total !== '0'"
				:current="page.current"
				:size="page.size"
				:total="page.total"
				@current-change="handleCurrentChange"
				@size-change="handleSizeChange"
			/>
		</el-card>

		<FormDialog
			ref="formDialogRef"
			:model-options="modelOptions"
			:scd-types="dimensionOptions.scdTypes"
			:history-keep-modes="dimensionOptions.historyKeepModes"
			@refresh="loadStrategies"
		/>
	</div>
</template>

<script setup lang="ts" name="DimensionStrategyList">
import type { FormInstance } from 'element-plus';
import {
	deleteDimensionStrategy,
	fetchDimensionModelOptions,
	fetchDimensionOptions,
	fetchDimensionStrategyPage,
	fetchDimensionTableOptions,
	setDimensionStrategyEnabled,
} from '/@/api/dataPlatform/dimension';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type {
	DimensionOption,
	DimensionStrategy,
	DimensionStrategyPage,
	DimensionStrategyQuery,
} from '/@/types/dataPlatform/dimension';
import FormDialog from './formDialog.vue';

const queryRef = ref<FormInstance>();
const formDialogRef = ref<InstanceType<typeof FormDialog>>();
const loading = ref(false);
const changingId = ref('');
const deletingId = ref('');
const strategies = ref<DimensionStrategy[]>([]);
const modelOptions = ref<DimensionOption[]>([]);
const tableOptions = ref<DimensionOption[]>([]);
const page = reactive({ current: 1, size: 10, total: '0' });
const dimensionOptions = reactive<{ scdTypes: DimensionOption[]; statuses: DimensionOption[]; historyKeepModes: DimensionOption[] }>({
	scdTypes: [],
	statuses: [],
	historyKeepModes: [],
});
const query = reactive<DimensionStrategyQuery>({
	current: 1,
	size: 10,
	keyword: '',
	modelId: '',
	dimTableId: '',
	scdType: '',
	status: '',
});

const optionLabel = (options: DimensionOption[], value?: string | null) => options.find((item) => item.value === value)?.label || value || '--';
const unsupportedScd = (value: string) => ['SCD2', 'SCD3'].includes(value);
const normalizeStrategy = (item: any): DimensionStrategy => ({
	...item,
	id: String(item.id),
	modelId: String(item.modelId),
	dimTableId: item.dimTableId == null ? null : String(item.dimTableId),
});

const buildQuery = (): DimensionStrategyQuery => {
	const params: DimensionStrategyQuery = { current: page.current, size: page.size };
	if (query.keyword?.trim()) params.keyword = query.keyword.trim();
	if (query.modelId) params.modelId = query.modelId;
	if (query.dimTableId) params.dimTableId = query.dimTableId;
	if (query.scdType) params.scdType = query.scdType;
	if (query.status) params.status = query.status;
	return params;
};

const loadStrategies = async () => {
	try {
		loading.value = true;
		const res = await fetchDimensionStrategyPage(buildQuery());
		const data = (res.data || {}) as DimensionStrategyPage;
		strategies.value = Array.isArray(data.records) ? data.records.map(normalizeStrategy) : [];
		page.total = String(data.total ?? '0');
	} catch (error: any) {
		strategies.value = [];
		page.total = '0';
		useMessage().error(error?.msg || '查询维度策略失败');
	} finally {
		loading.value = false;
	}
};

const loadOptions = async () => {
	const [dimensionRes, modelRes, tableRes] = await Promise.all([fetchDimensionOptions(), fetchDimensionModelOptions(), fetchDimensionTableOptions()]);
	const data = (dimensionRes.data || {}) as any;
	dimensionOptions.scdTypes = data.scdTypes || [];
	dimensionOptions.statuses = data.statuses || [];
	dimensionOptions.historyKeepModes = data.historyKeepModes || [];
	modelOptions.value = Array.isArray(modelRes.data) ? (modelRes.data as DimensionOption[]) : [];
	tableOptions.value = Array.isArray(tableRes.data) ? (tableRes.data as DimensionOption[]) : [];
};

const handleSearch = () => {
	page.current = 1;
	loadStrategies();
};
const resetQuery = () => {
	queryRef.value?.resetFields();
	page.current = 1;
	loadStrategies();
};
const handleCurrentChange = (current: number) => {
	page.current = current;
	loadStrategies();
};
const handleSizeChange = (size: number) => {
	page.current = 1;
	page.size = size;
	loadStrategies();
};

const handleToggle = async (strategy: DimensionStrategy) => {
	const enabled = strategy.status !== 'ENABLED';
	try {
		await useMessageBox().confirm(`确认${enabled ? '启用' : '停用'}策略“${strategy.strategyName}”吗？`);
	} catch {
		return;
	}
	try {
		changingId.value = strategy.id;
		await setDimensionStrategyEnabled(strategy.id, enabled);
		useMessage().success(`${enabled ? '启用' : '停用'}成功`);
		await loadStrategies();
	} catch (error: any) {
		useMessage().error(error?.msg || `${enabled ? '启用' : '停用'}维度策略失败`);
	} finally {
		changingId.value = '';
	}
};

const handleDelete = async (strategy: DimensionStrategy) => {
	try {
		await useMessageBox().confirm(`确认删除策略“${strategy.strategyName}”吗？`);
	} catch {
		return;
	}
	try {
		deletingId.value = strategy.id;
		await deleteDimensionStrategy(strategy.id);
		useMessage().success('删除成功');
		if (strategies.value.length === 1 && page.current > 1) page.current -= 1;
		await loadStrategies();
	} catch (error: any) {
		useMessage().error(error?.msg || '删除维度策略失败');
	} finally {
		deletingId.value = '';
	}
};

onMounted(async () => {
	try {
		await loadOptions();
	} catch (error: any) {
		useMessage().error(error?.msg || '加载维度策略选项失败');
	}
	await loadStrategies();
});
</script>

<style scoped lang="scss">
.dimension-strategy-page {
	.page-card {
		min-height: calc(100vh - 115px);
	}

	.page-heading,
	.table-heading,
	.row-actions {
		display: flex;
		align-items: center;
	}

	.page-heading,
	.table-heading {
		justify-content: space-between;
	}

	.page-heading {
		align-items: flex-start;
		padding-bottom: 18px;
		border-bottom: 1px solid var(--el-border-color-lighter);
	}

	.page-title {
		font-size: 20px;
		font-weight: 600;
	}

	.page-description {
		margin-top: 8px;
		color: var(--el-text-color-secondary);
	}

	.filter-panel {
		padding: 16px 16px 0;
		margin-top: 16px;
		background: var(--el-fill-color-lighter);
		border: 1px solid var(--el-border-color-lighter);
		border-radius: 4px;
	}

	.table-heading {
		margin: 18px 0 10px;
	}

	.table-title {
		font-size: 16px;
		font-weight: 600;

		span {
			color: var(--el-text-color-secondary);
		}
	}

	.row-actions {
		white-space: nowrap;

		:deep(.el-button + .el-button) {
			margin-left: 4px;
		}
	}
}
</style>
