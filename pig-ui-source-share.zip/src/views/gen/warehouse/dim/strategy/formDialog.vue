<template>
	<el-dialog v-model="visible" :title="strategyId ? '配置维度策略' : '新增维度策略'" width="780px" :close-on-click-modal="false" draggable>
		<el-form ref="formRef" :model="form" :rules="rules" label-width="110px">
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item label="策略名称" prop="strategyName">
						<el-input v-model="form.strategyName" maxlength="128" placeholder="请输入策略名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="维度模型" prop="modelId">
						<el-select v-model="form.modelId" filterable placeholder="请选择维度模型" style="width: 100%" @change="handleModelChange">
							<el-option v-for="item in modelOptions" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="SCD 类型" prop="scdType">
						<el-select v-model="form.scdType" placeholder="请选择 SCD 类型" style="width: 100%">
							<el-option
								v-for="item in scdTypes"
								:key="item.value"
								:label="unsupportedScd(item.value) ? `${item.label}（后续版本支持）` : item.label"
								:value="item.value"
								:disabled="unsupportedScd(item.value)"
							/>
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="自然键" prop="naturalKey">
						<el-input v-model="form.naturalKey" readonly placeholder="由模型主键属性自动带出" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="历史保留方式" prop="historyKeepMode">
						<el-select v-model="form.historyKeepMode" placeholder="请选择历史保留方式" style="width: 100%">
							<el-option v-for="item in historyKeepModes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-alert
						:title="form.scdType === 'SCD0' ? 'SCD0：数据创建后不允许变化。' : 'SCD1：直接覆盖旧值，不保留历史版本。'"
						type="info"
						show-icon
						:closable="false"
					/>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionStrategyFormDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { createDimensionStrategy, fetchDimensionAttributes, updateDimensionStrategy } from '/@/api/dataPlatform/dimension';
import { useMessage } from '/@/hooks/message';
import type {
	DimensionAttribute,
	DimensionOption,
	DimensionStrategy,
	DimensionStrategySaveRequest,
} from '/@/types/dataPlatform/dimension';

const props = defineProps<{
	modelOptions: DimensionOption[];
	scdTypes: DimensionOption[];
	historyKeepModes: DimensionOption[];
}>();
const emit = defineEmits<{ refresh: [] }>();
const visible = ref(false);
const submitting = ref(false);
const strategyId = ref('');
const formRef = ref<FormInstance>();

const createDefaultForm = (): DimensionStrategySaveRequest => ({
	strategyName: '',
	modelId: '',
	scdType: 'SCD1',
	naturalKey: '',
	surrogateKey: '',
	effectiveField: '',
	expireField: '',
	historyKeepMode: 'OVERWRITE',
	writeMode: 'OVERWRITE',
	scheduleCron: '',
});
const form = reactive<DimensionStrategySaveRequest>(createDefaultForm());
const rules: FormRules = {
	strategyName: [{ required: true, message: '请输入策略名称', trigger: 'blur' }],
	modelId: [{ required: true, message: '请选择维度模型', trigger: 'change' }],
	scdType: [{ required: true, message: '请选择 SCD 类型', trigger: 'change' }],
	naturalKey: [{ required: true, message: '所选模型尚未配置主键属性', trigger: 'change' }],
	historyKeepMode: [{ required: true, message: '请选择历史保留方式', trigger: 'change' }],
};

const unsupportedScd = (value: string) => ['SCD2', 'SCD3'].includes(value);

const loadNaturalKey = async (modelId: string, fallback = '') => {
	form.naturalKey = fallback;
	if (!modelId) return;
	try {
		const res = await fetchDimensionAttributes(modelId);
		const attributes = Array.isArray(res.data) ? (res.data as DimensionAttribute[]) : [];
		const keys = attributes.filter((item) => Number(item.isPk) === 1).map((item) => item.attrCode);
		form.naturalKey = keys.join(',') || fallback;
		if (!form.naturalKey) useMessage().warning('所选模型尚未配置主键属性，请先在模型详情中设置自然键');
	} catch (error: any) {
		useMessage().error(error?.msg || '读取模型自然键失败');
	}
};

const handleModelChange = async (modelId: string) => {
	await loadNaturalKey(modelId);
	formRef.value?.validateField('naturalKey').catch(() => undefined);
};

const openDialog = async (strategy?: DimensionStrategy) => {
	visible.value = true;
	strategyId.value = strategy?.id || '';
	Object.assign(form, createDefaultForm());
	if (strategy) {
		Object.assign(form, {
			strategyName: strategy.strategyName || '',
			modelId: String(strategy.modelId || ''),
			scdType: strategy.scdType || 'SCD1',
			naturalKey: strategy.naturalKey || '',
			surrogateKey: '',
			effectiveField: '',
			expireField: '',
			historyKeepMode: strategy.historyKeepMode || 'OVERWRITE',
			writeMode: strategy.writeMode || 'OVERWRITE',
			scheduleCron: strategy.scheduleCron || '',
		});
		await loadNaturalKey(form.modelId, form.naturalKey);
	}
	await nextTick();
	formRef.value?.clearValidate();
};

const handleSubmit = async () => {
	const valid = await formRef.value?.validate().catch(() => false);
	if (!valid) return;
	if (unsupportedScd(form.scdType)) {
		useMessage().warning('SCD2/SCD3 为后续版本支持');
		return;
	}
	const payload: DimensionStrategySaveRequest = {
		strategyName: form.strategyName.trim(),
		modelId: String(form.modelId),
		scdType: form.scdType,
		naturalKey: form.naturalKey,
		surrogateKey: '',
		effectiveField: '',
		expireField: '',
		historyKeepMode: form.historyKeepMode,
		writeMode: form.writeMode || 'OVERWRITE',
		scheduleCron: form.scheduleCron || '',
	};
	try {
		submitting.value = true;
		if (strategyId.value) await updateDimensionStrategy(strategyId.value, payload);
		else await createDimensionStrategy(payload);
		useMessage().success(strategyId.value ? '策略修改成功' : '策略新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || (strategyId.value ? '修改维度策略失败' : '新增维度策略失败'));
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>
