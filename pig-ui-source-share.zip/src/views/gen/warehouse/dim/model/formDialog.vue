<template>
	<el-dialog
		v-model="visible"
		:title="modelId ? '编辑维度模型' : '新建维度模型'"
		width="760px"
		:close-on-click-modal="false"
		draggable
		@closed="handleClosed"
	>
		<el-form ref="formRef" v-loading="loading" :model="form" :rules="rules" label-width="100px">
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item label="模型名称" prop="modelName">
						<el-input v-model="form.modelName" maxlength="128" show-word-limit placeholder="请输入维度模型名称" />
					</el-form-item>
				</el-col>
				<el-col v-if="modelId" :span="12">
					<el-form-item label="模型编码">
						<el-input v-model="form.modelCode" disabled />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="维度类型" prop="dimType">
						<el-select v-model="form.dimType" placeholder="请选择维度类型" style="width: 100%">
							<el-option v-for="item in dimTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="业务系统" prop="businessSystemId">
						<el-select
							v-model="form.businessSystemId"
							filterable
							placeholder="请选择业务系统"
							style="width: 100%"
							@change="handleSystemChange"
						>
							<el-option v-for="item in businessSystems" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="业务域" prop="businessDomainId">
						<el-select
							v-model="form.businessDomainId"
							filterable
							:disabled="!form.businessSystemId"
							:loading="domainLoading"
							placeholder="请选择业务域"
							style="width: 100%"
						>
							<el-option v-for="item in businessDomains" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="描述" prop="description">
						<el-input v-model="form.description" type="textarea" :rows="4" maxlength="500" show-word-limit placeholder="请输入维度描述" />
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>

		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionModelFormDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { createDimensionModel, getDimensionModel, updateDimensionModel } from '/@/api/dataPlatform/dimension';
import { fetchBusinessDomains } from '/@/api/dataPlatform/layeredTask';
import { useMessage } from '/@/hooks/message';
import type { DimensionModel, DimensionModelSaveRequest, DimensionOption, DimensionType } from '/@/types/dataPlatform/dimension';

const props = defineProps<{
	dimTypes: DimensionOption[];
	businessSystems: DimensionOption[];
}>();
const emit = defineEmits<{ refresh: [] }>();

const formRef = ref<FormInstance>();
const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const domainLoading = ref(false);
const modelId = ref('');
const businessDomains = ref<DimensionOption[]>([]);

const createDefaultForm = (): DimensionModelSaveRequest => ({
	modelCode: '',
	modelName: '',
	dimType: '',
	businessSystemId: '',
	businessDomainId: '',
	description: '',
});

const form = reactive<DimensionModelSaveRequest>(createDefaultForm());
const rules: FormRules = {
	modelName: [{ required: true, message: '请输入模型名称', trigger: 'blur' }],
	dimType: [{ required: true, message: '请选择维度类型', trigger: 'change' }],
	businessSystemId: [{ required: true, message: '请选择业务系统', trigger: 'change' }],
	businessDomainId: [{ required: true, message: '请选择业务域', trigger: 'change' }],
};

const loadBusinessDomains = async (systemId: string) => {
	businessDomains.value = [];
	if (!systemId) return;
	try {
		domainLoading.value = true;
		const res = await fetchBusinessDomains(systemId);
		businessDomains.value = Array.isArray(res.data) ? (res.data as DimensionOption[]) : [];
	} catch (error: any) {
		useMessage().error(error?.msg || '加载业务域失败');
	} finally {
		domainLoading.value = false;
	}
};

const handleSystemChange = async (systemId: string) => {
	form.businessDomainId = '';
	await loadBusinessDomains(systemId);
};

const openDialog = async (id?: string) => {
	visible.value = true;
	modelId.value = id || '';
	businessDomains.value = [];
	Object.assign(form, createDefaultForm());
	await nextTick();
	formRef.value?.clearValidate();
	if (!id) return;

	try {
		loading.value = true;
		const res = await getDimensionModel(id);
		const detail = res.data as DimensionModel;
		const systemId = detail.businessSystemId ? String(detail.businessSystemId) : '';
		await loadBusinessDomains(systemId);
		Object.assign(form, {
			modelCode: detail.modelCode || '',
			modelName: detail.modelName || '',
			dimType: (detail.dimType || '') as DimensionType | '',
			businessSystemId: systemId,
			businessDomainId: detail.businessDomainId ? String(detail.businessDomainId) : '',
			description: detail.description || '',
		});
	} catch (error: any) {
		visible.value = false;
		useMessage().error(error?.msg || '加载维度模型失败');
	} finally {
		loading.value = false;
	}
};

const handleSubmit = async () => {
	const valid = await formRef.value?.validate().catch(() => false);
	if (!valid) return;

	const payload: DimensionModelSaveRequest = {
		modelName: form.modelName.trim(),
		dimType: form.dimType,
		businessSystemId: String(form.businessSystemId),
		businessDomainId: String(form.businessDomainId),
		description: form.description.trim(),
	};

	try {
		submitting.value = true;
		if (modelId.value) await updateDimensionModel(modelId.value, payload);
		else await createDimensionModel(payload);
		useMessage().success(modelId.value ? '修改成功' : '新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || (modelId.value ? '修改维度模型失败' : '新增维度模型失败'));
	} finally {
		submitting.value = false;
	}
};

const handleClosed = () => {
	modelId.value = '';
	businessDomains.value = [];
	Object.assign(form, createDefaultForm());
	formRef.value?.clearValidate();
};

defineExpose({ openDialog });
</script>
