<template>
	<el-dialog v-model="visible" :title="levelId ? '编辑维度层级' : '新增维度层级'" width="680px" :close-on-click-modal="false" draggable>
		<el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item label="层级名称" prop="levelName">
						<el-input v-model="form.levelName" maxlength="64" placeholder="请输入层级名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="层级编码" prop="levelCode">
						<el-input v-model="form.levelCode" maxlength="64" placeholder="例如：ORG_COMPANY" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="上级层级" prop="parentLevelId">
						<el-select v-model="form.parentLevelId" clearable placeholder="无（作为顶级）" style="width: 100%">
							<el-option v-for="item in availableParents" :key="item.id" :label="item.levelName" :value="item.id" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="对应字段" prop="codeField">
						<el-select v-model="form.codeField" filterable placeholder="请选择维度属性" style="width: 100%">
							<el-option v-for="item in attributes" :key="item.id" :label="`${item.attrName}（${item.attrCode}）`" :value="item.attrCode" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="显示顺序" prop="sortOrder">
						<el-input-number v-model="form.sortOrder" :min="1" :max="999" controls-position="right" style="width: 100%" />
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="描述" prop="description">
						<el-input v-model="form.description" type="textarea" :rows="3" maxlength="500" show-word-limit placeholder="请输入层级描述" />
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<el-alert title="本期层级仅支持单父链，请按顺序逐级配置。" type="info" show-icon :closable="false" />
		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionLevelDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { createDimensionLevel, updateDimensionLevel } from '/@/api/dataPlatform/dimension';
import { useMessage } from '/@/hooks/message';
import type { DimensionAttribute, DimensionLevel, DimensionLevelSaveRequest } from '/@/types/dataPlatform/dimension';

const props = defineProps<{ modelId: string; levels: DimensionLevel[]; attributes: DimensionAttribute[] }>();
const emit = defineEmits<{ refresh: [] }>();
const formRef = ref<FormInstance>();
const visible = ref(false);
const submitting = ref(false);
const levelId = ref('');
const availableParents = computed(() => props.levels.filter((item) => item.id !== levelId.value));

const createDefaultForm = (): DimensionLevelSaveRequest => ({
	levelCode: '',
	levelName: '',
	parentLevelId: null,
	codeField: '',
	sortOrder: props.levels.length + 1,
	description: '',
});
const form = reactive<DimensionLevelSaveRequest>(createDefaultForm());
const rules: FormRules = {
	levelName: [{ required: true, message: '请输入层级名称', trigger: 'blur' }],
	levelCode: [{ required: true, message: '请输入层级编码', trigger: 'blur' }],
	codeField: [{ required: true, message: '请选择对应维度字段', trigger: 'change' }],
	sortOrder: [{ required: true, message: '请输入显示顺序', trigger: 'change' }],
};

const openDialog = async (level?: DimensionLevel) => {
	visible.value = true;
	levelId.value = level?.id || '';
	Object.assign(form, createDefaultForm());
	if (level) {
		Object.assign(form, {
			levelCode: level.levelCode || '',
			levelName: level.levelName || '',
			parentLevelId: level.parentLevelId ? String(level.parentLevelId) : null,
			codeField: level.codeField || '',
			sortOrder: Number(level.sortOrder || 1),
			description: level.description || '',
		});
	}
	await nextTick();
	formRef.value?.clearValidate();
};

const handleSubmit = async () => {
	const valid = await formRef.value?.validate().catch(() => false);
	if (!valid) return;
	const payload: DimensionLevelSaveRequest = {
		levelCode: form.levelCode.trim(),
		levelName: form.levelName.trim(),
		parentLevelId: form.parentLevelId ? String(form.parentLevelId) : null,
		codeField: form.codeField,
		sortOrder: Number(form.sortOrder),
		description: form.description.trim(),
	};
	try {
		submitting.value = true;
		if (levelId.value) await updateDimensionLevel(props.modelId, levelId.value, payload);
		else await createDimensionLevel(props.modelId, payload);
		useMessage().success(levelId.value ? '层级修改成功' : '层级新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || (levelId.value ? '修改维度层级失败' : '新增维度层级失败'));
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>
