<template>
	<div class="dimension-model-page layout-padding">
		<el-card shadow="never" class="page-card">
			<div class="page-heading">
				<div>
					<div class="page-title">维度模型设计</div>
					<div class="page-description">定义维度基础信息，并为后续属性字段、层级路径和业务映射提供统一入口。</div>
				</div>
				<el-button v-auth="'dp_dim_model_add'" type="primary" icon="Plus" @click="formDialogRef?.openDialog()">新建维度</el-button>
			</div>

			<div class="filter-panel">
				<el-form ref="queryRef" :inline="true" :model="query" @keyup.enter="handleSearch">
					<el-form-item label="模型检索" prop="keyword">
						<el-input v-model="query.keyword" clearable placeholder="中文名称或英文名称" style="width: 210px" />
					</el-form-item>
					<el-form-item label="业务系统" prop="businessSystemId">
						<el-select
							v-model="query.businessSystemId"
							clearable
							filterable
							placeholder="全部系统"
							style="width: 160px"
							@change="handleQuerySystemChange"
						>
							<el-option v-for="item in businessSystems" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="业务域" prop="businessDomainId">
						<el-select
							v-model="query.businessDomainId"
							clearable
							filterable
							:disabled="!query.businessSystemId"
							:loading="domainLoading"
							placeholder="全部业务域"
							style="width: 160px"
						>
							<el-option v-for="item in queryBusinessDomains" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="维度类型" prop="dimType">
						<el-select v-model="query.dimType" clearable placeholder="全部类型" style="width: 150px">
							<el-option v-for="item in dimensionOptions.dimTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item label="状态" prop="status">
						<el-select v-model="query.status" clearable placeholder="全部状态" style="width: 130px">
							<el-option v-for="item in dimensionOptions.statuses" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
					<el-form-item>
						<el-button type="primary" icon="Search" @click="handleSearch">查询</el-button>
						<el-button icon="Refresh" @click="resetQuery">重置</el-button>
					</el-form-item>
				</el-form>
			</div>

			<div class="table-heading">
				<div class="table-title">维度模型列表 <span>（{{ page.total }}）</span></div>
				<el-button icon="Refresh" :loading="loading" @click="loadModels">刷新</el-button>
			</div>

			<el-table v-loading="loading" :data="models" border row-key="id" empty-text="暂无维度模型，请先新建维度" class="model-table">
				<el-table-column type="index" label="#" width="56" align="center" />
				<el-table-column prop="modelName" label="中文名称" min-width="150" show-overflow-tooltip />
				<el-table-column prop="modelCode" label="模型编码" min-width="190" show-overflow-tooltip />
				<el-table-column label="业务系统" min-width="130" show-overflow-tooltip>
					<template #default="{ row }">{{ businessSystemName(row) }}</template>
				</el-table-column>
				<el-table-column label="业务域" min-width="130" show-overflow-tooltip>
					<template #default="{ row }">{{ businessDomainName(row) }}</template>
				</el-table-column>
				<el-table-column label="维度类型" width="120" align="center">
					<template #default="{ row }">{{ optionLabel(dimensionOptions.dimTypes, row.dimType) }}</template>
				</el-table-column>
				<el-table-column label="层级路径" width="110" align="center">
					<template #default="{ row }">{{ row.levelCount ?? '0' }} 条</template>
				</el-table-column>
				<el-table-column prop="generatedTableName" label="已生成维表" min-width="170" show-overflow-tooltip>
					<template #default="{ row }">{{ row.generatedTableName || '--' }}</template>
				</el-table-column>
				<el-table-column label="状态" width="100" align="center">
					<template #default="{ row }">
						<el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">{{ optionLabel(dimensionOptions.statuses, row.status) }}</el-tag>
					</template>
				</el-table-column>
				<el-table-column prop="updateTime" label="更新时间" width="180">
					<template #default="{ row }">{{ row.updateTime || '--' }}</template>
				</el-table-column>
				<el-table-column label="操作" width="310" fixed="right">
					<template #default="{ row }">
						<div class="row-actions">
							<el-button v-auth="'dp_dim_model_view'" text type="primary" icon="View" @click="openDetail(row)">查看</el-button>
							<el-button v-auth="'dp_dim_model_edit'" text type="primary" icon="Edit" @click="formDialogRef?.openDialog(row.id)">编辑</el-button>
							<el-button
								v-auth="'dp_dim_model_edit'"
								text
								:type="row.status === 'ENABLED' ? 'warning' : 'success'"
								:icon="row.status === 'ENABLED' ? 'CircleClose' : 'CircleCheck'"
								:loading="changingId === row.id"
								@click="handleToggle(row)"
							>
								{{ row.status === 'ENABLED' ? '停用' : '启用' }}
							</el-button>
							<el-tooltip v-if="row.generatedTableName" content="请先删除关联维表" placement="top">
								<span><el-button v-auth="'dp_dim_model_delete'" text type="danger" icon="Delete" disabled>删除</el-button></span>
							</el-tooltip>
							<el-button
								v-else
								v-auth="'dp_dim_model_delete'"
								text
								type="danger"
								icon="Delete"
								:loading="deletingId === row.id"
								@click="handleDelete(row)"
							>
								删除
							</el-button>
						</div>
					</template>
				</el-table-column>
			</el-table>

			<pagination
				v-if="page.total !== '0'"
				:current="page.current"
				:size="page.size"
				:total="page.total"
				@current-change="handleCurrentChange"
				@size-change="handleSizeChange"
			/>
		</el-card>

		<FormDialog
			ref="formDialogRef"
			:dim-types="dimensionOptions.dimTypes"
			:business-systems="businessSystems"
			@refresh="loadModels"
		/>
	</div>
</template>

<script setup lang="ts" name="DimensionModelList">
import type { FormInstance } from 'element-plus';
import {
	deleteDimensionModel,
	fetchDimensionModelPage,
	fetchDimensionOptions,
	setDimensionModelEnabled,
} from '/@/api/dataPlatform/dimension';
import { fetchBusinessDomains, fetchBusinessSystems } from '/@/api/dataPlatform/layeredTask';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type {
	DimensionModel,
	DimensionModelPage,
	DimensionModelQuery,
	DimensionOption,
	DimensionOptions,
} from '/@/types/dataPlatform/dimension';
import FormDialog from './formDialog.vue';

const formDialogRef = ref<InstanceType<typeof FormDialog>>();
const router = useRouter();
const queryRef = ref<FormInstance>();
const loading = ref(false);
const domainLoading = ref(false);
const changingId = ref('');
const deletingId = ref('');
const models = ref<DimensionModel[]>([]);
const businessSystems = ref<DimensionOption[]>([]);
const queryBusinessDomains = ref<DimensionOption[]>([]);
const businessDomainLabels = ref<Record<string, string>>({});
const loadedDomainSystemIds = new Set<string>();
const dimensionOptions = reactive<DimensionOptions>({ dimTypes: [], statuses: [] });
const page = reactive({ current: 1, size: 10, total: '0' });
const query = reactive<DimensionModelQuery>({
	current: 1,
	size: 10,
	keyword: '',
	dimType: '',
	businessSystemId: '',
	businessDomainId: '',
	status: '',
});

const optionLabel = (options: DimensionOption[], value?: string | null) => options.find((item) => item.value === value)?.label || value || '--';

const businessSystemName = (row: DimensionModel) =>
	row.businessSystemName || optionLabel(businessSystems.value, row.businessSystemId ? String(row.businessSystemId) : '');

const businessDomainName = (row: DimensionModel) =>
	row.businessDomainName || businessDomainLabels.value[String(row.businessDomainId || '')] || row.businessDomainId || '--';

const cacheBusinessDomains = (options: DimensionOption[]) => {
	const labels = { ...businessDomainLabels.value };
	options.forEach((item) => {
		labels[String(item.value)] = item.label;
	});
	businessDomainLabels.value = labels;
};

const loadModelBusinessDomainLabels = async (records: DimensionModel[]) => {
	const systemIds = [
		...new Set(
			records
				.map((item) => (item.businessSystemId ? String(item.businessSystemId) : ''))
				.filter((systemId) => systemId && !loadedDomainSystemIds.has(systemId))
		),
	];
	await Promise.all(
		systemIds.map(async (systemId) => {
			try {
				const res = await fetchBusinessDomains(systemId);
				const options = Array.isArray(res.data) ? (res.data as DimensionOption[]) : [];
				cacheBusinessDomains(options);
				loadedDomainSystemIds.add(systemId);
			} catch {
				// 名称加载失败时保留接口返回的 ID，不阻塞主列表。
			}
		})
	);
};

const normalizeModel = (item: any): DimensionModel => ({
	...item,
	id: String(item.id),
	businessSystemId: item.businessSystemId == null ? null : String(item.businessSystemId),
	businessDomainId: item.businessDomainId == null ? null : String(item.businessDomainId),
});

const buildQuery = (): DimensionModelQuery => {
	const params: DimensionModelQuery = { current: page.current, size: page.size };
	if (query.keyword?.trim()) params.keyword = query.keyword.trim();
	if (query.dimType) params.dimType = query.dimType;
	if (query.businessSystemId) params.businessSystemId = query.businessSystemId;
	if (query.businessDomainId) params.businessDomainId = query.businessDomainId;
	if (query.status) params.status = query.status;
	return params;
};

const loadModels = async () => {
	try {
		loading.value = true;
		const res = await fetchDimensionModelPage(buildQuery());
		const data = (res.data || {}) as DimensionModelPage;
		models.value = Array.isArray(data.records) ? data.records.map(normalizeModel) : [];
		page.total = String(data.total ?? '0');
		await loadModelBusinessDomainLabels(models.value);
	} catch (error: any) {
		models.value = [];
		page.total = '0';
		useMessage().error(error?.msg || '查询维度模型失败');
	} finally {
		loading.value = false;
	}
};

const loadBaseOptions = async () => {
	const [dimensionResult, systemResult] = await Promise.allSettled([fetchDimensionOptions(), fetchBusinessSystems()]);
	if (dimensionResult.status === 'fulfilled') {
		const data = (dimensionResult.value.data || {}) as Partial<DimensionOptions>;
		dimensionOptions.dimTypes = data.dimTypes || [];
		dimensionOptions.statuses = data.statuses || [];
	} else {
		useMessage().error((dimensionResult.reason as any)?.msg || '加载维度枚举失败');
	}
	if (systemResult.status === 'fulfilled') {
		businessSystems.value = Array.isArray(systemResult.value.data) ? (systemResult.value.data as DimensionOption[]) : [];
	} else {
		useMessage().error((systemResult.reason as any)?.msg || '加载业务系统失败');
	}
};

const loadQueryBusinessDomains = async (systemId: string) => {
	queryBusinessDomains.value = [];
	if (!systemId) return;
	try {
		domainLoading.value = true;
		const res = await fetchBusinessDomains(systemId);
		queryBusinessDomains.value = Array.isArray(res.data) ? (res.data as DimensionOption[]) : [];
		cacheBusinessDomains(queryBusinessDomains.value);
		loadedDomainSystemIds.add(systemId);
	} catch (error: any) {
		useMessage().error(error?.msg || '加载业务域失败');
	} finally {
		domainLoading.value = false;
	}
};

const handleQuerySystemChange = async (systemId: string) => {
	query.businessDomainId = '';
	await loadQueryBusinessDomains(systemId);
};

const handleSearch = () => {
	page.current = 1;
	loadModels();
};

const resetQuery = () => {
	queryRef.value?.resetFields();
	queryBusinessDomains.value = [];
	page.current = 1;
	loadModels();
};

const handleCurrentChange = (current: number) => {
	page.current = current;
	loadModels();
};

const handleSizeChange = (size: number) => {
	page.current = 1;
	page.size = size;
	loadModels();
};

const openDetail = (model: DimensionModel) => router.push(`/gen/warehouse/dim/model/${model.id}`);

const handleToggle = async (model: DimensionModel) => {
	const enabled = model.status !== 'ENABLED';
	try {
		await useMessageBox().confirm(`确认${enabled ? '启用' : '停用'}维度模型“${model.modelName}”吗？`);
	} catch {
		return;
	}
	try {
		changingId.value = model.id;
		await setDimensionModelEnabled(model.id, enabled);
		useMessage().success(`${enabled ? '启用' : '停用'}成功`);
		await loadModels();
	} catch (error: any) {
		useMessage().error(error?.msg || `${enabled ? '启用' : '停用'}维度模型失败`);
	} finally {
		changingId.value = '';
	}
};

const handleDelete = async (model: DimensionModel) => {
	try {
		await useMessageBox().confirm(`删除后普通列表中将不再显示“${model.modelName}”，确认删除吗？`);
	} catch {
		return;
	}
	try {
		deletingId.value = model.id;
		await deleteDimensionModel(model.id);
		useMessage().success('删除成功');
		if (models.value.length === 1 && page.current > 1) page.current -= 1;
		await loadModels();
	} catch (error: any) {
		useMessage().error(error?.msg || '删除维度模型失败');
	} finally {
		deletingId.value = '';
	}
};

onMounted(async () => {
	await loadBaseOptions();
	await loadModels();
});
</script>

<style scoped lang="scss">
.dimension-model-page {
	.page-card {
		min-height: calc(100vh - 115px);
	}

	.page-heading {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		padding-bottom: 18px;
		border-bottom: 1px solid var(--el-border-color-lighter);
	}

	.page-title {
		font-size: 20px;
		font-weight: 600;
		color: var(--el-text-color-primary);
	}

	.page-description {
		margin-top: 8px;
		font-size: 14px;
		color: var(--el-text-color-secondary);
	}

	.filter-panel {
		margin-top: 16px;
		padding: 16px 16px 0;
		background: var(--el-fill-color-lighter);
		border: 1px solid var(--el-border-color-lighter);
		border-radius: 4px;
	}

	.table-heading {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin: 18px 0 10px;
	}

	.table-title {
		font-size: 16px;
		font-weight: 600;

		span {
			color: var(--el-text-color-secondary);
		}
	}

	.model-table {
		width: 100%;
	}

	.row-actions {
		display: flex;
		align-items: center;
		white-space: nowrap;

		:deep(.el-button + .el-button) {
			margin-left: 4px;
		}
	}
}
</style>
