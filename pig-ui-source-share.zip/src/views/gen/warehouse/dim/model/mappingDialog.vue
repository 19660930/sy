<template>
	<el-dialog v-model="visible" :title="mappingId ? '编辑关联映射' : '新增关联映射'" width="740px" :close-on-click-modal="false" draggable>
		<el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item label="业务系统" prop="businessSystemId">
						<el-select v-model="form.businessSystemId" filterable placeholder="请选择业务系统" style="width: 100%" @change="handleSystemChange">
							<el-option v-for="item in businessSystems" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="业务域" prop="businessDomainId">
						<el-select
							v-model="form.businessDomainId"
							filterable
							:disabled="!form.businessSystemId"
							:loading="domainLoading"
							placeholder="请选择业务域"
							style="width: 100%"
							@change="handleDomainChange"
						>
							<el-option v-for="item in businessDomains" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="源表" prop="sourceTableId">
						<el-select
							v-model="form.sourceTableId"
							clearable
							filterable
							:disabled="!form.businessDomainId"
							:loading="tableLoading"
							placeholder="请选择源表"
							style="width: 100%"
							@change="handleTableChange"
						>
							<el-option
								v-for="item in businessTables"
								:key="item.id"
								:label="formatTableLabel(item)"
								:value="item.id"
							/>
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="源字段" prop="sourceColumnId">
						<el-select
							v-model="form.sourceColumnId"
							clearable
							filterable
							:disabled="!form.sourceTableId"
							:loading="fieldLoading"
							placeholder="请选择源字段"
							style="width: 100%"
						>
							<el-option
								v-for="item in businessFields"
								:key="item.id"
								:label="formatColumnLabel(item)"
								:value="item.id"
							/>
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="维度字段" prop="dimField">
						<el-select v-model="form.dimField" filterable placeholder="请选择维度属性" style="width: 100%">
							<el-option v-for="item in attributes" :key="item.id" :label="`${item.attrName}（${item.attrCode}）`" :value="item.attrCode" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="匹配方式" prop="matchType">
						<el-select v-model="form.matchType" placeholder="请选择匹配方式" style="width: 100%">
							<el-option v-for="item in matchTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<el-alert title="源表和源字段来自已注册元数据；若没有候选项，请先完成元数据采集或联系管理员授权。" type="info" show-icon :closable="false" />
		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionMappingDialog">
import type { FormInstance, FormRules } from 'element-plus';
import {
	createDimensionMapping,
	fetchDimensionSourceColumns,
	fetchDimensionSourceTables,
	updateDimensionMapping,
} from '/@/api/dataPlatform/dimension';
import { fetchBusinessDomains } from '/@/api/dataPlatform/layeredTask';
import { useMessage } from '/@/hooks/message';
import type {
	DimensionAttribute,
	DimensionMapping,
	DimensionMappingSaveRequest,
	DimensionOption,
	DimensionSourceOption,
} from '/@/types/dataPlatform/dimension';

const props = defineProps<{
	modelId: string;
	attributes: DimensionAttribute[];
	businessSystems: DimensionOption[];
	matchTypes: DimensionOption[];
}>();
const emit = defineEmits<{ refresh: [] }>();
const formRef = ref<FormInstance>();
const visible = ref(false);
const submitting = ref(false);
const domainLoading = ref(false);
const tableLoading = ref(false);
const fieldLoading = ref(false);
const mappingId = ref('');
const businessDomains = ref<DimensionOption[]>([]);
const businessTables = ref<DimensionSourceOption[]>([]);
const businessFields = ref<DimensionSourceOption[]>([]);

const createDefaultForm = (): DimensionMappingSaveRequest => ({
	businessSystemId: '',
	businessDomainId: '',
	sourceTableId: '',
	sourceColumnId: '',
	dimField: '',
	matchType: '',
});
const form = reactive<DimensionMappingSaveRequest>(createDefaultForm());
const rules: FormRules = {
	businessSystemId: [{ required: true, message: '请选择业务系统', trigger: 'change' }],
	businessDomainId: [{ required: true, message: '请选择业务域', trigger: 'change' }],
	sourceTableId: [{ required: true, message: '请选择源表', trigger: 'change' }],
	sourceColumnId: [{ required: true, message: '请选择源字段', trigger: 'change' }],
	dimField: [{ required: true, message: '请选择维度字段', trigger: 'change' }],
	matchType: [{ required: true, message: '请选择匹配方式', trigger: 'change' }],
};

const loadDomains = async (systemId: string) => {
	businessDomains.value = [];
	if (!systemId) return;
	try {
		domainLoading.value = true;
		const res = await fetchBusinessDomains(systemId);
		businessDomains.value = Array.isArray(res.data) ? (res.data as DimensionOption[]) : [];
	} catch (error: any) {
		useMessage().error(error?.msg || '加载业务域失败');
	} finally {
		domainLoading.value = false;
	}
};

const handleSystemChange = async (systemId: string) => {
	form.businessDomainId = '';
	form.sourceTableId = '';
	form.sourceColumnId = '';
	businessTables.value = [];
	businessFields.value = [];
	await loadDomains(systemId);
};

const loadTables = async (systemId: string, domainId: string) => {
	businessTables.value = [];
	if (!systemId || !domainId) return;
	try {
		tableLoading.value = true;
		const res = await fetchDimensionSourceTables({
			businessSystemId: systemId,
			businessDomainId: domainId,
		});
		businessTables.value = Array.isArray(res.data) ? res.data : [];
	} catch (error: any) {
		useMessage().error(error?.msg || '源表选项加载失败');
	} finally {
		tableLoading.value = false;
	}
};

const loadFields = async (objectId: string) => {
	businessFields.value = [];
	if (!objectId) return;
	try {
		fieldLoading.value = true;
		const res = await fetchDimensionSourceColumns(objectId);
		businessFields.value = Array.isArray(res.data) ? res.data : [];
	} catch (error: any) {
		useMessage().error(error?.msg || '源字段选项加载失败');
	} finally {
		fieldLoading.value = false;
	}
};

const handleDomainChange = async (domainId: string) => {
	form.sourceTableId = '';
	form.sourceColumnId = '';
	businessFields.value = [];
	await loadTables(String(form.businessSystemId || ''), domainId);
};

const handleTableChange = async (tableId: string) => {
	form.sourceColumnId = '';
	businessFields.value = [];
	if (tableId) await loadFields(tableId);
};

const sourceTableName = (item: DimensionSourceOption) => item.objectCode || item.label;
const sourceColumnName = (item: DimensionSourceOption) => item.columnName || item.objectCode || item.label;
const formatTableLabel = (item: DimensionSourceOption) => {
	const tableName = sourceTableName(item);
	return item.objectName && item.objectName !== tableName ? `${tableName}（${item.objectName}）` : tableName;
};
const formatColumnLabel = (item: DimensionSourceOption) => {
	const columnName = sourceColumnName(item);
	const columnComment = item.columnComment || (item.objectName !== columnName ? item.objectName : '');
	return columnComment ? `${columnName}（${columnComment}）` : columnName;
};

const openDialog = async (mapping?: DimensionMapping) => {
	visible.value = true;
	mappingId.value = mapping?.id || '';
	Object.assign(form, createDefaultForm());
	businessDomains.value = [];
	businessTables.value = [];
	businessFields.value = [];
	if (mapping) {
		const systemId = mapping.businessSystemId
			? String(mapping.businessSystemId)
			: props.businessSystems.find((item) => item.label === mapping.businessSystemName)?.value || '';
		await loadDomains(systemId);
		const domainId = mapping.businessDomainId
			? String(mapping.businessDomainId)
			: businessDomains.value.find((item) => item.label === mapping.businessDomainName)?.value || '';
		await loadTables(systemId, domainId);
		const legacyTableName = mapping.sourceTableName || mapping.businessTable || '';
		const sourceTableId = mapping.sourceTableId
			? String(mapping.sourceTableId)
			: businessTables.value.find((item) => sourceTableName(item) === legacyTableName)?.id || '';
		if (sourceTableId) await loadFields(sourceTableId);
		const legacyColumnName = mapping.sourceColumnName || mapping.businessField || '';
		const sourceColumnId = mapping.sourceColumnId
			? String(mapping.sourceColumnId)
			: businessFields.value.find((item) => sourceColumnName(item) === legacyColumnName)?.id || '';
		Object.assign(form, {
			businessSystemId: systemId,
			businessDomainId: domainId,
			sourceTableId,
			sourceColumnId,
			dimField: mapping.dimField || '',
			matchType: mapping.matchType || '',
		});
	}
	await nextTick();
	formRef.value?.clearValidate();
};

const handleSubmit = async () => {
	const valid = await formRef.value?.validate().catch(() => false);
	if (!valid) return;
	const payload: DimensionMappingSaveRequest = {
		businessSystemId: String(form.businessSystemId),
		businessDomainId: String(form.businessDomainId),
		sourceTableId: String(form.sourceTableId),
		sourceColumnId: String(form.sourceColumnId),
		dimField: form.dimField,
		matchType: form.matchType,
	};
	try {
		submitting.value = true;
		const res = mappingId.value
			? await updateDimensionMapping(mappingId.value, payload)
			: await createDimensionMapping(props.modelId, payload);
		if (res.msg && res.msg !== 'success') useMessage().warning(res.msg);
		else useMessage().success(mappingId.value ? '映射修改成功' : '映射新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || (mappingId.value ? '修改关联映射失败' : '新增关联映射失败'));
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>
