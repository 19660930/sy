<template>
	<div class="dimension-detail-page layout-padding">
		<el-card v-loading="loading" shadow="never" class="summary-card">
			<div class="detail-heading">
				<div class="title-group">
					<el-button text type="primary" icon="ArrowLeft" @click="backToList">返回列表</el-button>
					<div>
						<div class="title-line">
							<h1>{{ model?.modelName || '维度模型详情' }}</h1>
							<el-tag v-if="model" :type="model.status === 'ENABLED' ? 'success' : 'info'">{{ statusLabel }}</el-tag>
						</div>
						<p>{{ model?.modelCode || '--' }}</p>
					</div>
				</div>
				<el-button
					v-if="model && !model.generatedTableName"
					v-auth="'dp_dim_table_generate'"
					type="primary"
					icon="MagicStick"
					@click="tableFormRef?.openDialog('GENERATE', modelId)"
				>
					生成维表
				</el-button>
			</div>

			<div v-if="model" class="summary-grid">
				<div class="summary-item"><span>中文名称</span><strong>{{ model.modelName }}</strong></div>
				<div class="summary-item"><span>模型编码</span><strong>{{ model.modelCode }}</strong></div>
				<div class="summary-item"><span>维度类型</span><strong>{{ dimTypeLabel }}</strong></div>
				<div class="summary-item"><span>业务系统</span><strong>{{ businessSystemLabel }}</strong></div>
				<div class="summary-item"><span>业务域</span><strong>{{ businessDomainLabel }}</strong></div>
				<div class="summary-item"><span>已生成维表</span><strong>{{ model.generatedTableName || '--' }}</strong></div>
				<div class="summary-item"><span>层级数量</span><strong>{{ model.levelCount ?? '0' }}</strong></div>
				<div class="summary-item"><span>创建人</span><strong>{{ model.createBy || '--' }}</strong></div>
				<div class="summary-item summary-wide"><span>描述</span><strong>{{ model.description || '--' }}</strong></div>
				<div class="summary-item"><span>创建时间</span><strong>{{ model.createTime || '--' }}</strong></div>
				<div class="summary-item"><span>更新时间</span><strong>{{ model.updateTime || '--' }}</strong></div>
			</div>
		</el-card>

		<el-card shadow="never" class="detail-card">
			<el-tabs v-model="activeTab">
				<el-tab-pane label="属性字段" name="attributes">
					<div class="tab-toolbar">
						<div>
							<h2>维度属性</h2>
							<p>配置维度字段、自然键、数据类型及默认值。</p>
						</div>
						<el-button v-auth="'dp_dim_attribute_add'" type="primary" icon="Plus" @click="attributeDialogRef?.openDialog()">新增属性</el-button>
					</div>
					<el-table v-loading="attributeLoading" :data="attributes" border empty-text="暂无维度属性">
						<el-table-column type="index" label="#" width="56" align="center" />
						<el-table-column prop="attrName" label="中文名称" min-width="140" show-overflow-tooltip />
						<el-table-column prop="attrCode" label="英文名称" min-width="160" show-overflow-tooltip />
						<el-table-column prop="dataType" label="数据类型" width="120" />
						<el-table-column label="长度/小数位" width="130" align="center">
							<template #default="{ row }">{{ formatLength(row) }}</template>
						</el-table-column>
						<el-table-column label="自然键" width="90" align="center">
							<template #default="{ row }"><el-tag v-if="Number(row.isPk) === 1" type="primary">是</el-tag><span v-else>否</span></template>
						</el-table-column>
						<el-table-column label="必填" width="80" align="center">
							<template #default="{ row }">{{ Number(row.isRequired) === 1 ? '是' : '否' }}</template>
						</el-table-column>
						<el-table-column prop="defaultValue" label="默认值" min-width="120" show-overflow-tooltip>
							<template #default="{ row }">{{ row.defaultValue || '--' }}</template>
						</el-table-column>
						<el-table-column prop="description" label="描述" min-width="180" show-overflow-tooltip>
							<template #default="{ row }">{{ row.description || '--' }}</template>
						</el-table-column>
						<el-table-column label="操作" width="150" fixed="right">
							<template #default="{ row }">
								<el-button v-auth="'dp_dim_attribute_edit'" text type="primary" icon="Edit" @click="attributeDialogRef?.openDialog(row)">编辑</el-button>
								<el-button v-auth="'dp_dim_attribute_delete'" text type="danger" icon="Delete" @click="handleDeleteAttribute(row)">删除</el-button>
							</template>
						</el-table-column>
					</el-table>
				</el-tab-pane>

				<el-tab-pane label="层级配置" name="levels">
					<div class="tab-toolbar">
						<div>
							<h2>维度层级</h2>
							<p>本期支持单父链，层级按照显示顺序依次展开。</p>
						</div>
						<el-button v-auth="'dp_dim_level_add'" type="primary" icon="Plus" :disabled="!attributes.length" @click="levelDialogRef?.openDialog()">
							新增层级
						</el-button>
					</div>

					<div v-if="sortedLevels.length" class="level-flow">
						<template v-for="(level, index) in sortedLevels" :key="level.id">
							<button type="button" :class="['level-node', { active: selectedLevelId === level.id }]" @click="selectedLevelId = level.id">
								<span>{{ level.levelName }}</span><small>{{ level.levelCode }}</small>
							</button>
							<el-icon v-if="index < sortedLevels.length - 1" class="level-arrow"><Right /></el-icon>
						</template>
					</div>

					<div v-if="selectedLevel" class="level-summary">
						<div><span>层级名称</span><strong>{{ selectedLevel.levelName }}</strong></div>
						<div><span>上级层级</span><strong>{{ parentLevelName(selectedLevel.parentLevelId) }}</strong></div>
						<div><span>对应字段</span><strong>{{ selectedLevel.codeField }}</strong></div>
						<div><span>描述</span><strong>{{ selectedLevel.description || '--' }}</strong></div>
					</div>

					<el-table v-loading="levelLoading" :data="sortedLevels" border empty-text="暂无层级，请先配置维度属性后新增层级">
						<el-table-column prop="sortOrder" label="顺序" width="80" align="center" />
						<el-table-column prop="levelName" label="层级名称" min-width="140" />
						<el-table-column prop="levelCode" label="层级编码" min-width="170" show-overflow-tooltip />
						<el-table-column label="上级层级" min-width="140">
							<template #default="{ row }">{{ parentLevelName(row.parentLevelId) }}</template>
						</el-table-column>
						<el-table-column prop="codeField" label="对应字段" min-width="160" show-overflow-tooltip />
						<el-table-column prop="description" label="描述" min-width="180" show-overflow-tooltip>
							<template #default="{ row }">{{ row.description || '--' }}</template>
						</el-table-column>
						<el-table-column label="操作" width="150" fixed="right">
							<template #default="{ row }">
								<div class="level-row-actions">
									<el-button v-auth="'dp_dim_level_edit'" text type="primary" icon="Edit" @click="levelDialogRef?.openDialog(row)">编辑</el-button>
									<el-tooltip v-if="hasChild(row.id)" content="请先删除下级层级" placement="top">
										<span><el-button v-auth="'dp_dim_level_delete'" text type="danger" icon="Delete" disabled>删除</el-button></span>
									</el-tooltip>
									<el-button v-else v-auth="'dp_dim_level_delete'" text type="danger" icon="Delete" @click="handleDeleteLevel(row)">删除</el-button>
								</div>
							</template>
						</el-table-column>
					</el-table>
				</el-tab-pane>

				<el-tab-pane label="关联映射" name="mappings">
					<div class="tab-toolbar">
						<div>
							<h2>业务字段映射</h2>
							<p>记录业务字段与维度属性之间的匹配关系。</p>
						</div>
						<el-button
							v-auth="'dp_dim_mapping_add'"
							type="primary"
							icon="Plus"
							:disabled="!attributes.length"
							@click="mappingDialogRef?.openDialog()"
						>
							新增映射
						</el-button>
					</div>
					<el-table v-loading="mappingLoading" :data="mappings" border empty-text="暂无关联映射">
						<el-table-column prop="businessSystemName" label="业务系统" min-width="130">
							<template #default="{ row }">{{ row.businessSystemName || '--' }}</template>
						</el-table-column>
						<el-table-column prop="businessDomainName" label="业务域" min-width="130">
							<template #default="{ row }">{{ row.businessDomainName || '--' }}</template>
						</el-table-column>
						<el-table-column label="源表" min-width="210" show-overflow-tooltip>
							<template #default="{ row }">{{ mappingSourceTableName(row) }}</template>
						</el-table-column>
						<el-table-column label="源字段" min-width="160" show-overflow-tooltip>
							<template #default="{ row }">{{ mappingSourceColumnName(row) }}</template>
						</el-table-column>
						<el-table-column prop="dimField" label="维度字段" min-width="160" show-overflow-tooltip />
						<el-table-column label="匹配方式" width="120">
							<template #default="{ row }">{{ optionLabel(dimensionOptions.matchTypes, row.matchType) }}</template>
						</el-table-column>
						<el-table-column label="状态" width="100" align="center">
							<template #default="{ row }">
								<el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">{{ optionLabel(dimensionOptions.statuses, row.status) }}</el-tag>
							</template>
						</el-table-column>
						<el-table-column label="操作" width="220" fixed="right">
							<template #default="{ row }">
								<el-button v-auth="'dp_dim_mapping_edit'" text type="primary" icon="Edit" @click="mappingDialogRef?.openDialog(row)">编辑</el-button>
								<el-button
									v-auth="'dp_dim_mapping_edit'"
									text
									:type="row.status === 'ENABLED' ? 'warning' : 'success'"
									@click="handleToggleMapping(row)"
								>
									{{ row.status === 'ENABLED' ? '停用' : '启用' }}
								</el-button>
								<el-button v-auth="'dp_dim_mapping_delete'" text type="danger" icon="Delete" @click="handleDeleteMapping(row)">删除</el-button>
							</template>
						</el-table-column>
					</el-table>
				</el-tab-pane>

				<el-tab-pane label="版本记录" name="versions">
					<div class="tab-toolbar">
						<div>
							<h2>版本记录</h2>
							<p>模型、属性和层级发生变化时自动生成结构审计版本。</p>
						</div>
						<el-button icon="Refresh" :loading="versionLoading" @click="loadVersions">刷新</el-button>
					</div>
					<el-table v-loading="versionLoading" :data="versions" border empty-text="暂无版本记录">
						<el-table-column prop="versionNo" label="版本号" width="120" />
						<el-table-column prop="changelog" label="变更内容" min-width="300" show-overflow-tooltip>
							<template #default="{ row }">{{ row.changelog || '--' }}</template>
						</el-table-column>
						<el-table-column label="版本状态" width="120" align="center">
							<template #default="{ row }"><el-tag :type="row.isCurrent ? 'success' : 'info'">{{ row.isCurrent ? '当前版本' : '历史版本' }}</el-tag></template>
						</el-table-column>
						<el-table-column prop="effectiveTime" label="生效时间" width="180">
							<template #default="{ row }">{{ row.effectiveTime || '--' }}</template>
						</el-table-column>
						<el-table-column prop="operator" label="操作人" width="140">
							<template #default="{ row }">{{ row.operator || '--' }}</template>
						</el-table-column>
					</el-table>
				</el-tab-pane>
			</el-tabs>
		</el-card>

		<AttributeDialog ref="attributeDialogRef" :model-id="modelId" :data-types="dimensionOptions.dataTypes" @refresh="handleAttributeRefresh" />
		<LevelDialog ref="levelDialogRef" :model-id="modelId" :levels="levels" :attributes="attributes" @refresh="handleLevelRefresh" />
		<MappingDialog
			ref="mappingDialogRef"
			:model-id="modelId"
			:attributes="attributes"
			:business-systems="businessSystems"
			:match-types="dimensionOptions.matchTypes"
			@refresh="loadMappings"
		/>
		<TableFormDialog ref="tableFormRef" @refresh="loadDetail" />
	</div>
</template>

<script setup lang="ts" name="DimensionModelDetail">
import {
	deleteDimensionAttribute,
	deleteDimensionLevel,
	deleteDimensionMapping,
	fetchDimensionAttributes,
	fetchDimensionLevels,
	fetchDimensionMappings,
	fetchDimensionModelVersions,
	fetchDimensionOptions,
	getDimensionModel,
	setDimensionMappingEnabled,
} from '/@/api/dataPlatform/dimension';
import { fetchBusinessDomains, fetchBusinessSystems } from '/@/api/dataPlatform/layeredTask';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type {
	DimensionAttribute,
	DimensionLevel,
	DimensionMapping,
	DimensionModel,
	DimensionModelVersion,
	DimensionOption,
} from '/@/types/dataPlatform/dimension';
import AttributeDialog from './attributeDialog.vue';
import LevelDialog from './levelDialog.vue';
import MappingDialog from './mappingDialog.vue';
import TableFormDialog from '../table/tableFormDialog.vue';

const route = useRoute();
const router = useRouter();
const modelId = computed(() => String(route.params.id || ''));
const model = ref<DimensionModel | null>(null);
const attributes = ref<DimensionAttribute[]>([]);
const levels = ref<DimensionLevel[]>([]);
const mappings = ref<DimensionMapping[]>([]);
const versions = ref<DimensionModelVersion[]>([]);
const businessSystems = ref<DimensionOption[]>([]);
const businessDomains = ref<DimensionOption[]>([]);
const loading = ref(false);
const attributeLoading = ref(false);
const levelLoading = ref(false);
const versionLoading = ref(false);
const mappingLoading = ref(false);
const activeTab = ref('attributes');
const selectedLevelId = ref('');
const attributeDialogRef = ref<InstanceType<typeof AttributeDialog>>();
const levelDialogRef = ref<InstanceType<typeof LevelDialog>>();
const mappingDialogRef = ref<InstanceType<typeof MappingDialog>>();
const tableFormRef = ref<InstanceType<typeof TableFormDialog>>();
const dimensionOptions = reactive<{ dimTypes: DimensionOption[]; statuses: DimensionOption[]; dataTypes: DimensionOption[]; matchTypes: DimensionOption[] }>({
	dimTypes: [],
	statuses: [],
	dataTypes: [],
	matchTypes: [],
});

const optionLabel = (options: DimensionOption[], value?: string | null) => options.find((item) => item.value === value)?.label || value || '--';
const mappingSourceTableName = (mapping: DimensionMapping) => mapping.sourceTableName || mapping.businessTable || '--';
const mappingSourceColumnName = (mapping: DimensionMapping) => mapping.sourceColumnName || mapping.businessField || '--';
const statusLabel = computed(() => optionLabel(dimensionOptions.statuses, model.value?.status));
const dimTypeLabel = computed(() => optionLabel(dimensionOptions.dimTypes, model.value?.dimType));
const businessSystemLabel = computed(
	() => model.value?.businessSystemName || optionLabel(businessSystems.value, model.value?.businessSystemId ? String(model.value.businessSystemId) : '')
);
const businessDomainLabel = computed(
	() => model.value?.businessDomainName || optionLabel(businessDomains.value, model.value?.businessDomainId ? String(model.value.businessDomainId) : '')
);
const sortedLevels = computed(() => [...levels.value].sort((left, right) => Number(left.sortOrder || 0) - Number(right.sortOrder || 0)));
const selectedLevel = computed(() => sortedLevels.value.find((item) => item.id === selectedLevelId.value) || sortedLevels.value[0]);

const normalizeAttribute = (item: any): DimensionAttribute => ({ ...item, id: String(item.id) });
const normalizeLevel = (item: any): DimensionLevel => ({
	...item,
	id: String(item.id),
	parentLevelId: item.parentLevelId == null ? null : String(item.parentLevelId),
});

const loadDetail = async () => {
	try {
		loading.value = true;
		const res = await getDimensionModel(modelId.value);
		const detail = res.data as DimensionModel;
		model.value = {
			...detail,
			id: String(detail.id),
			businessSystemId: detail.businessSystemId == null ? null : String(detail.businessSystemId),
			businessDomainId: detail.businessDomainId == null ? null : String(detail.businessDomainId),
		};
		if (model.value.businessSystemId) {
			const domainRes = await fetchBusinessDomains(String(model.value.businessSystemId));
			businessDomains.value = Array.isArray(domainRes.data) ? (domainRes.data as DimensionOption[]) : [];
		}
	} catch (error: any) {
		useMessage().error(error?.msg || '加载维度模型详情失败');
	} finally {
		loading.value = false;
	}
};

const loadAttributes = async () => {
	try {
		attributeLoading.value = true;
		const res = await fetchDimensionAttributes(modelId.value);
		attributes.value = Array.isArray(res.data) ? res.data.map(normalizeAttribute) : [];
	} catch (error: any) {
		attributes.value = [];
		useMessage().error(error?.msg || '加载维度属性失败');
	} finally {
		attributeLoading.value = false;
	}
};

const loadLevels = async () => {
	try {
		levelLoading.value = true;
		const res = await fetchDimensionLevels(modelId.value);
		levels.value = Array.isArray(res.data) ? res.data.map(normalizeLevel) : [];
		if (!levels.value.some((item) => item.id === selectedLevelId.value)) selectedLevelId.value = levels.value[0]?.id || '';
	} catch (error: any) {
		levels.value = [];
		useMessage().error(error?.msg || '加载维度层级失败');
	} finally {
		levelLoading.value = false;
	}
};

const loadVersions = async () => {
	try {
		versionLoading.value = true;
		const res = await fetchDimensionModelVersions(modelId.value);
		versions.value = Array.isArray(res.data) ? (res.data as DimensionModelVersion[]) : [];
	} catch (error: any) {
		versions.value = [];
		useMessage().error(error?.msg || '加载版本记录失败');
	} finally {
		versionLoading.value = false;
	}
};

const loadMappings = async () => {
	try {
		mappingLoading.value = true;
		const res = await fetchDimensionMappings(modelId.value);
		mappings.value = Array.isArray(res.data)
			? res.data.map((item: any) => ({
					...item,
					id: String(item.id),
					businessSystemId: item.businessSystemId == null ? null : String(item.businessSystemId),
					businessDomainId: item.businessDomainId == null ? null : String(item.businessDomainId),
			  }))
			: [];
	} catch (error: any) {
		mappings.value = [];
		useMessage().error(error?.msg || '加载关联映射失败');
	} finally {
		mappingLoading.value = false;
	}
};

const loadOptions = async () => {
	const [dimensionRes, systemRes] = await Promise.all([fetchDimensionOptions(), fetchBusinessSystems()]);
	const options = (dimensionRes.data || {}) as any;
	dimensionOptions.dimTypes = options.dimTypes || [];
	dimensionOptions.statuses = options.statuses || [];
	dimensionOptions.dataTypes = options.dataTypes || [];
	dimensionOptions.matchTypes = options.matchTypes || [];
	businessSystems.value = Array.isArray(systemRes.data) ? (systemRes.data as DimensionOption[]) : [];
};

const formatLength = (attribute: DimensionAttribute) => {
	const length = Number(attribute.dataLength || 0);
	const scale = Number(attribute.dataScale || 0);
	if (!length) return '--';
	return scale ? `${length}, ${scale}` : String(length);
};
const parentLevelName = (parentId?: string | null) => levels.value.find((item) => item.id === parentId)?.levelName || '无';
const hasChild = (levelId: string) => levels.value.some((item) => item.parentLevelId === levelId);
const backToList = () => router.push('/gen/warehouse/dim/model');

const handleDeleteAttribute = async (attribute: DimensionAttribute) => {
	try {
		await useMessageBox().confirm(`确认删除属性“${attribute.attrName}”吗？删除后将生成新的结构版本。`);
	} catch {
		return;
	}
	try {
		await deleteDimensionAttribute(modelId.value, attribute.id);
		useMessage().success('属性删除成功');
		await handleAttributeRefresh();
	} catch (error: any) {
		useMessage().error(error?.msg || '删除维度属性失败');
	}
};

const handleDeleteLevel = async (level: DimensionLevel) => {
	try {
		await useMessageBox().confirm(`确认删除层级“${level.levelName}”吗？删除后将生成新的结构版本。`);
	} catch {
		return;
	}
	try {
		await deleteDimensionLevel(modelId.value, level.id);
		useMessage().success('层级删除成功');
		await handleLevelRefresh();
	} catch (error: any) {
		useMessage().error(error?.msg || '删除维度层级失败');
	}
};

const handleToggleMapping = async (mapping: DimensionMapping) => {
	const enabled = mapping.status !== 'ENABLED';
	try {
		await useMessageBox().confirm(`确认${enabled ? '启用' : '停用'}该字段映射吗？`);
	} catch {
		return;
	}
	try {
		await setDimensionMappingEnabled(mapping.id, enabled);
		useMessage().success(`${enabled ? '启用' : '停用'}成功`);
		await loadMappings();
	} catch (error: any) {
		useMessage().error(error?.msg || `${enabled ? '启用' : '停用'}关联映射失败`);
	}
};

const handleDeleteMapping = async (mapping: DimensionMapping) => {
	try {
		await useMessageBox().confirm(`确认删除“${mappingSourceTableName(mapping)}.${mappingSourceColumnName(mapping)}”的关联映射吗？`);
	} catch {
		return;
	}
	try {
		await deleteDimensionMapping(mapping.id);
		useMessage().success('映射删除成功');
		await loadMappings();
	} catch (error: any) {
		useMessage().error(error?.msg || '删除关联映射失败');
	}
};

const handleAttributeRefresh = async () => {
	await Promise.all([loadAttributes(), loadVersions()]);
};
const handleLevelRefresh = async () => {
	await Promise.all([loadLevels(), loadVersions(), loadDetail()]);
};

onMounted(async () => {
	if (!modelId.value) {
		backToList();
		return;
	}
	try {
		await loadOptions();
	} catch (error: any) {
		useMessage().error(error?.msg || '加载维度选项失败');
	}
	await Promise.all([loadDetail(), loadAttributes(), loadLevels(), loadMappings(), loadVersions()]);
});
</script>

<style scoped lang="scss">
.dimension-detail-page {
	.summary-card,
	.detail-card {
		border: 1px solid var(--el-border-color-lighter);
	}

	.detail-card {
		margin-top: 14px;
	}

	.detail-heading,
	.title-group,
	.title-line,
	.tab-toolbar {
		display: flex;
		align-items: center;
	}

	.detail-heading,
	.tab-toolbar {
		justify-content: space-between;
	}

	.title-group {
		gap: 14px;
	}

	.title-line {
		gap: 12px;

		h1 {
			margin: 0;
			font-size: 21px;
		}
	}

	.title-group p,
	.tab-toolbar p {
		margin: 5px 0 0;
		color: var(--el-text-color-secondary);
	}

	.summary-grid {
		display: grid;
		grid-template-columns: repeat(4, minmax(0, 1fr));
		gap: 1px;
		margin-top: 18px;
		background: var(--el-border-color-lighter);
		border: 1px solid var(--el-border-color-lighter);
	}

	.summary-item {
		min-height: 68px;
		padding: 12px 16px;
		background: var(--el-bg-color);

		span,
		strong {
			display: block;
		}

		span {
			margin-bottom: 7px;
			font-size: 12px;
			color: var(--el-text-color-secondary);
		}

		strong {
			font-weight: 500;
			word-break: break-word;
		}
	}

	.summary-wide {
		grid-column: span 2;
	}

	.tab-toolbar {
		margin: 5px 0 14px;

		h2 {
			margin: 0;
			font-size: 17px;
		}
	}

	.level-flow {
		display: flex;
		align-items: center;
		min-height: 100px;
		padding: 18px;
		margin-bottom: 14px;
		overflow-x: auto;
		background: var(--el-fill-color-lighter);
		border: 1px solid var(--el-border-color-lighter);
		border-radius: 4px;
	}

	.level-node {
		min-width: 160px;
		padding: 13px 18px;
		text-align: left;
		cursor: pointer;
		background: var(--el-bg-color);
		border: 1px solid var(--el-border-color);
		border-left: 4px solid var(--el-color-primary);
		border-radius: 4px;

		span,
		small {
			display: block;
		}

		span {
			font-weight: 600;
		}

		small {
			margin-top: 5px;
			color: var(--el-text-color-secondary);
		}

		&.active {
			background: var(--el-color-primary-light-9);
			border-color: var(--el-color-primary);
		}
	}

	.level-arrow {
		flex: 0 0 auto;
		margin: 0 12px;
		color: var(--el-color-primary);
	}

	.level-summary {
		display: grid;
		grid-template-columns: repeat(4, minmax(0, 1fr));
		gap: 16px;
		padding: 14px 18px;
		margin-bottom: 14px;
		border: 1px solid var(--el-border-color-lighter);
		border-radius: 4px;

		span,
		strong {
			display: block;
		}

		span {
			margin-bottom: 5px;
			font-size: 12px;
			color: var(--el-text-color-secondary);
		}
	}

	.level-row-actions {
		display: flex;
		align-items: center;
		gap: 12px;

		:deep(.el-button) {
			margin-left: 0;
		}
	}
}

@media (max-width: 1200px) {
	.dimension-detail-page {
		.summary-grid,
		.level-summary {
			grid-template-columns: repeat(2, minmax(0, 1fr));
		}
	}
}
</style>
