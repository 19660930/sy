<template>
	<el-dialog v-model="visible" :title="attributeId ? '编辑维度属性' : '新增维度属性'" width="780px" :close-on-click-modal="false" draggable>
		<el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item label="关联标准">
						<el-input disabled placeholder="本期仅展示，暂不关联主数据标准" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="中文名称" prop="attrName">
						<el-input v-model="form.attrName" maxlength="64" placeholder="请输入属性中文名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="英文名称" prop="attrCode">
						<el-input v-model="form.attrCode" maxlength="64" placeholder="例如：ORG_CODE" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="数据类型" prop="dataType">
						<el-select v-model="form.dataType" placeholder="请选择数据类型" style="width: 100%">
							<el-option v-for="item in dataTypes" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="字段长度" prop="dataLength">
						<el-input-number v-model="form.dataLength" :min="0" :max="65535" controls-position="right" style="width: 100%" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="小数位数" prop="dataScale">
						<el-input-number v-model="form.dataScale" :min="0" :max="30" controls-position="right" style="width: 100%" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="是否主键" prop="isPk">
						<el-switch v-model="form.isPk" :active-value="1" :inactive-value="0" inline-prompt active-text="是" inactive-text="否" />
						<span class="form-tip">模型内最多一个自然键</span>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="是否必填" prop="isRequired">
						<el-switch v-model="form.isRequired" :active-value="1" :inactive-value="0" inline-prompt active-text="是" inactive-text="否" />
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="默认值" prop="defaultValue">
						<el-input v-model="form.defaultValue" maxlength="255" placeholder="请输入默认值，可留空" />
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="描述" prop="description">
						<el-input v-model="form.description" type="textarea" :rows="3" maxlength="500" show-word-limit placeholder="请输入属性描述" />
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" :loading="submitting" @click="handleSubmit">确定</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DimensionAttributeDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { createDimensionAttribute, updateDimensionAttribute } from '/@/api/dataPlatform/dimension';
import { useMessage } from '/@/hooks/message';
import type { DimensionAttribute, DimensionAttributeSaveRequest, DimensionOption } from '/@/types/dataPlatform/dimension';

const props = defineProps<{ modelId: string; dataTypes: DimensionOption[] }>();
const emit = defineEmits<{ refresh: [] }>();
const formRef = ref<FormInstance>();
const visible = ref(false);
const submitting = ref(false);
const attributeId = ref('');

const createDefaultForm = (): DimensionAttributeSaveRequest => ({
	attrCode: '',
	attrName: '',
	dataType: '',
	dataLength: 0,
	dataScale: 0,
	isPk: 0,
	isRequired: 0,
	defaultValue: '',
	description: '',
});
const form = reactive<DimensionAttributeSaveRequest>(createDefaultForm());
const rules: FormRules = {
	attrName: [{ required: true, message: '请输入中文名称', trigger: 'blur' }],
	attrCode: [{ required: true, message: '请输入英文名称', trigger: 'blur' }],
	dataType: [{ required: true, message: '请选择数据类型', trigger: 'change' }],
};

const openDialog = async (attribute?: DimensionAttribute) => {
	visible.value = true;
	attributeId.value = attribute?.id || '';
	Object.assign(form, createDefaultForm());
	if (attribute) {
		Object.assign(form, {
			attrCode: attribute.attrCode || '',
			attrName: attribute.attrName || '',
			dataType: attribute.dataType || '',
			dataLength: Number(attribute.dataLength || 0),
			dataScale: Number(attribute.dataScale || 0),
			isPk: Number(attribute.isPk || 0),
			isRequired: Number(attribute.isRequired || 0),
			defaultValue: attribute.defaultValue || '',
			description: attribute.description || '',
		});
	}
	await nextTick();
	formRef.value?.clearValidate();
};

const handleSubmit = async () => {
	const valid = await formRef.value?.validate().catch(() => false);
	if (!valid) return;
	const payload: DimensionAttributeSaveRequest = {
		attrCode: form.attrCode.trim(),
		attrName: form.attrName.trim(),
		dataType: form.dataType,
		dataLength: Number(form.dataLength || 0),
		dataScale: Number(form.dataScale || 0),
		isPk: Number(form.isPk),
		isRequired: Number(form.isRequired),
		defaultValue: form.defaultValue.trim(),
		description: form.description.trim(),
	};
	try {
		submitting.value = true;
		if (attributeId.value) await updateDimensionAttribute(props.modelId, attributeId.value, payload);
		else await createDimensionAttribute(props.modelId, payload);
		useMessage().success(attributeId.value ? '属性修改成功' : '属性新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || (attributeId.value ? '修改维度属性失败' : '新增维度属性失败'));
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>

<style scoped>
.form-tip {
	margin-left: 10px;
	font-size: 12px;
	color: var(--el-text-color-secondary);
}
</style>
