<template>
	<div class="layout-padding">
		<el-card shadow="never">
			<div class="page-heading">
				<div>
					<h2>明细数据运维</h2>
					<p>按模型、版本和运行查看 DWD 质量、治理与增量处理结果。</p>
				</div>
				<el-button icon="Refresh" :loading="loading" :disabled="!visibleKinds.length" @click="load">刷新</el-button>
			</div>
			<el-alert v-if="!visibleKinds.length" title="当前账号没有 DWD 运维查询权限" type="warning" :closable="false" />
			<template v-else>
				<el-tabs v-model="kind" @tab-change="changeKind">
					<el-tab-pane v-for="item in visibleKinds" :key="item.value" :label="item.label" :name="item.value" />
				</el-tabs>
				<el-alert v-if="kind === 'watermark'" title="首跑未完成时增量不可用；水位是只读值，不可在此修改。" type="info" :closable="false" />
				<el-alert v-if="kind === 'governance-audit'" title="治理前后样本可能包含敏感信息，此页不展示样本值。" type="info" :closable="false" />
				<el-form :inline="true" class="filters" @keyup.enter="search">
					<el-form-item label="模型 ID"><el-input v-model="filters.modelId" clearable placeholder="精确匹配" /></el-form-item>
					<el-form-item v-for="item in currentConfig.filters" :key="item.key" :label="item.label">
						<el-select
							v-if="item.key === 'status' || item.key === 'governanceType' || item.key === 'checkScope'"
							v-model="filters[item.key]"
							clearable
							placeholder="全部"
							style="width: 160px"
						>
							<el-option v-for="option in item.options || []" :key="option" :label="option" :value="option" />
						</el-select>
						<el-input v-else v-model="filters[item.key]" clearable placeholder="精确匹配" style="width: 170px" />
					</el-form-item>
					<el-form-item
						><el-button type="primary" icon="Search" @click="search">查询</el-button><el-button @click="reset">重置</el-button></el-form-item
					>
				</el-form>
				<el-table v-loading="loading" :data="records" border row-key="id" empty-text="暂无记录">
					<el-table-column
						v-for="column in currentConfig.columns"
						:key="column.key"
						:label="column.label"
						:min-width="column.width || 130"
						show-overflow-tooltip
					>
						<template #default="{ row }">{{ display(row[column.key]) }}</template>
					</el-table-column>
					<el-table-column v-if="auth(currentConfig.viewPermission)" label="操作" width="90" fixed="right">
						<template #default="{ row }"><el-button link type="primary" @click="showDetail(row.id)">详情</el-button></template>
					</el-table-column>
				</el-table>
				<pagination :current="page.current" :size="page.size" :total="page.total" @current-change="changePage" @size-change="changeSize" />
			</template>
		</el-card>
		<el-dialog v-model="detailVisible" :title="`${currentConfig.label}详情`" width="760px">
			<el-descriptions v-if="detail" :column="2" border>
				<el-descriptions-item v-for="field in currentConfig.details" :key="field.key" :label="field.label">{{
					display(detail[field.key])
				}}</el-descriptions-item>
			</el-descriptions>
		</el-dialog>
	</div>
</template>

<script setup lang="ts" name="DwdOperations">
import { fetchDwdOperationPage, getDwdOperation } from '/@/api/dataPlatform/dwdOperations';
import type { DwdOperationKind, DwdOperationRecord, DwdOperationQuery } from '/@/api/dataPlatform/dwdOperations';
import { useMessage } from '/@/hooks/message';
import { auth } from '/@/utils/authFunction';
import { dwdId } from '/@/utils/dwdId';

type Field = { key: string; label: string; width?: number; options?: string[] };
type OperationConfig = {
	value: DwdOperationKind;
	label: string;
	permission: string;
	viewPermission: string;
	filters: Field[];
	columns: Field[];
	details: Field[];
};
const field = (key: string, label: string, width?: number): Field => ({ key, label, width });
const ids = [field('id', '记录 ID'), field('modelId', '模型 ID'), field('versionId', '版本 ID'), field('runId', '运行 ID')];
const configs: OperationConfig[] = [
	{
		value: 'quality-result',
		label: '质量检查结果',
		permission: 'dp_dwd_quality_result_query',
		viewPermission: 'dp_dwd_quality_result_view',
		filters: [
			field('versionId', '版本 ID'),
			field('runId', '运行 ID'),
			field('ruleId', '规则 ID'),
			{ key: 'status', label: '状态', options: ['PASSED', 'FAILED', 'WARNING'] },
			{ key: 'checkScope', label: '检查范围', options: ['FULL', 'INCREMENTAL'] },
		],
		columns: [
			field('id', '记录 ID'),
			field('ruleName', '规则名称', 160),
			field('checkScope', '检查范围'),
			field('checkedCount', '检查行数'),
			field('failedCount', '失败行数'),
			field('status', '状态'),
			field('createTime', '检查时间', 180),
		],
		details: [
			...ids,
			field('ruleId', '规则 ID'),
			field('ruleName', '规则名称'),
			field('ruleType', '规则类型'),
			field('checkScope', '检查范围'),
			field('checkedCount', '检查行数'),
			field('failedCount', '失败行数'),
			field('threshold', '阈值'),
			field('actualValue', '实际值'),
			field('status', '状态'),
			field('errorMessage', '错误信息'),
			field('createTime', '创建时间'),
		],
	},
	{
		value: 'governance-audit',
		label: '治理审计',
		permission: 'dp_dwd_governance_audit_query',
		viewPermission: 'dp_dwd_governance_audit_view',
		filters: [
			field('versionId', '版本 ID'),
			field('runId', '运行 ID'),
			field('ruleId', '规则 ID'),
			{ key: 'governanceType', label: '治理类型', options: ['CLEAN', 'MASK', 'TRANSFORM', 'QUALITY'] },
			field('targetColumn', '目标列'),
		],
		columns: [
			field('id', '记录 ID'),
			field('governanceType', '治理类型'),
			field('targetColumn', '目标列'),
			field('ruleId', '规则 ID'),
			field('rowCount', '影响行数'),
			field('createTime', '审计时间', 180),
		],
		details: [
			...ids,
			field('ruleId', '规则 ID'),
			field('governanceType', '治理类型'),
			field('targetColumn', '目标列'),
			field('appliedExpression', '应用表达式'),
			field('rowCount', '影响行数'),
			field('createTime', '创建时间'),
		],
	},
	{
		value: 'partition-maintenance-event',
		label: '分区维护',
		permission: 'dp_dwd_partition_maintenance_event_query',
		viewPermission: 'dp_dwd_partition_maintenance_event_view',
		filters: [
			{ key: 'status', label: '状态', options: ['STARTED', 'COMPLETED', 'FAILED'] },
			field('databaseName', '数据库'),
			field('physicalName', '物理表'),
		],
		columns: [
			field('id', '记录 ID'),
			field('databaseName', '数据库'),
			field('physicalName', '物理表'),
			field('addedCount', '新增分区'),
			field('droppedCount', '删除分区'),
			field('status', '状态'),
			field('createTime', '创建时间', 180),
		],
		details: [
			field('id', '记录 ID'),
			field('modelId', '模型 ID'),
			field('databaseName', '数据库'),
			field('physicalName', '物理表'),
			field('retentionDays', '保留天数'),
			field('status', '状态'),
			field('addedCount', '新增分区'),
			field('droppedCount', '删除分区'),
			field('addedPartitions', '新增分区明细'),
			field('droppedPartitions', '删除分区明细'),
			field('baseDate', '基准日期'),
			field('lastError', '最近错误'),
			field('createBy', '创建人'),
			field('createTime', '创建时间'),
			field('updateBy', '更新人'),
			field('updateTime', '更新时间'),
		],
	},
	{
		value: 'watermark',
		label: '增量水位',
		permission: 'dp_dwd_watermark_query',
		viewPermission: 'dp_dwd_watermark_view',
		filters: [field('versionId', '版本 ID'), field('sourceId', '来源 ID'), { key: 'status', label: '状态', options: ['BOOTSTRAP_PENDING', 'READY'] }],
		columns: [
			field('id', '记录 ID'),
			field('sourceTable', '来源表', 170),
			field('sourceId', '来源 ID'),
			field('status', '状态', 170),
			field('checkpoint', '当前水位', 170),
			field('lastAdvanceTime', '推进时间', 180),
		],
		details: [
			field('id', '记录 ID'),
			field('modelId', '模型 ID'),
			field('versionId', '版本 ID'),
			field('sourceId', '来源 ID'),
			field('sourceDatasourceId', '来源数据源 ID'),
			field('sourceTable', '来源表'),
			field('status', '状态'),
			field('checkpoint', '当前水位'),
			field('bootstrapRunId', '首跑运行 ID'),
			field('bootstrapTime', '首跑完成时间'),
			field('lastSuccessRunId', '最近成功运行 ID'),
			field('lastAdvanceTime', '水位推进时间'),
			field('createTime', '创建时间'),
			field('updateTime', '更新时间'),
		],
	},
	{
		value: 'compute-replica',
		label: '计算副本',
		permission: 'dp_dwd_compute_replica_query',
		viewPermission: 'dp_dwd_compute_replica_view',
		filters: [
			field('versionId', '版本 ID'),
			field('runId', '运行 ID'),
			field('replicaKey', '副本键'),
			{ key: 'status', label: '状态', options: ['PROVISIONING', 'READY', 'REFERENCED', 'OBSOLETE', 'FAILED', 'BLOCKED'] },
		],
		columns: [
			field('id', '记录 ID'),
			field('sourceTable', '来源表', 160),
			field('replicaTable', '副本表', 160),
			field('generation', '世代'),
			field('status', '状态'),
			field('rowCount', '副本行数'),
			field('createTime', '创建时间', 180),
		],
		details: [
			...ids,
			field('replicaKey', '副本键'),
			field('taskId', '任务 ID'),
			field('sourceDatasourceId', '来源数据源 ID'),
			field('sourceDatabase', '来源库'),
			field('sourceTable', '来源表'),
			field('sourceSchema', '来源 Schema'),
			field('targetDatasourceId', '目标数据源 ID'),
			field('replicaDatabase', '副本库'),
			field('replicaTable', '副本表'),
			field('writeMode', '写入方式'),
			field('generation', '世代'),
			field('batchId', '批次 ID'),
			field('status', '状态'),
			field('seatunnelJobId', 'SeaTunnel 作业 ID'),
			field('rowCount', '副本行数'),
			field('sizeBytes', '占用字节'),
			field('inputReady', '输入就绪'),
			field('inputReadyTime', '就绪时间'),
			field('retentionHours', '保留小时数'),
			field('reclaimProtected', '回收保护'),
			field('lastUsedTime', '最近使用时间'),
			field('expireAt', '过期时间'),
			field('errorSummary', '错误摘要'),
			field('createTime', '创建时间'),
			field('updateTime', '更新时间'),
		],
	},
	{
		value: 'event-application',
		label: '事件应用',
		permission: 'dp_dwd_event_application_query',
		viewPermission: 'dp_dwd_event_application_view',
		filters: [
			field('versionId', '版本 ID'),
			field('sourceId', '来源 ID'),
			field('businessKey', '业务主键'),
			field('sourceEtlTime', '来源 ETL 时间'),
			{ key: 'status', label: '状态', options: ['PENDING', 'DELETE_APPLIED', 'UPSERT_APPLIED', 'COMPLETE'] },
		],
		columns: [
			field('id', '记录 ID'),
			field('businessKey', '业务主键', 150),
			field('sourceEtlTime', '来源 ETL 时间', 180),
			field('runId', '运行 ID'),
			field('status', '状态', 150),
			field('updateTime', '更新时间', 180),
		],
		details: [
			...ids,
			field('sourceId', '来源 ID'),
			field('businessKey', '业务主键'),
			field('sourceEtlTime', '来源 ETL 时间'),
			field('businessDate', '业务日期'),
			field('deleteTargetDate', '删除目标日期'),
			field('status', '状态'),
			field('lastError', '最近错误'),
			field('createTime', '创建时间'),
			field('updateTime', '更新时间'),
		],
	},
];

const route = useRoute();
const visibleKinds = computed(() => configs.filter((item) => auth(item.permission)));
const kind = ref<DwdOperationKind>('quality-result');
const currentConfig = computed(() => configs.find((item) => item.value === kind.value)!);
const filters = reactive<Record<string, string>>({ modelId: '' });
const page = reactive({ current: 1, size: 10, total: 0 });
const records = ref<DwdOperationRecord[]>([]);
const detail = ref<DwdOperationRecord>();
const detailVisible = ref(false);
const loading = ref(false);
let requestNo = 0;
const display = (value: unknown) =>
	value === null || value === undefined || value === '' ? '--' : typeof value === 'boolean' ? (value ? '是' : '否') : String(value);
const errorText = (error: unknown, fallback: string) => (error as { msg?: string; message?: string })?.msg || (error as Error)?.message || fallback;
const safeRecord = (item: DwdOperationRecord, selectedKind: DwdOperationKind): DwdOperationRecord => {
	const record = { ...item, id: dwdId(item.id) };
	if (selectedKind === 'governance-audit') {
		delete record.inputSample;
		delete record.outputSample;
	}
	return record;
};

const load = async () => {
	if (!auth(currentConfig.value.permission)) return;
	const sequence = ++requestNo;
	const selectedKind = kind.value;
	loading.value = true;
	try {
		const params: DwdOperationQuery = { current: page.current, size: page.size };
		for (const item of [field('modelId', '模型 ID'), ...currentConfig.value.filters]) {
			const value = filters[item.key]?.trim();
			if (value) params[item.key] = value;
		}
		const response = await fetchDwdOperationPage(selectedKind, params);
		if (sequence !== requestNo) return;
		records.value = Array.isArray(response.data?.records) ? response.data.records.map((item) => safeRecord(item, selectedKind)) : [];
		page.total = Number(response.data?.total ?? 0);
	} catch (error) {
		if (sequence !== requestNo) return;
		records.value = [];
		useMessage().error(errorText(error, '加载运维记录失败'));
	} finally {
		if (sequence === requestNo) loading.value = false;
	}
};
const search = () => {
	page.current = 1;
	load();
};
const reset = () => {
	Object.keys(filters).forEach((key) => delete filters[key]);
	page.current = 1;
	load();
};
const changeKind = () => {
	requestNo += 1;
	records.value = [];
	detailVisible.value = false;
	detail.value = undefined;
	page.current = 1;
	page.total = 0;
	load();
};
const changePage = (value: number) => {
	page.current = value;
	load();
};
const changeSize = (value: number) => {
	page.size = value;
	page.current = 1;
	load();
};
const showDetail = async (id: string) => {
	if (!auth(currentConfig.value.viewPermission)) return;
	const selectedKind = kind.value;
	try {
		const response = await getDwdOperation(selectedKind, id);
		if (selectedKind !== kind.value) return;
		detail.value = response.data ? safeRecord(response.data, selectedKind) : undefined;
		detailVisible.value = Boolean(detail.value);
	} catch (error) {
		useMessage().error(errorText(error, '加载详情失败'));
	}
};

onMounted(() => {
	if (!visibleKinds.value.length) return;
	kind.value = visibleKinds.value[0].value;
	filters.modelId = typeof route.query.modelId === 'string' ? route.query.modelId : '';
	load();
});
</script>

<style scoped>
.page-heading {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding-bottom: 16px;
}
.page-heading h2 {
	margin: 0 0 6px;
	font-size: 20px;
}
.page-heading p {
	margin: 0;
	color: var(--el-text-color-secondary);
}
.filters {
	padding-top: 18px;
}
</style>
