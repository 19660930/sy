<template>
	<div class="layout-padding">
		<el-card shadow="never">
			<div class="page-heading">
				<div>
					<h2>明细规则配置</h2>
					<p>维护清洗、转换、脱敏和质量规则；规则配置不等于任务发布或执行。</p>
				</div>
				<el-button v-if="auth(permission('add'))" type="primary" icon="Plus" @click="dialogRef?.openDialog(kind)"
					>新增{{ currentKind.label }}</el-button
				>
			</div>
			<el-tabs v-model="kind" @tab-change="switchKind">
				<el-tab-pane v-for="item in visibleKinds" :key="item.value" :label="item.label" :name="item.value" />
			</el-tabs>
			<el-alert v-if="!visibleKinds.length" title="当前账号没有 DWD 规则查询权限" type="warning" :closable="false" />
			<el-alert :title="currentKind.note" type="info" :closable="false" show-icon />
			<el-form :inline="true" class="filters" @keyup.enter="search">
				<el-form-item label="规则检索"><el-input v-model="filters.keyword" clearable placeholder="规则编码或名称" /></el-form-item>
				<el-form-item label="类型">
					<el-select v-model="filters.type" clearable placeholder="全部" style="width: 150px">
						<el-option v-for="item in ruleTypes[kind]" :key="item.value" :label="item.label" :value="item.value" />
					</el-select>
				</el-form-item>
				<el-form-item label="业务系统">
					<el-select v-model="filters.businessSystemId" clearable filterable placeholder="全部" style="width: 160px" @change="systemChanged">
						<el-option v-for="item in systems" :key="item.value" :label="item.label" :value="item.value" />
					</el-select>
				</el-form-item>
				<el-form-item label="业务域">
					<el-select
						v-model="filters.businessDomainId"
						clearable
						filterable
						:disabled="!filters.businessSystemId"
						placeholder="全部"
						style="width: 160px"
					>
						<el-option v-for="item in domains" :key="item.value" :label="item.label" :value="item.value" />
					</el-select>
				</el-form-item>
				<el-form-item label="状态">
					<el-select v-model="filters.status" clearable placeholder="全部" style="width: 110px">
						<el-option label="草稿" value="DRAFT" /><el-option label="启用" value="ENABLED" /><el-option label="停用" value="DISABLED" />
					</el-select>
				</el-form-item>
				<el-form-item
					><el-button type="primary" icon="Search" @click="search">查询</el-button><el-button @click="reset">重置</el-button></el-form-item
				>
			</el-form>
			<div class="table-title">
				<strong>{{ currentKind.label }}（{{ page.total }}）</strong><el-button icon="Refresh" :loading="loading" @click="load">刷新</el-button>
			</div>
			<el-table v-loading="loading" :data="rules" border row-key="id" empty-text="暂无规则">
				<el-table-column prop="ruleCode" label="规则编码" min-width="145" show-overflow-tooltip />
				<el-table-column prop="ruleName" label="规则名称" min-width="170" show-overflow-tooltip />
				<el-table-column label="规则类型" min-width="130"
					><template #default="{ row }">{{ ruleTypeLabel(kind, kind === 'mask' ? row.maskType : row.ruleType) }}</template></el-table-column
				>
				<el-table-column label="模型 ID" min-width="105"
					><template #default="{ row }">{{ row.modelId || '--' }}</template></el-table-column
				>
				<el-table-column label="目标字段" min-width="130" show-overflow-tooltip
					><template #default="{ row }">{{ row.targetColumn || row.targetField || '--' }}</template></el-table-column
				>
				<el-table-column label="业务系统" min-width="130"
					><template #default="{ row }">{{ labelOf(systems, row.businessSystemId) }}</template></el-table-column
				>
				<el-table-column label="业务域" min-width="130"
					><template #default="{ row }">{{ domainLabel(row.businessDomainId) }}</template></el-table-column
				>
				<el-table-column label="状态" width="90"
					><template #default="{ row }"
						><el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">{{ row.status === 'ENABLED' ? '启用' : row.status === 'DRAFT' ? '草稿' : '停用' }}</el-tag></template
					></el-table-column
				>
				<el-table-column prop="updateTime" label="更新时间" min-width="165" />
				<el-table-column label="操作" width="230" fixed="right">
					<template #default="{ row }">
						<el-button v-if="auth(permission('edit'))" link type="primary" @click="dialogRef?.openDialog(kind, row.id)">编辑</el-button>
						<el-button
							v-if="auth(permission('edit'))"
							link
							:type="row.status === 'ENABLED' ? 'warning' : 'success'"
							:loading="busyId === row.id"
							@click="toggle(row)"
							>{{ row.status === 'ENABLED' ? '停用' : '启用' }}</el-button
						>
						<el-button v-if="auth(permission('del'))" link type="danger" :loading="busyId === row.id" @click="remove(row)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
			<pagination :current="page.current" :size="page.size" :total="page.total" @current-change="changePage" @size-change="changeSize" />
		</el-card>
		<RuleDialog ref="dialogRef" :systems="systems" @saved="load" />
	</div>
</template>

<script setup lang="ts" name="DwdRuleList">
import { deleteDwdRule, fetchDwdRulePage, setDwdRuleEnabled } from '/@/api/dataPlatform/dwdRule';
import { fetchBusinessDomains, fetchBusinessSystems } from '/@/api/dataPlatform/layeredTask';
import { useMessage, useMessageBox } from '/@/hooks/message';
import { auth } from '/@/utils/authFunction';
import { dwdId, optionalDwdId } from '/@/utils/dwdId';
import type { DwdOption } from '/@/types/dataPlatform/dwd';
import type { DwdRule, DwdRuleKind, DwdRuleQuery } from '/@/types/dataPlatform/dwdRule';
import { ruleKinds, ruleTypeLabel, ruleTypes } from './constants';
import RuleDialog from './formDialog.vue';

const kind = ref<DwdRuleKind>('clean');
const visibleKinds = computed(() => ruleKinds.filter((item) => auth(`${item.permission}query`)));
const currentKind = computed(() => ruleKinds.find((item) => item.value === kind.value)!);
const permission = (action: string) => `${currentKind.value.permission}${action}`;
const dialogRef = ref<InstanceType<typeof RuleDialog>>();
const loading = ref(false);
const busyId = ref('');
const rules = ref<DwdRule[]>([]);
const systems = ref<DwdOption[]>([]);
const domains = ref<DwdOption[]>([]);
const page = reactive({ current: 1, size: 10, total: 0 });
const filters = reactive({ keyword: '', type: '', businessSystemId: '', businessDomainId: '', status: '' });
let requestNo = 0;
const errorText = (error: unknown, fallback: string) => (error as { msg?: string })?.msg || fallback;
const labelOf = (items: DwdOption[], id: string | null | undefined) => items.find((item) => item.value === id)?.label || id || '--';
const domainLabel = (id: unknown) => labelOf(domains.value, id);

const load = async () => {
	const sequence = ++requestNo;
	const selectedKind = kind.value;
	loading.value = true;
	try {
		const params: DwdRuleQuery = { current: page.current, size: page.size };
		if (filters.keyword.trim()) params.keyword = filters.keyword.trim();
		if (filters.status) params.status = filters.status;
		if (filters.businessSystemId) params.businessSystemId = filters.businessSystemId;
		if (filters.businessDomainId) params.businessDomainId = filters.businessDomainId;
		if (filters.type) params[selectedKind === 'mask' ? 'maskType' : 'ruleType'] = filters.type;
		const response = await fetchDwdRulePage(selectedKind, params);
		if (sequence !== requestNo) return;
		rules.value = Array.isArray(response.data?.records)
			? response.data.records.map((item) => ({
					...item,
					id: dwdId(item.id),
					businessSystemId: optionalDwdId(item.businessSystemId),
					businessDomainId: optionalDwdId(item.businessDomainId),
					modelId: optionalDwdId(item.modelId),
			  }))
			: [];
		page.total = Number(response.data?.total ?? 0);
	} catch (error) {
		if (sequence !== requestNo) return;
		rules.value = [];
		useMessage().error(errorText(error, '加载规则失败'));
	} finally {
		if (sequence === requestNo) loading.value = false;
	}
};
const search = () => {
	page.current = 1;
	load();
};
const reset = () => {
	Object.assign(filters, { keyword: '', type: '', businessSystemId: '', businessDomainId: '', status: '' });
	domains.value = [];
	search();
};
const switchKind = () => {
	reset();
};
const changePage = (value: number) => {
	page.current = value;
	load();
};
const changeSize = (value: number) => {
	page.size = value;
	page.current = 1;
	load();
};
const systemChanged = async (id: string) => {
	filters.businessDomainId = '';
	domains.value = [];
	if (!id) return;
	try {
		const response = await fetchBusinessDomains(id);
		if (id === filters.businessSystemId)
			domains.value = Array.isArray(response.data) ? response.data.map((item: DwdOption) => ({ value: dwdId(item.value), label: item.label })) : [];
	} catch (error) {
		useMessage().error(errorText(error, '加载业务域失败'));
	}
};
const toggle = async (row: DwdRule) => {
	const enabled = row.status !== 'ENABLED';
	try {
		if (!enabled && kind.value === 'transform')
			await useMessageBox().confirm('停用被字段映射引用的转换规则，会使对应模型 SQL 生成失败。确定停用吗？');
		busyId.value = row.id;
		await setDwdRuleEnabled(kind.value, row.id, enabled);
		useMessage().success(enabled ? '已启用' : '已停用');
		await load();
	} catch (error) {
		if (error !== 'cancel' && error !== 'close') useMessage().error(errorText(error, '切换状态失败'));
	} finally {
		busyId.value = '';
	}
};
const remove = async (row: DwdRule) => {
	try {
		await useMessageBox().confirm(`确定永久删除规则“${row.ruleName}”吗？删除不可恢复，服务端不会检查模型引用。`);
		busyId.value = row.id;
		await deleteDwdRule(kind.value, row.id);
		useMessage().success('删除成功');
		await load();
	} catch (error) {
		if (error !== 'cancel' && error !== 'close') useMessage().error(errorText(error, '删除失败'));
	} finally {
		busyId.value = '';
	}
};

onMounted(async () => {
	if (!visibleKinds.value.length) return;
	kind.value = visibleKinds.value[0].value;
	try {
		const response = await fetchBusinessSystems();
		systems.value = Array.isArray(response.data) ? response.data.map((item: DwdOption) => ({ value: dwdId(item.value), label: item.label })) : [];
	} catch {
		useMessage().warning('业务系统选项加载失败');
	}
	load();
});
</script>

<style scoped>
.page-heading,
.table-title {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.page-heading {
	padding-bottom: 16px;
}
.page-heading h2 {
	margin: 0 0 6px;
	font-size: 20px;
}
.page-heading p {
	margin: 0;
	color: var(--el-text-color-secondary);
}
.filters {
	padding-top: 20px;
}
.table-title {
	padding: 4px 0 14px;
}
</style>
