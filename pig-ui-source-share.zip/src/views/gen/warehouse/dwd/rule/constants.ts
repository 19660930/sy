import type { DwdRuleKind } from '/@/types/dataPlatform/dwdRule';

export const ruleKinds: Array<{ value: DwdRuleKind; label: string; note: string; permission: string }> = [
	{ value: 'clean', label: '清洗规则', note: '按模型和目标列参与 SQL 生成。', permission: 'dp_dwd_clean_rule_' },
	{
		value: 'transform',
		label: '转换规则',
		note: '由字段映射引用规则编码；停用或删除可能导致模型 SQL 生成失败。',
		permission: 'dp_dwd_transform_rule_',
	},
	{ value: 'mask', label: '脱敏规则', note: '按关联模型和目标字段参与冻结校验与 SQL 生成。', permission: 'dp_dwd_mask_rule_' },
	{ value: 'quality', label: '质量规则', note: '按业务域进入模型构建快照。', permission: 'dp_dwd_quality_rule_' },
];

export const ruleTypes: Record<DwdRuleKind, Array<{ value: string; label: string }>> = {
	clean: [
		{ value: 'NULL_HANDLE', label: 'NULL 处理' },
		{ value: 'FORMAT_CONVERT', label: '格式转换' },
		{ value: 'TYPE_CONVERT', label: '类型转换' },
		{ value: 'FILTER_ABNORMAL', label: '异常过滤' },
		{ value: 'VALUE_REPLACE', label: '值替换' },
	],
	transform: [
		{ value: 'DATE_FORMAT', label: '日期格式化' },
		{ value: 'NUMBER_ROUND', label: '数值四舍五入' },
		{ value: 'STRING_CONCAT', label: '字符串拼接' },
		{ value: 'CASE_WHEN', label: 'CASE WHEN' },
		{ value: 'CALCULATION', label: '计算' },
		{ value: 'UPPER', label: '转大写' },
		{ value: 'LOWER', label: '转小写' },
		{ value: 'TRIM', label: '去除空白' },
		{ value: 'EXPRESSION', label: '表达式' },
		{ value: 'LOOKUP', label: '查找' },
	],
	mask: [
		{ value: 'PHONE_MASK', label: '手机号' },
		{ value: 'ID_CARD_MASK', label: '身份证' },
		{ value: 'BANK_CARD_MASK', label: '银行卡' },
		{ value: 'EMAIL_MASK', label: '邮箱' },
		{ value: 'NAME_MASK', label: '姓名' },
		{ value: 'CUSTOM_MASK', label: '自定义' },
	],
	quality: [
		{ value: 'NOT_NULL', label: '非空校验' },
		{ value: 'NULL_RATE', label: '空值率' },
		{ value: 'RANGE_CHECK', label: '范围校验' },
		{ value: 'UNIQUE_CHECK', label: '唯一性校验' },
		{ value: 'FORMAT_CHECK', label: '格式校验' },
		{ value: 'REGEX', label: '正则校验' },
		{ value: 'THRESHOLD', label: '阈值校验' },
		{ value: 'CUSTOM_SQL', label: '自定义 SQL' },
	],
};

export const ruleTypeLabel = (kind: DwdRuleKind, value?: string) => ruleTypes[kind].find((item) => item.value === value)?.label || value || '--';
