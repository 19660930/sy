<template>
	<el-dialog
		v-model="visible"
		:title="`${editingId ? '编辑' : '新增'}${kindLabel}`"
		width="760px"
		append-to-body
		destroy-on-close
		:close-on-click-modal="false"
	>
		<el-form ref="formRef" v-loading="loading" :model="form" :rules="rules" label-width="112px" class="rule-form">
			<el-alert v-if="kind === 'mask'" type="info" :closable="false" title="自定义脱敏需填写目标字段，并使用引用该字段的白名单函数表达式。" class="form-alert" />
			<el-alert v-if="kind === 'quality'" type="info" :closable="false" title="质量规则按业务域进入构建快照；建议选择业务域。" class="form-alert" />
			<el-row :gutter="16">
				<el-col :span="12"
					><el-form-item label="规则名称" prop="ruleName"
						><el-input v-model="form.ruleName" maxlength="128" show-word-limit placeholder="请输入规则名称" /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item :label="kind === 'mask' ? '脱敏类型' : '规则类型'" prop="type"
						><el-select v-model="form.type" style="width: 100%" placeholder="请选择类型"
							><el-option v-for="item in ruleTypes[kind]" :key="item.value" :label="item.label" :value="item.value" /></el-select></el-form-item
				></el-col>
				<el-col v-if="editingId" :span="12"
					><el-form-item label="规则编码"><el-input :model-value="ruleCode" disabled /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="状态"
						><el-select v-model="form.status" style="width: 100%"
							><el-option label="草稿" value="DRAFT" /><el-option label="启用" value="ENABLED" /><el-option label="停用" value="DISABLED" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="业务系统"
						><el-select v-model="form.businessSystemId" clearable filterable style="width: 100%" placeholder="可选" @change="systemChanged"
							><el-option v-for="item in systems" :key="item.value" :label="item.label" :value="item.value" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="业务域"
						><el-select
							v-model="form.businessDomainId"
							clearable
							filterable
							:loading="domainLoading"
							:disabled="!form.businessSystemId"
							style="width: 100%"
							placeholder="可选"
							><el-option v-for="item in domains" :key="item.value" :label="item.label" :value="item.value" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="关联模型"
						><el-select v-model="form.modelId" clearable filterable :loading="modelLoading" style="width: 100%" placeholder="可选"
							><el-option v-for="item in models" :key="item.value" :label="item.label" :value="item.value" /></el-select></el-form-item
				></el-col>
				<template v-if="kind === 'clean'">
					<el-col :span="12"
						><el-form-item label="目标字段"><el-input v-model="form.targetColumn" maxlength="128" placeholder="规则作用列" /></el-form-item
					></el-col>
					<el-col :span="12"
						><el-form-item label="执行顺序"
							><el-input-number v-model="form.execOrder" :min="0" :precision="0" controls-position="right" style="width: 100%" /></el-form-item
					></el-col>
					<el-col :span="24"
						><el-form-item label="条件 JSON" prop="conditionJson"
							><el-input
								v-model="form.conditionJson"
								type="textarea"
								:rows="3"
								maxlength="2000"
								show-word-limit
								placeholder='例如：{"column":"status","operator":"IS NULL"}' /></el-form-item
					></el-col>
					<el-col :span="24"
						><el-form-item label="动作 JSON" prop="actionJson"
							><el-input
								v-model="form.actionJson"
								type="textarea"
								:rows="3"
								maxlength="2000"
								show-word-limit
								placeholder='例如：{"action":"SET_DEFAULT","value":"0"}' /></el-form-item
					></el-col>
				</template>
				<template v-if="kind === 'transform'">
					<el-col :span="12"
						><el-form-item label="目标字段"><el-input v-model="form.targetField" maxlength="128" placeholder="输出字段名" /></el-form-item
					></el-col>
					<el-col :span="12"
						><el-form-item label="源字段"><el-input v-model="form.sourceFields" maxlength="500" placeholder="多个字段以逗号分隔" /></el-form-item
					></el-col>
					<el-col :span="24"
						><el-form-item label="SQL 表达式"
							><el-input
								v-model="form.sqlExpression"
								type="textarea"
								:rows="3"
								maxlength="1024"
								show-word-limit
								placeholder="SELECT 中使用的表达式片段；保存时不试运行" /></el-form-item
					></el-col>
					<el-col :span="24"
						><el-form-item label="转换配置 JSON" prop="transformConfig"
							><el-input
								v-model="form.transformConfig"
								type="textarea"
								:rows="3"
								maxlength="2000"
								show-word-limit
								placeholder="可选，填写合法 JSON" /></el-form-item
					></el-col>
				</template>
				<template v-if="kind === 'mask'">
					<el-col :span="12"
						><el-form-item label="目标字段"><el-input v-model="form.targetField" maxlength="128" placeholder="目标字段名" /></el-form-item
					></el-col>
					<el-col :span="24"
						><el-form-item label="SQL 函数模板"
						><el-input v-model="form.sqlFunction" maxlength="256" placeholder="自定义时填写，如 MD5(phone)" /></el-form-item
					></el-col>
					<el-col :span="24"
						><el-form-item label="策略 JSON" prop="strategyJson"
							><el-input
								v-model="form.strategyJson"
								type="textarea"
								:rows="3"
								maxlength="2000"
								show-word-limit
								placeholder='例如：{"showPrefix":3,"showSuffix":4,"maskChar":"*"}' /></el-form-item
					></el-col>
				</template>
				<template v-if="kind === 'quality'">
					<el-col :span="12"
						><el-form-item label="目标字段"><el-input v-model="form.targetColumn" maxlength="128" placeholder="规则作用列" /></el-form-item
					></el-col>
					<el-col :span="12"
						><el-form-item label="阈值"><el-input v-model="form.threshold" maxlength="64" placeholder="例如 0.95" /></el-form-item
					></el-col>
					<el-col :span="12"
						><el-form-item label="异常动作"><el-input v-model="form.anomalyAction" maxlength="32" placeholder="例如 BLOCK / WARN" /></el-form-item
					></el-col>
					<el-col :span="24"
						><el-form-item label="条件 JSON" prop="conditionJson"
							><el-input
								v-model="form.conditionJson"
								type="textarea"
								:rows="3"
								maxlength="2000"
								show-word-limit
								placeholder='例如：{"column":"amount","operator":">","value":100}' /></el-form-item
					></el-col>
				</template>
				<el-col :span="24"
					><el-form-item label="描述"><el-input v-model="form.description" type="textarea" :rows="2" maxlength="500" show-word-limit /></el-form-item
				></el-col>
			</el-row>
		</el-form>
		<template #footer
			><el-button @click="visible = false">取消</el-button
			><el-button type="primary" :loading="submitting" :disabled="loading" @click="submit">确定</el-button></template
		>
	</el-dialog>
</template>

<script setup lang="ts" name="DwdRuleFormDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { fetchDwdModelOptions } from '/@/api/dataPlatform/dwd';
import { createDwdRule, getDwdRule, updateDwdRule } from '/@/api/dataPlatform/dwdRule';
import { fetchBusinessDomains } from '/@/api/dataPlatform/layeredTask';
import { useMessage } from '/@/hooks/message';
import { dwdId, optionalDwdId } from '/@/utils/dwdId';
import type { DwdOption } from '/@/types/dataPlatform/dwd';
import type { DwdRule, DwdRuleKind, DwdRuleSaveRequest } from '/@/types/dataPlatform/dwdRule';
import { ruleKinds, ruleTypes } from './constants';

defineProps<{ systems: DwdOption[] }>();
const emit = defineEmits<{ saved: [] }>();
const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const domainLoading = ref(false);
const modelLoading = ref(false);
const kind = ref<DwdRuleKind>('clean');
const kindLabel = computed(() => ruleKinds.find((item) => item.value === kind.value)?.label || '规则');
const editingId = ref('');
const ruleCode = ref('');
const formRef = ref<FormInstance>();
const domains = ref<DwdOption[]>([]);
const models = ref<DwdOption[]>([]);
const blankForm = () => ({
	ruleName: '',
	type: '',
	status: 'ENABLED',
	description: '',
	businessSystemId: '',
	businessDomainId: '',
	modelId: '',
	targetColumn: '',
	targetField: '',
	conditionJson: '',
	actionJson: '',
	transformConfig: '',
	strategyJson: '',
	execOrder: undefined as number | undefined,
	sqlExpression: '',
	sourceFields: '',
	sqlFunction: '',
	threshold: '',
	anomalyAction: '',
});
const form = reactive(blankForm());
const validateJson = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (!value?.trim()) return callback();
	try {
		JSON.parse(value);
		callback();
	} catch {
		callback(new Error('请输入合法 JSON'));
	}
};
const rules: FormRules = {
	ruleName: [{ required: true, whitespace: true, message: '请输入规则名称', trigger: 'blur' }],
	type: [{ required: true, message: '请选择规则类型', trigger: 'change' }],
	conditionJson: [{ validator: validateJson, trigger: 'blur' }],
	actionJson: [{ validator: validateJson, trigger: 'blur' }],
	transformConfig: [{ validator: validateJson, trigger: 'blur' }],
	strategyJson: [{ validator: validateJson, trigger: 'blur' }],
};
const errorText = (error: unknown, fallback: string) => (error as { msg?: string; message?: string })?.msg || (error as Error)?.message || fallback;
const optionalText = (value: string) => value.trim() || undefined;
const loadDomains = async (systemId: string) => {
	domains.value = [];
	if (!systemId) return;
	try {
		domainLoading.value = true;
		const response = await fetchBusinessDomains(systemId);
		if (systemId === form.businessSystemId)
			domains.value = Array.isArray(response.data) ? response.data.map((item: DwdOption) => ({ value: dwdId(item.value), label: item.label })) : [];
	} catch (error) {
		useMessage().error(errorText(error, '加载业务域失败'));
	} finally {
		domainLoading.value = false;
	}
};
const systemChanged = (id: string) => {
	form.businessDomainId = '';
	loadDomains(id);
};
const loadModels = async () => {
	try {
		modelLoading.value = true;
		const response = await fetchDwdModelOptions();
		models.value = Array.isArray(response.data) ? response.data.map((item) => ({ value: dwdId(item.value), label: item.label })) : [];
	} catch (error) {
		useMessage().error(errorText(error, '加载模型选项失败'));
	} finally {
		modelLoading.value = false;
	}
};
const fill = (row: DwdRule) => {
	Object.assign(form, {
		ruleName: row.ruleName || '',
		type: (kind.value === 'mask' ? row.maskType : row.ruleType) || '',
		status: row.status || 'ENABLED',
		description: row.description || '',
		businessSystemId: optionalDwdId(row.businessSystemId),
		businessDomainId: optionalDwdId(row.businessDomainId),
		modelId: optionalDwdId(row.modelId),
		targetColumn: row.targetColumn || '',
		targetField: row.targetField || '',
		conditionJson: row.conditionJson || '',
		actionJson: row.actionJson || '',
		transformConfig: row.transformConfig || '',
		strategyJson: row.strategyJson || '',
		execOrder: row.execOrder ?? undefined,
		sqlExpression: row.sqlExpression || '',
		sourceFields: row.sourceFields || '',
		sqlFunction: row.sqlFunction || '',
		threshold: row.threshold || '',
		anomalyAction: row.anomalyAction || '',
	});
	ruleCode.value = row.ruleCode;
};
const openDialog = async (selectedKind: DwdRuleKind, id?: string) => {
	kind.value = selectedKind;
	editingId.value = id || '';
	ruleCode.value = '';
	Object.assign(form, blankForm());
	visible.value = true;
	await nextTick();
	formRef.value?.clearValidate();
	loadModels();
	if (!id) return;
	try {
		loading.value = true;
		const response = await getDwdRule(selectedKind, id);
		if (!response.data) throw new Error('规则详情为空');
		fill(response.data);
		if (form.businessSystemId) await loadDomains(form.businessSystemId);
	} catch (error) {
		visible.value = false;
		useMessage().error(errorText(error, '加载规则详情失败'));
	} finally {
		loading.value = false;
	}
};
const payload = (): DwdRuleSaveRequest => {
	const common: DwdRuleSaveRequest = {
		ruleName: form.ruleName.trim(),
		status: form.status,
		description: optionalText(form.description),
		businessSystemId: form.businessSystemId ? dwdId(form.businessSystemId) : undefined,
		businessDomainId: form.businessDomainId ? dwdId(form.businessDomainId) : undefined,
		modelId: form.modelId ? dwdId(form.modelId) : undefined,
	};
	if (kind.value === 'clean')
		return {
			...common,
			ruleType: form.type,
			targetColumn: optionalText(form.targetColumn),
			execOrder: form.execOrder,
			conditionJson: optionalText(form.conditionJson),
			actionJson: optionalText(form.actionJson),
		};
	if (kind.value === 'transform')
		return {
			...common,
			ruleType: form.type,
			targetField: optionalText(form.targetField),
			sourceFields: optionalText(form.sourceFields),
			sqlExpression: optionalText(form.sqlExpression),
			transformConfig: optionalText(form.transformConfig),
		};
	if (kind.value === 'mask')
		return {
			...common,
			maskType: form.type,
			targetField: optionalText(form.targetField),
			sqlFunction: optionalText(form.sqlFunction),
			strategyJson: optionalText(form.strategyJson),
		};
	return {
		...common,
		ruleType: form.type,
		conditionJson: optionalText(form.conditionJson),
		threshold: optionalText(form.threshold),
		anomalyAction: optionalText(form.anomalyAction),
		targetColumn: optionalText(form.targetColumn),
	};
};
const submit = async () => {
	if (!(await formRef.value?.validate().catch(() => false))) return;
	if (kind.value === 'mask' && form.type === 'CUSTOM_MASK' && (!form.targetField.trim() || !form.sqlFunction.trim()))
		return useMessage().warning('自定义脱敏必须填写目标字段和 SQL 函数表达式');
	try {
		submitting.value = true;
		const data = payload();
		if (editingId.value) await updateDwdRule(kind.value, editingId.value, data);
		else await createDwdRule(kind.value, data);
		useMessage().success('保存成功');
		visible.value = false;
		emit('saved');
	} catch (error) {
		useMessage().error(errorText(error, '保存规则失败'));
	} finally {
		submitting.value = false;
	}
};
defineExpose({ openDialog });
</script>

<style scoped>
.form-alert {
	margin-bottom: 18px;
}
</style>
