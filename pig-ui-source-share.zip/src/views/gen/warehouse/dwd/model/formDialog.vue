<template>
	<el-dialog
		v-model="visible"
		:title="modelId ? '编辑明细模型' : '新建明细模型'"
		width="820px"
		:close-on-click-modal="false"
		@closed="formRef?.clearValidate()"
	>
		<el-form ref="formRef" v-loading="loading" :model="form" :rules="rules" label-width="110px">
			<el-row :gutter="20">
				<el-col :span="12"
					><el-form-item label="模型名称" prop="modelName"><el-input v-model="form.modelName" maxlength="128" /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="模型编号"><el-input :model-value="modelCode || '保存后自动生成'" disabled /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="业务系统" prop="businessSystemId"
						><el-select v-model="form.businessSystemId" filterable style="width: 100%" @change="onSystemChange"
							><el-option v-for="item in systems" :key="item.value" :label="item.label" :value="item.value" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="业务域" prop="businessDomainId"
						><el-select v-model="form.businessDomainId" filterable :disabled="!form.businessSystemId" :loading="domainLoading" style="width: 100%"
							><el-option v-for="item in domains" :key="item.value" :label="item.label" :value="item.value" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="明细粒度" prop="grain"><el-input v-model="form.grain" placeholder="如：一笔订单一行" /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="负责人" prop="owner"><el-input v-model="form.owner" /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="目标数据源" prop="datasourceId"
						><el-select v-model="form.datasourceId" filterable :loading="datasourceLoading" placeholder="请选择目标数据源" style="width: 100%"
							><el-option v-for="item in datasources" :key="item.value" :label="item.label" :value="item.value" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="目标数据库" prop="databaseName"><el-input v-model="form.databaseName" placeholder="请输入数据库名" /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="物理表名" prop="physicalName"><el-input v-model="form.physicalName" placeholder="如 dwd_order_detail" /></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="状态"
						><el-select v-model="form.status" style="width: 100%"
							><el-option label="草稿" value="DRAFT" /><el-option label="启用" value="ENABLED" /><el-option label="停用" value="DISABLED" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"
					><el-form-item label="写入方式"><el-select v-model="form.writeMode" style="width: 100%"><el-option label="追加写入" value="APPEND" /><el-option label="按主键更新" value="UPSERT" /></el-select></el-form-item
				></el-col>
				<el-col :span="12"><el-form-item label="启用治理"><el-switch v-model="form.governanceEnabled" /></el-form-item></el-col>
				<el-col :span="24"
					><el-form-item label="描述"><el-input v-model="form.description" type="textarea" :rows="3" maxlength="500" show-word-limit /></el-form-item
				></el-col>
			</el-row>
		</el-form>
		<el-alert type="info" :closable="false" title="这里只保存模型配置；版本冻结和数据开发任务发布是后续独立步骤。" />
		<template #footer
			><el-button @click="visible = false">取消</el-button
			><el-button type="primary" :loading="submitting" @click="submit">保存配置</el-button></template
		>
	</el-dialog>
</template>

<script setup lang="ts" name="DwdModelFormDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { createDwdModel, fetchDwdDatasources, fetchDwdDraftRevision, getDwdModel, updateDwdModel } from '/@/api/dataPlatform/dwd';
import { fetchBusinessDomains } from '/@/api/dataPlatform/layeredTask';
import { useMessage } from '/@/hooks/message';
import { dwdId, dwdRevision, optionalDwdId } from '/@/utils/dwdId';
import type { DwdModelSaveRequest, DwdOption } from '/@/types/dataPlatform/dwd';

defineProps<{ systems: DwdOption[] }>();
const emit = defineEmits<{ saved: [id: string] }>();
const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const domainLoading = ref(false);
const datasourceLoading = ref(false);
const modelId = ref('');
const modelCode = ref('');
const draftRevision = ref('');
const formRef = ref<FormInstance>();
const domains = ref<DwdOption[]>([]);
const datasources = ref<DwdOption[]>([]);
const emptyForm = () => ({
	modelName: '',
	businessSystemId: '',
	businessDomainId: '',
	grain: '',
	owner: '',
	datasourceId: '',
	databaseName: '',
	physicalName: '',
	description: '',
	status: 'DRAFT',
	writeMode: 'APPEND' as 'APPEND' | 'UPSERT',
	governanceEnabled: true,
});
const form = reactive(emptyForm());
const rules: FormRules = Object.fromEntries(
	['modelName', 'businessSystemId', 'businessDomainId', 'grain', 'owner', 'datasourceId', 'databaseName', 'physicalName'].map((key) => [
		key,
		[{ required: true, message: '请填写或选择此项', trigger: ['blur', 'change'] }],
	])
);

const loadDomains = async (systemId: string) => {
	domains.value = [];
	if (!systemId) return;
	try {
		domainLoading.value = true;
		const response = await fetchBusinessDomains(systemId);
		domains.value = Array.isArray(response.data) ? response.data.map((item: DwdOption) => ({ value: dwdId(item.value), label: item.label })) : [];
	} catch (error) {
		useMessage().error((error as { msg?: string })?.msg || '加载业务域失败');
	} finally {
		domainLoading.value = false;
	}
};

const onSystemChange = (systemId: string) => {
	form.businessDomainId = '';
	loadDomains(systemId);
};

const loadDatasources = async () => {
	try {
		datasourceLoading.value = true;
		const response = await fetchDwdDatasources();
		const data = response.data as { records?: unknown[]; list?: unknown[] } | unknown[];
		const rows = Array.isArray(data) ? data : data?.records || data?.list || [];
		datasources.value = rows
			.map((item: unknown) => {
				const row = item as {
					id?: string | number;
					datasourceId?: string | number;
					displayName?: string;
					name?: string;
					alias?: string;
					dsName?: string;
				};
				return {
					value: optionalDwdId(row.id ?? row.datasourceId),
					label: row.displayName || row.alias || row.name || row.dsName || String(row.id ?? ''),
				};
			})
			.filter((item) => item.value);
	} catch (error) {
		useMessage().error((error as { msg?: string })?.msg || '加载数据源失败');
	} finally {
		datasourceLoading.value = false;
	}
};

const openDialog = async (id?: string) => {
	modelId.value = id || '';
	modelCode.value = '';
	draftRevision.value = '';
	Object.assign(form, emptyForm());
	visible.value = true;
	await nextTick();
	formRef.value?.clearValidate();
	await loadDatasources();
	if (!id) return;
	try {
		loading.value = true;
		const revisionResponse = await fetchDwdDraftRevision(id);
		draftRevision.value = dwdRevision(revisionResponse.data);
		const response = await getDwdModel(id);
		const item = response.data;
		if (!item) throw new Error('模型不存在');
		if (item.draftRevision != null && dwdRevision(item.draftRevision) !== draftRevision.value) throw new Error('模型配置已变化，请重新打开编辑弹窗');
		modelCode.value = item.modelCode;
		await loadDomains(optionalDwdId(item.businessSystemId));
		Object.assign(form, {
			...item,
			writeMode: item.writeMode || 'APPEND',
			governanceEnabled: item.governanceEnabled ?? true,
			businessSystemId: optionalDwdId(item.businessSystemId),
			businessDomainId: optionalDwdId(item.businessDomainId),
			datasourceId: optionalDwdId(item.datasourceId),
		});
	} catch (error) {
		visible.value = false;
		useMessage().error((error as { msg?: string })?.msg || '加载模型失败');
	} finally {
		loading.value = false;
	}
};

const submit = async () => {
	if (!(await formRef.value?.validate().catch(() => false))) return;
	try {
		submitting.value = true;
		const data: DwdModelSaveRequest = {
			modelName: form.modelName.trim(),
			businessSystemId: dwdId(form.businessSystemId),
			businessDomainId: dwdId(form.businessDomainId),
			grain: form.grain.trim(),
			owner: form.owner.trim(),
			datasourceId: dwdId(form.datasourceId),
			databaseName: form.databaseName.trim(),
			physicalName: form.physicalName.trim(),
			description: form.description.trim(),
			status: form.status,
			writeMode: form.writeMode,
			governanceEnabled: form.governanceEnabled,
			warehouseLayer: 'DWD',
			...(modelId.value ? { expectedRevision: draftRevision.value } : {}),
		};
		const response = modelId.value ? await updateDwdModel(modelId.value, data) : await createDwdModel(data);
		const savedId = modelId.value || dwdId(response.data);
		visible.value = false;
		useMessage().success('模型配置已保存');
		emit('saved', savedId);
	} catch (error) {
		useMessage().error((error as { message?: string; msg?: string })?.msg || (error as Error)?.message || '保存模型失败');
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>
