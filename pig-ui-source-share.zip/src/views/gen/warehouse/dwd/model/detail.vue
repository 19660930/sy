<template>
	<div class="layout-padding">
		<el-card shadow="never" v-loading="loading">
			<div class="heading">
				<div>
					<el-button link type="primary" icon="Back" @click="router.push('/gen/warehouse/dwd/model')">返回列表</el-button>
					<h2>
						{{ model?.modelName || '明细模型详情' }}
						<el-tag v-if="model" :type="model.status === 'ENABLED' ? 'success' : 'info'">{{ model.status === 'ENABLED' ? '启用' : model.status === 'DRAFT' ? '草稿' : '停用' }}</el-tag>
					</h2>
					<p>{{ model?.modelCode || '--' }} · {{ model?.databaseName || '--' }}.{{ model?.physicalName || '--' }}</p>
				</div>
				<div><el-button @click="router.push({ path: '/gen/warehouse/dwd/operations', query: { modelId } })">查看运维结果</el-button><el-button v-auth="'dp_dwd_model_edit'" @click="formDialogRef?.openDialog(modelId)">编辑基本信息</el-button></div>
			</div>
			<el-alert type="info" :closable="false" title="先保存模型配置，再预览 SQL、冻结 DWD 版本；任务版本发布与执行在“分层任务运维”中进行。" />
			<el-tabs v-model="activeTab" class="detail-tabs" @tab-change="tabChanged">
				<el-tab-pane label="基本信息" name="basic"
					><el-descriptions v-if="model" :column="2" border
						><el-descriptions-item label="模型名称">{{ model.modelName }}</el-descriptions-item
						><el-descriptions-item label="明细粒度">{{ model.grain }}</el-descriptions-item
						><el-descriptions-item label="业务系统">{{ model.businessSystemName || model.businessSystemId }}</el-descriptions-item
						><el-descriptions-item label="业务域">{{ model.businessDomainName || model.businessDomainId }}</el-descriptions-item
						><el-descriptions-item label="负责人">{{ model.owner }}</el-descriptions-item
						><el-descriptions-item label="目标数据源 ID">{{ model.datasourceId }}</el-descriptions-item
						><el-descriptions-item label="数据库">{{ model.databaseName }}</el-descriptions-item
						><el-descriptions-item label="物理表">{{ model.physicalName }}</el-descriptions-item
						><el-descriptions-item label="目标表状态">{{ model.targetTableStatus || '--' }}</el-descriptions-item
						><el-descriptions-item label="写入方式">{{ model.writeMode === 'UPSERT' ? '按主键更新' : '追加写入' }}</el-descriptions-item
						><el-descriptions-item label="数据治理">{{ model.governanceEnabled ? '启用' : '停用' }}</el-descriptions-item
						><el-descriptions-item label="当前版本">{{ model.currentVersionNo || '--' }}</el-descriptions-item
						><el-descriptions-item label="描述">{{ model.description || '--' }}</el-descriptions-item></el-descriptions
					></el-tab-pane
				>
				<el-tab-pane label="数据来源与关联" name="sources">
					<div class="tab-toolbar">
						<span>选择 ODS/DIM 来源，主表之外的来源需配置关联条件。</span>
						<div>
							<el-button v-auth="'dp_dwd_model_edit'" icon="Plus" @click="openSource()">添加来源</el-button
							><el-button v-auth="'dp_dwd_model_edit'" type="primary" :loading="saving === 'sources'" @click="saveSources">保存全部来源</el-button>
						</div>
					</div>
					<el-table :data="sources" border empty-text="尚未配置来源表"
						><el-table-column prop="sourceType" label="层级" width="80" /><el-table-column
							prop="sourceTable"
							label="来源表"
							min-width="170"
						/><el-table-column prop="alias" label="别名" width="80" /><el-table-column label="主表" width="80"
							><template #default="{ row }">{{ row.isMain ? '是' : '否' }}</template></el-table-column
						><el-table-column prop="joinType" label="关联方式" width="125" /><el-table-column
							prop="joinCondition"
							label="关联条件"
							min-width="230"
							show-overflow-tooltip
						/><el-table-column label="操作" width="115"
							><template #default="{ row, $index }"
								><el-button link type="primary" @click="openSource(row, $index)">编辑</el-button
								><el-button link type="danger" @click="sources.splice($index, 1)">移除</el-button></template
							></el-table-column
						></el-table
					>
					<p class="hint">保存会完整替换已有来源；移除后需点击“保存全部来源”才生效。清空全部来源会再次确认。</p>
				</el-tab-pane>
				<el-tab-pane label="字段映射" name="fields">
					<div class="tab-toolbar">
						<span>来源字段可选择，也可按表达式或常量手填；目标列、类型和角色必填。</span>
						<div>
							<el-button v-auth="'dp_dwd_model_edit'" :loading="saving === 'generate-fields'" :disabled="Boolean(saving) && saving !== 'generate-fields'" @click="generateFieldsFromSources">从来源表批量生成</el-button>
							<el-button v-auth="'dp_dwd_model_edit'" type="danger" plain :disabled="!selectedFields.size || Boolean(saving)" @click="bulkRemoveFields">批量删除（{{ selectedFields.size }}）</el-button>
							<el-button v-auth="'dp_dwd_model_edit'" icon="Plus" @click="addField">添加字段</el-button
							><el-button v-auth="'dp_dwd_model_edit'" type="primary" :loading="saving === 'fields'" :disabled="saving === 'generate-fields'" @click="saveFields">保存全部字段</el-button>
						</div>
					</div>
					<el-table :data="visibleFields" border empty-text="尚未配置字段映射" class="field-table"
						><el-table-column width="55" align="center"
							><template #header>
								<el-checkbox :model-value="visibleFields.length > 0 && pageSelectionCount === visibleFields.length" :indeterminate="pageSelectionCount > 0 && pageSelectionCount < visibleFields.length" @change="togglePageSelection(Boolean($event))" />
							</template>
							<template #default="{ row }"><el-checkbox :model-value="selectedFields.has(row)" @change="toggleFieldSelection(row, Boolean($event))" /></template></el-table-column
						><el-table-column label="序号" width="70"
							><template #default="{ row }"
								><el-input-number v-model="row.seq" :min="1" :controls="false" style="width: 55px" /></template></el-table-column
						><el-table-column label="目标列" min-width="140"
							><template #default="{ row }"><el-input v-model="row.targetColumn" /></template></el-table-column
						><el-table-column label="目标类型" min-width="145"
							><template #default="{ row }"
								><el-select v-model="row.targetType" filterable allow-create default-first-option
									><el-option
										v-for="item in dwdOptions.dataTypes"
										:key="item.value"
										:label="item.label"
										:value="item.value" /></el-select></template></el-table-column
						><el-table-column label="取值方式" min-width="130"
							><template #default="{ row }"
								><el-select v-model="row.sourceType"
									><el-option
										v-for="item in dwdOptions.fieldSourceTypes"
										:key="item.value"
										:label="item.label"
										:value="item.value" /></el-select></template></el-table-column
						><el-table-column label="来源字段/表达式/常量" min-width="200"
							><template #default="{ row }"
								><el-select-v2 v-if="row.sourceType === 'ODS_FIELD'" v-model="row.sourceExpr" :options="sourceColumnOptions" filterable allow-create default-first-option />
								<el-input v-else v-model="row.sourceExpr" /></template></el-table-column
						><el-table-column label="字段角色" min-width="135"
							><template #default="{ row }"
								><el-select v-model="row.role"
									><el-option
										v-for="item in dwdOptions.fieldRoles"
										:key="item.value"
										:label="item.label"
										:value="item.value" /></el-select></template></el-table-column
						><el-table-column label="主键" width="70"
							><template #default="{ row }"><el-switch v-model="row.isPk" /></template></el-table-column
						><el-table-column label="脱敏" width="70"
							><template #default="{ row }"><el-switch v-model="row.isMasked" /></template></el-table-column
						><el-table-column label="转换" min-width="125"
							><template #default="{ row }"><el-input v-model="row.transformRule" placeholder="可选说明" /></template></el-table-column
						><el-table-column label="操作" width="115"
							><template #default="{ $index }"
								><el-button link type="primary" @click="openField(fieldAbsoluteIndex($index))">配置</el-button
								><el-button link type="danger" @click="removeField(fieldAbsoluteIndex($index))">移除</el-button></template
							></el-table-column
						></el-table
					>
					<pagination
						v-if="fields.length > fieldPage.size"
						:current="fieldPage.current"
						:size="fieldPage.size"
						:total="fields.length"
						:page-sizes="[10, 20, 50]"
						@current-change="fieldPage.current = $event"
						@size-change="changeFieldPageSize"
					/>
					<p class="hint">保存会完整替换已有字段映射；提交空列表会清空已有字段。</p>
				</el-tab-pane>
				<el-tab-pane label="分区与增量" name="partition"
					><el-form :model="partition" label-width="120px" class="partition-form"
						><el-row :gutter="18"
							><el-col :span="12"
								><el-form-item label="分区字段" :required="partition.partitionGranularity === 'DAY'"
									><el-select v-model="partition.partitionColumn" filterable clearable placeholder="请选择字段映射中的目标列"
										><el-option v-for="item in partitionFieldOptions" :key="item.name" :label="`${item.name}（${item.type || '未设置类型'}）`" :value="item.name" /></el-select></el-form-item></el-col
							><el-col :span="12"
								><el-form-item label="分区粒度" required
									><el-select v-model="partition.partitionGranularity"
										><el-option label="不分区" value="NONE" /><el-option label="按日" value="DAY" /></el-select></el-form-item></el-col
							><el-col :span="12"
								><el-form-item label="增量方式" required
									><el-select v-model="partition.incrementType"
										><el-option label="时间戳" value="TIMESTAMP" /><el-option
											label="业务日期"
											value="BUSINESS_DATE" /></el-select></el-form-item></el-col
							><el-col :span="12"
								><el-form-item label="增量字段"
									><el-select v-model="partition.incrementField" filterable allow-create default-first-option clearable :loading="incrementFieldsLoading" placeholder="可选：选择或输入 ODS 来源字段名"
										><el-option v-for="item in incrementFieldOptions" :key="item.name" :label="`${item.name}（${item.tables.join('、')}）`" :value="item.name" /></el-select>
									<div class="hint">默认使用 ODS 主表的 _etl_time；仅保存纯字段名，不带表别名。实际增量执行以任务配置为准。</div>
								</el-form-item></el-col
							><el-col :span="12"
								><el-form-item label="数据范围"><el-input v-model="partition.dataRange" /></el-form-item></el-col
							><el-col :span="12"
								><el-form-item label="更新周期"><el-input v-model="partition.updateCycle" /></el-form-item></el-col
							><el-col :span="12"
								><el-form-item label="迟到数据处理"><el-input v-model="partition.lateDataLookback" /></el-form-item></el-col
							><el-col :span="12"
								><el-form-item label="重跑策略"><el-input v-model="partition.rerunStrategy" /></el-form-item></el-col></el-row
						><el-form-item
							><el-button v-auth="'dp_dwd_model_edit'" type="primary" :loading="saving === 'partition'" @click="savePartition"
								>保存分区配置</el-button
							></el-form-item
						></el-form
					></el-tab-pane
				>
				<el-tab-pane label="SQL 预览" name="sql"
					><div class="tab-toolbar">
						<span>SQL 由服务端根据当前已保存配置生成，仅供查看，不会执行。</span
						><el-button v-auth="'dp_dwd_model_view'" :loading="saving === 'sql'" @click="loadSql">重新生成</el-button>
					</div>
					<pre v-if="sql" class="sql-code">{{ sql }}</pre>
					<el-empty v-else description="尚无可预览的 SQL，请先保存配置"
				/></el-tab-pane>
				<el-tab-pane label="版本历史" name="versions"
					><div class="tab-toolbar">
						<span>冻结版本保留当前模型配置与生成 SQL，不等于发布任务。</span
						><el-button v-auth="'dp_dwd_model_edit'" type="primary" :loading="saving === 'freeze'" @click="freeze">冻结当前配置</el-button>
					</div>
					<el-table :data="versions" border empty-text="暂无冻结版本"
						><el-table-column prop="versionNo" label="版本号" width="130" /><el-table-column label="当前版本" width="100"
							><template #default="{ row }">{{ row.isCurrent ? '是' : '否' }}</template></el-table-column
						><el-table-column prop="changelog" label="变更说明" min-width="180" /><el-table-column
							prop="operator"
							label="操作人"
							width="130"
						/><el-table-column prop="effectiveTime" label="生效时间" width="180" /><el-table-column label="操作" width="80"
							><template #default="{ row }"><el-button link type="primary" @click="showVersion(row.id)">查看</el-button></template></el-table-column
						></el-table
					></el-tab-pane
				>
			</el-tabs>
		</el-card>
		<FormDialog ref="formDialogRef" :systems="systems" @saved="refreshModel" />
		<el-dialog v-model="sourceDialog" :title="sourceIndex < 0 ? '添加来源表' : '编辑来源表'" width="min(860px, 96vw)" :close-on-click-modal="false"
			><el-form :model="sourceDraft" label-width="105px"
				><el-row :gutter="16"
					><el-col :span="12"
						><el-form-item label="来源层级" required
							><el-select v-model="sourceDraft.sourceType" @change="sourceTypeChanged"
								><el-option label="ODS" value="ODS" /><el-option label="DIM" value="DIM" /></el-select></el-form-item></el-col
					><el-col v-if="sourceDraft.sourceType === 'ODS'" :span="12"
						><el-form-item label="来源数据源" required
							><el-select v-model="sourceDatasourceId" filterable @change="loadSourceTables"
								><el-option
									v-for="item in datasources"
									:key="item.value"
									:label="item.label"
									:value="item.value" /></el-select></el-form-item></el-col
					><el-col :span="12"
						><el-form-item :label="sourceDraft.sourceType === 'ODS' ? 'ODS 表' : 'DIM 模型'" required
							><el-select v-model="sourceDraft.sourceTableId" filterable :loading="tableLoading" @change="sourceTableChanged"
								><el-option
									v-for="item in sourceTableOptions"
									:key="item.id || item.label"
									:label="item.label"
									:value="item.id"
									:disabled="!item.id" /></el-select></el-form-item></el-col
					><el-col :span="12"
						><el-form-item label="表别名" required><el-input v-model="sourceDraft.alias" placeholder="如 o" /></el-form-item></el-col
					><el-col :span="12"
						><el-form-item label="是否主表"><el-switch v-model="sourceDraft.isMain" @change="mainSourceChanged" /></el-form-item></el-col
					><el-col v-if="!sourceDraft.isMain" :span="12"
						><el-form-item label="JOIN 类型"
							><el-select v-model="sourceDraft.joinType"
								><el-option
									v-for="item in dwdOptions.joinTypes"
									:key="item.value"
									:label="item.label"
									:value="item.value" /></el-select></el-form-item></el-col
					><el-col v-if="!sourceDraft.isMain" :span="24"
						><el-form-item label="关联方式">
							<el-radio-group v-model="joinMode">
								<el-radio value="PAIRS">字段配对</el-radio>
								<el-radio value="EXPRESSION">自定义条件</el-radio>
							</el-radio-group>
						</el-form-item></el-col
					><el-col v-if="!sourceDraft.isMain && joinMode === 'PAIRS'" :span="24"
						><el-form-item label="关联键" required>
							<div class="join-pair-editor" v-loading="joinColumnsLoading">
								<el-alert v-if="!mainSource" title="请先在来源配置中添加主表，再配置关联键。" type="warning" :closable="false" />
								<div v-for="(pair, pairIndex) in joinPairs" :key="pairIndex" class="join-pair-row">
									<el-select v-model="pair.left" filterable allow-create default-first-option :disabled="!mainSource" placeholder="选择或输入主表字段">
										<el-option v-for="column in mainJoinColumns" :key="column" :label="`${mainSource?.alias}.${column}`" :value="column" />
									</el-select>
									<span>＝</span>
									<el-select v-model="pair.right" filterable allow-create default-first-option :disabled="!sourceDraft.sourceTableId" placeholder="选择或输入当前表字段">
										<el-option v-for="column in currentJoinColumns" :key="column" :label="`${sourceDraft.alias || '当前表'}.${column}`" :value="column" />
									</el-select>
									<el-button link type="danger" :disabled="joinPairs.length === 1" @click="joinPairs.splice(pairIndex, 1)">删除</el-button>
								</div>
								<el-button link type="primary" @click="joinPairs.push({ left: '', right: '' })">添加一组关联键</el-button>
								<div class="join-pair-help">字段来自 ODS 元数据或 DIM 模型属性；元数据缺失时也可直接输入字段名。</div>
								<div v-if="joinPreview" class="join-pair-help">条件预览：{{ joinPreview }}</div>
							</div>
						</el-form-item></el-col
					><el-col v-if="!sourceDraft.isMain && joinMode === 'EXPRESSION'" :span="24"
						><el-form-item label="关联条件" required
						><el-input
								v-model="sourceDraft.joinCondition"
								type="textarea"
								:rows="3"
								placeholder="如 o.supplier_code = s.supplier_code" /></el-form-item></el-col
					><el-col v-if="!sourceDraft.isMain" :span="24"
						><el-form-item label="版本匹配"
							><el-input v-model="sourceDraft.joinVersionMode" placeholder="如按业务日期匹配有效维度版本" /></el-form-item></el-col
					></el-row></el-form
			><el-alert
				v-if="sourceDraft.sourceType === 'ODS' && sourceDatasourceId && !tableLoading && !sourceTableOptions.length"
				type="warning"
				:closable="false"
				title="该数据源暂无 ODS 层元数据表；请先完成 ODS 元数据采集，或确认元数据查看权限。"
			/><template #footer
				><el-button @click="sourceDialog = false">取消</el-button><el-button type="primary" @click="applySource">加入配置</el-button></template
			></el-dialog
		>
		<el-dialog v-model="fieldDialog" title="字段详细配置" width="620px" :close-on-click-modal="false">
			<el-form :model="fieldDraft" label-width="100px">
				<el-form-item label="目标列注释"><el-input v-model="fieldDraft.targetComment" /></el-form-item>
				<el-form-item label="来源别名"><el-input v-model="fieldDraft.sourceAlias" placeholder="如 o；可留空" /></el-form-item>
				<el-form-item label="转换类型"
					><el-select v-model="fieldDraft.transformType" style="width: 100%"
						><el-option v-for="item in transformTypes" :key="item" :label="item" :value="item" /></el-select
				></el-form-item>
				<el-form-item label="转换参数"
					><el-input v-model="fieldDraft.transformParams" type="textarea" :rows="3" placeholder='可选 JSON，如 {"scale":2}'
				/></el-form-item>
				<el-form-item label="转换说明"><el-input v-model="fieldDraft.transformRule" /></el-form-item>
			</el-form>
			<template #footer
				><el-button @click="fieldDialog = false">取消</el-button><el-button type="primary" @click="applyField">确定</el-button></template
			>
		</el-dialog>
		<el-dialog v-model="versionDialog" title="冻结版本详情" width="780px">
			<pre class="version-code">{{ JSON.stringify(versionDetail, null, 2) }}</pre>
		</el-dialog>
	</div>
</template>

<script setup lang="ts" name="DwdModelDetail">
import { fetchDimensionAttributes, fetchDimensionModelPage } from '/@/api/dataPlatform/dimension';
import { fetchDatasourceReferences } from '/@/api/dataPlatform/datasourceAsset';
import { fetchBusinessSystems } from '/@/api/dataPlatform/layeredTask';
import {
	fetchDwdDraftRevision,
	fetchDwdFields,
	fetchDwdOptions,
	fetchDwdOdsTablePage,
	fetchDwdPartition,
	fetchDwdSources,
	fetchDwdSql,
	fetchDwdTableColumns,
	fetchDwdVersions,
	freezeDwdVersion,
	getDwdModel,
	getDwdVersion,
	saveDwdFields,
	saveDwdPartition,
	saveDwdSources,
	validateDwdModel,
} from '/@/api/dataPlatform/dwd';
import { useMessage, useMessageBox } from '/@/hooks/message';
import { dwdId, dwdRevision, isDwdId, optionalDwdId } from '/@/utils/dwdId';
import type { DwdField, DwdFrozenVersion, DwdModel, DwdOption, DwdOptions, DwdPartition, DwdSource, DwdVersion } from '/@/types/dataPlatform/dwd';
import FormDialog from './formDialog.vue';

const route = useRoute();
const router = useRouter();
const modelId = String(route.params.id || '');
const formDialogRef = ref<InstanceType<typeof FormDialog>>();
const model = ref<DwdModel>();
const loading = ref(false);
const saving = ref('');
const activeTab = ref('basic');
const loadedTabs = new Set<string>();
const systems = ref<DwdOption[]>([]);
const datasources = ref<DwdOption[]>([]);
const sources = ref<DwdSource[]>([]);
const fields = ref<DwdField[]>([]);
const fieldPage = reactive({ current: 1, size: 10 });
const visibleFields = computed(() => fields.value.slice((fieldPage.current - 1) * fieldPage.size, fieldPage.current * fieldPage.size));
const selectedFields = shallowRef<Set<DwdField>>(new Set());
const pageSelectionCount = computed(() => visibleFields.value.filter((field) => selectedFields.value.has(field)).length);
const toggleFieldSelection = (field: DwdField, selected: boolean) => {
	const next = new Set(selectedFields.value);
	if (selected) next.add(field);
	else next.delete(field);
	selectedFields.value = next;
};
const togglePageSelection = (selected: boolean) => {
	const next = new Set(selectedFields.value);
	visibleFields.value.forEach((field) => {
		if (selected) next.add(field);
		else next.delete(field);
	});
	selectedFields.value = next;
};
const fieldAbsoluteIndex = (index: number) => (fieldPage.current - 1) * fieldPage.size + index;
const changeFieldPageSize = (size: number) => {
	fieldPage.size = size;
	fieldPage.current = 1;
};
const versions = ref<DwdVersion[]>([]);
const dwdOptions = reactive<DwdOptions>({
	sourceTypes: [],
	joinTypes: [],
	fieldRoles: [],
	fieldSourceTypes: [],
	statuses: [],
	dataTypes: [],
	partitionTypes: [],
});
const blankPartition = (): DwdPartition => ({ partitionColumn: '', partitionGranularity: 'DAY', incrementType: 'TIMESTAMP', incrementField: '' });
const partition = reactive<DwdPartition>(blankPartition());
const partitionFieldOptions = computed(() => {
	const options = fields.value
		.filter((field) => field.targetColumn?.trim())
		.map((field) => ({ name: field.targetColumn.trim(), type: field.targetType?.trim() || '' }));
	const unique = [...new Map(options.map((item) => [item.name.toLowerCase(), item])).values()];
	if (partition.partitionGranularity === 'DAY')
		unique.sort((a, b) => Number(/^(DATE|DATETIME|TIMESTAMP)/i.test(b.type)) - Number(/^(DATE|DATETIME|TIMESTAMP)/i.test(a.type)));
	return unique;
});
const incrementFieldOptions = ref<Array<{ name: string; tables: string[] }>>([]);
const incrementFieldsLoading = ref(false);
const sql = ref('');
const sourceColumns = ref<string[]>([]);
const sourceColumnOptions = computed(() => sourceColumns.value.map((name) => ({ label: name, value: name })));
const fieldDialog = ref(false);
const fieldIndex = ref(-1);
const fieldDraft = reactive<DwdField>({ targetColumn: '', targetType: '', sourceType: 'ODS_FIELD', sourceExpr: '', role: '', seq: 1 });
const transformTypes = ['NONE', 'TRIM', 'UPPER', 'LOWER', 'DATE_FORMAT', 'NUMBER_ROUND', 'CAST'];
const sourceDialog = ref(false);
const sourceIndex = ref(-1);
const sourceDatasourceId = ref('');
const sourceTableOptions = ref<Array<{ id: string; label: string; tableName?: string; database?: string }>>([]);
const tableLoading = ref(false);
let sourceTableRequestNo = 0;
const blankSource = (): DwdSource => ({
	sourceType: 'ODS',
	sourceTableId: '',
	sourceTable: '',
	alias: '',
	isMain: false,
	joinType: 'LEFT_JOIN',
	joinCondition: '',
	sortOrder: 0,
	status: 'ENABLED',
});
const sourceDraft = reactive<DwdSource>(blankSource());
const joinMode = ref<'PAIRS' | 'EXPRESSION'>('PAIRS');
const joinPairs = ref<Array<{ left: string; right: string }>>([{ left: '', right: '' }]);
const mainJoinColumns = ref<string[]>([]);
const currentJoinColumns = ref<string[]>([]);
const joinColumnsLoading = ref(false);
let joinColumnsRequestNo = 0;
const mainSource = computed(() => sources.value.find((source, index) => source.isMain && index !== sourceIndex.value));
const joinColumnName = (value: string) => value.includes('.') ? value.slice(value.indexOf('.') + 1) : value;
const joinPreview = computed(() => {
	const leftAlias = mainSource.value?.alias.trim();
	const rightAlias = sourceDraft.alias.trim();
	if (!leftAlias || !rightAlias) return '';
	return joinPairs.value
		.filter((pair) => joinColumnName(pair.left.trim()) && joinColumnName(pair.right.trim()))
		.map((pair) => `${leftAlias}.${joinColumnName(pair.left.trim())} = ${rightAlias}.${joinColumnName(pair.right.trim())}`)
		.join(' AND ');
});
const versionDialog = ref(false);
const versionDetail = ref<DwdFrozenVersion>();
const errorText = (error: unknown, fallback: string) => (error as { msg?: string; message?: string })?.msg || (error as Error)?.message || fallback;
const invalidateSql = () => {
	sql.value = '';
	loadedTabs.delete('sql');
};

const refreshModel = async () => {
	try {
		loading.value = true;
		const response = await getDwdModel(modelId);
		model.value = response.data
			? {
					...response.data,
					id: dwdId(response.data.id),
					businessSystemId: optionalDwdId(response.data.businessSystemId),
					businessDomainId: optionalDwdId(response.data.businessDomainId),
					datasourceId: optionalDwdId(response.data.datasourceId),
			  }
			: undefined;
		invalidateSql();
	} catch (error) {
		useMessage().error(errorText(error, '加载模型失败'));
	} finally {
		loading.value = false;
	}
};

const loadSources = async () => {
	const response = await fetchDwdSources(modelId);
	sources.value = Array.isArray(response.data)
		? response.data.map((item, index) => ({
				...item,
				id: item.id == null ? undefined : dwdId(item.id),
				modelId: item.modelId == null ? null : dwdId(item.modelId),
				sourceTableId: dwdId(item.sourceTableId),
				sortOrder: item.sortOrder ?? index,
		  }))
		: [];
};
const loadFields = async () => {
	const response = await fetchDwdFields(modelId);
	fields.value = Array.isArray(response.data) ? response.data.map((item, index) => ({ ...item, seq: item.seq ?? index + 1 })) : [];
	selectedFields.value = new Set();
	fieldPage.current = Math.min(fieldPage.current, Math.max(1, Math.ceil(fields.value.length / fieldPage.size)));
	await loadSourceColumns();
};
const loadPartition = async () => {
	const response = await fetchDwdPartition(modelId);
	Object.assign(partition, blankPartition(), response.data || {});
};
const loadVersions = async () => {
	const response = await fetchDwdVersions(modelId);
	versions.value = Array.isArray(response.data) ? response.data.map((item) => ({ ...item, id: dwdId(item.id), modelId: dwdId(item.modelId) })) : [];
};
const loadSql = async () => {
	try {
		saving.value = 'sql';
		const response = await fetchDwdSql(modelId);
		sql.value = response.data?.sql || '';
	} catch (error) {
		sql.value = '';
		useMessage().error(errorText(error, 'SQL 预览失败'));
	} finally {
		saving.value = '';
	}
};
const tabChanged = async (value: string | number) => {
	const name = String(value);
	if (name === 'basic' || loadedTabs.has(name)) return;
	try {
		loading.value = true;
		if (name === 'sources') await loadSources();
		if (name === 'fields') {
			if (!loadedTabs.has('sources')) {
				await loadSources();
				loadedTabs.add('sources');
			}
			await loadFields();
		}
		if (name === 'partition') {
			if (!loadedTabs.has('sources')) {
				await loadSources();
				loadedTabs.add('sources');
			}
			if (!loadedTabs.has('fields')) {
				await loadFields();
				loadedTabs.add('fields');
			}
			await Promise.all([loadPartition(), loadIncrementFieldOptions()]);
			if (!partition.incrementField?.trim() && sources.value.some((source) => source.sourceType === 'ODS' && source.isMain))
				partition.incrementField = '_etl_time';
		}
		if (name === 'sql') await loadSql();
		if (name === 'versions') await loadVersions();
		loadedTabs.add(name);
	} catch (error) {
		useMessage().error(errorText(error, '加载配置失败'));
	} finally {
		loading.value = false;
	}
};

const confirmEmpty = async (items: unknown[], label: string) => {
	if (items.length) return true;
	try {
		await useMessageBox().confirm(`即将清空全部${label}，此操作会替换后端现有配置。确定继续吗？`);
		return true;
	} catch {
		return false;
	}
};
const saveSources = async () => {
	if (!loadedTabs.has('sources')) return useMessage().warning('来源配置尚未成功加载，请先重新进入此页');
	if (!(await confirmEmpty(sources.value, '来源表'))) return;
	if (sources.value.some((item) => !isDwdId(item.sourceTableId) || !item.alias.trim() || (!item.isMain && !item.joinCondition?.trim() && !item.joinKeys?.trim())))
		return useMessage().warning('请补齐来源表、别名及关联条件或关联键');
	if (sources.value.filter((item) => item.isMain).length !== 1 && sources.value.length) return useMessage().warning('请设置且仅设置一张主表');
	try {
		saving.value = 'sources';
		await saveDwdSources(
			modelId,
			sources.value.map((item, index) => ({
				sourceType: item.sourceType,
				sourceTableId: item.sourceTableId,
				sourceDatabase: item.sourceDatabase,
				sourceTable: item.sourceTable,
				alias: item.alias,
				isMain: item.isMain,
				joinType: item.isMain ? undefined : item.joinType,
				joinCondition: item.isMain ? undefined : item.joinCondition?.trim() || undefined,
				joinKeys: item.isMain ? undefined : item.joinKeys?.trim() || undefined,
				joinVersionMode: item.isMain ? undefined : item.joinVersionMode,
				sortOrder: index,
				status: item.status,
			}))
		);
		await loadSources();
		if (loadedTabs.has('fields')) await loadSourceColumns();
		if (loadedTabs.has('partition')) {
			await loadIncrementFieldOptions();
			if (!partition.incrementField?.trim() && sources.value.some((source) => source.sourceType === 'ODS' && source.isMain))
				partition.incrementField = '_etl_time';
		}
		invalidateSql();
		useMessage().success('来源配置已保存');
	} catch (error) {
		useMessage().error(errorText(error, '保存来源失败'));
	} finally {
		saving.value = '';
	}
};
const addField = () => {
	fields.value.push({
		targetColumn: '',
		targetType: '',
		sourceType: 'ODS_FIELD',
		sourceExpr: '',
		role: '',
		seq: fields.value.length + 1,
		isPk: false,
		isMasked: false,
	});
	fieldPage.current = Math.ceil(fields.value.length / fieldPage.size);
};
const removeField = (index: number) => {
	const [removed] = fields.value.splice(index, 1);
	if (removed) toggleFieldSelection(removed, false);
	fieldPage.current = Math.min(fieldPage.current, Math.max(1, Math.ceil(fields.value.length / fieldPage.size)));
};
const bulkRemoveFields = async () => {
	const count = selectedFields.value.size;
	if (!count) return;
	try {
		await useMessageBox().confirm(`确定移除选中的 ${count} 个字段映射吗？点击“保存全部字段”后才会提交到后端。`);
	} catch {
		return;
	}
	fields.value = fields.value.filter((field) => !selectedFields.value.has(field));
	selectedFields.value = new Set();
	fieldPage.current = Math.min(fieldPage.current, Math.max(1, Math.ceil(fields.value.length / fieldPage.size)));
	useMessage().success(`已移除 ${count} 个字段映射，请保存全部字段`);
};
type SourceColumn = { name: string; type: string; comment: string; primaryKey: boolean };
const sourceColumnDetails = async (source: DwdSource): Promise<SourceColumn[]> => {
	if (!isDwdId(source.sourceTableId)) return [];
	const response = source.sourceType === 'DIM' ? await fetchDimensionAttributes(source.sourceTableId) : await fetchDwdTableColumns(source.sourceTableId);
	const data = response.data as { records?: unknown[]; columns?: unknown[] } | unknown[];
	const rows = Array.isArray(data) ? data : data?.records || data?.columns || [];
	return rows
		.map((item) => {
			const column = item as Record<string, unknown>;
			return {
				name: String(column.columnName || column.attrCode || column.attributeCode || column.fieldName || column.name || '').trim(),
				type: String(column.typeName || column.dataType || column.columnType || '').trim(),
				comment: String(column.columnComment || column.attrName || column.description || '').trim(),
				primaryKey: [true, 1, '1'].includes(column.primaryKey as string | number | boolean) || [true, 1, '1'].includes(column.isPk as string | number | boolean),
			};
		})
		.filter((column) => column.name);
};
const inferredTargetType = (sourceType: string): string => {
	const type = sourceType.toUpperCase().replace(/\(.*/, '').trim();
	const available = new Set(dwdOptions.dataTypes.map((item) => item.value.toUpperCase()));
	if (available.has(type)) return type;
	if (/^(TINYINT|SMALLINT|MEDIUMINT|INT|INTEGER)$/.test(type) && available.has('BIGINT')) return 'BIGINT';
	if (/^(NUMERIC|FLOAT|DOUBLE|REAL)$/.test(type) && available.has('DECIMAL')) return 'DECIMAL';
	return available.has('VARCHAR') ? 'VARCHAR' : dwdOptions.dataTypes[0]?.value || 'VARCHAR';
};
const deletedTargetColumn = (source: DwdSource) => `${(source.sourceTable.trim().split('.').pop() || source.alias).replace(/[^A-Za-z0-9_]/g, '_')}_dp_deleted`;
const generateFieldsFromSources = async () => {
	const activeSources = sources.value.filter((source) => source.status !== 'DISABLED');
	if (!activeSources.length) return useMessage().warning('请先配置并保存启用的来源表');
	if (activeSources.some((source) => !source.alias?.trim())) return useMessage().warning('来源表别名不能为空，请先完善来源配置');
	try {
		await useMessageBox().confirm('将从已配置且启用的来源表批量生成字段映射，保留现有映射；同名目标列按主表优先跳过。生成后请检查类型、角色和主键，再保存全部字段。');
	} catch {
		return;
	}
	try {
		saving.value = 'generate-fields';
		const orderedSources = [...activeSources].sort((a, b) => Number(b.isMain) - Number(a.isMain) || a.sortOrder - b.sortOrder);
		const results = await Promise.allSettled(orderedSources.map((source) => sourceColumnDetails(source)));
		const failed = results.flatMap((result, index) => result.status === 'rejected' || !result.value.length ? [orderedSources[index].sourceTable] : []);
		if (failed.length) throw new Error(`以下来源表的字段未能完整加载：${failed.join('、')}。请检查元数据后重试`);
		let renamed = 0;
		fields.value.forEach((field) => {
			if (field.targetColumn.trim().toLowerCase() !== '_dp_deleted') return;
			const source = orderedSources.find((item) => field.sourceExpr.trim().toLowerCase() === `${item.alias}._dp_deleted`.toLowerCase());
			if (!source) return;
			const targetColumn = deletedTargetColumn(source);
			if (fields.value.some((item) => item !== field && item.targetColumn.trim().toLowerCase() === targetColumn.toLowerCase())) return;
			field.targetColumn = targetColumn;
			renamed += 1;
		});
		const existing = new Set(fields.value.map((field) => field.targetColumn.trim().toLowerCase()));
		const additions: DwdField[] = [];
		let skipped = 0;
		results.forEach((result, index) => {
			if (result.status !== 'fulfilled') return;
			const source = orderedSources[index];
			result.value.forEach((column) => {
				const targetColumn = column.name.toLowerCase() === '_dp_deleted' ? deletedTargetColumn(source) : column.name;
				const key = targetColumn.toLowerCase();
				if (existing.has(key)) {
					skipped += 1;
					return;
				}
				existing.add(key);
				const targetType = inferredTargetType(column.type);
				const isPk = source.isMain && column.primaryKey;
				additions.push({
					targetColumn,
					targetType,
					targetComment: column.comment || undefined,
					sourceType: 'ODS_FIELD',
					sourceExpr: `${source.alias}.${column.name}`,
					sourceAlias: source.alias,
					role: isPk ? 'BUSINESS_KEY' : targetType === 'DATE' ? 'TIME' : 'ATTRIBUTE',
					seq: fields.value.length + additions.length + 1,
					isPk,
					isMasked: false,
				});
			});
		});
		fields.value.push(...additions);
		fieldPage.current = 1;
		useMessage().success(`已生成 ${additions.length} 个字段映射${renamed ? `，修正 ${renamed} 个保留列名` : ''}${skipped ? `，跳过 ${skipped} 个同名字段` : ''}；请检查后保存`);
	} catch (error) {
		useMessage().error(errorText(error, '批量生成字段映射失败'));
	} finally {
		saving.value = '';
	}
};
const openField = (index: number) => {
	fieldIndex.value = index;
	Object.assign(fieldDraft, fields.value[index]);
	fieldDialog.value = true;
};
const applyField = () => {
	if (fieldDraft.transformParams?.trim()) {
		try {
			JSON.parse(fieldDraft.transformParams);
		} catch {
			return useMessage().warning('转换参数必须是合法 JSON');
		}
	}
	const previous = fields.value[fieldIndex.value];
	const updated = { ...fieldDraft };
	fields.value.splice(fieldIndex.value, 1, updated);
	if (selectedFields.value.has(previous)) {
		const next = new Set(selectedFields.value);
		next.delete(previous);
		next.add(fields.value[fieldIndex.value]);
		selectedFields.value = next;
	}
	fieldDialog.value = false;
};
const saveFields = async () => {
	if (!loadedTabs.has('fields')) return useMessage().warning('字段映射尚未成功加载，请先重新进入此页');
	if (!(await confirmEmpty(fields.value, '字段映射'))) return;
	if (fields.value.some((item) => item.targetColumn.trim().toLowerCase() === '_dp_deleted'))
		return useMessage().warning('目标列 _dp_deleted 是系统保留列名，请改为来源表名_dp_deleted');
	if (fields.value.some((item) => !item.targetColumn.trim() || !item.targetType.trim() || !item.sourceExpr.trim() || !item.role))
		return useMessage().warning('请补齐目标列、目标类型、来源取值及角色');
	if (new Set(fields.value.map((item) => item.targetColumn.toLowerCase())).size !== fields.value.length)
		return useMessage().warning('目标列名不能重复');
	try {
		saving.value = 'fields';
		await saveDwdFields(
			modelId,
			fields.value.map((item, index) => ({ ...item, seq: item.seq || index + 1, sortOrder: index }))
		);
		await loadFields();
		invalidateSql();
		useMessage().success('字段映射已保存');
	} catch (error) {
		useMessage().error(errorText(error, '保存字段映射失败'));
	} finally {
		saving.value = '';
	}
};
const savePartition = async () => {
	const partitionColumn = partition.partitionColumn?.trim() || '';
	const incrementField = partition.incrementField?.trim() || '';
	if (partition.partitionGranularity === 'DAY' && !partitionColumn) return useMessage().warning('按日分区时请选择分区字段');
	if (partitionColumn && !partitionFieldOptions.value.some((item) => item.name === partitionColumn))
		return useMessage().warning('分区字段必须是字段映射中的目标列');
	if (incrementField && !/^[A-Za-z0-9_$]+$/.test(incrementField)) return useMessage().warning('增量字段只能填写 ODS 来源表的纯字段名');
	if (incrementField.toLowerCase() === '_etl_time' && !sources.value.some((source) => source.sourceType === 'ODS' && source.isMain))
		return useMessage().warning('_etl_time 仅可用于 ODS 主表');
	try {
		saving.value = 'partition';
		await saveDwdPartition(modelId, { ...partition, partitionColumn, incrementField });
		Object.assign(partition, { partitionColumn, incrementField });
		invalidateSql();
		useMessage().success('分区配置已保存');
	} catch (error) {
		useMessage().error(errorText(error, '保存分区配置失败'));
	} finally {
		saving.value = '';
	}
};
const freeze = async () => {
	try {
		saving.value = 'freeze';
		const revisionResponse = await fetchDwdDraftRevision(modelId);
		const revision = dwdRevision(revisionResponse.data);
		const validationResponse = await validateDwdModel(modelId, revision);
		const validation = validationResponse.data;
		if (!validation?.valid) {
			const issues = validation?.issues?.map((item) => `${item.path}: ${item.message}`).join('\n') || '草稿校验未通过';
			await useMessageBox().warning(issues);
			return;
		}
		await useMessageBox().confirm('校验通过。将基于服务端当前已保存的配置冻结版本；未保存的页面修改不会进入版本，确定继续吗？');
		await freezeDwdVersion(modelId, { expectedRevision: revision });
		await loadVersions();
		useMessage().success('版本已冻结；这不是任务发布');
	} catch (error) {
		if (error !== 'cancel' && error !== 'close') useMessage().error(errorText(error, '冻结版本失败'));
	} finally {
		saving.value = '';
	}
};
const showVersion = async (id: string) => {
	try {
		const response = await getDwdVersion(modelId, id);
		versionDetail.value = response.data
			? { ...response.data, versionId: dwdId(response.data.versionId), modelId: dwdId(response.data.modelId) }
			: undefined;
		versionDialog.value = true;
	} catch (error) {
		useMessage().error(errorText(error, '加载版本详情失败'));
	}
};

const loadSourceTables = async () => {
	const sequence = ++sourceTableRequestNo;
	++joinColumnsRequestNo;
	joinColumnsLoading.value = false;
	currentJoinColumns.value = [];
	joinPairs.value = [{ left: '', right: '' }];
	sourceDraft.joinCondition = '';
	sourceTableOptions.value = [];
	sourceDraft.sourceTableId = '';
	if (!sourceDatasourceId.value) return;
	const datasourceId = sourceDatasourceId.value;
	try {
		tableLoading.value = true;
		const rows = [] as Array<{ id: string; label: string; tableName: string; database?: string }>;
		let current = 1;
		let total = 0;
		do {
			const response = await fetchDwdOdsTablePage(datasourceId, current, 100);
			if (sequence !== sourceTableRequestNo || sourceDraft.sourceType !== 'ODS' || sourceDatasourceId.value !== datasourceId) return;
			const pageRows = Array.isArray(response.data?.records) ? response.data.records : [];
			rows.push(
				...pageRows.map((row) => ({
					id: dwdId(row.id),
					label: `${[row.schemaName || row.catalogName, row.tableName].filter(Boolean).join('.')}${row.schemaName && row.catalogName ? ` (${row.catalogName})` : ''}`,
					tableName: row.tableName,
					database: row.catalogName || row.schemaName || undefined,
				}))
			);
			total = Number(response.data?.total ?? rows.length);
			if (!pageRows.length) break;
			current += 1;
		} while (rows.length < total);
		sourceTableOptions.value = rows;
	} catch (error) {
		if (sequence === sourceTableRequestNo) useMessage().error(errorText(error, '加载 ODS 元数据表失败，请确认元数据查看权限'));
	} finally {
		if (sequence === sourceTableRequestNo) tableLoading.value = false;
	}
};
const sourceTypeChanged = async () => {
	sourceTableRequestNo += 1;
	++joinColumnsRequestNo;
	joinColumnsLoading.value = false;
	currentJoinColumns.value = [];
	joinPairs.value = [{ left: '', right: '' }];
	sourceDraft.joinCondition = '';
	tableLoading.value = false;
	sourceDatasourceId.value = '';
	sourceDraft.sourceTableId = '';
	sourceDraft.sourceTable = '';
	sourceTableOptions.value = [];
	if (sourceDraft.sourceType !== 'DIM') return;
	try {
		tableLoading.value = true;
		const response = await fetchDimensionModelPage({ current: 1, size: 100 });
		const data = response.data as { records?: Array<{ id: string | number; modelName: string; generatedTableName?: string; physicalName?: string }> };
		sourceTableOptions.value = (data?.records || []).map((item) => ({
			id: dwdId(item.id),
			label: item.physicalName || item.generatedTableName || item.modelName,
		}));
	} catch (error) {
		useMessage().error(errorText(error, '加载 DIM 模型失败'));
	} finally {
		tableLoading.value = false;
	}
};
const sourceTableChanged = (id: string) => {
	const item = sourceTableOptions.value.find((row) => row.id === id);
	sourceDraft.sourceTable = item?.tableName || item?.label || '';
	sourceDraft.sourceDatabase = item?.database || '';
	joinPairs.value = [{ left: '', right: '' }];
	sourceDraft.joinCondition = '';
	currentJoinColumns.value = [];
	if (!sourceDraft.isMain) loadJoinColumns();
};
const sourceColumnNames = async (source: DwdSource): Promise<string[]> => (await sourceColumnDetails(source)).map((column) => column.name);
const loadIncrementFieldOptions = async () => {
	const odsSources = sources.value.filter((source) => source.sourceType === 'ODS');
	incrementFieldOptions.value = [];
	if (!odsSources.length) return;
	try {
		incrementFieldsLoading.value = true;
		const results = await Promise.allSettled(odsSources.map((source) => sourceColumnNames(source)));
		const options = new Map<string, { name: string; tables: string[] }>();
		const mainSource = odsSources.find((source) => source.isMain);
		if (mainSource) options.set('_etl_time', { name: '_etl_time', tables: [`主表：${mainSource.sourceTable || mainSource.alias || 'ODS 来源表'}`] });
		results.forEach((result, index) => {
			if (result.status !== 'fulfilled') return;
			const table = odsSources[index].sourceTable || odsSources[index].alias || 'ODS 来源表';
			result.value.forEach((name) => {
				if (!/^[A-Za-z0-9_$]+$/.test(name) || name.toLowerCase() === '_etl_time') return;
				const key = name.toLowerCase();
				if (!options.has(key)) options.set(key, { name, tables: [] });
				const tables = options.get(key)!.tables;
				if (!tables.includes(table)) tables.push(table);
			});
		});
		incrementFieldOptions.value = [...options.values()];
	} finally {
		incrementFieldsLoading.value = false;
	}
};
const loadJoinColumns = async () => {
	const requestNo = ++joinColumnsRequestNo;
	mainJoinColumns.value = [];
	currentJoinColumns.value = [];
	if (sourceDraft.isMain) return;
	try {
		joinColumnsLoading.value = true;
		const [mainResult, currentResult] = await Promise.allSettled([
			mainSource.value ? sourceColumnNames(mainSource.value) : Promise.resolve([]),
			sourceColumnNames(sourceDraft),
		]);
		if (requestNo !== joinColumnsRequestNo) return;
		mainJoinColumns.value = mainResult.status === 'fulfilled' ? mainResult.value : [];
		currentJoinColumns.value = currentResult.status === 'fulfilled' ? currentResult.value : [];
		if (mainResult.status === 'rejected' || currentResult.status === 'rejected')
			useMessage().warning('部分字段元数据读取失败，可直接输入字段名或改用自定义条件');
	} finally {
		if (requestNo === joinColumnsRequestNo) joinColumnsLoading.value = false;
	}
};
const mainSourceChanged = () => {
	if (!sourceDraft.isMain) loadJoinColumns();
};
const openSource = async (item?: DwdSource, index = -1) => {
	sourceTableRequestNo += 1;
	++joinColumnsRequestNo;
	joinColumnsLoading.value = false;
	tableLoading.value = false;
	sourceIndex.value = index;
	Object.assign(sourceDraft, blankSource(), item || {}, { sourceTableId: optionalDwdId(item?.sourceTableId) });
	joinMode.value = item?.joinKeys?.trim() ? 'PAIRS' : item?.joinCondition?.trim() ? 'EXPRESSION' : 'PAIRS';
	joinPairs.value = [{ left: '', right: '' }];
	if (item?.joinKeys?.trim()) {
		try {
			const parsed = JSON.parse(item.joinKeys) as Array<{ left?: string; right?: string }>;
			if (!Array.isArray(parsed) || !parsed.length || parsed.some((pair) => typeof pair.left !== 'string' || typeof pair.right !== 'string'))
				throw new Error('invalid join keys');
			joinPairs.value = parsed.map((pair) => ({ left: joinColumnName(pair.left || ''), right: joinColumnName(pair.right || '') }));
		} catch {
			joinMode.value = 'EXPRESSION';
			useMessage().warning('已有的关联键 JSON 无法回填，请重新配置字段配对或自定义条件');
		}
	}
	mainJoinColumns.value = [];
	currentJoinColumns.value = [];
	sourceDatasourceId.value = '';
	sourceTableOptions.value = item ? [{ id: dwdId(item.sourceTableId), label: item.sourceTable, database: item.sourceDatabase }] : [];
	sourceDialog.value = true;
	if (sourceDraft.sourceType === 'DIM' && !item) await sourceTypeChanged();
	if (!sourceDraft.isMain) await loadJoinColumns();
};
const applySource = () => {
	if (!isDwdId(sourceDraft.sourceTableId) || !sourceDraft.sourceTable || !sourceDraft.alias.trim())
		return useMessage().warning('请选择带元数据 ID 的来源表并填写别名');
	if (!sourceDraft.isMain && joinMode.value === 'PAIRS') {
		if (!mainSource.value) return useMessage().warning('请先添加主表，再配置关联键');
		if (!joinPairs.value.length || joinPairs.value.some((pair) => !joinColumnName(pair.left.trim()) || !joinColumnName(pair.right.trim())))
			return useMessage().warning('请完整选择或输入每组关联字段');
		const keys = joinPairs.value.map((pair) => ({
			left: `${mainSource.value?.alias}.${joinColumnName(pair.left.trim())}`,
			right: `${sourceDraft.alias.trim()}.${joinColumnName(pair.right.trim())}`,
		}));
		if (new Set(keys.map((pair) => `${pair.left}=${pair.right}`)).size !== keys.length) return useMessage().warning('关联键不能重复');
		sourceDraft.joinKeys = JSON.stringify(keys);
		sourceDraft.joinCondition = '';
	} else if (!sourceDraft.isMain) {
		if (!sourceDraft.joinCondition?.trim()) return useMessage().warning('请输入自定义关联条件');
		sourceDraft.joinKeys = '';
	} else {
		sourceDraft.joinCondition = '';
		sourceDraft.joinKeys = '';
	}
	if (sourceDraft.isMain && sources.value.some((item, index) => item.isMain && index !== sourceIndex.value))
		return useMessage().warning('已有主表，请先修改原主表');
	const row = { ...sourceDraft, sortOrder: sourceIndex.value < 0 ? sources.value.length : sourceIndex.value };
	if (sourceIndex.value < 0) sources.value.push(row);
	else sources.value.splice(sourceIndex.value, 1, row);
	sourceDialog.value = false;
};
const loadSourceColumns = async () => {
	const results = await Promise.allSettled(
		sources.value.map(async (source) => (await sourceColumnNames(source)).map((column) => `${source.alias}.${column}`))
	);
	sourceColumns.value = [...new Set(results.flatMap((result) => (result.status === 'fulfilled' ? result.value : [])))];
};

onMounted(async () => {
	await refreshModel();
	const results = await Promise.allSettled([fetchDwdOptions(), fetchBusinessSystems(), fetchDatasourceReferences()]);
	try {
		if (results[0].status === 'fulfilled') Object.assign(dwdOptions, results[0].value.data || {});
		if (results[1].status === 'fulfilled')
			systems.value = Array.isArray(results[1].value.data)
				? results[1].value.data.map((item: DwdOption) => ({ value: dwdId(item.value), label: item.label }))
				: [];
		if (results[2].status === 'fulfilled')
			datasources.value = Array.isArray(results[2].value.data)
				? results[2].value.data
						.filter((item) => item.capabilities?.source !== false)
						.map((item) => ({ value: dwdId(item.id), label: item.displayName || item.name || item.dsName }))
				: [];
	} catch (error) {
		useMessage().error(errorText(error, '下拉选项中的 ID 无效'));
	}
	if (results.some((result) => result.status === 'rejected')) useMessage().warning('部分下拉选项加载失败，请刷新后再配置');
});
</script>

<style scoped>
.heading,
.tab-toolbar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 16px;
}
.heading {
	padding-bottom: 18px;
}
.heading h2 {
	margin: 10px 0 4px;
	font-size: 20px;
}
.heading p,
.tab-toolbar span,
.hint {
	color: var(--el-text-color-secondary);
}
.detail-tabs {
	margin-top: 16px;
}
.tab-toolbar {
	margin: 12px 0 16px;
}
.hint {
	font-size: 12px;
}
.partition-form {
	max-width: 900px;
	padding-top: 18px;
}
.partition-form .el-select {
	width: 100%;
}
.field-table .el-select,
.field-table .el-select-v2 {
	width: 100%;
}
.join-pair-editor {
	width: 100%;
}
.join-pair-row {
	display: flex;
	align-items: center;
	gap: 10px;
	margin-bottom: 10px;
}
.join-pair-row .el-select {
	flex: 1;
	min-width: 0;
}
.join-pair-help {
	margin-top: 4px;
	font-size: 12px;
	color: var(--el-text-color-secondary);
}
.sql-code,
.version-code {
	max-height: 600px;
	overflow: auto;
	padding: 18px;
	background: #f6f8fb;
	border: 1px solid var(--el-border-color-light);
	white-space: pre-wrap;
	word-break: break-word;
}
</style>
