<template>
	<div class="layout-padding">
		<el-card shadow="never">
			<div class="page-heading">
				<div>
					<h2>明细模型设计</h2>
					<p>定义 DWD 明细粒度、ODS/DIM 来源、字段映射和增量加工配置。</p>
				</div>
				<el-button v-auth="'dp_dwd_model_add'" type="primary" icon="Plus" @click="formDialogRef?.openDialog()">新建模型</el-button>
			</div>
			<el-form :inline="true" class="filters" @keyup.enter="search">
				<el-form-item label="模型检索"><el-input v-model="filters.keyword" clearable placeholder="名称或编号" /></el-form-item>
				<el-form-item label="业务系统"
					><el-select v-model="filters.businessSystemId" clearable filterable placeholder="全部" @change="systemChanged"
						><el-option v-for="item in systems" :key="item.value" :label="item.label" :value="item.value" /></el-select
				></el-form-item>
				<el-form-item label="业务域"
					><el-select v-model="filters.businessDomainId" clearable filterable :disabled="!filters.businessSystemId" placeholder="全部"
						><el-option v-for="item in domains" :key="item.value" :label="item.label" :value="item.value" /></el-select
				></el-form-item>
				<el-form-item label="状态"
					><el-select v-model="filters.status" clearable placeholder="全部"
						><el-option label="草稿" value="DRAFT" /><el-option label="启用" value="ENABLED" /><el-option label="停用" value="DISABLED" /></el-select
				></el-form-item>
				<el-form-item
					><el-button type="primary" icon="Search" @click="search">查询</el-button><el-button @click="reset">重置</el-button></el-form-item
				>
			</el-form>
			<div class="table-title">
				<strong>明细模型列表（{{ page.total }}）</strong><el-button icon="Refresh" :loading="loading" @click="load">刷新</el-button>
			</div>
			<el-table v-loading="loading" :data="models" border row-key="id" empty-text="暂无明细模型，请先新建">
				<el-table-column prop="modelCode" label="模型编号" min-width="135" show-overflow-tooltip />
				<el-table-column prop="modelName" label="模型名称" min-width="170" show-overflow-tooltip />
				<el-table-column prop="physicalName" label="物理表名" min-width="175" show-overflow-tooltip />
				<el-table-column label="业务系统" min-width="120"
					><template #default="{ row }">{{ row.businessSystemName || labelOf(systems, row.businessSystemId) }}</template></el-table-column
				>
				<el-table-column label="业务域" min-width="110"
					><template #default="{ row }">{{ row.businessDomainName || row.businessDomainId || '--' }}</template></el-table-column
				>
				<el-table-column prop="grain" label="明细粒度" min-width="160" show-overflow-tooltip />
				<el-table-column prop="owner" label="负责人" width="110" />
				<el-table-column label="状态" width="90"
					><template #default="{ row }"
						><el-tag :type="row.status === 'ENABLED' ? 'success' : 'info'">{{ row.status === 'ENABLED' ? '启用' : row.status === 'DRAFT' ? '草稿' : '停用' }}</el-tag></template
					></el-table-column
				>
				<el-table-column label="操作" width="210" fixed="right"
					><template #default="{ row }"
						><el-button v-auth="'dp_dwd_model_view'" link type="primary" @click="openDetail(row.id)">设计</el-button
						><el-button v-auth="'dp_dwd_model_edit'" link type="primary" @click="formDialogRef?.openDialog(row.id)">编辑</el-button
						><el-button v-auth="'dp_dwd_model_delete'" link type="danger" :loading="deletingId === row.id" @click="remove(row)"
							>删除</el-button
						></template
					></el-table-column
				>
			</el-table>
			<pagination
				v-if="page.total !== '0'"
				:current="page.current"
				:size="page.size"
				:total="page.total"
				@current-change="(value: number) => { page.current = value; load(); }"
				@size-change="(value: number) => { page.size = value; page.current = 1; load(); }"
			/>
		</el-card>
		<FormDialog ref="formDialogRef" :systems="systems" @saved="saved" />
	</div>
</template>

<script setup lang="ts" name="DwdModelList">
import { deleteDwdModel, fetchDwdModelPage, fetchDwdModelReferences } from '/@/api/dataPlatform/dwd';
import { fetchBusinessDomains, fetchBusinessSystems } from '/@/api/dataPlatform/layeredTask';
import { useMessage, useMessageBox } from '/@/hooks/message';
import { dwdId, optionalDwdId } from '/@/utils/dwdId';
import type { DwdModel, DwdModelQuery, DwdOption } from '/@/types/dataPlatform/dwd';
import FormDialog from './formDialog.vue';

const router = useRouter();
const formDialogRef = ref<InstanceType<typeof FormDialog>>();
const loading = ref(false);
const deletingId = ref('');
const models = ref<DwdModel[]>([]);
const systems = ref<DwdOption[]>([]);
const domains = ref<DwdOption[]>([]);
const page = reactive({ current: 1, size: 10, total: '0' });
const filters = reactive({ keyword: '', businessSystemId: '', businessDomainId: '', status: '' });
const labelOf = (items: DwdOption[], value?: string) => items.find((item) => item.value === value)?.label || value || '--';

const load = async () => {
	try {
		loading.value = true;
		const params: DwdModelQuery = { current: page.current, size: page.size };
		if (filters.keyword.trim()) params.keyword = filters.keyword.trim();
		if (filters.businessSystemId) params.businessSystemId = filters.businessSystemId;
		if (filters.businessDomainId) params.businessDomainId = filters.businessDomainId;
		if (filters.status) params.status = filters.status;
		const response = await fetchDwdModelPage(params);
		models.value = Array.isArray(response.data?.records)
			? response.data.records.map((item) => ({
					...item,
					id: dwdId(item.id),
					businessSystemId: optionalDwdId(item.businessSystemId),
					businessDomainId: optionalDwdId(item.businessDomainId),
					datasourceId: optionalDwdId(item.datasourceId),
			  }))
			: [];
		page.total = String(response.data?.total ?? 0);
	} catch (error) {
		models.value = [];
		useMessage().error((error as { msg?: string })?.msg || '加载明细模型失败');
	} finally {
		loading.value = false;
	}
};

const loadDomains = async (systemId: string) => {
	domains.value = [];
	if (!systemId) return;
	try {
		const response = await fetchBusinessDomains(systemId);
		domains.value = Array.isArray(response.data) ? response.data.map((item: DwdOption) => ({ value: dwdId(item.value), label: item.label })) : [];
	} catch (error) {
		useMessage().error((error as { msg?: string })?.msg || '加载业务域失败');
	}
};

const systemChanged = (id: string) => {
	filters.businessDomainId = '';
	loadDomains(id);
};
const search = () => {
	page.current = 1;
	load();
};
const reset = () => {
	Object.assign(filters, { keyword: '', businessSystemId: '', businessDomainId: '', status: '' });
	domains.value = [];
	search();
};
const openDetail = (id: string) => router.push(`/gen/warehouse/dwd/model/${id}`);
const saved = (id: string) => {
	load();
	if (id) openDetail(id);
};

const remove = async (row: DwdModel) => {
	try {
		const references = await fetchDwdModelReferences(row.id);
		if (references.data?.length) return useMessage().warning(`模型被 ${references.data.length} 个任务版本引用，请先处理引用`);
		await useMessageBox().confirm(`确定删除明细模型“${row.modelName}”吗？`);
		deletingId.value = row.id;
		await deleteDwdModel(row.id);
		useMessage().success('删除成功');
		load();
	} catch (error) {
		if (error !== 'cancel' && error !== 'close') useMessage().error((error as { msg?: string })?.msg || '删除失败');
	} finally {
		deletingId.value = '';
	}
};

onMounted(async () => {
	try {
		const response = await fetchBusinessSystems();
		systems.value = Array.isArray(response.data) ? response.data.map((item: DwdOption) => ({ value: dwdId(item.value), label: item.label })) : [];
	} catch {
		useMessage().warning('业务系统选项加载失败');
	}
	load();
});
</script>

<style scoped>
.page-heading,
.table-title {
	display: flex;
	align-items: center;
	justify-content: space-between;
}
.page-heading {
	padding-bottom: 18px;
	border-bottom: 1px solid var(--el-border-color-lighter);
}
.page-heading h2 {
	margin: 0 0 6px;
	font-size: 20px;
}
.page-heading p {
	margin: 0;
	color: var(--el-text-color-secondary);
}
.filters {
	padding-top: 20px;
}
.table-title {
	padding: 4px 0 14px;
}
</style>
