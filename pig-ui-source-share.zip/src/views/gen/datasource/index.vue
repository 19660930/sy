<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<el-row class="ml10" v-show="showSearch">
				<el-form :inline="true" :model="state.queryForm" @keyup.enter="getDataList" ref="queryRef">
					<el-form-item :label="$t('datasourceconf.dsName')" prop="dsName">
						<el-input :placeholder="$t('datasourceconf.inputdsNameTip')" v-model="state.queryForm.dsName" />
					</el-form-item>
					<el-form-item>
						<el-button @click="getDataList" icon="search" type="primary">
							{{ $t('common.queryBtn') }}
						</el-button>
						<el-button @click="resetQuery" icon="Refresh">{{ $t('common.resetBtn') }} </el-button>
					</el-form-item>
				</el-form>
			</el-row>
			<el-row>
				<div class="mb8" style="width: 100%">
					<el-button @click="formDialogRef.openDialog()" class="ml10" icon="folder-add" type="primary">
						{{ $t('common.addBtn') }}
					</el-button>
					<right-toolbar
						@queryTable="getDataList"
						class="ml10"
						style="float: right; margin-right: 20px"
						v-model:showSearch="showSearch"
					></right-toolbar>
				</div>
			</el-row>
			<el-table
				:data="state.dataList"
				style="width: 100%"
				v-loading="state.loading"
				border
				:cell-style="tableStyle.cellStyle"
				:header-cell-style="tableStyle.headerCellStyle"
			>
				<el-table-column :label="t('datasourceconf.index')" type="index" width="60" />
				<el-table-column :label="t('datasourceconf.name')" prop="name" show-overflow-tooltip />
				<el-table-column :label="t('datasourceconf.dsName')" prop="dsName" show-overflow-tooltip />
				<el-table-column :label="t('datasourceconf.dsType')" prop="dsType" show-overflow-tooltip />
				<el-table-column :label="t('datasourceconf.username')" prop="username" show-overflow-tooltip />
				<el-table-column :label="t('datasourceconf.createTime')" prop="createTime" show-overflow-tooltip />
				<el-table-column :label="$t('common.action')" width="390">
					<template #default="scope">
						<el-button icon="document" @click="downloadDoc(scope.row.name)" text type="primary">{{ $t('datasourceconf.docBtn') }} </el-button>

						<el-button icon="edit" @click="formDialogRef.openDialog(scope.row.id)" text type="primary">{{ $t('common.editBtn') }} </el-button>
						<el-button v-auth="'dp_datasource_manage'" icon="Setting" text type="primary" @click="tableConfigurationRef.openDialog(scope.row)">
							配置
						</el-button>
						<el-button
							v-auth="'dp_datasource_manage'"
							icon="Delete"
							text
							type="danger"
							:disabled="Boolean(deletingId)"
							:loading="deletingId === String(scope.row.id)"
							@click="handleDelete(scope.row)"
						>
							删除
						</el-button>
					</template>
				</el-table-column>
			</el-table>
			<pagination @current-change="currentChangeHandle" @size-change="sizeChangeHandle" v-bind="state.pagination" />
		</div>

		<!-- 编辑、新增  -->
		<form-dialog @refresh="getDataList()" ref="formDialogRef" />
		<table-configuration-dialog ref="tableConfigurationRef" />
	</div>
</template>

<script lang="ts" name="systemDatasourceConf" setup>
import { BasicTableProps, useTable } from '/@/hooks/table';
import { deleteDatasource, fetchList } from '/@/api/gen/datasource';
import { useMessage, useMessageBox } from '/@/hooks/message';
import { useI18n } from 'vue-i18n';
import { downBlobFile } from '/@/utils/other';

const FormDialog = defineAsyncComponent(() => import('./form.vue'));
const TableConfigurationDialog = defineAsyncComponent(() => import('./tableConfigurationDialog.vue'));
const { t } = useI18n();
const formDialogRef = ref();
const tableConfigurationRef = ref();
const queryRef = ref();
const showSearch = ref(true);
const deletingId = ref('');

const state: BasicTableProps = reactive<BasicTableProps>({
	queryForm: {},
	pageList: fetchList,
	descs: ['create_time'],
});

const { getDataList, currentChangeHandle, sizeChangeHandle, tableStyle } = useTable(state);

const downloadDoc = (dsName: string) => {
	downBlobFile('/data-platform/dsconf/doc', { dsName }, `${dsName}.html`);
};

const resetQuery = () => {
	queryRef.value.resetFields();
	getDataList();
};

const handleDelete = async (row: { id: string | number; name?: string; dsName?: string }) => {
	const datasourceName = row.name || row.dsName || String(row.id);
	try {
		await useMessageBox().confirm(`删除数据源“${datasourceName}”后将移除对应的动态数据源配置，确认继续吗？`);
	} catch {
		return;
	}

	try {
		deletingId.value = String(row.id);
		await deleteDatasource(row.id);
		useMessage().success('删除数据源成功');
		await getDataList();
	} catch (error: any) {
		useMessage().error(error?.msg || '删除数据源失败');
	} finally {
		deletingId.value = '';
	}
};
</script>
