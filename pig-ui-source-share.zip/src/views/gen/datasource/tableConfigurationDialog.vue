<template>
	<el-dialog v-model="visible" :title="`配置数据表 - ${datasourceName}`" width="960px" :close-on-click-modal="false" destroy-on-close>
		<el-alert
			title="已绑定任务的表不能取消配置；其他表可按需勾选或取消。保存时将提交该数据源的完整配置结果。"
			type="info"
			show-icon
			:closable="false"
			class="mb16"
		/>

		<div class="table-toolbar">
			<el-input v-model="query.keyword" clearable placeholder="输入表名搜索" style="width: 300px" @keyup.enter="handleSearch">
				<template #append>
					<el-button icon="Search" @click="handleSearch" />
				</template>
			</el-input>
			<span>已配置 {{ selectedTables.size }} 张表</span>
		</div>

		<el-table
			ref="tableRef"
			v-loading="loading"
			:data="physicalTables"
			:row-key="tableKey"
			border
			height="430"
			empty-text="暂无可配置的数据表"
			@selection-change="handleSelectionChange"
		>
			<el-table-column type="selection" width="52" :selectable="tableSelectable" reserve-selection />
			<el-table-column prop="tableName" label="表名" min-width="260" show-overflow-tooltip />
			<el-table-column prop="remarks" label="表注释" min-width="260" show-overflow-tooltip>
				<template #default="{ row }">{{ row.remarks || '--' }}</template>
			</el-table-column>
			<el-table-column label="配置状态" width="150">
				<template #default="{ row }">
					<el-tooltip v-if="row.disabledReason" :content="row.disabledReason" placement="top">
						<el-tag :type="statusTagType(row)">{{ statusText(row) }}</el-tag>
					</el-tooltip>
					<el-tag v-else :type="statusTagType(row)">{{ statusText(row) }}</el-tag>
				</template>
			</el-table-column>
		</el-table>

		<div class="pagination-wrapper">
			<el-pagination
				v-model:current-page="query.current"
				v-model:page-size="query.size"
				background
				layout="total, sizes, prev, pager, next, jumper"
				:page-sizes="[10, 20, 50, 100]"
				:total="total"
				@current-change="loadPhysicalTables"
				@size-change="handleSizeChange"
			/>
		</div>

		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button v-auth="'dp_datasource_manage'" type="primary" :loading="submitting" @click="handleSave">保存配置</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DatasourceTableConfigurationDialog">
import type { TableInstance } from 'element-plus';
import {
	fetchDatasourcePhysicalTablePage,
	fetchDatasourceTableConfigurations,
	saveDatasourceTableConfigurations,
} from '/@/api/dataPlatform/datasourceTableConfiguration';
import { useMessage } from '/@/hooks/message';
import type {
	DatasourcePhysicalTablePage,
	DatasourceTableConfiguration,
	DatasourceTableIdentifier,
} from '/@/types/dataPlatform/datasourceTableConfiguration';

const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const restoringSelection = ref(false);
const datasourceId = ref('');
const datasourceName = ref('');
const tableRef = ref<TableInstance>();
const physicalTables = ref<DatasourceTableConfiguration[]>([]);
const selectedTables = reactive(new Map<string, DatasourceTableIdentifier>());
const deselectedTables = reactive(new Set<string>());
const total = ref(0);
const query = reactive({ keyword: '', current: 1, size: 10 });

const tableKey = (table: DatasourceTableIdentifier) => JSON.stringify([table.catalog ?? null, table.schema ?? null, table.tableName]);
const toIdentifier = (table: DatasourceTableIdentifier): DatasourceTableIdentifier => ({
	catalog: table.catalog ?? null,
	schema: table.schema ?? null,
	tableName: table.tableName,
});

const compatibleSelectedKeys = (table: DatasourceTableIdentifier) =>
	[...selectedTables.entries()]
		.filter(([, selected]) => {
			if (selected.tableName !== table.tableName) return false;
			const catalogMatches = selected.catalog == null || table.catalog == null || selected.catalog === table.catalog;
			const schemaMatches = selected.schema == null || table.schema == null || selected.schema === table.schema;
			return catalogMatches && schemaMatches;
		})
		.map(([key]) => key);

const selectTable = (table: DatasourceTableIdentifier) => {
	const key = tableKey(table);
	compatibleSelectedKeys(table).forEach((compatibleKey) => selectedTables.delete(compatibleKey));
	selectedTables.set(key, toIdentifier(table));
	deselectedTables.delete(key);
};

const deselectTable = (table: DatasourceTableIdentifier) => {
	const key = tableKey(table);
	compatibleSelectedKeys(table).forEach((compatibleKey) => selectedTables.delete(compatibleKey));
	deselectedTables.add(key);
};

const normalizeList = (data: unknown): DatasourceTableConfiguration[] => {
	if (Array.isArray(data)) return data;
	const result = data as { records?: DatasourceTableConfiguration[]; tables?: DatasourceTableConfiguration[] } | null;
	return result?.records || result?.tables || [];
};

const tableSelectable = (row: DatasourceTableConfiguration) => !row.taskBound && (row.selectable ?? true);
const statusText = (row: DatasourceTableConfiguration) => (row.taskBound ? '已绑定任务' : row.configured ? '已配置' : '未配置');
const statusTagType = (row: DatasourceTableConfiguration) => (row.taskBound ? 'warning' : row.configured ? 'success' : 'info');

const restoreCurrentPageSelection = async () => {
	await nextTick();
	restoringSelection.value = true;
	tableRef.value?.clearSelection();
	physicalTables.value.forEach((row) => {
		if (selectedTables.has(tableKey(row))) tableRef.value?.toggleRowSelection(row, true);
	});
	await nextTick();
	restoringSelection.value = false;
};

const mergePhysicalTableStatus = () => {
	physicalTables.value.forEach((row) => {
		const key = tableKey(row);
		if (row.taskBound) {
			selectTable(row);
			return;
		}
		if (row.configured && !deselectedTables.has(key)) selectTable(row);
	});
};

const loadConfigurations = async () => {
	const response = await fetchDatasourceTableConfigurations(datasourceId.value);
	selectedTables.clear();
	deselectedTables.clear();
	normalizeList(response.data).forEach((table) => selectedTables.set(tableKey(table), toIdentifier(table)));
};

const loadPhysicalTables = async () => {
	if (!datasourceId.value) return;
	try {
		loading.value = true;
		const response = await fetchDatasourcePhysicalTablePage(datasourceId.value, {
			keyword: query.keyword.trim() || undefined,
			current: query.current,
			size: query.size,
		});
		const result = response.data as DatasourcePhysicalTablePage | DatasourceTableConfiguration[];
		physicalTables.value = normalizeList(result).map((item) => ({ ...item, taskId: item.taskId ? String(item.taskId) : null }));
		const totalCount = Array.isArray(result) ? result.length : Number(result?.total ?? 0);
		total.value = Number.isFinite(totalCount) ? totalCount : 0;
		mergePhysicalTableStatus();
		await restoreCurrentPageSelection();
	} catch (error: any) {
		physicalTables.value = [];
		total.value = 0;
		useMessage().error(error?.msg || '加载数据表失败');
	} finally {
		loading.value = false;
	}
};

const handleSelectionChange = (selection: DatasourceTableConfiguration[]) => {
	if (restoringSelection.value) return;
	const currentSelectionKeys = new Set(selection.map(tableKey));
	physicalTables.value.forEach((table) => {
		const key = tableKey(table);
		if (table.taskBound || currentSelectionKeys.has(key)) selectTable(table);
		else deselectTable(table);
	});
};

const handleSearch = () => {
	query.current = 1;
	loadPhysicalTables();
};

const handleSizeChange = () => {
	query.current = 1;
	loadPhysicalTables();
};

const openDialog = async (row: { id: string | number; name?: string; dsName?: string }) => {
	visible.value = true;
	datasourceId.value = String(row.id);
	datasourceName.value = row.name || row.dsName || String(row.id);
	Object.assign(query, { keyword: '', current: 1, size: 10 });
	selectedTables.clear();
	deselectedTables.clear();
	physicalTables.value = [];
	total.value = 0;
	try {
		loading.value = true;
		await loadConfigurations();
		await loadPhysicalTables();
	} catch (error: any) {
		useMessage().error(error?.msg || '加载数据源配置失败');
	} finally {
		loading.value = false;
	}
};

const handleSave = async () => {
	try {
		submitting.value = true;
		await saveDatasourceTableConfigurations(datasourceId.value, { tables: [...selectedTables.values()] });
		await loadConfigurations();
		await loadPhysicalTables();
		useMessage().success('数据表配置保存成功');
		visible.value = false;
	} catch (error: any) {
		useMessage().error(error?.msg || '保存数据表配置失败');
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDialog });
</script>

<style scoped>
.table-toolbar,
.pagination-wrapper {
	display: flex;
	align-items: center;
	justify-content: space-between;
}

.table-toolbar {
	margin-bottom: 12px;
	color: var(--el-text-color-secondary);
}

.pagination-wrapper {
	justify-content: flex-end;
	margin-top: 16px;
}
</style>
