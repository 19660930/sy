<template>
	<el-dialog :title="form.id ? $t('common.editBtn') : $t('common.addBtn')" v-model="visible" :close-on-click-modal="false" draggable>
		<el-form ref="dataFormRef" :model="form" :rules="dataRules" formDialogRef label-width="90px" v-loading="loading">
			<el-row :gutter="20">
				<el-col :span="24" class="mb20" v-if="parserPluginMessage">
					<el-alert :title="parserPluginMessage" type="warning" show-icon :closable="false" />
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item :label="t('datasourceconf.dsType')" prop="dsType">
						<el-select v-model="form.dsType" :placeholder="t('datasourceconf.inputdsTypeTip')" @change="onDsTypeChange">
							<el-option :key="item.value" :label="item.label" :value="item.value" v-for="item in datasourceTypeOptions"></el-option>
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item :label="t('datasourceconf.name')" prop="name">
						<el-input v-model="form.name" :placeholder="t('datasourceconf.inputnameTip')" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item :label="t('datasourceconf.username')" prop="username">
						<el-input v-model="form.username" :placeholder="t('datasourceconf.inputusernameTip')" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item :label="t('datasourceconf.password')" prop="password">
						<el-input v-model="form.password" :placeholder="t('datasourceconf.inputpasswordTip')" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20">
					<el-form-item :label="t('datasourceconf.confType')" prop="confType">
						<el-radio-group v-model="form.confType" :disabled="form.dsType === 'mongodb'">
							<el-radio :value="Number(item.value)" v-for="(item, index) in ds_config_type" border :key="index">
								{{ item.label }}
							</el-radio>
						</el-radio-group>
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20" v-if="form.confType === 0 && form.dsType === 'mssql'">
					<el-form-item :label="t('datasourceconf.instance')" prop="instance">
						<el-input v-model="form.instance" :placeholder="t('datasourceconf.inputinstanceTip')" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20" v-if="form.confType === 0">
					<el-form-item :label="t('datasourceconf.port')" prop="port">
						<el-input-number v-model="form.port" :placeholder="t('datasourceconf.inputportTip')" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20" v-if="form.confType === 0">
					<el-form-item :label="t('datasourceconf.host')" prop="host">
						<el-input v-model="form.host" :placeholder="t('datasourceconf.inputhostTip')" />
					</el-form-item>
				</el-col>
				<el-col :span="12" class="mb20" v-if="form.confType === 0">
					<el-form-item :label="t('datasourceconf.dsName')" prop="dsName">
						<el-input v-model="form.dsName" :placeholder="t('datasourceconf.inputdsNameTip')" />
					</el-form-item>
				</el-col>
				<el-col :span="24" class="mb20" v-if="form.confType === 1">
					<el-form-item :label="t('datasourceconf.url')" prop="url">
						<el-input v-model="form.url" type="textarea" :placeholder="t('datasourceconf.inputurlTip')" />
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>
		<template #footer>
			<div class="datasource-dialog-footer">
				<div class="datasource-dialog-footer__test">
					<el-button type="primary" plain :loading="testing" :disabled="loading || isParserPluginBlocked" @click="onTestConnection">
						{{ t('datasourceconf.testConnection') }}
					</el-button>
				</div>
				<div class="datasource-dialog-footer__actions">
					<el-button @click="visible = false">{{ $t('common.cancelButtonText') }}</el-button>
					<el-button type="primary" @click="onSubmit" :disabled="loading || testing || isParserPluginBlocked || !connectionTested">{{
						$t('common.confirmButtonText')
					}}</el-button>
				</div>
			</div>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="systemDatasourceConfDialog">
import { useMessage } from '/@/hooks/message';
import { getObj, addObj, putObj, getParserPlugins, testConnection, type DatasourceParserPlugins } from '/@/api/gen/datasource';
import { useI18n } from 'vue-i18n';
import { useDict } from '/@/hooks/dict';
import { rule, clearMaskedField } from '/@/utils/validate';

const emit = defineEmits(['refresh']);
const { t } = useI18n();
const dataFormRef = ref();
const visible = ref(false);
const loading = ref(false);
const testing = ref(false);
const connectionTested = ref(false);
const { ds_config_type, ds_type } = useDict('ds_config_type', 'ds_type');
const parserPlugins = ref<DatasourceParserPlugins>({});
const parserPluginsLoaded = ref(false);
const supportedDatasourceTypes = [
	{ label: 'MySQL', value: 'mysql' },
	{ label: 'Oracle', value: 'oracle' },
	{ label: 'SQL Server', value: 'mssql' },
	{ label: 'PostgreSQL', value: 'pg' },
	{ label: '达梦', value: 'dm' },
	{ label: '人大金仓', value: 'kingbase' },
	{ label: 'Doris', value: 'doris' },
	{ label: 'MongoDB', value: 'mongodb' },
];
const datasourceTypeOptions = computed(() =>
	supportedDatasourceTypes.map((item) => ({
		...item,
		label: ds_type.value?.find((option) => option.value === item.value)?.label || item.label,
	}))
);

// 提交表单数据
const form = reactive({
	id: '',
	name: '',
	url: '',
	username: '',
	password: undefined as string | undefined,
	createTime: '',
	updateTime: '',
	dsType: '',
	confType: 0,
	dsName: '',
	instance: '',
	port: 3306,
	host: '',
});

const defaultPorts: Record<string, number> = {
	mysql: 3306,
	oracle: 1521,
	mssql: 1433,
	pg: 5432,
	dm: 5236,
	kingbase: 54321,
	mongodb: 27017,
	doris: 9030,
};

const onDsTypeChange = (dsType: string) => {
	form.port = defaultPorts[dsType] ?? form.port;
	if (dsType === 'mongodb') form.confType = 1;
};

/**
 *
 * @param {校验数据源名} rule
 * @param {*} value
 * @param {*} callback
 */
const validateDsName = (_rule, value, callback) => {
	const re = /(?=.*[a-z])(?=.*_)/;
	if (value && !re.test(value)) {
		callback(new Error('数据源名称不合法, 组名_数据源名形式'));
	} else {
		callback();
	}
};

const validateConnectionUrl = (_rule, value, callback) => {
	if (!value) return callback(new Error('连接URL不能为空'));
	if (form.dsType === 'mongodb' && !/^mongodb(?:\+srv)?:\/\//i.test(value)) {
		return callback(new Error('MongoDB连接必须使用 mongodb:// 或 mongodb+srv:// URL'));
	}
	callback();
};

const validateUsername = (_rule, value, callback) => {
	if (form.dsType !== 'mongodb' && !value) return callback(new Error('用户名不能为空'));
	callback();
};

const validatePassword = (_rule, value, callback) => {
	if (form.dsType !== 'mongodb' && !value) return callback(new Error('密码不能为空'));
	callback();
};

// 定义校验规则
const dataRules = ref({
	name: [
		{ required: true, message: '别名不能为空', trigger: 'blur' },
		{ validator: validateDsName, trigger: 'blur' },
	],
	url: [
		{ validator: validateConnectionUrl, trigger: 'blur' },
		{
			min: 10,
			max: 500,
			message: 'URL长度必须介于 10 和 500 字符之间',
			trigger: 'blur',
		},
	],
	username: [
		{ validator: rule.overLength, trigger: 'blur' },
		{ validator: validateUsername, trigger: 'blur' },
	],
	password: [
		{ validator: rule.overLength, trigger: 'blur' },
		{ validator: validatePassword, trigger: 'blur' },
	],
	dsType: [{ required: true, message: '数据库类型不能为空', trigger: 'blur' }],
	confType: [{ required: true, message: '配置类型不能为空', trigger: 'blur' }],
	dsName: [
		{ validator: rule.overLength, trigger: 'blur' },
		{ required: true, message: '数据库名称不能为空', trigger: 'blur' },
	],
	instance: [
		{ validator: rule.overLength, trigger: 'blur' },
		{ required: true, message: '实例不能为空', trigger: 'blur' },
	],
	port: [{ required: true, message: '端口不能为空', trigger: 'blur' }],
	host: [
		{ validator: rule.overLength, trigger: 'blur' },
		{ required: true, message: '主机不能为空', trigger: 'blur' },
	],
});

const requiresParserPlugin = computed(() => form.dsType !== 'mongodb' && Object.prototype.hasOwnProperty.call(parserPlugins.value, form.dsType));
const unsupportedParserPlugin = computed(() => requiresParserPlugin.value && parserPluginsLoaded.value && parserPlugins.value[form.dsType] === false);
const parserPluginMessage = computed(() => {
	if (unsupportedParserPlugin.value) {
		return '后台未维护当前数据库解析插件，请添加对应 AnyLine 解析插件后再连接该数据库';
	}
	return '';
});
const isParserPluginBlocked = computed(() => unsupportedParserPlugin.value);

const loadParserPlugins = async () => {
	if (parserPluginsLoaded.value) {
		return;
	}
	try {
		const res = await getParserPlugins();
		parserPlugins.value = res.data || {};
		parserPluginsLoaded.value = true;
	} catch {
		parserPluginsLoaded.value = false;
	}
};

const validateParserPlugin = () => {
	if (isParserPluginBlocked.value) {
		useMessage().error(parserPluginMessage.value);
		return false;
	}
	return true;
};

// 打开弹窗
const openDialog = async (id: string) => {
	visible.value = true;
	form.id = '';
	testing.value = false;
	connectionTested.value = false;
	await loadParserPlugins();

	// 重置表单数据
	nextTick(() => {
		dataFormRef.value?.resetFields();
	});

	// 获取DatasourceConf信息
	if (id) {
		form.id = id;
		await getDatasourceConfData(id);
		// 修改密码时候，原密码打码
		form.password = '********';
		// 已保存的数据源已经通过后端保存校验，仅修改连接参数后才需要重新测试
		await nextTick();
		connectionTested.value = true;
	}
};

const getConnectionFields = () => {
	const fields = ['dsType', 'confType'];
	if (form.dsType !== 'mongodb') fields.push('username');
	const password = clearMaskedField(form.password);
	if (form.dsType !== 'mongodb' && (!form.id || password)) fields.push('password');
	if (form.confType === 0) {
		fields.push('host', 'port', 'dsName');
		if (form.dsType === 'mssql') fields.push('instance');
	} else {
		fields.push('url');
	}
	return fields;
};

const onTestConnection = async () => {
	if (!validateParserPlugin()) return;

	const valid = await dataFormRef.value
		.validateField(getConnectionFields())
		.then(() => true)
		.catch(() => false);
	if (!valid) return;

	const payload: Record<string, unknown> = { ...form };
	const password = clearMaskedField(form.password);
	if (form.dsType !== 'mongodb' && !form.id && !password) {
		useMessage().error(t('datasourceconf.inputPasswordBeforeTest'));
		return;
	}
	if (password) {
		payload.password = password;
	} else {
		delete payload.password;
	}

	try {
		testing.value = true;
		connectionTested.value = false;
		const res = await testConnection(payload);
		connectionTested.value = res.data === 1;
		connectionTested.value ? useMessage().success(t('datasourceconf.connectionSuccess')) : useMessage().error(t('datasourceconf.connectionFailed'));
	} catch (err: any) {
		connectionTested.value = false;
		useMessage().error(err?.msg || t('datasourceconf.connectionTestError'));
	} finally {
		testing.value = false;
	}
};

watch(
	() => [form.dsType, form.confType, form.host, form.port, form.url, form.instance, form.dsName, form.username, form.password],
	() => {
		connectionTested.value = false;
	}
);

// 提交
const onSubmit = async () => {
	if (!validateParserPlugin()) return false;

	const valid = await dataFormRef.value.validate().catch(() => {});
	if (!valid) return false;

	// 清除脱敏字段（编辑时不提交星号占位符）
	const payload = { ...form };
	payload.password = clearMaskedField(payload.password);

	try {
		loading.value = true;
		form.id ? await putObj(payload) : await addObj(payload);
		useMessage().success(t(form.id ? 'common.editSuccessText' : 'common.addSuccessText'));
		visible.value = false;
		emit('refresh');
	} catch (err: any) {
		useMessage().error(err.msg);
	} finally {
		loading.value = false;
	}
};

// 初始化表单数据
const getDatasourceConfData = (id: string) => {
	// 获取数据
	return getObj(id).then((res: any) => {
		Object.assign(form, res.data);
		if (form.dsType === 'mongodb') form.confType = 1;
	});
};

// 暴露变量
defineExpose({
	openDialog,
});
</script>

<style scoped>
.datasource-dialog-footer {
	display: flex;
	flex-direction: column;
	gap: 16px;
}

.datasource-dialog-footer__test {
	display: flex;
	justify-content: center;
}

.datasource-dialog-footer__actions {
	display: flex;
	justify-content: flex-end;
}
</style>
