<template>
	<div class="data-platform-welcome" />
</template>

<style scoped>
.data-platform-welcome {
	min-height: 100%;
}
</style>
