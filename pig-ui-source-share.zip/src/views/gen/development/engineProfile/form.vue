<template>
	<el-dialog v-model="visible" :title="profileId ? '修改引擎档案' : '新增引擎档案'" width="760px" :close-on-click-modal="false" draggable>
		<el-form ref="dataFormRef" v-loading="loading" :model="form" :rules="dataRules" label-width="120px">
			<el-row :gutter="20">
				<el-col :span="12">
					<el-form-item label="档案名称" prop="profileName">
						<el-input v-model="form.profileName" maxlength="64" show-word-limit placeholder="请输入档案名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="引擎类型" prop="engineType">
						<el-select v-model="form.engineType" :disabled="Boolean(profileId)" placeholder="请选择引擎类型" style="width: 100%">
							<el-option label="DolphinScheduler" value="DOLPHIN_SCHEDULER" />
							<el-option label="SeaTunnel" value="SEATUNNEL" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="启用状态" prop="enabled">
						<el-switch v-model="form.enabled" inline-prompt active-text="启用" inactive-text="停用" />
					</el-form-item>
				</el-col>

				<template v-if="form.engineType === 'DOLPHIN_SCHEDULER'">
					<el-col :span="24">
						<el-divider content-position="left">DolphinScheduler 配置</el-divider>
					</el-col>
					<el-col :span="24">
						<el-form-item label="服务地址" prop="baseUrl">
							<el-input v-model="form.baseUrl" placeholder="例如：http://dolphinscheduler-api:12345/dolphinscheduler" />
						</el-form-item>
					</el-col>
					<el-col :span="24">
						<el-form-item label="API Token" prop="apiToken">
							<el-input
								v-model="form.apiToken"
								type="password"
								show-password
								:placeholder="profileId && tokenConfigured ? '留空则保留原 Token' : '请输入 DolphinScheduler API Token'"
							/>
						</el-form-item>
					</el-col>
				</template>

				<template v-if="form.engineType === 'SEATUNNEL'">
					<el-col :span="24">
						<el-divider content-position="left">SeaTunnel 配置</el-divider>
					</el-col>
					<el-col :span="12">
						<el-form-item label="运行模式" prop="runtimeMode">
							<el-select v-model="form.runtimeMode" style="width: 100%">
								<el-option label="本地模式（LOCAL）" value="LOCAL" />
								<el-option label="集群模式（CLUSTER）" value="CLUSTER" />
								<el-option label="REST 模式" value="REST" />
							</el-select>
						</el-form-item>
					</el-col>
					<el-col :span="12" v-if="form.runtimeMode !== 'REST'">
						<el-form-item label="安装目录" prop="installHome">
							<el-input v-model="form.installHome" placeholder="例如：/opt/seatunnel" />
						</el-form-item>
					</el-col>
					<el-col :span="24" v-if="form.runtimeMode === 'REST'">
						<el-form-item label="REST服务地址" prop="baseUrl">
							<el-input v-model="form.baseUrl" />
						</el-form-item>
					</el-col>
					<el-col :span="24" v-if="form.runtimeMode === 'REST'">
						<el-form-item label="API Token" prop="apiToken">
							<el-input
								v-model="form.apiToken"
								type="password"
								show-password
								:placeholder="profileId && tokenConfigured ? '留空则保留原 Token' : '未启用 Token 时可留空'"
							/>
						</el-form-item>
					</el-col>
					<el-col :span="24" v-if="form.runtimeMode !== 'REST'">
						<el-form-item label="配置目录" prop="configDir">
							<el-input v-model="form.configDir" placeholder="例如：/data/seatunnel/configs" />
						</el-form-item>
					</el-col>
					<el-col :span="24" v-if="form.runtimeMode !== 'REST'">
						<el-form-item label="命令模板" prop="commandTemplate">
							<el-input v-model="form.commandTemplate" placeholder="${installHome}/bin/seatunnel.sh --config ${configFile}" />
						</el-form-item>
					</el-col>
				</template>

				<el-col v-if="form.engineType" :span="24">
					<el-form-item label="扩展配置" prop="extraConfigJson">
						<el-input
							v-model="form.extraConfigJson"
							type="textarea"
							:rows="5"
							placeholder='请输入 JSON 对象，例如：{"projectName":"data-platform"}'
						/>
						<div class="form-tip">禁止填写 password、token、secret 等敏感信息。</div>
					</el-form-item>
				</el-col>
			</el-row>
		</el-form>

		<template #footer>
			<el-button @click="visible = false">{{ $t('common.cancelButtonText') }}</el-button>
			<el-button type="primary" :loading="loading" @click="onSubmit">{{ $t('common.confirmButtonText') }}</el-button>
		</template>
	</el-dialog>
</template>

<script setup lang="ts" name="DataPlatformEngineProfileDialog">
import type { FormInstance, FormRules } from 'element-plus';
import { addEngineProfile, getEngineProfile, updateEngineProfile } from '/@/api/dataPlatform/engineProfile';
import { useMessage } from '/@/hooks/message';
import type { EngineProfile, EngineProfileSaveRequest } from '/@/types/dataPlatform/engineProfile';

const emit = defineEmits<{ refresh: [] }>();
const dataFormRef = ref<FormInstance>();
const visible = ref(false);
const loading = ref(false);
const profileId = ref('');
const tokenConfigured = ref(false);

const createDefaultForm = (): EngineProfileSaveRequest => ({
	profileName: '',
	engineType: '',
	enabled: true,
	baseUrl: '',
	apiToken: '',
	runtimeMode: 'LOCAL',
	installHome: '',
	configDir: '',
	commandTemplate: '${installHome}/bin/seatunnel.sh --config ${configFile}',
	extraConfigJson: '{}',
});

const form = reactive<EngineProfileSaveRequest>(createDefaultForm());

const validateBaseUrl = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	const requiresBaseUrl = form.engineType === 'DOLPHIN_SCHEDULER' || (form.engineType === 'SEATUNNEL' && form.runtimeMode === 'REST');
	if (!requiresBaseUrl) return callback();
	if (!value)
		return callback(new Error(form.engineType === 'DOLPHIN_SCHEDULER' ? '请输入 DolphinScheduler 服务地址' : '请输入 SeaTunnel REST 服务地址'));
	try {
		const url = new URL(value);
		if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
			return callback(new Error('请输入不含账号、查询参数和锚点的 HTTP/HTTPS 地址'));
		}
		callback();
	} catch {
		callback(new Error('服务地址格式不正确'));
	}
};

const validateApiToken = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (form.engineType === 'DOLPHIN_SCHEDULER' && !value && (!profileId.value || !tokenConfigured.value)) {
		return callback(new Error('请输入 DolphinScheduler API Token'));
	}
	callback();
};

const validateCommandTemplate = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (form.engineType !== 'SEATUNNEL' || !value) return callback();
	if (!value.includes('${installHome}') || !value.includes('${configFile}')) {
		return callback(new Error('命令模板必须包含 ${installHome} 和 ${configFile}'));
	}
	callback();
};

const validateExtraConfig = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (!value) return callback();
	try {
		const config = JSON.parse(value);
		if (!config || Array.isArray(config) || typeof config !== 'object') return callback(new Error('扩展配置必须是 JSON 对象'));
		if (Object.keys(config).some((key) => /(password|token|secret)/i.test(key))) {
			return callback(new Error('扩展配置中不能包含 password、token 或 secret 等敏感字段'));
		}
		callback();
	} catch {
		callback(new Error('扩展配置不是合法的 JSON'));
	}
};

const dataRules: FormRules = {
	profileName: [{ required: true, message: '请输入档案名称', trigger: 'blur' }],
	engineType: [{ required: true, message: '请选择引擎类型', trigger: 'change' }],
	baseUrl: [{ validator: validateBaseUrl, trigger: 'blur' }],
	apiToken: [{ validator: validateApiToken, trigger: 'blur' }],
	runtimeMode: [{ required: true, message: '请选择运行模式', trigger: 'change' }],
	installHome: [{ required: true, message: '请输入 SeaTunnel 安装目录', trigger: 'blur' }],
	configDir: [{ required: true, message: '请输入配置目录', trigger: 'blur' }],
	commandTemplate: [
		{ required: true, message: '请输入命令模板', trigger: 'blur' },
		{ validator: validateCommandTemplate, trigger: 'blur' },
	],
	extraConfigJson: [{ validator: validateExtraConfig, trigger: 'blur' }],
};

const buildPayload = (): EngineProfileSaveRequest => {
	const payload: EngineProfileSaveRequest = {
		profileName: form.profileName.trim(),
		engineType: form.engineType,
		enabled: form.enabled,
		extraConfigJson: form.extraConfigJson?.trim() || '{}',
	};
	if (form.engineType === 'DOLPHIN_SCHEDULER') {
		payload.baseUrl = form.baseUrl?.trim();
		if (form.apiToken?.trim()) payload.apiToken = form.apiToken.trim();
	} else {
		payload.runtimeMode = form.runtimeMode;
		if (form.runtimeMode === 'REST') {
			payload.baseUrl = form.baseUrl?.trim();
			if (form.apiToken?.trim()) payload.apiToken = form.apiToken.trim();
			payload.installHome = null;
			payload.configDir = null;
			payload.commandTemplate = null;
		} else {
			payload.baseUrl = null;
			payload.apiToken = null;
			payload.installHome = form.installHome?.trim();
			payload.configDir = form.configDir?.trim();
			payload.commandTemplate = form.commandTemplate?.trim();
		}
	}
	return payload;
};

const openDialog = async (id?: string) => {
	visible.value = true;
	profileId.value = id || '';
	tokenConfigured.value = false;
	Object.assign(form, createDefaultForm());
	await nextTick();
	dataFormRef.value?.clearValidate();
	if (!id) return;

	try {
		loading.value = true;
		const res = await getEngineProfile(id);
		const profile = res.data as EngineProfile;
		tokenConfigured.value = Boolean(profile.tokenConfigured);
		Object.assign(form, {
			profileName: profile.profileName,
			engineType: profile.engineType,
			enabled: profile.enabled,
			baseUrl: profile.baseUrl || '',
			apiToken: '',
			runtimeMode: profile.runtimeMode || 'LOCAL',
			installHome: profile.installHome || '',
			configDir: profile.configDir || '',
			commandTemplate: profile.commandTemplate || '${installHome}/bin/seatunnel.sh --config ${configFile}',
			extraConfigJson: profile.extraConfigJson || '{}',
		});
	} catch (error: any) {
		visible.value = false;
		useMessage().error(error?.msg || '加载引擎档案失败');
	} finally {
		loading.value = false;
	}
};

const onSubmit = async () => {
	const valid = await dataFormRef.value?.validate().catch(() => false);
	if (!valid) return;
	try {
		loading.value = true;
		const payload = buildPayload();
		profileId.value ? await updateEngineProfile(profileId.value, payload) : await addEngineProfile(payload);
		useMessage().success(profileId.value ? '修改成功' : '新增成功');
		visible.value = false;
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || '保存引擎档案失败');
	} finally {
		loading.value = false;
	}
};

defineExpose({ openDialog });
</script>

<style scoped>
.form-tip {
	color: var(--el-text-color-secondary);
	font-size: 12px;
	line-height: 20px;
}
</style>
