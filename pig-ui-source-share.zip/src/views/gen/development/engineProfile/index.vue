<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view">
			<el-row v-show="showSearch" class="ml10">
				<el-form ref="queryRef" :inline="true" :model="queryForm" @keyup.enter="loadProfiles">
					<el-form-item label="引擎类型" prop="engineType">
						<el-select v-model="queryForm.engineType" clearable placeholder="全部类型" style="width: 200px">
							<el-option label="DolphinScheduler" value="DOLPHIN_SCHEDULER" />
							<el-option label="SeaTunnel" value="SEATUNNEL" />
						</el-select>
					</el-form-item>
					<el-form-item label="启用状态" prop="enabled">
						<el-select v-model="queryForm.enabled" clearable placeholder="全部状态" style="width: 160px">
							<el-option label="已启用" :value="true" />
							<el-option label="已停用" :value="false" />
						</el-select>
					</el-form-item>
					<el-form-item>
						<el-button type="primary" icon="search" @click="loadProfiles">查询</el-button>
						<el-button icon="Refresh" @click="resetQuery">重置</el-button>
					</el-form-item>
				</el-form>
			</el-row>

			<el-row>
				<div class="mb8" style="width: 100%">
					<el-button v-auth="'dp_engine_manage'" class="ml10" type="primary" icon="folder-add" @click="formDialogRef.openDialog()"> 新增 </el-button>
					<right-toolbar v-model:showSearch="showSearch" class="ml10" style="float: right; margin-right: 20px" @queryTable="loadProfiles" />
				</div>
			</el-row>

			<el-table
				v-loading="loading"
				:data="profiles"
				border
				empty-text="暂无引擎档案，请先新增 DolphinScheduler 和 SeaTunnel 配置"
				style="width: 100%"
			>
				<el-table-column type="index" label="#" width="60" align="center" />
				<el-table-column prop="profileName" label="档案名称" min-width="180" show-overflow-tooltip />
				<el-table-column label="引擎类型" min-width="180">
					<template #default="{ row }">
						<el-tag :type="row.engineType === 'DOLPHIN_SCHEDULER' ? 'primary' : 'success'">
							{{ engineTypeText(row.engineType) }}
						</el-tag>
					</template>
				</el-table-column>
				<el-table-column label="连接/运行配置" min-width="300" show-overflow-tooltip>
					<template #default="{ row }">
						<span v-if="row.engineType === 'DOLPHIN_SCHEDULER'">{{ row.baseUrl || '--' }}</span>
						<span v-else-if="row.runtimeMode === 'REST'">{{ runtimeModeText(row.runtimeMode) }} · {{ row.baseUrl || '--' }}</span>
						<span v-else>{{ runtimeModeText(row.runtimeMode) }} · {{ row.installHome || '--' }}</span>
					</template>
				</el-table-column>
				<el-table-column label="Token" width="100" align="center">
					<template #default="{ row }">
						<el-tag
							v-if="row.engineType === 'DOLPHIN_SCHEDULER' || row.runtimeMode === 'REST'"
							:type="row.tokenConfigured ? 'success' : row.engineType === 'DOLPHIN_SCHEDULER' ? 'danger' : 'info'"
						>
							{{ row.tokenConfigured ? '已配置' : '未配置' }}
						</el-tag>
						<span v-else>--</span>
					</template>
				</el-table-column>
				<el-table-column label="状态" width="100" align="center">
					<template #default="{ row }">
						<el-tag :type="row.enabled ? 'success' : 'info'">{{ row.enabled ? '已启用' : '已停用' }}</el-tag>
					</template>
				</el-table-column>
				<el-table-column prop="updateTime" label="更新时间" width="180" show-overflow-tooltip />
				<el-table-column label="操作" width="230" fixed="right">
					<template #default="{ row }">
						<el-button v-auth="'dp_engine_manage'" text type="primary" icon="Connection" :loading="testingId === row.id" @click="handleTest(row)">
							测试
						</el-button>
						<el-button v-auth="'dp_engine_manage'" text type="primary" icon="Edit" @click="formDialogRef.openDialog(row.id)">修改</el-button>
						<el-button v-auth="'dp_engine_manage'" text type="primary" icon="Delete" @click="handleDelete(row)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>

		<form-dialog ref="formDialogRef" @refresh="loadProfiles" />
	</div>
</template>

<script setup lang="ts" name="DataPlatformEngineProfile">
import type { FormInstance } from 'element-plus';
import { deleteEngineProfile, fetchEngineProfiles, testEngineProfile } from '/@/api/dataPlatform/engineProfile';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type {
	EngineProfile,
	EngineProfileQuery,
	EngineProfileTestResult,
	EngineType,
	SeaTunnelRuntimeMode,
} from '/@/types/dataPlatform/engineProfile';

const FormDialog = defineAsyncComponent(() => import('./form.vue'));
const formDialogRef = ref();
const queryRef = ref<FormInstance>();
const showSearch = ref(true);
const loading = ref(false);
const testingId = ref('');
const profiles = ref<EngineProfile[]>([]);
const queryForm = reactive<{ engineType: EngineType | ''; enabled: boolean | '' }>({
	engineType: '',
	enabled: '',
});

const engineTypeText = (engineType: EngineType) => (engineType === 'DOLPHIN_SCHEDULER' ? 'DolphinScheduler' : 'SeaTunnel');
const runtimeModeText = (runtimeMode?: SeaTunnelRuntimeMode) =>
	({ LOCAL: '本地模式', CLUSTER: '集群模式', REST: 'REST 模式' }[runtimeMode || 'LOCAL']);

const loadProfiles = async () => {
	const query: EngineProfileQuery = {};
	if (queryForm.engineType) query.engineType = queryForm.engineType;
	if (queryForm.enabled !== '') query.enabled = queryForm.enabled;
	try {
		loading.value = true;
		const res = await fetchEngineProfiles(query);
		profiles.value = Array.isArray(res.data) ? res.data : res.data?.records || [];
	} catch (error: any) {
		profiles.value = [];
		useMessage().error(error?.msg || '查询引擎档案失败');
	} finally {
		loading.value = false;
	}
};

const resetQuery = () => {
	queryRef.value?.resetFields();
	loadProfiles();
};

const handleTest = async (profile: EngineProfile) => {
	try {
		testingId.value = profile.id;
		const res = await testEngineProfile(profile.id);
		const result = res.data as EngineProfileTestResult;
		result.success ? useMessage().success(result.message || '配置测试成功') : useMessage().error(result.message || '配置测试失败');
	} catch (error: any) {
		useMessage().error(error?.msg || '配置测试失败');
	} finally {
		testingId.value = '';
	}
};

const handleDelete = async (profile: EngineProfile) => {
	try {
		await useMessageBox().confirm(`确认删除引擎档案“${profile.profileName}”吗？`);
	} catch {
		return;
	}
	try {
		await deleteEngineProfile(profile.id);
		useMessage().success('删除成功');
		loadProfiles();
	} catch (error: any) {
		useMessage().error(error?.msg || '删除失败，该档案可能已被任务版本引用');
	}
};

onMounted(loadProfiles);
</script>
