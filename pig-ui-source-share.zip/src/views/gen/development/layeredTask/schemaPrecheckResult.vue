<template>
	<div class="schema-precheck-result">
		<el-alert :title="result.summary" :type="alertType" :closable="false" show-icon />

		<div v-if="result.warnings?.length" class="result-section">
			<div class="section-title">风险提示</div>
			<ul>
				<li v-for="(warning, index) in result.warnings" :key="index">{{ warning }}</li>
			</ul>
		</div>

		<div v-if="result.blockingIssues?.length" class="result-section blocking-section">
			<div class="section-title">阻断问题</div>
			<div v-for="(issue, index) in result.blockingIssues" :key="`${issue.code || 'issue'}-${index}`" class="blocking-item">
				<div>{{ issue.columnName ? `${issue.columnName}：` : '' }}{{ issue.message }}</div>
				<div v-if="issue.suggestedAction" class="suggestion">建议：{{ issue.suggestedAction }}</div>
			</div>
		</div>

		<el-collapse v-if="result.plannedDdl?.length" class="ddl-collapse">
			<el-collapse-item title="查看计划执行的 DDL" name="ddl">
				<pre class="ddl-content">{{ result.plannedDdl.join('\n\n') }}</pre>
			</el-collapse-item>
		</el-collapse>
	</div>
</template>

<script setup lang="ts" name="SchemaPrecheckResult">
import type { SchemaPrecheckResult } from '/@/types/dataPlatform/layeredTask';

const props = defineProps<{ result: SchemaPrecheckResult }>();
const alertType = computed(() => {
	if (props.result.action === 'BLOCK' || props.result.canPublish === false) return 'error';
	return ['APPEND', 'RECREATE'].includes(props.result.action) ? 'warning' : 'success';
});
</script>

<style scoped>
.schema-precheck-result {
	display: flex;
	flex-direction: column;
	gap: 12px;
}

.result-section {
	padding: 12px 14px;
	color: var(--el-text-color-regular);
	background: var(--el-fill-color-light);
	border-radius: 4px;
}

.result-section ul {
	padding-left: 20px;
	margin: 8px 0 0;
}

.section-title {
	font-weight: 600;
}

.blocking-section {
	color: var(--el-color-danger);
	background: var(--el-color-danger-light-9);
}

.blocking-item + .blocking-item {
	margin-top: 10px;
}

.suggestion {
	margin-top: 4px;
	color: var(--el-text-color-secondary);
}

.ddl-collapse {
	border-top: 0;
}

.ddl-content {
	padding: 12px;
	margin: 0;
	overflow: auto;
	color: #d8dee9;
	font-family: Consolas, Monaco, monospace;
	line-height: 1.6;
	white-space: pre-wrap;
	background: #1f2329;
	border-radius: 4px;
}
</style>
