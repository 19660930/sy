<template>
	<el-drawer v-model="visible" :title="drawerTitle" size="min(1180px, 96vw)" :close-on-click-modal="false" class="task-form-drawer">
		<el-form ref="formRef" v-loading="loading" :model="form" :rules="rules" label-width="130px" class="task-form">
			<el-alert :title="formTip" type="info" :closable="false" show-icon class="mb20" />

			<el-divider content-position="left">基本信息</el-divider>
			<el-row :gutter="24">
				<el-col :span="12">
					<el-form-item label="数仓层级" prop="warehouseLayer">
						<el-select v-model="form.warehouseLayer" :disabled="Boolean(editingTaskId)" style="width: 100%" @change="handleWarehouseLayerChange">
							<el-option label="ODS 操作数据层" value="ODS" />
							<el-option label="DIM 维度层" value="DIM" :disabled="!editingTaskId" />
							<el-option label="DWD 明细层" value="DWD" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="任务类型" prop="taskType">
						<el-select v-model="form.taskType" disabled style="width: 100%">
							<el-option label="源表同步" value="SOURCE_SYNC" />
							<el-option label="维度物化" value="DIM_BUILD" />
							<el-option label="明细加工" value="DWD_PROCESS" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="任务名称" prop="taskName">
						<el-input v-model="form.taskName" maxlength="128" show-word-limit placeholder="请输入任务名称" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="任务编号" prop="taskCode">
						<el-input v-model="form.taskCode" :disabled="Boolean(editingTaskId)" maxlength="64" placeholder="可不填，由系统自动生成" />
					</el-form-item>
				</el-col>
				<el-col v-if="!isDwdProcess" :span="12">
					<el-form-item label="业务系统">
						<el-select
							v-model="form.businessSystemId"
							clearable
							filterable
							placeholder="请选择业务系统"
							style="width: 100%"
							@change="handleBusinessSystemChange"
						>
							<el-option v-for="item in businessSystems" :key="item.id" :label="item.name" :value="item.id" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col v-if="!isDwdProcess" :span="12">
					<el-form-item label="业务域">
						<el-select
							v-model="form.businessDomainId"
							clearable
							filterable
							:loading="domainLoading"
							:disabled="!form.businessSystemId"
							:placeholder="form.businessSystemId ? '请选择业务域' : '请先选择业务系统'"
							style="width: 100%"
						>
							<el-option v-for="item in businessDomains" :key="item.id" :label="item.name" :value="item.id" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="任务描述">
						<el-input v-model="form.description" type="textarea" :rows="2" maxlength="500" show-word-limit placeholder="请输入任务说明" />
					</el-form-item>
				</el-col>
			</el-row>

			<el-divider content-position="left">{{ isDimBuild ? '维度输入与输出' : isDwdProcess ? '冻结模型版本' : '数据源与表' }}</el-divider>
			<el-row v-if="isDimBuild" :gutter="24">
				<el-col :span="12">
					<el-form-item label="数据来源">
						<el-input model-value="平台维度值" readonly />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="关联模型" prop="relatedModelId">
						<el-input :model-value="dimBinding.relatedModelName || form.relatedModelId || '--'" readonly />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="ENTITY表">
						<el-input :model-value="dimBinding.entityTableName || '--'" readonly />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="目标数据源" prop="targetDatasourceId">
						<el-input :model-value="dimBinding.targetDatasourceName || form.targetDatasourceId || '--'" readonly />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="数据库">
						<el-input :model-value="dimBinding.databaseName || '--'" readonly />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="物理表" prop="targetTable">
						<el-input :model-value="dimBinding.physicalName || form.targetTable || '--'" readonly />
					</el-form-item>
				</el-col>
			</el-row>
			<el-row v-else-if="isDwdProcess" :gutter="24">
				<el-col :span="12">
					<el-form-item label="明细模型" required>
						<el-select v-model="dwdModelId" filterable :loading="dwdModelLoading" placeholder="请选择明细模型" style="width: 100%" @change="handleDwdModelChange">
							<el-option v-for="item in dwdModels" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="冻结版本" prop="dwdVersionId">
						<el-select v-model="form.dwdVersionId" filterable :loading="dwdVersionLoading" :disabled="!dwdModelId" placeholder="请选择已冻结的模型版本" style="width: 100%">
							<el-option v-for="item in dwdVersions" :key="item.id" :label="`${item.versionNo}（${item.id}）`" :value="item.id" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="暂存数据库">
						<el-input v-model="form.replicaDatabase" placeholder="可不填，使用后端默认暂存库" />
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-alert title="来源表、目标数据源和目标表由所选冻结版本决定；保存后需发布任务版本，新配置才会参与执行。" type="info" :closable="false" show-icon />
				</el-col>
			</el-row>
			<el-row v-else :gutter="24">
				<el-col :span="12">
					<el-form-item label="源数据源" prop="sourceDatasourceId">
						<el-select
							v-model="form.sourceDatasourceId"
							filterable
							placeholder="请选择源数据源"
							style="width: 100%"
							@change="handleSourceDatasourceChange"
						>
							<el-option v-for="item in sourceDatasourceReferences" :key="item.id" :label="datasourceLabel(item)" :value="item.id" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="目标数据源" prop="targetDatasourceId">
						<el-select v-model="form.targetDatasourceId" filterable placeholder="请选择 PostgreSQL 目标数据源" style="width: 100%">
							<el-option v-for="item in targetDatasourceReferences" :key="item.id" :label="datasourceLabel(item)" :value="item.id" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="源表" prop="sourceTable">
						<el-select
							v-model="form.sourceTable"
							filterable
							remote
							:remote-method="loadSourceTables"
							:loading="tableLoading"
							:disabled="!form.sourceDatasourceId"
							placeholder="输入表名查询"
							style="width: 100%"
							@change="handleSourceTableChange"
						>
							<el-option v-for="item in sourceTables" :key="qualifiedTableName(item)" :label="tableLabel(item)" :value="qualifiedTableName(item)" />
							<template #empty>
								<div class="source-table-empty">暂无可用源表，请先在“数据源管理 → 配置”中选择允许使用的表</div>
							</template>
						</el-select>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="目标表" prop="targetTable">
						<div class="target-table-field">
							<el-input v-model="form.targetTable" placeholder="选择业务系统和源表后自动生成，也可手动修改" @blur="handleTargetTableBlur" />
							<div class="target-table-name-help">
								<span>根据数仓层级、业务系统和源表自动生成</span>
								<el-tooltip
									content="命名规则：数仓层级_业务系统编码_源表名，统一使用小写字母、数字和下划线；源表带数据库或 Schema 前缀时仅取最后一段，最长 63 字节。"
									placement="top"
								>
									<el-button link type="primary">查看命名规则</el-button>
								</el-tooltip>
							</div>
							<div v-if="targetTableGenerating" class="target-table-generating">正在生成目标表名…</div>
							<div v-else-if="targetTableFormatWarning" class="target-table-format-warning">建议目标表名仅使用小写字母、数字和下划线</div>
						</div>
					</el-form-item>
				</el-col>
				<el-col :span="24">
					<el-form-item label="目标表处理方式" prop="targetTableMode">
						<div class="target-table-mode">
							<el-radio-group v-model="form.targetTableMode" class="target-table-mode-options">
								<el-radio value="APPEND" border class="target-table-mode-option">
									<span class="target-table-mode-title">追加写入</span>
									<span class="target-table-mode-summary">保留目标表现有数据</span>
								</el-radio>
								<el-radio value="RECREATE_ON_PUBLISH" border class="target-table-mode-option">
									<span class="target-table-mode-title">发布时重建</span>
									<span class="target-table-mode-summary">发布时删除并重建目标表</span>
								</el-radio>
							</el-radio-group>
							<div v-if="form.targetTableMode === 'APPEND'" class="target-table-help">
								目标表不存在时将在发布时自动创建；目标表已存在时保留数据和额外字段，并继续追加写入。
							</div>
							<el-alert
								v-else
								title="仅在发布时删除并重建目标表；后续手动或定时执行不会再次删表。现有数据、额外字段和自定义索引将被删除。"
								type="warning"
								:closable="false"
								show-icon
								class="target-table-warning"
							/>
						</div>
					</el-form-item>
				</el-col>
				<el-col v-if="schemaPrecheckReady" :span="24">
					<div v-loading="schemaChecking" class="schema-precheck-panel">
						<SchemaPrecheckResult v-if="schemaPrecheckResult" :result="schemaPrecheckResult" />
						<el-alert
							v-else-if="schemaPrecheckError"
							title="发布前检查暂不可用"
							:description="schemaPrecheckError"
							type="warning"
							:closable="false"
							show-icon
						/>
						<el-alert v-else title="正在检查目标表结构与写入风险" type="info" :closable="false" show-icon />
					</div>
				</el-col>
			</el-row>

			<el-divider content-position="left">{{ isDimBuild ? '物化策略' : isDwdProcess ? '加工模式' : '同步与增量配置' }}</el-divider>
			<el-row v-if="isDimBuild" :gutter="24">
				<el-col :span="12">
					<el-form-item label="同步模式" prop="syncMode"><el-input model-value="全量物化（FULL）" readonly /></el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="写入策略"><el-input model-value="按 key 覆盖写入（REPLACE）" readonly /></el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="SCD策略"><el-input :model-value="dimBinding.scdType || '--'" readonly /></el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="批次大小"><el-input :model-value="String(form.batchSize || '--')" readonly /></el-form-item>
				</el-col>
			</el-row>
			<el-row v-else-if="isDwdProcess" :gutter="24">
				<el-col :span="12">
					<el-form-item label="同步模式" prop="syncMode"><el-input :model-value="form.syncMode === 'FULL' ? '全量加工（FULL）' : form.syncMode" readonly /></el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="批次大小" prop="batchSize">
						<el-input-number v-model="form.batchSize" :min="1" :max="100000" controls-position="right" style="width: 100%" />
					</el-form-item>
				</el-col>
			</el-row>
			<el-row v-else :gutter="24">
				<el-col :span="12">
					<el-form-item label="同步模式" prop="syncMode">
						<el-select v-model="form.syncMode" style="width: 100%" @change="handleSyncModeChange">
							<el-option label="全量同步" value="FULL" />
							<el-option label="增量同步" value="INCREMENTAL" />
							<el-option label="首次全量后增量（仅 REST）" value="FULL_THEN_INCREMENTAL" :disabled="!isRestRuntime" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col v-if="isIncremental" :span="24">
					<el-form-item label="增量字段配置" :error="incrementalColumnsError">
						<div class="compound-columns">
							<div v-for="(item, index) in incrementalColumnRows" :key="item.name || index" class="compound-column-row">
								<span class="compound-column-order">{{ index + 1 }}</span>
								<el-select
									v-model="item.name"
									filterable
									:loading="columnLoading"
									placeholder="请选择可用增量字段"
									class="compound-column-field"
									@change="handleIncrementalColumnChange(index)"
								>
									<el-option
										v-for="column in selectableIncrementalColumns(index)"
										:key="column.columnName"
										:label="columnLabel(column)"
										:value="column.columnName"
									/>
								</el-select>
								<el-input v-model="item.type" readonly placeholder="字段类型" class="compound-column-type" />
								<el-input
									v-if="form.syncMode === 'INCREMENTAL'"
									v-model="item.initialValue"
									:placeholder="item.initialValuePlaceholder || '请输入初始值'"
									clearable
									class="compound-column-initial-value"
								/>
								<span v-else class="compound-column-initial-value-not-required">首次全量后自动生成水位</span>
								<el-button text type="primary" :disabled="index === 0" @click="moveIncrementalColumn(index, -1)">上移</el-button>
								<el-button text type="primary" :disabled="index === incrementalColumnRows.length - 1" @click="moveIncrementalColumn(index, 1)"
									>下移</el-button
								>
								<el-button text type="danger" @click="removeIncrementalColumn(index)">删除</el-button>
							</div>
							<el-button
								type="primary"
								plain
								:disabled="incrementalColumnRows.length >= 3 || (!isRestRuntime && incrementalColumnRows.length >= 1)"
								@click="addIncrementalColumn"
							>
								添加字段
							</el-button>
							<div class="incremental-order-tip">字段顺序决定复合游标的比较顺序；选择多个字段时必须使用 SeaTunnel REST 档案。</div>
						</div>
					</el-form-item>
				</el-col>
				<el-col v-if="isIncremental" :span="12">
					<el-form-item label="增量策略" prop="incrementalStrategy">
						<el-select v-model="form.incrementalStrategy" style="width: 100%">
							<el-option v-for="item in incrementalStrategies" :key="item.value" :label="item.label" :value="item.value" />
						</el-select>
						<div class="configuration-help">{{ incrementalStrategyDescription }}</div>
					</el-form-item>
				</el-col>
				<el-col v-if="isIncremental" :span="24">
					<el-form-item label="源端物理删除处理" prop="sourceDeleteStrategy">
						<div class="source-delete-configuration">
							<el-radio-group v-model="form.sourceDeleteStrategy">
								<el-radio v-for="item in sourceDeleteStrategies" :key="item.value" :value="item.value">{{ item.label }}</el-radio>
							</el-radio-group>
							<div class="configuration-help">{{ sourceDeleteStrategyDescription }}</div>
						</div>
					</el-form-item>
				</el-col>
				<template v-if="isIncremental && form.sourceDeleteStrategy === 'MARK_DELETED'">
					<el-col :span="12">
						<el-form-item label="全量对账间隔" prop="reconciliationIntervalMinutes">
							<el-input-number v-model="form.reconciliationIntervalMinutes" :min="5" :max="100000" controls-position="right" style="width: 100%" />
							<span class="field-unit">分钟</span>
						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="单次最大标记数" prop="reconciliationMaxDeleteRows">
							<el-input-number v-model="form.reconciliationMaxDeleteRows" :min="1" :max="1000000" controls-position="right" style="width: 100%" />
							<span class="field-unit">条</span>
						</el-form-item>
					</el-col>
					<el-col :span="24">
						<el-alert
							title="对账不会在每次增量后执行，而是在达到设定间隔后执行。目标端不会物理删除数据，只会通过 _dp_deleted 和 _dp_deleted_at 标记源端已删除记录。"
							type="warning"
							:closable="false"
							show-icon
							class="reconciliation-tip"
						/>
					</el-col>
				</template>
				<el-col v-if="isIncremental" :span="12">
					<el-form-item label="水位存储" prop="watermarkStorage">
						<el-radio-group v-model="form.watermarkStorage">
							<el-radio value="DATABASE">数据库</el-radio>
							<el-radio value="FILE">文件</el-radio>
						</el-radio-group>
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="批次大小" prop="batchSize">
						<el-input-number v-model="form.batchSize" :min="1" :max="100000" controls-position="right" style="width: 100%" />
					</el-form-item>
				</el-col>
			</el-row>

			<el-divider content-position="left">调度与引擎</el-divider>
			<el-row :gutter="24">
				<el-col :span="12">
					<el-form-item label="调度方式" prop="scheduleType">
						<el-radio-group v-model="form.scheduleType" @change="handleScheduleTypeChange">
							<el-radio value="MANUAL">手动</el-radio>
							<el-radio value="CRON">定时</el-radio>
						</el-radio-group>
					</el-form-item>
				</el-col>
				<el-col v-if="form.scheduleType === 'CRON'" :span="24">
					<el-form-item label="定时规则" prop="cronExpression">
						<cron-schedule-builder ref="cronScheduleBuilderRef" v-model="form.cronExpression" :timezone="form.timezone" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="时区" prop="timezone">
						<el-input v-model="form.timezone" placeholder="Asia/Shanghai" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="重试次数" prop="retryTimes">
						<el-input-number v-model="form.retryTimes" :min="0" :max="10" controls-position="right" style="width: 100%" />
					</el-form-item>
				</el-col>
				<el-col :span="12">
					<el-form-item label="重试间隔" prop="retryIntervalMinutes">
						<el-input-number v-model="form.retryIntervalMinutes" :min="1" :max="1440" controls-position="right" style="width: 100%" />
						<span class="field-unit">分钟</span>
					</el-form-item>
				</el-col>
				<el-col v-if="!isDwdProcess || form.scheduleType === 'CRON'" :span="12">
					<el-form-item label="DS档案" prop="dsProfileId">
						<el-select v-model="form.dsProfileId" filterable placeholder="请选择启用的 DolphinScheduler 档案" style="width: 100%">
							<el-option v-for="item in dsProfiles" :key="item.id" :label="item.profileName" :value="item.id" :disabled="item.enabled === false" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col v-if="!isDimBuild" :span="12">
					<el-form-item label="SeaTunnel档案" prop="seatunnelProfileId">
						<el-select
							v-model="form.seatunnelProfileId"
							filterable
							placeholder="请选择 LOCAL、CLUSTER 或 REST 档案"
							style="width: 100%"
							@change="handleSeatunnelProfileChange"
						>
							<el-option v-for="item in seatunnelProfiles" :key="item.id" :label="`${item.profileName}（${item.runtimeMode}）`" :value="item.id" :disabled="item.enabled === false" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col v-if="!isDimBuild && !isDwdProcess && isRestRuntime" :span="24">
					<el-alert
						:title="
							restInternalUrlConfigured ? 'REST 模式将由 DS Worker 调用数据平台内部接口执行。' : '所选 DS 档案缺少 dataPlatformInternalUrl 配置。'
						"
						:type="restInternalUrlConfigured ? 'info' : 'warning'"
						:closable="false"
						show-icon
						class="mb20"
					/>
				</el-col>
				<el-col v-if="!isDwdProcess || form.scheduleType === 'CRON'" :span="24">
					<el-form-item label="前置依赖">
						<el-select
							v-model="form.dependencyTaskIds"
							multiple
							filterable
							collapse-tags
							collapse-tags-tooltip
							placeholder="可选择前置任务，最多100个"
							style="width: 100%"
						>
							<el-option v-for="item in dependencyTasks" :key="item.id" :label="`${item.taskName}（${item.taskCode}）`" :value="item.id" />
						</el-select>
					</el-form-item>
				</el-col>
				<el-col v-if="isDwdProcess && form.scheduleType === 'MANUAL'" :span="24">
					<el-alert title="手动执行仅支持无冻结上游依赖的任务；存在此类依赖时请改用定时工作流，服务端会再次校验。" type="warning" :closable="false" show-icon />
				</el-col>
			</el-row>
		</el-form>

		<template #footer>
			<el-button @click="visible = false">取消</el-button>
			<el-button type="primary" :loading="submitting" @click="handleSubmit">保存草稿</el-button>
		</template>
	</el-drawer>
</template>

<script setup lang="ts" name="SyncTaskFormDrawer">
import type { FormInstance, FormRules } from 'element-plus';
import { fetchDwdModelOptions, fetchDwdVersions } from '/@/api/dataPlatform/dwd';
import {
	createSyncTask,
	fetchBusinessDomains,
	fetchBusinessSystems,
	fetchIncrementalStrategies,
	fetchLayeredTaskPage,
	precheckSyncTaskSchema,
	fetchSyncTaskDatasourceOptions,
	fetchSyncTaskEngineProfileOptions,
	fetchSyncTaskVersions,
	fetchSyncTaskSourceTableColumns,
	fetchSyncTaskSourceTables,
	fetchSourceDeleteStrategies,
	generateTargetTableName,
	getLayeredTask,
	updateSyncTask,
} from '/@/api/dataPlatform/layeredTask';
import { useMessage } from '/@/hooks/message';
import type { DatasourceReference } from '/@/types/dataPlatform/datasourceAsset';
import type { DwdOption, DwdVersion } from '/@/types/dataPlatform/dwd';
import type { EngineProfile } from '/@/types/dataPlatform/engineProfile';
import type {
	BusinessDomainOption,
	BusinessSystemOption,
	DatasourceMetadataColumn,
	DatasourceMetadataTable,
	DwdSyncTaskSaveRequest,
	IncrementalColumnConfig,
	IncrementalColumnType,
	IncrementalStrategy,
	LayeredTaskDetail,
	LayeredTaskSummary,
	PageResult,
	SchemaPrecheckRequest,
	SchemaPrecheckResult as SchemaPrecheckResultType,
	SourceDeleteStrategy,
	SyncEnumOption,
	SyncTaskSaveRequest,
	SyncTaskSaveResult,
	SyncTaskVersion,
} from '/@/types/dataPlatform/layeredTask';
import CronScheduleBuilder from './CronScheduleBuilder.vue';
import SchemaPrecheckResult from './schemaPrecheckResult.vue';

const emit = defineEmits<{ saved: [result: SyncTaskSaveResult] }>();
const visible = ref(false);
const loading = ref(false);
const submitting = ref(false);
const tableLoading = ref(false);
const columnLoading = ref(false);
const domainLoading = ref(false);
const schemaChecking = ref(false);
const targetTableGenerating = ref(false);
const schemaPrecheckResult = ref<SchemaPrecheckResultType>();
const schemaPrecheckError = ref('');
const lastAutoGeneratedTargetTable = ref('');
const editingTaskId = ref('');
const formRef = ref<FormInstance>();
const cronScheduleBuilderRef = ref<InstanceType<typeof CronScheduleBuilder>>();
const sourceDatasourceReferences = ref<DatasourceReference[]>([]);
const targetDatasourceReferences = ref<DatasourceReference[]>([]);
const dsProfiles = ref<EngineProfile[]>([]);
const seatunnelProfiles = ref<EngineProfile[]>([]);
const sourceTables = ref<DatasourceMetadataTable[]>([]);
const sourceColumns = ref<DatasourceMetadataColumn[]>([]);
const dwdModels = ref<DwdOption[]>([]);
const dwdVersions = ref<DwdVersion[]>([]);
const dwdModelId = ref('');
const dwdModelLoading = ref(false);
const dwdVersionLoading = ref(false);
const dependencyTasks = ref<LayeredTaskSummary[]>([]);
const businessSystems = ref<BusinessSystemOption[]>([]);
const businessDomains = ref<BusinessDomainOption[]>([]);
const dimBinding = reactive({
	relatedModelName: '',
	entityTableName: '',
	targetDatasourceName: '',
	databaseName: '',
	physicalName: '',
	scdType: '',
});
const incrementalStrategies = ref<SyncEnumOption<IncrementalStrategy>[]>([
	{ value: 'APPEND', label: '追加', description: '只新增数据，不处理已存在记录，可能产生重复数据。' },
	{ value: 'UPSERT', label: '更新插入', description: '根据主键或唯一键判断，已存在记录更新，不存在记录插入。' },
]);
const sourceDeleteStrategies = ref<SyncEnumOption<SourceDeleteStrategy>[]>([
	{ value: 'IGNORE', label: '忽略', description: '仅同步新增和修改，不处理源端已物理删除的数据。' },
	{ value: 'MARK_DELETED', label: '定期对账并标记删除', description: '保留目标数据，仅标记源端已删除记录；不会执行物理删除。' },
]);
const incrementalColumnTypes: IncrementalColumnType[] = ['TIMESTAMP', 'DATETIME', 'DATE', 'TIME', 'BIGINT', 'INT', 'DECIMAL', 'STRING'];
const defaultCronExpression = '0 0/10 * * * ?';
const incrementalColumnsError = ref('');

const defaultForm = (): SyncTaskSaveRequest => ({
	warehouseLayer: 'ODS',
	taskType: 'SOURCE_SYNC',
	businessSystemId: '',
	businessDomainId: '',
	relatedModelId: null,
	dwdVersionId: '',
	replicaDatabase: '',
	description: '',
	taskCode: '',
	taskName: '',
	sourceDatasourceId: '',
	targetDatasourceId: '',
	sourceTable: '',
	targetTable: '',
	targetTableMode: 'APPEND',
	syncMode: 'FULL',
	incrementalColumn: '',
	incrementalColumns: [],
	incrementalColumnType: undefined,
	incrementalStrategy: 'APPEND',
	incrementalStartValue: '',
	sourceDeleteStrategy: 'IGNORE',
	reconciliationIntervalMinutes: 1440,
	reconciliationMaxDeleteRows: 1000,
	watermarkStorage: 'DATABASE',
	scheduleType: 'MANUAL',
	cronExpression: '',
	timezone: 'Asia/Shanghai',
	batchSize: 10000,
	retryTimes: 2,
	retryIntervalMinutes: 10,
	dsProfileId: '',
	seatunnelProfileId: '',
	dependencyTaskIds: [],
});

const form = reactive<SyncTaskSaveRequest>(defaultForm());
const isDimBuild = computed(() => form.taskType === 'DIM_BUILD');
const isDwdProcess = computed(() => form.taskType === 'DWD_PROCESS');
const drawerTitle = computed(() => {
	if (isDimBuild.value) return '编辑维度物化任务';
	if (isDwdProcess.value) return editingTaskId.value ? '编辑明细加工任务' : '新建明细加工任务';
	return editingTaskId.value ? '编辑数据同步任务' : '新建数据同步任务';
});
const formTip = computed(() =>
	isDimBuild.value
		? 'DIM 物化任务从平台维度值生成绑定的 ENTITY 表；模型、输出表和 SCD 策略由当前绑定决定。'
		: isDwdProcess.value
			? 'DWD 明细加工任务绑定已冻结的模型版本；手动任务使用 SeaTunnel 档案，定时任务还需 DolphinScheduler 档案。'
			: '当前支持 ODS 源表同步、DIM 维度物化和 DWD 明细加工；DWS、ADS 任务将在后续版本开放。'
);
const isIncremental = computed(() => !isDimBuild.value && !isDwdProcess.value && form.syncMode !== 'FULL');
const incrementalColumnRows = computed(() => form.incrementalColumns || []);
const selectedSeatunnelProfile = computed(() => seatunnelProfiles.value.find((item) => item.id === form.seatunnelProfileId));
const isRestRuntime = computed(() => selectedSeatunnelProfile.value?.runtimeMode === 'REST');
const restInternalUrlConfigured = computed(() => {
	if (!isRestRuntime.value) return true;
	const profile = dsProfiles.value.find((item) => item.id === form.dsProfileId);
	if (!profile?.extraConfigJson) return false;
	try {
		const config = typeof profile.extraConfigJson === 'string' ? JSON.parse(profile.extraConfigJson) : profile.extraConfigJson;
		return Boolean(config?.dataPlatformInternalUrl);
	} catch {
		return false;
	}
});
const schemaPrecheckReady = computed(() =>
	Boolean(!isDimBuild.value && !isDwdProcess.value && form.sourceDatasourceId && form.sourceTable?.trim() && form.targetDatasourceId && form.targetTable.trim())
);
const targetTableFormatWarning = computed(
	() => !isDimBuild.value && !isDwdProcess.value && Boolean(form.targetTable.trim()) && !/^[a-z0-9_]+$/.test(form.targetTable.trim())
);
const eligibleIncrementalColumns = computed(() => sourceColumns.value.filter((column) => column.incrementalEligible === true));
const incrementalStrategyDescription = computed(
	() => incrementalStrategies.value.find((item) => item.value === form.incrementalStrategy)?.description || ''
);
const sourceDeleteStrategyDescription = computed(
	() => sourceDeleteStrategies.value.find((item) => item.value === form.sourceDeleteStrategy)?.description || ''
);

const validateTaskCode = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (!value || /^[A-Z0-9_]{3,64}$/.test(value)) return callback();
	callback(new Error('任务编号只能包含3至64位大写字母、数字和下划线'));
};
const validateIdentifier = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (/^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*){0,2}$/.test(value || '')) return callback();
	callback(new Error('请输入最多三段、仅包含字母数字和下划线的安全表名'));
};
const validateCron = (_rule: unknown, value: string, callback: (error?: Error) => void) => {
	if (form.scheduleType !== 'CRON' || value?.trim()) return callback();
	callback(new Error('定时调度必须填写 Spring 六段 Cron'));
};

const rules = computed<FormRules>(() => {
	if (isDwdProcess.value) {
		return {
			taskName: [{ required: true, message: '请输入任务名称', trigger: 'blur' }],
			taskCode: [{ validator: validateTaskCode, trigger: 'blur' }],
			dwdVersionId: [{ required: true, message: '请选择已冻结的明细模型版本', trigger: 'change' }],
			syncMode: [{ required: true, message: '请选择同步模式', trigger: 'change' }],
			seatunnelProfileId: [{ required: true, message: '请选择 SeaTunnel 档案', trigger: 'change' }],
			batchSize: [{ type: 'number', required: true, min: 1, max: 100000, message: '批次大小范围为1至100000', trigger: 'change' }],
			cronExpression: [{ validator: validateCron, trigger: 'blur' }],
			...(form.scheduleType === 'CRON'
				? {
					timezone: [{ required: true, message: '请输入合法的 Java 时区', trigger: 'blur' }],
					dsProfileId: [{ required: true, message: '请选择 DolphinScheduler 档案', trigger: 'change' }],
				  }
				: {}),
		};
	}
	const commonRules: FormRules = {
		taskName: [{ required: true, message: '请输入任务名称', trigger: 'blur' }],
		taskCode: [{ validator: validateTaskCode, trigger: 'blur' }],
		targetDatasourceId: [{ required: true, message: '缺少模型绑定的目标数据源', trigger: 'change' }],
		targetTable: [{ required: true, message: '缺少模型绑定的物理表', trigger: 'blur' }],
		syncMode: [{ required: true, message: '请选择同步模式', trigger: 'change' }],
		cronExpression: [{ validator: validateCron, trigger: 'blur' }],
		timezone: [{ required: true, message: '请输入合法的 Java 时区', trigger: 'blur' }],
		batchSize: [{ type: 'number', required: true, min: 1, max: 100000, message: '批次大小范围为1至100000', trigger: 'change' }],
		retryTimes: [{ type: 'number', required: true, min: 0, max: 10, message: '重试次数范围为0至10', trigger: 'change' }],
		retryIntervalMinutes: [{ type: 'number', required: true, min: 1, max: 1440, message: '重试间隔范围为1至1440分钟', trigger: 'change' }],
		dsProfileId: [{ required: true, message: '请选择 DolphinScheduler 档案', trigger: 'change' }],
	};
	if (isDimBuild.value) {
		return {
			...commonRules,
			relatedModelId: [{ required: true, message: '缺少关联维度模型', trigger: 'change' }],
		};
	}
	return {
		...commonRules,
		sourceDatasourceId: [{ required: true, message: '请选择源数据源', trigger: 'change' }],
		sourceTable: [
			{ required: true, message: '请选择源表', trigger: 'change' },
			{ validator: validateIdentifier, trigger: 'change' },
		],
		targetTableMode: [{ required: true, message: '请选择目标表处理方式', trigger: 'change' }],
		incrementalStrategy: [{ required: true, message: '请选择增量策略', trigger: 'change' }],
		sourceDeleteStrategy: [{ required: true, message: '请选择源端物理删除处理方式', trigger: 'change' }],
		reconciliationIntervalMinutes: [
			{ type: 'number', required: true, min: 5, max: 100000, message: '全量对账间隔必须在5至100000分钟之间', trigger: 'change' },
		],
		reconciliationMaxDeleteRows: [
			{ type: 'number', required: true, min: 1, max: 1000000, message: '单次最大标记数必须在1至1000000条之间', trigger: 'change' },
		],
		seatunnelProfileId: [{ required: true, message: '请选择 SeaTunnel 档案', trigger: 'change' }],
	};
});

const datasourceLabel = (item: DatasourceReference) => `${item.displayName || item.name}（${item.dsType} / ${item.dsName}）`;
const qualifiedTableName = (item: DatasourceMetadataTable) => {
	if (item.tableName.includes('.')) return item.tableName;
	return [item.catalog, item.schema, item.tableName].filter(Boolean).join('.');
};
const tableLabel = (item: DatasourceMetadataTable) => {
	const name = qualifiedTableName(item);
	return item.remarks ? `${name}（${item.remarks}）` : name;
};

const buildSchemaPrecheckRequest = (): SchemaPrecheckRequest => ({
	sourceDatasourceId: form.sourceDatasourceId || '',
	sourceTable: form.sourceTable?.trim() || '',
	targetDatasourceId: form.targetDatasourceId,
	targetTable: form.targetTable.trim(),
	targetTableMode: form.targetTableMode || 'APPEND',
});

let schemaPrecheckTimer: ReturnType<typeof setTimeout> | undefined;
let schemaPrecheckRequestId = 0;

const clearSchemaPrecheckTimer = () => {
	if (schemaPrecheckTimer) clearTimeout(schemaPrecheckTimer);
	schemaPrecheckTimer = undefined;
};

const loadSchemaPrecheck = async () => {
	if (!schemaPrecheckReady.value) return;
	const requestId = ++schemaPrecheckRequestId;
	try {
		schemaChecking.value = true;
		schemaPrecheckError.value = '';
		const res = await precheckSyncTaskSchema(buildSchemaPrecheckRequest());
		if (requestId !== schemaPrecheckRequestId) return;
		schemaPrecheckResult.value = res.data as SchemaPrecheckResultType;
	} catch (error: any) {
		if (requestId !== schemaPrecheckRequestId) return;
		schemaPrecheckResult.value = undefined;
		schemaPrecheckError.value = error?.msg || '后端发布前检查接口尚未就绪，请稍后重试。';
	} finally {
		if (requestId === schemaPrecheckRequestId) schemaChecking.value = false;
	}
};

const scheduleSchemaPrecheck = () => {
	clearSchemaPrecheckTimer();
	++schemaPrecheckRequestId;
	schemaPrecheckResult.value = undefined;
	schemaPrecheckError.value = '';
	schemaChecking.value = false;
	if (!visible.value || !schemaPrecheckReady.value) return;
	schemaPrecheckTimer = setTimeout(loadSchemaPrecheck, 500);
};
const columnLabel = (item: DatasourceMetadataColumn) => {
	const type = item.dataType || item.columnType;
	const comment = item.columnComment || item.remarks;
	const nullableTip = item.isNullable ? ' [可空，NULL值不参与增量比较]' : '';
	return `${item.columnName}${type ? `（${type}）` : ''}${comment ? ` - ${comment}` : ''}${
		item.isPrimaryKey ? ' [主键]' : item.isIndexed ? ' [索引]' : ''
	}${nullableTip}`;
};

const inferIncrementalColumnType = (column?: DatasourceMetadataColumn): IncrementalColumnType => {
	const dataType = String(column?.dataType || column?.columnType || '').toUpperCase();
	if (dataType.includes('TIMESTAMP')) return 'TIMESTAMP';
	if (dataType.includes('DATETIME')) return 'DATETIME';
	if (dataType === 'DATE') return 'DATE';
	if (dataType === 'TIME') return 'TIME';
	if (dataType.includes('BIGINT') || dataType.includes('BIGSERIAL')) return 'BIGINT';
	if (/(^|\W)(INT|INTEGER|SMALLINT|TINYINT|SERIAL)(\W|$)/.test(dataType)) return 'INT';
	if (/(DECIMAL|NUMERIC|NUMBER|FLOAT|DOUBLE|REAL)/.test(dataType)) return 'DECIMAL';
	return 'STRING';
};

const getInitialValuePlaceholder = (dataType?: string) => {
	const normalizedType = String(dataType || '').toUpperCase();
	if (normalizedType.includes('DATETIME') || normalizedType.includes('TIMESTAMP')) return '例如：1970-01-01 00:00:00';
	if (normalizedType === 'DATE') return '例如：1970-01-01';
	if (normalizedType === 'TIME') return '例如：00:00:00';
	if (
		normalizedType.includes('INT') ||
		normalizedType.includes('NUMERIC') ||
		normalizedType.includes('DECIMAL') ||
		normalizedType.includes('NUMBER') ||
		normalizedType.includes('FLOAT') ||
		normalizedType.includes('DOUBLE') ||
		normalizedType.includes('REAL')
	)
		return '例如：0';
	return '请输入初始值';
};

const createIncrementalColumn = (
	name = '',
	type: IncrementalColumnType = 'STRING',
	order = 1,
	initialValue = '',
	initialValuePlaceholder = ''
): IncrementalColumnConfig => ({
	name,
	type,
	order,
	initialValue,
	initialValuePlaceholder: initialValuePlaceholder || getInitialValuePlaceholder(type),
});

const resetIncrementalSelection = () => {
	form.incrementalColumn = '';
	form.incrementalColumnType = undefined;
	form.incrementalColumns = [];
	incrementalColumnsError.value = '';
};

const toOptionList = <T extends { id: string; name: string }>(data: unknown): T[] => {
	const raw = Array.isArray(data) ? data : (data as { records?: T[] })?.records || [];
	return raw.map((item: any) => ({
		...item,
		id: String(item.id ?? item.value),
		name: item.name || item.label || item.systemName || item.domainName || '--',
	}));
};

const normalizeTables = (data: unknown): DatasourceMetadataTable[] => {
	const raw = Array.isArray(data)
		? data
		: (data as { records?: unknown[]; tables?: unknown[] })?.records || (data as { tables?: unknown[] })?.tables || [];
	return raw.map((item: any) => ({ ...item, tableName: item.tableName || item.name }));
};

const normalizeColumns = (data: unknown): DatasourceMetadataColumn[] => {
	const raw = Array.isArray(data) ? data : (data as { records?: unknown[] })?.records || [];
	const toBoolean = (value: unknown) => value === true || value === 1 || value === '1' || value === 'true';
	return raw.map((item: any) => {
		const isPrimaryKey = toBoolean(item.isPrimaryKey ?? item.primaryKey);
		const isIndexed = toBoolean(item.isIndexed ?? item.indexed ?? item.index);
		const incrementalEligible = toBoolean(item.incrementalEligible);
		return {
			...item,
			columnName: item.columnName || item.name,
			columnType: item.columnType || item.typeName || item.dataType,
			isPrimaryKey,
			isIndexed,
			isNullable: toBoolean(item.isNullable),
			incrementalEligible,
			incrementalReason: item.incrementalReason,
			primaryKey: isPrimaryKey,
			indexed: isIndexed,
		};
	});
};

const normalizeSyncEnumOptions = <T extends string>(data: unknown, allowedValues: readonly T[]): SyncEnumOption<T>[] => {
	const raw = Array.isArray(data) ? data : (data as { records?: unknown[] })?.records || [];
	return raw
		.filter((item: any) => allowedValues.includes(item.value as T))
		.map((item: any) => ({ value: item.value as T, label: item.label || item.value, description: item.description }));
};

const loadBaseOptions = async () => {
	const [
		sourceResult,
		targetResult,
		dsResult,
		seatunnelResult,
		systemResult,
		dependencyResult,
		incrementalStrategyResult,
		sourceDeleteStrategyResult,
	] = await Promise.allSettled([
		fetchSyncTaskDatasourceOptions('SOURCE'),
		fetchSyncTaskDatasourceOptions('TARGET'),
		fetchSyncTaskEngineProfileOptions('DOLPHIN_SCHEDULER'),
		fetchSyncTaskEngineProfileOptions('SEATUNNEL'),
		fetchBusinessSystems(),
		fetchLayeredTaskPage({ current: 1, size: 100, layer: 'ODS' }),
		fetchIncrementalStrategies(),
		fetchSourceDeleteStrategies(),
	]);
	if (sourceResult.status === 'fulfilled')
		sourceDatasourceReferences.value = (sourceResult.value.data || [])
			.map((item: DatasourceReference) => ({ ...item, id: String(item.id) }))
			.filter((item: DatasourceReference) => !item.capabilities || (item.capabilities.source && item.capabilities.odsCompatible));
	if (targetResult.status === 'fulfilled')
		targetDatasourceReferences.value = (targetResult.value.data || [])
			.map((item: DatasourceReference) => ({ ...item, id: String(item.id) }))
			.filter((item: DatasourceReference) => !item.capabilities || item.capabilities.target);
	if (dsResult.status === 'fulfilled') {
		const profiles: EngineProfile[] = dsResult.value.data?.records || dsResult.value.data || [];
		dsProfiles.value = profiles.map((item) => ({ ...item, id: String(item.id) }));
	}
	if (seatunnelResult.status === 'fulfilled') {
		const profiles: EngineProfile[] = seatunnelResult.value.data?.records || seatunnelResult.value.data || [];
		seatunnelProfiles.value = profiles.map((item) => ({ ...item, id: String(item.id) }));
	}
	if (systemResult.status === 'fulfilled') businessSystems.value = toOptionList<BusinessSystemOption>(systemResult.value.data);
	if (dependencyResult.status === 'fulfilled') {
		const page = (dependencyResult.value.data || {}) as PageResult<LayeredTaskSummary>;
		dependencyTasks.value = (page.records || []).map((item) => ({ ...item, id: String(item.id) })).filter((item) => item.id !== editingTaskId.value);
	}
	if (incrementalStrategyResult.status === 'fulfilled') {
		const options = normalizeSyncEnumOptions<IncrementalStrategy>(incrementalStrategyResult.value.data, ['APPEND', 'UPSERT']);
		if (options.length) incrementalStrategies.value = options;
	}
	if (sourceDeleteStrategyResult.status === 'fulfilled') {
		const options = normalizeSyncEnumOptions<SourceDeleteStrategy>(sourceDeleteStrategyResult.value.data, ['IGNORE', 'MARK_DELETED']);
		if (options.length) sourceDeleteStrategies.value = options;
	}
	const enabledDsProfiles = dsProfiles.value.filter((item) => item.enabled !== false);
	const enabledSeatunnelProfiles = seatunnelProfiles.value.filter((item) => item.enabled !== false);
	if (!form.dsProfileId && enabledDsProfiles.length === 1) form.dsProfileId = enabledDsProfiles[0].id;
	if (!form.seatunnelProfileId && enabledSeatunnelProfiles.length === 1) form.seatunnelProfileId = enabledSeatunnelProfiles[0].id;
};

const loadDwdModels = async () => {
	try {
		dwdModelLoading.value = true;
		const res = await fetchDwdModelOptions();
		dwdModels.value = (res.data || []).map((item) => ({ value: String(item.value), label: item.label }));
	} catch (error: any) {
		dwdModels.value = [];
		useMessage().error(error?.msg || '加载明细模型失败');
	} finally {
		dwdModelLoading.value = false;
	}
};

let dwdVersionRequestId = 0;
const loadDwdVersions = async (modelId: string) => {
	const requestId = ++dwdVersionRequestId;
	dwdVersions.value = [];
	dwdVersionLoading.value = false;
	if (!modelId) return;
	try {
		dwdVersionLoading.value = true;
		const res = await fetchDwdVersions(modelId);
		if (requestId !== dwdVersionRequestId) return;
		dwdVersions.value = (res.data || []).map((item) => ({ ...item, id: String(item.id), modelId: String(item.modelId) }));
	} catch (error: any) {
		if (requestId === dwdVersionRequestId) useMessage().error(error?.msg || '加载冻结版本失败');
	} finally {
		if (requestId === dwdVersionRequestId) dwdVersionLoading.value = false;
	}
};

const handleDwdModelChange = (modelId: string) => {
	form.dwdVersionId = '';
	formRef.value?.clearValidate('dwdVersionId');
	loadDwdVersions(modelId);
};

const handleWarehouseLayerChange = (layer: string) => {
	form.taskType = layer === 'DWD' ? 'DWD_PROCESS' : 'SOURCE_SYNC';
	form.syncMode = 'FULL';
	form.dwdVersionId = '';
	dwdModelId.value = '';
	dwdVersions.value = [];
	++dwdVersionRequestId;
	dwdVersionLoading.value = false;
	if (layer === 'DWD') loadDwdModels();
	nextTick(() => formRef.value?.clearValidate());
};

const loadBusinessDomains = async (systemId?: string) => {
	businessDomains.value = [];
	if (!systemId) return;
	try {
		domainLoading.value = true;
		const res = await fetchBusinessDomains(systemId);
		businessDomains.value = toOptionList<BusinessDomainOption>(res.data);
	} catch (error: any) {
		useMessage().error(error?.msg || '加载业务域失败');
	} finally {
		domainLoading.value = false;
	}
};

const handleBusinessSystemChange = (systemId?: string) => {
	form.businessDomainId = '';
	loadBusinessDomains(systemId);
};

let targetTableNameTimer: ReturnType<typeof setTimeout> | undefined;
let targetTableNameRequestId = 0;

const clearTargetTableNameTimer = () => {
	if (targetTableNameTimer) clearTimeout(targetTableNameTimer);
	targetTableNameTimer = undefined;
};

const targetTableNameReady = () => Boolean(!isDimBuild.value && !isDwdProcess.value && form.warehouseLayer && form.businessSystemId && form.sourceTable?.trim());

const loadGeneratedTargetTableName = async (requestId = ++targetTableNameRequestId) => {
	if (!targetTableNameReady()) return false;
	const currentTargetTable = form.targetTable.trim();
	if (currentTargetTable && currentTargetTable !== lastAutoGeneratedTargetTable.value) return true;
	try {
		targetTableGenerating.value = true;
		const res = await generateTargetTableName({
			warehouseLayer: form.warehouseLayer,
			businessSystemId: String(form.businessSystemId),
			sourceTable: form.sourceTable?.trim() || '',
		});
		if (requestId !== targetTableNameRequestId) return false;
		const generatedName = String(res.data || '').trim();
		if (!generatedName) throw new Error('后端未返回目标表名');
		const latestTargetTable = form.targetTable.trim();
		if (!latestTargetTable || latestTargetTable === lastAutoGeneratedTargetTable.value) {
			form.targetTable = generatedName;
			lastAutoGeneratedTargetTable.value = generatedName;
			formRef.value?.clearValidate('targetTable');
		}
		return true;
	} catch (error: any) {
		if (requestId === targetTableNameRequestId) useMessage().warning(error?.msg || error?.message || '自动生成目标表名失败，请手动填写');
		return false;
	} finally {
		if (requestId === targetTableNameRequestId) targetTableGenerating.value = false;
	}
};

const scheduleTargetTableNameGeneration = () => {
	clearTargetTableNameTimer();
	const requestId = ++targetTableNameRequestId;
	targetTableGenerating.value = false;
	if (!visible.value || loading.value || !targetTableNameReady()) return;
	const currentTargetTable = form.targetTable.trim();
	if (currentTargetTable && currentTargetTable !== lastAutoGeneratedTargetTable.value) return;
	targetTableNameTimer = setTimeout(() => loadGeneratedTargetTableName(requestId), 250);
};

const handleTargetTableBlur = async () => {
	if (!form.targetTable.trim()) {
		clearTargetTableNameTimer();
		await loadGeneratedTargetTableName();
		return;
	}
	if (targetTableFormatWarning.value) useMessage().warning('建议目标表名仅使用小写字母、数字和下划线');
};

const loadSourceTables = async (keyword = '') => {
	if (!form.sourceDatasourceId) return;
	try {
		tableLoading.value = true;
		const res = await fetchSyncTaskSourceTables(form.sourceDatasourceId, keyword.trim() || undefined, editingTaskId.value || undefined);
		sourceTables.value = normalizeTables(res.data);
	} catch (error: any) {
		sourceTables.value = [];
		useMessage().error(error?.msg || '加载源表失败');
	} finally {
		tableLoading.value = false;
	}
};

const loadSourceColumns = async () => {
	sourceColumns.value = [];
	if (!form.sourceDatasourceId || !form.sourceTable) return;
	try {
		columnLoading.value = true;
		const res = await fetchSyncTaskSourceTableColumns(form.sourceDatasourceId, form.sourceTable, true);
		sourceColumns.value = normalizeColumns(res.data);
	} catch (error: any) {
		useMessage().error(error?.msg || '加载源表字段失败');
	} finally {
		columnLoading.value = false;
	}
};

const selectableIncrementalColumns = (currentIndex: number) => {
	const selectedNames = new Set(incrementalColumnRows.value.filter((_, index) => index !== currentIndex).map((item) => item.name));
	return eligibleIncrementalColumns.value.filter((column) => !selectedNames.has(column.columnName));
};

const updateIncrementalOrders = () => {
	incrementalColumnRows.value.forEach((item, index) => {
		item.order = index + 1;
	});
};

const remindIncrementalStartValue = () => {
	if (incrementalColumnRows.value.some((item) => item.initialValue?.trim()))
		useMessage().warning('增量字段或顺序已变化，请确认各字段初始值仍与当前配置一致');
};

const handleIncrementalColumnChange = (index: number) => {
	const item = incrementalColumnRows.value[index];
	const column = eligibleIncrementalColumns.value.find((candidate) => candidate.columnName === item.name);
	item.type = inferIncrementalColumnType(column);
	item.order = index + 1;
	item.initialValue = '';
	item.initialValuePlaceholder = column?.initialValuePlaceholder || getInitialValuePlaceholder(column?.dataType || column?.columnType || item.type);
	incrementalColumnsError.value = '';
};

const addIncrementalColumn = () => {
	if (incrementalColumnRows.value.length >= 3) return;
	const selectedNames = new Set(incrementalColumnRows.value.map((item) => item.name));
	const column = eligibleIncrementalColumns.value.find((item) => !selectedNames.has(item.columnName));
	if (!column) {
		useMessage().warning(form.sourceTable ? '没有更多可用的增量字段' : '请先选择源表');
		return;
	}
	incrementalColumnRows.value.push(
		createIncrementalColumn(
			column.columnName,
			inferIncrementalColumnType(column),
			incrementalColumnRows.value.length + 1,
			'',
			column.initialValuePlaceholder || getInitialValuePlaceholder(column.dataType || column.columnType)
		)
	);
	incrementalColumnsError.value = '';
};

const removeIncrementalColumn = (index: number) => {
	incrementalColumnRows.value.splice(index, 1);
	updateIncrementalOrders();
	incrementalColumnsError.value = '';
	remindIncrementalStartValue();
};

const moveIncrementalColumn = (index: number, direction: -1 | 1) => {
	const target = index + direction;
	if (target < 0 || target >= incrementalColumnRows.value.length) return;
	const [item] = incrementalColumnRows.value.splice(index, 1);
	incrementalColumnRows.value.splice(target, 0, item);
	updateIncrementalOrders();
	remindIncrementalStartValue();
};

const handleSeatunnelProfileChange = () => {
	if (isRestRuntime.value) return;
	if (form.syncMode === 'FULL_THEN_INCREMENTAL') {
		useMessage().warning('首次全量后增量必须使用 SeaTunnel REST 档案，请切换后再保存');
		return;
	}
	if (incrementalColumnRows.value.length > 1) {
		useMessage().warning('复合增量游标必须使用 SeaTunnel REST 档案，请切换后再保存');
	}
};

const validateIncrementalInitialValue = (item: IncrementalColumnConfig) => {
	const value = item.initialValue?.trim();
	if (!value) return `增量字段 ${item.name || '--'} 的初始值不能为空，请按提示格式填写`;
	const sourceColumn = sourceColumns.value.find((column) => column.columnName === item.name);
	const type = String(sourceColumn?.dataType || sourceColumn?.columnType || item.type || '').toUpperCase();
	if ((type.includes('DATETIME') || type.includes('TIMESTAMP')) && !/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(value))
		return `${item.name} 的初始值格式应为 yyyy-MM-dd HH:mm:ss`;
	if (type === 'DATE' && !/^\d{4}-\d{2}-\d{2}$/.test(value)) return `${item.name} 的初始值格式应为 yyyy-MM-dd`;
	if (type === 'TIME' && !/^\d{2}:\d{2}:\d{2}$/.test(value)) return `${item.name} 的初始值格式应为 HH:mm:ss`;
	if (
		(type.includes('INT') ||
			type.includes('NUMERIC') ||
			type.includes('DECIMAL') ||
			type.includes('NUMBER') ||
			type.includes('FLOAT') ||
			type.includes('DOUBLE') ||
			type.includes('REAL')) &&
		!/^-?\d+(\.\d+)?$/.test(value)
	)
		return `${item.name} 的初始值必须是数字`;
	return '';
};

const validateIncrementalColumns = () => {
	if (!isIncremental.value) {
		incrementalColumnsError.value = '';
		return true;
	}
	const columns = incrementalColumnRows.value;
	if (columns.length < 1 || columns.length > 3) {
		incrementalColumnsError.value = '增量模式必须选择1至3个字段';
		return false;
	}
	if (columns.some((item) => !item.name || !item.type)) {
		incrementalColumnsError.value = '请完整选择增量字段，字段类型不能为空';
		return false;
	}
	if (form.syncMode === 'INCREMENTAL') {
		const initialValueError = columns.map(validateIncrementalInitialValue).find(Boolean);
		if (initialValueError) {
			incrementalColumnsError.value = initialValueError;
			return false;
		}
	}
	if (new Set(columns.map((item) => item.name)).size !== columns.length) {
		incrementalColumnsError.value = '增量字段不能重复';
		return false;
	}
	const eligibleNames = new Set(eligibleIncrementalColumns.value.map((item) => item.columnName));
	if (columns.some((item) => !eligibleNames.has(item.name))) {
		incrementalColumnsError.value = '存在后端未判定为可用的增量字段，请重新选择';
		return false;
	}
	if (columns.length > 1 && !isRestRuntime.value) {
		incrementalColumnsError.value = '多字段复合游标必须使用 SeaTunnel REST 档案';
		return false;
	}
	incrementalColumnsError.value = '';
	const lastColumn = eligibleIncrementalColumns.value.find((item) => item.columnName === columns[columns.length - 1].name);
	if (columns.length > 1 && lastColumn && !lastColumn.isPrimaryKey && String(lastColumn.indexType || '').toUpperCase() !== 'UNIQUE') {
		useMessage().warning('建议将主键或稳定唯一索引字段放在增量字段配置的最后一项');
	}
	return true;
};

const handleSourceDatasourceChange = () => {
	form.sourceTable = '';
	resetIncrementalSelection();
	form.incrementalStartValue = '';
	sourceTables.value = [];
	sourceColumns.value = [];
	loadSourceTables();
};

const handleSourceTableChange = () => {
	resetIncrementalSelection();
	form.incrementalStartValue = '';
	loadSourceColumns();
};

const handleSyncModeChange = () => {
	if (!isIncremental.value) {
		resetIncrementalSelection();
		form.incrementalStartValue = '';
		return;
	}
	if (form.syncMode === 'FULL_THEN_INCREMENTAL') {
		incrementalColumnRows.value.forEach((item) => {
			item.initialValue = '';
		});
		form.incrementalStartValue = '';
	}
	if (!incrementalColumnRows.value.length && eligibleIncrementalColumns.value.length) addIncrementalColumn();
};

const handleScheduleTypeChange = () => {
	if (form.scheduleType === 'CRON' && !form.cronExpression?.trim()) form.cronExpression = defaultCronExpression;
	if (isDwdProcess.value && form.scheduleType === 'MANUAL') form.dependencyTaskIds = [];
	nextTick(() => formRef.value?.validateField('cronExpression').catch(() => undefined));
};

const restoreIncrementalColumns = (detail: LayeredTaskDetail) => {
	const typeNames = String(detail.incrementalColumnType || '')
		.split(',')
		.map((item) => item.trim())
		.filter(Boolean);
	const detailColumns = detail.incrementalColumnDetails?.length
		? [...detail.incrementalColumnDetails].sort((left, right) => (left.order || 0) - (right.order || 0))
		: undefined;
	const rawColumns = detailColumns || detail.incrementalColumns;
	const names = Array.isArray(rawColumns)
		? rawColumns.map((item) => item.name)
		: String(rawColumns || detail.incrementalColumn || '')
				.split(',')
				.map((item) => item.trim())
				.filter(Boolean);
	const legacyInitialValues: Record<string, string> = {};
	if (names.length === 1) {
		legacyInitialValues[names[0]] = String(detail.incrementalStartValue || '');
	} else if (detail.incrementalStartValue) {
		try {
			const parsed = JSON.parse(detail.incrementalStartValue) as Record<string, unknown>;
			if (parsed && !Array.isArray(parsed) && typeof parsed === 'object') {
				names.forEach((name) => {
					if (Object.prototype.hasOwnProperty.call(parsed, name)) legacyInitialValues[name] = String(parsed[name] ?? '');
				});
			}
		} catch {
			// 旧复合任务可能没有合法 JSON 水位，保留为空并交由用户补充。
		}
	}
	form.incrementalColumns = names.slice(0, 3).map((name, index) => {
		const arrayItem = Array.isArray(rawColumns) ? rawColumns[index] : undefined;
		const rawType = arrayItem?.type || typeNames[index];
		const type = incrementalColumnTypes.includes(rawType as IncrementalColumnType) ? (rawType as IncrementalColumnType) : 'STRING';
		const initialValue = detail.syncMode === 'INCREMENTAL' ? arrayItem?.initialValue ?? legacyInitialValues[name] ?? '' : '';
		const sourceColumn = eligibleIncrementalColumns.value.find((item) => item.columnName === name);
		const placeholder =
			arrayItem?.initialValuePlaceholder ||
			sourceColumn?.initialValuePlaceholder ||
			getInitialValuePlaceholder(sourceColumn?.dataType || sourceColumn?.columnType || rawType);
		return createIncrementalColumn(name, type, arrayItem?.order || index + 1, String(initialValue), placeholder);
	});
	updateIncrementalOrders();
	form.incrementalColumn = form.incrementalColumns.map((item) => item.name).join(',');
	form.incrementalColumnType = form.incrementalColumns.map((item) => item.type).join(',');
};

const normalizeTaskDetail = (detail: LayeredTaskDetail): LayeredTaskDetail => ({
	...detail,
	id: String(detail.id),
	warehouseLayer: detail.warehouseLayer || 'ODS',
	targetTableMode: detail.taskType === 'SOURCE_SYNC' ? detail.targetTableMode || 'APPEND' : undefined,
	dwdVersionId: detail.dwdVersionId ? String(detail.dwdVersionId) : '',
	sourceDeleteStrategy: detail.sourceDeleteStrategy || 'IGNORE',
	reconciliationIntervalMinutes: detail.reconciliationIntervalMinutes ?? 1440,
	reconciliationMaxDeleteRows: detail.reconciliationMaxDeleteRows ?? 1000,
	businessSystemId: detail.businessSystemId ? String(detail.businessSystemId) : undefined,
	businessDomainId: detail.businessDomainId ? String(detail.businessDomainId) : undefined,
	sourceDatasourceId: String(detail.sourceDatasourceId || ''),
	targetDatasourceId: String(detail.targetDatasourceId || ''),
	relatedModelId: detail.relatedModelId ? String(detail.relatedModelId) : null,
	entityTableId: detail.entityTableId ? String(detail.entityTableId) : null,
	timezone: detail.timezone?.trim() || 'Asia/Shanghai',
	dsProfileId: String(detail.dsProfileId || ''),
	seatunnelProfileId: detail.seatunnelProfileId ? String(detail.seatunnelProfileId) : undefined,
	dependencyTaskIds: (detail.dependencyTaskIds || []).map(String),
});

const openDrawer = async (taskId?: string, initialLayer: 'ODS' | 'DWD' = 'ODS') => {
	clearSchemaPrecheckTimer();
	clearTargetTableNameTimer();
	++schemaPrecheckRequestId;
	++targetTableNameRequestId;
	visible.value = true;
	editingTaskId.value = taskId ? String(taskId) : '';
	Object.assign(form, defaultForm(), !taskId && initialLayer === 'DWD' ? { warehouseLayer: 'DWD', taskType: 'DWD_PROCESS' } : {});
	dwdModelId.value = '';
	dwdVersions.value = [];
	++dwdVersionRequestId;
	dwdVersionLoading.value = false;
	Object.assign(dimBinding, {
		relatedModelName: '',
		entityTableName: '',
		targetDatasourceName: '',
		databaseName: '',
		physicalName: '',
		scdType: '',
	});
	sourceTables.value = [];
	sourceColumns.value = [];
	businessDomains.value = [];
	schemaPrecheckResult.value = undefined;
	schemaPrecheckError.value = '';
	schemaChecking.value = false;
	targetTableGenerating.value = false;
	lastAutoGeneratedTargetTable.value = '';
	incrementalColumnsError.value = '';
	await nextTick();
	formRef.value?.clearValidate();
	try {
		loading.value = true;
		await loadBaseOptions();
		if (editingTaskId.value) {
			const res = await getLayeredTask(editingTaskId.value);
			const detail = normalizeTaskDetail(res.data as LayeredTaskDetail);
			const usedLegacyMerge = String(detail.incrementalStrategy || '').toUpperCase() === 'MERGE';
			const formDetail = { ...detail };
			delete formDetail.incrementalColumns;
			delete formDetail.incrementalColumnDetails;
			Object.assign(form, defaultForm(), formDetail, { taskCode: detail.taskCode || '' });
			if (detail.taskType === 'DIM_BUILD') {
				form.warehouseLayer = 'DIM';
				form.syncMode = 'FULL';
				Object.assign(dimBinding, {
					relatedModelName: detail.relatedModelName || '',
					entityTableName: detail.entityTableName || '',
					targetDatasourceName: detail.targetDatasourceName || '',
					databaseName: detail.databaseName || '',
					physicalName: detail.physicalName || '',
					scdType: detail.scdType || '',
				});
			}
			if (detail.taskType === 'DWD_PROCESS') {
				form.warehouseLayer = 'DWD';
				form.syncMode = detail.syncMode || 'FULL';
				await loadDwdModels();
				dwdModelId.value = detail.relatedModelId || '';
				if (!form.dwdVersionId) {
					const versionRes = await fetchSyncTaskVersions(editingTaskId.value);
					const data = versionRes.data as SyncTaskVersion[] | PageResult<SyncTaskVersion>;
					const versions = Array.isArray(data) ? data : data?.records || [];
					const currentVersion = versions.find((item) => String(item.id || item.versionId) === String(detail.currentVersionId || '')) ||
						versions.find((item) => item.versionNo === detail.currentVersionNo);
					form.dwdVersionId = currentVersion?.dwdVersionId ? String(currentVersion.dwdVersionId) : '';
				}
				if (dwdModelId.value) await loadDwdVersions(dwdModelId.value);
			}
			if (usedLegacyMerge) {
				form.incrementalStrategy = 'APPEND';
				useMessage().warning('该任务使用已停止支持的 MERGE 策略，已切换为“追加”，请确认后再保存');
			}
			await loadBusinessDomains(form.businessSystemId);
			if (!isDimBuild.value && !isDwdProcess.value) {
				await loadSourceTables(form.sourceTable || '');
				if (form.sourceTable && !sourceTables.value.some((item) => qualifiedTableName(item) === form.sourceTable))
					sourceTables.value.unshift({ tableName: form.sourceTable });
				await loadSourceColumns();
				restoreIncrementalColumns(detail);
			}
		} else if (isDwdProcess.value) {
			await loadDwdModels();
		}
	} catch (error: any) {
		visible.value = false;
		useMessage().error(error?.msg || '加载任务配置失败');
	} finally {
		loading.value = false;
	}
};

watch(() => [form.sourceDatasourceId, form.sourceTable, form.targetDatasourceId, form.targetTable, form.targetTableMode], scheduleSchemaPrecheck);
watch(() => [form.warehouseLayer, form.businessSystemId, form.sourceTable], scheduleTargetTableNameGeneration);

watch(visible, (value) => {
	if (!value) {
		clearSchemaPrecheckTimer();
		clearTargetTableNameTimer();
		++schemaPrecheckRequestId;
		++targetTableNameRequestId;
		++dwdVersionRequestId;
		targetTableGenerating.value = false;
		dwdVersionLoading.value = false;
	}
});

onBeforeUnmount(() => {
	clearSchemaPrecheckTimer();
	clearTargetTableNameTimer();
});

const buildPayload = (): SyncTaskSaveRequest | DwdSyncTaskSaveRequest => {
	if (isDwdProcess.value) {
		return {
			taskName: form.taskName.trim(),
			taskCode: form.taskCode?.trim() || undefined,
			description: form.description?.trim() || undefined,
			warehouseLayer: 'DWD',
			taskType: 'DWD_PROCESS',
			dwdVersionId: String(form.dwdVersionId),
			syncMode: 'FULL',
			scheduleType: form.scheduleType,
			seatunnelProfileId: String(form.seatunnelProfileId),
			batchSize: form.batchSize,
			retryTimes: form.retryTimes,
			retryIntervalMinutes: form.retryIntervalMinutes,
			replicaDatabase: form.replicaDatabase?.trim() || undefined,
			...(form.scheduleType === 'CRON'
				? {
					cronExpression: form.cronExpression?.trim(),
					timezone: form.timezone,
					dsProfileId: form.dsProfileId,
					dependencyTaskIds: form.dependencyTaskIds.map(String),
				  }
				: {}),
		};
	}
	const commonPayload = {
		businessSystemId: form.businessSystemId || undefined,
		businessDomainId: form.businessDomainId || undefined,
		description: form.description?.trim() || undefined,
		taskCode: form.taskCode?.trim() || undefined,
		taskName: form.taskName.trim(),
		targetDatasourceId: form.targetDatasourceId,
		targetTable: form.targetTable.trim(),
		cronExpression: form.scheduleType === 'CRON' ? form.cronExpression?.trim() : undefined,
		scheduleType: form.scheduleType,
		timezone: form.timezone,
		batchSize: form.batchSize,
		retryTimes: form.retryTimes,
		retryIntervalMinutes: form.retryIntervalMinutes,
		dsProfileId: form.dsProfileId,
		dependencyTaskIds: form.dependencyTaskIds.map(String),
	};
	if (isDimBuild.value) {
		return {
			...commonPayload,
			warehouseLayer: 'DIM',
			taskType: 'DIM_BUILD',
			relatedModelId: form.relatedModelId,
			syncMode: 'FULL',
		};
	}
	const payload: SyncTaskSaveRequest = {
		...form,
		...commonPayload,
		sourceTable: form.sourceTable?.trim() || '',
	};
	if (!isIncremental.value) {
		payload.incrementalColumn = undefined;
		payload.incrementalColumns = undefined;
		payload.incrementalColumnType = undefined;
		payload.incrementalStrategy = undefined;
		payload.incrementalStartValue = undefined;
		payload.sourceDeleteStrategy = undefined;
		payload.reconciliationIntervalMinutes = undefined;
		payload.reconciliationMaxDeleteRows = undefined;
		payload.watermarkStorage = undefined;
	} else {
		const incrementalColumns = incrementalColumnRows.value.map((item, index) => {
			const column = {
				name: item.name,
				type: item.type,
				order: index + 1,
			} as IncrementalColumnConfig;
			if (form.syncMode === 'INCREMENTAL') column.initialValue = item.initialValue?.trim() || '';
			return column;
		});
		payload.incrementalColumns = incrementalColumns;
		payload.incrementalColumn = incrementalColumns.map((item) => item.name).join(',');
		payload.incrementalColumnType = incrementalColumns.map((item) => item.type).join(',');
		payload.incrementalStartValue =
			form.syncMode === 'INCREMENTAL'
				? incrementalColumns.length === 1
					? incrementalColumns[0].initialValue
					: JSON.stringify(Object.fromEntries(incrementalColumns.map((item) => [item.name, item.initialValue])))
				: undefined;
		if (payload.sourceDeleteStrategy !== 'MARK_DELETED') {
			payload.reconciliationIntervalMinutes = undefined;
			payload.reconciliationMaxDeleteRows = undefined;
		}
	}
	return payload;
};

const handleSubmit = async () => {
	if (isDwdProcess.value && seatunnelProfiles.value.find((item) => item.id === form.seatunnelProfileId)?.enabled === false) {
		useMessage().warning('请选择已启用的 SeaTunnel 档案');
		return;
	}
	if (isDwdProcess.value && form.scheduleType === 'CRON' && dsProfiles.value.find((item) => item.id === form.dsProfileId)?.enabled === false) {
		useMessage().warning('请选择已启用的 DolphinScheduler 档案');
		return;
	}
	if (isDwdProcess.value && form.syncMode !== 'FULL') {
		useMessage().warning('当前表单仅支持全量明细加工；已有增量任务配置不会被改写');
		return;
	}
	if (isDwdProcess.value && !dwdModelId.value) {
		useMessage().warning('请先选择明细模型');
		return;
	}
	if (isDwdProcess.value && !dwdVersions.value.some((item) => item.id === form.dwdVersionId)) {
		useMessage().warning('请选择当前明细模型的有效冻结版本');
		return;
	}
	if (isDimBuild.value && !['SCD0', 'SCD1'].includes(dimBinding.scdType)) {
		useMessage().warning('DIM 物化仅支持绑定 SCD0 或 SCD1 的 ENTITY 表');
		return;
	}
	if (!isDimBuild.value && !isDwdProcess.value && !form.targetTable.trim()) {
		clearTargetTableNameTimer();
		await loadGeneratedTargetTableName();
	}
	if (!isDimBuild.value && !isDwdProcess.value && !restInternalUrlConfigured.value) {
		useMessage().warning('SeaTunnel REST 模式要求所选 DS 档案配置 dataPlatformInternalUrl');
		return;
	}
	if (!isDimBuild.value && !isDwdProcess.value && form.syncMode === 'FULL_THEN_INCREMENTAL' && !isRestRuntime.value) {
		useMessage().warning('首次全量后增量仅支持 SeaTunnel REST 档案');
		return;
	}
	if (!isDimBuild.value && !isDwdProcess.value && incrementalColumnRows.value.length > 1 && !isRestRuntime.value) {
		useMessage().warning('复合增量游标仅支持 SeaTunnel REST 档案');
		return;
	}
	if (!validateIncrementalColumns()) return;
	if (
		isIncremental.value &&
		form.sourceDeleteStrategy === 'MARK_DELETED' &&
		(!form.reconciliationIntervalMinutes || form.reconciliationIntervalMinutes < 5 || form.reconciliationIntervalMinutes > 100000)
	) {
		useMessage().warning('全量对账间隔必须在5至100000分钟之间');
		return;
	}
	if (
		isIncremental.value &&
		form.sourceDeleteStrategy === 'MARK_DELETED' &&
		(!form.reconciliationMaxDeleteRows || form.reconciliationMaxDeleteRows < 1 || form.reconciliationMaxDeleteRows > 1000000)
	) {
		useMessage().warning('单次最大标记数必须在1至1000000条之间');
		return;
	}
	if (form.scheduleType === 'CRON' && cronScheduleBuilderRef.value?.validate() === false) {
		useMessage().warning('Cron 表达式格式不正确，请检查定时规则');
		return;
	}
	const valid = await formRef.value?.validate().catch(() => false);
	if (!valid) return;
	if (form.dependencyTaskIds.length > 100) {
		useMessage().warning('前置依赖最多选择100个');
		return;
	}
	try {
		submitting.value = true;
		const res = editingTaskId.value ? await updateSyncTask(editingTaskId.value, buildPayload()) : await createSyncTask(buildPayload());
		const result = res.data as SyncTaskSaveResult;
		const normalizedResult = { taskId: String(result.taskId), versionId: String(result.versionId) };
		useMessage().success(
			isDwdProcess.value
				? editingTaskId.value
					? '明细加工配置已保存为新任务版本，请重新发布后执行'
					: '明细加工任务草稿已创建，请发布任务版本后执行'
				: editingTaskId.value
					? '任务修改已保存为新版本'
					: '任务草稿创建成功'
		);
		visible.value = false;
		emit('saved', normalizedResult);
	} catch (error: any) {
		useMessage().error(error?.msg || '保存任务失败');
	} finally {
		submitting.value = false;
	}
};

defineExpose({ openDrawer });
</script>

<style scoped>
.task-form {
	padding: 0 4px 20px;
}

.task-form :deep(.el-form-item__label) {
	white-space: nowrap;
}

.task-form :deep(.el-form-item) {
	margin-bottom: 24px !important;
}

.task-form :deep(.el-divider--horizontal) {
	margin: 28px 0 22px;
}

.task-form :deep(.el-divider__text) {
	font-size: 15px;
	font-weight: 600;
}

.field-unit {
	margin-left: 8px;
	color: var(--el-text-color-secondary);
}

.compound-columns {
	display: flex;
	width: 100%;
	flex-direction: column;
	gap: 10px;
}

.compound-column-row {
	display: flex;
	align-items: center;
	gap: 8px;
}

.compound-column-order {
	display: inline-flex;
	width: 24px;
	height: 24px;
	align-items: center;
	justify-content: center;
	border-radius: 50%;
	background: var(--el-fill-color-light);
	color: var(--el-text-color-secondary);
}

.compound-column-field {
	flex: 1;
}

.compound-column-type {
	width: 170px;
}

.compound-column-initial-value {
	width: 220px;
}

.compound-column-initial-value-not-required {
	width: 220px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.incremental-order-tip {
	color: var(--el-text-color-secondary);
	font-size: 12px;
	line-height: 20px;
}

.source-delete-configuration {
	width: 100%;
}

.configuration-help {
	margin-top: 6px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
	line-height: 20px;
}

.reconciliation-tip {
	margin-bottom: 18px;
}

.source-table-empty {
	padding: 12px 16px;
	color: var(--el-text-color-secondary);
	line-height: 22px;
	text-align: center;
}

.target-table-mode {
	width: 100%;
}

.target-table-field {
	width: 100%;
}

.target-table-name-help,
.target-table-generating,
.target-table-format-warning {
	margin-top: 6px;
	font-size: 12px;
	line-height: 20px;
}

.target-table-name-help,
.target-table-generating {
	color: var(--el-text-color-secondary);
}

.target-table-name-help {
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 12px;
}

.target-table-name-help .el-button {
	flex: none;
	padding: 0;
}

.target-table-format-warning {
	color: var(--el-color-warning);
}

.target-table-help {
	width: 100%;
	margin-top: 10px;
	color: var(--el-text-color-secondary);
	font-size: 12px;
	line-height: 20px;
}

.target-table-mode-options {
	display: grid;
	width: 100%;
	grid-template-columns: repeat(2, minmax(0, 1fr));
	gap: 14px;
}

.target-table-mode-option {
	width: 100%;
	height: auto;
	min-height: 64px;
	padding: 12px 16px;
	margin: 0;
}

.target-table-mode-option :deep(.el-radio__label) {
	display: flex;
	min-width: 0;
	flex-direction: column;
	gap: 4px;
}

.target-table-mode-title {
	font-weight: 600;
}

.target-table-mode-summary {
	color: var(--el-text-color-secondary);
	font-size: 12px;
}

.target-table-warning {
	margin-top: 8px;
}

.schema-precheck-panel {
	min-height: 48px;
	padding: 14px;
	margin-bottom: 18px;
	border: 1px solid var(--el-border-color-light);
	border-radius: 4px;
}

@media (max-width: 1199px) {
	.task-form :deep(.el-col-12) {
		max-width: 100%;
		flex: 0 0 100%;
	}
}

@media (max-width: 767px) {
	.task-form {
		padding-inline: 0;
	}

	.task-form :deep(.el-form-item) {
		margin-bottom: 20px !important;
	}

	.target-table-mode-options {
		grid-template-columns: 1fr;
	}

	.target-table-name-help {
		align-items: flex-start;
		flex-direction: column;
		gap: 2px;
	}
}
</style>
