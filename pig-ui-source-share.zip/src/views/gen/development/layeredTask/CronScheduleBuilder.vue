<template>
	<div class="cron-schedule-builder">
		<div class="config-row">
			<span class="config-label">配置方式</span>
			<el-radio-group v-model="configMode" @change="handleModeChange">
				<el-radio value="SIMPLE">简单配置</el-radio>
				<el-radio value="ADVANCED">高级 Cron</el-radio>
			</el-radio-group>
		</div>

		<template v-if="configMode === 'SIMPLE'">
			<div class="config-row">
				<span class="config-label">执行频率</span>
				<el-select v-model="frequency" style="width: 260px" @change="handleFrequencyChange">
					<el-option label="每隔一段时间" value="INTERVAL" />
					<el-option label="每天" value="DAILY" />
					<el-option label="每周" value="WEEKLY" />
					<el-option label="每月" value="MONTHLY" />
					<el-option label="工作日" value="WEEKDAY" />
					<el-option label="自定义 Cron" value="CUSTOM" />
				</el-select>
			</div>

			<div v-if="frequency === 'INTERVAL'" class="config-row">
				<span class="config-label">间隔</span>
				<el-input-number v-model="intervalValue" :min="1" :max="intervalMax" controls-position="right" @change="updateSimpleExpression" />
				<el-select v-model="intervalUnit" style="width: 110px" @change="handleIntervalUnitChange">
					<el-option label="秒" value="SECOND" />
					<el-option label="分钟" value="MINUTE" />
					<el-option label="小时" value="HOUR" />
				</el-select>
			</div>

			<div v-if="frequency === 'WEEKLY'" class="config-row config-row-start">
				<span class="config-label">星期</span>
				<el-checkbox-group v-model="weekdays" @change="updateSimpleExpression">
					<el-checkbox v-for="item in weekdayOptions" :key="item.value" :value="item.value">{{ item.label }}</el-checkbox>
				</el-checkbox-group>
			</div>

			<div v-if="frequency === 'MONTHLY'" class="config-row config-row-start">
				<span class="config-label">每月日期</span>
				<el-select v-model="monthDays" multiple collapse-tags collapse-tags-tooltip style="width: 360px" @change="updateSimpleExpression">
					<el-option v-for="day in 31" :key="day" :label="`${day} 日`" :value="day" />
				</el-select>
			</div>

			<div v-if="showExecutionTimes" class="config-row config-row-start">
				<span class="config-label">执行时间</span>
				<div class="time-list">
					<div v-for="(_time, index) in executionTimes" :key="index" class="time-row">
						<el-time-picker
							v-model="executionTimes[index]"
							format="HH:mm"
							value-format="HH:mm"
							:clearable="false"
							placeholder="选择时间"
							@change="updateSimpleExpression"
						/>
						<el-button v-if="executionTimes.length > 1" text type="danger" @click="removeExecutionTime(index)">删除</el-button>
					</div>
					<el-button type="primary" text :disabled="executionTimes.length >= 8" @click="addExecutionTime">+ 添加时间</el-button>
					<span v-if="executionTimes.length > 1" class="config-help">多个时间需使用相同的分钟，例如 09:00、18:00。</span>
				</div>
			</div>
		</template>

		<div v-else class="advanced-panel">
			<el-input v-model="advancedExpression" clearable placeholder="例如：0 0/10 * * * ?" @input="updateAdvancedExpression" />
			<div class="config-help">格式：秒 分 时 日 月 周。支持范围、L、# 等 Spring/Quartz 六段语法。</div>
			<div class="advanced-examples">
				<span>示例：</span>
				<el-button text type="primary" @click="useAdvancedExample('0 0 9-18 * * ?')">工作时段每小时</el-button>
				<el-button text type="primary" @click="useAdvancedExample('0 0 2 L * ?')">每月最后一天</el-button>
				<el-button text type="primary" @click="useAdvancedExample('0 0 2 ? * MON#1')">每月第一个周一</el-button>
			</div>
		</div>

		<div class="cron-result" :class="{ 'is-error': Boolean(cronStatus.error) }">
			<template v-if="cronStatus.error">
				<div>{{ cronStatus.error }}</div>
			</template>
			<template v-else>
				<div><strong>当前规则：</strong>{{ cronDescription }}</div>
				<div><strong>下次执行：</strong>{{ cronStatus.nextTime }}</div>
				<div class="cron-expression"><strong>Cron：</strong>{{ expression }}</div>
			</template>
		</div>
	</div>
</template>

<script setup lang="ts" name="CronScheduleBuilder">
import { CronExpressionParser } from 'cron-parser';

type ConfigMode = 'SIMPLE' | 'ADVANCED';
type Frequency = 'INTERVAL' | 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'WEEKDAY' | 'CUSTOM';
type IntervalUnit = 'SECOND' | 'MINUTE' | 'HOUR';

const DEFAULT_CRON = '0 0/10 * * * ?';
const props = withDefaults(defineProps<{ modelValue?: string; timezone?: string }>(), {
	modelValue: '',
	timezone: 'Asia/Shanghai',
});
const emit = defineEmits<{ 'update:modelValue': [value: string] }>();

const configMode = ref<ConfigMode>('SIMPLE');
const frequency = ref<Frequency>('INTERVAL');
const intervalValue = ref(10);
const intervalUnit = ref<IntervalUnit>('MINUTE');
const executionTimes = ref<string[]>(['02:00']);
const weekdays = ref<string[]>(['MON']);
const monthDays = ref<number[]>([1]);
const advancedExpression = ref('');
const expression = ref('');
const simpleError = ref('');
const clock = ref(Date.now());
let clockTimer: ReturnType<typeof setInterval> | undefined;

const weekdayOptions = [
	{ label: '周一', value: 'MON' },
	{ label: '周二', value: 'TUE' },
	{ label: '周三', value: 'WED' },
	{ label: '周四', value: 'THU' },
	{ label: '周五', value: 'FRI' },
	{ label: '周六', value: 'SAT' },
	{ label: '周日', value: 'SUN' },
];

const intervalMax = computed(() => (intervalUnit.value === 'HOUR' ? 23 : 59));
const showExecutionTimes = computed(() => ['DAILY', 'WEEKLY', 'MONTHLY', 'WEEKDAY'].includes(frequency.value));

const emitExpression = (value: string) => {
	expression.value = value;
	emit('update:modelValue', value);
};

const parseTime = (value: string) => {
	const [hour, minute] = String(value || '').split(':');
	return { hour: Number(hour), minute: Number(minute) };
};

const sortedUniqueNumbers = (values: number[]) => [...new Set(values)].sort((left, right) => left - right);
const sortedUniqueStrings = (values: string[]) => [...new Set(values)];

const buildTimeParts = () => {
	if (!executionTimes.value.length || executionTimes.value.some((item) => !/^\d{2}:\d{2}$/.test(item))) {
		return { error: '请至少配置一个合法的执行时间' };
	}
	const parsedTimes = executionTimes.value.map(parseTime);
	const minutes = sortedUniqueNumbers(parsedTimes.map((item) => item.minute));
	if (minutes.length > 1) return { error: '单个 Cron 的多个执行时间必须使用相同分钟，请改用高级 Cron' };
	const hours = sortedUniqueNumbers(parsedTimes.map((item) => item.hour));
	return { minute: minutes[0], hours: hours.join(',') };
};

const buildSimpleCron = (): { cron?: string; error?: string } => {
	if (frequency.value === 'INTERVAL') {
		const value = Number(intervalValue.value);
		if (!Number.isInteger(value) || value < 1 || value > intervalMax.value) return { error: `间隔必须为 1 至 ${intervalMax.value} 的整数` };
		if (intervalUnit.value === 'SECOND') return { cron: `0/${value} * * * * ?` };
		if (intervalUnit.value === 'MINUTE') return { cron: `0 0/${value} * * * ?` };
		return { cron: `0 0 0/${value} * * ?` };
	}

	const timeParts = buildTimeParts();
	if (timeParts.error) return timeParts;
	if (frequency.value === 'DAILY') return { cron: `0 ${timeParts.minute} ${timeParts.hours} * * ?` };
	if (frequency.value === 'WEEKDAY') return { cron: `0 ${timeParts.minute} ${timeParts.hours} ? * MON-FRI` };
	if (frequency.value === 'WEEKLY') {
		if (!weekdays.value.length) return { error: '请至少选择一个星期' };
		return { cron: `0 ${timeParts.minute} ${timeParts.hours} ? * ${sortedUniqueStrings(weekdays.value).join(',')}` };
	}
	if (frequency.value === 'MONTHLY') {
		if (!monthDays.value.length) return { error: '请至少选择一个每月执行日期' };
		return { cron: `0 ${timeParts.minute} ${timeParts.hours} ${sortedUniqueNumbers(monthDays.value).join(',')} * ?` };
	}
	return { error: '请选择执行频率' };
};

const updateSimpleExpression = () => {
	if (configMode.value !== 'SIMPLE' || frequency.value === 'CUSTOM') return;
	const result = buildSimpleCron();
	simpleError.value = result.error || '';
	emitExpression(result.cron || '');
};

const handleIntervalUnitChange = () => {
	intervalValue.value = Math.min(Math.max(Number(intervalValue.value) || 1, 1), intervalMax.value);
	updateSimpleExpression();
};

const updateAdvancedExpression = () => {
	simpleError.value = '';
	emitExpression(advancedExpression.value.trim());
};

const addExecutionTime = () => {
	if (executionTimes.value.length >= 8) return;
	const base = parseTime(executionTimes.value[0] || '00:00');
	const usedHours = new Set(executionTimes.value.map((item) => parseTime(item).hour));
	let nextHour = base.hour;
	for (let offset = 1; offset < 24; offset += 1) {
		const candidate = (base.hour + offset) % 24;
		if (!usedHours.has(candidate)) {
			nextHour = candidate;
			break;
		}
	}
	executionTimes.value.push(`${String(nextHour).padStart(2, '0')}:${String(base.minute).padStart(2, '0')}`);
	updateSimpleExpression();
};

const removeExecutionTime = (index: number) => {
	executionTimes.value.splice(index, 1);
	updateSimpleExpression();
};

const resetSimpleConfig = () => {
	frequency.value = 'INTERVAL';
	intervalUnit.value = 'MINUTE';
	intervalValue.value = 10;
	executionTimes.value = ['02:00'];
	weekdays.value = ['MON'];
	monthDays.value = [1];
};

const parseNumericList = (value: string, min: number, max: number) => {
	const values = value.split(',').map(Number);
	return values.length > 0 && values.every((item) => Number.isInteger(item) && item >= min && item <= max) ? values : undefined;
};

const hydrateSimpleExpression = (value: string) => {
	const fields = value.trim().split(/\s+/);
	if (fields.length !== 6) return false;
	const [second, minute, hour, dayOfMonth, month, dayOfWeek] = fields;
	if (month !== '*') return false;

	let match = second.match(/^0\/(\d+)$/);
	if (match && minute === '*' && hour === '*' && dayOfMonth === '*' && dayOfWeek === '?') {
		frequency.value = 'INTERVAL';
		intervalUnit.value = 'SECOND';
		intervalValue.value = Number(match[1]);
		return true;
	}
	match = minute.match(/^0\/(\d+)$/);
	if (second === '0' && match && hour === '*' && dayOfMonth === '*' && dayOfWeek === '?') {
		frequency.value = 'INTERVAL';
		intervalUnit.value = 'MINUTE';
		intervalValue.value = Number(match[1]);
		return true;
	}
	match = hour.match(/^0\/(\d+)$/);
	if (second === '0' && minute === '0' && match && dayOfMonth === '*' && dayOfWeek === '?') {
		frequency.value = 'INTERVAL';
		intervalUnit.value = 'HOUR';
		intervalValue.value = Number(match[1]);
		return true;
	}

	if (second !== '0' || !/^\d+$/.test(minute)) return false;
	const hours = parseNumericList(hour, 0, 23);
	if (!hours) return false;
	executionTimes.value = hours.map((item) => `${String(item).padStart(2, '0')}:${String(Number(minute)).padStart(2, '0')}`);
	if (dayOfMonth === '*' && dayOfWeek === '?') {
		frequency.value = 'DAILY';
		return true;
	}
	if (dayOfMonth === '?' && dayOfWeek === 'MON-FRI') {
		frequency.value = 'WEEKDAY';
		return true;
	}
	if (dayOfMonth === '?' && dayOfWeek !== '?' && dayOfWeek !== '*') {
		const values = dayOfWeek.split(',');
		if (!values.every((item) => weekdayOptions.some((option) => option.value === item))) return false;
		frequency.value = 'WEEKLY';
		weekdays.value = values;
		return true;
	}
	if (dayOfWeek === '?') {
		const values = parseNumericList(dayOfMonth, 1, 31);
		if (!values) return false;
		frequency.value = 'MONTHLY';
		monthDays.value = values;
		return true;
	}
	return false;
};

const hydrateExpression = (value?: string) => {
	const normalized = value?.trim() || DEFAULT_CRON;
	expression.value = normalized;
	if (hydrateSimpleExpression(normalized)) {
		configMode.value = 'SIMPLE';
		simpleError.value = '';
	} else {
		configMode.value = 'ADVANCED';
		advancedExpression.value = normalized;
	}
	if (!value?.trim()) emit('update:modelValue', normalized);
};

const handleModeChange = (mode: ConfigMode) => {
	if (mode === 'ADVANCED') {
		advancedExpression.value = expression.value || DEFAULT_CRON;
		updateAdvancedExpression();
		return;
	}
	if (!hydrateSimpleExpression(expression.value)) resetSimpleConfig();
	updateSimpleExpression();
};

const handleFrequencyChange = (value: Frequency) => {
	if (value === 'CUSTOM') {
		configMode.value = 'ADVANCED';
		advancedExpression.value = expression.value || DEFAULT_CRON;
		updateAdvancedExpression();
		return;
	}
	updateSimpleExpression();
};

const useAdvancedExample = (value: string) => {
	advancedExpression.value = value;
	updateAdvancedExpression();
};

const timeText = (minute: string, hour: string) =>
	hour
		.split(',')
		.map((item) => `${String(Number(item)).padStart(2, '0')}:${String(Number(minute)).padStart(2, '0')}`)
		.join('、');

const describeCron = (value: string) => {
	const fields = value.trim().split(/\s+/);
	if (fields.length !== 6) return 'Cron 表达式';
	const [second, minute, hour, dayOfMonth, month, dayOfWeek] = fields;
	let match = second.match(/^0\/(\d+)$/);
	if (match && minute === '*' && hour === '*') return `每 ${match[1]} 秒执行一次`;
	match = minute.match(/^0\/(\d+)$/);
	if (second === '0' && match && hour === '*') return `每 ${match[1]} 分钟执行一次`;
	match = hour.match(/^0\/(\d+)$/);
	if (second === '0' && minute === '0' && match) return `每 ${match[1]} 小时执行一次`;
	if (second === '0' && /^\d+$/.test(minute) && /^\d+(,\d+)*$/.test(hour) && month === '*') {
		const times = timeText(minute, hour);
		if (dayOfMonth === '*' && dayOfWeek === '?') return `每天 ${times} 执行`;
		if (dayOfMonth === '?' && dayOfWeek === 'MON-FRI') return `工作日 ${times} 执行`;
		if (dayOfMonth === '?' && dayOfWeek !== '?') {
			const labels = dayOfWeek
				.split(',')
				.map((item) => weekdayOptions.find((option) => option.value === item)?.label || item)
				.join('、');
			return `每周${labels} ${times} 执行`;
		}
		if (dayOfWeek === '?' && /^\d+(,\d+)*$/.test(dayOfMonth)) return `每月 ${dayOfMonth.replace(/,/g, '、')} 日 ${times} 执行`;
	}
	if (second === '0' && minute === '0' && hour === '9-18' && dayOfMonth === '*' && month === '*' && dayOfWeek === '?')
		return '每天 09:00 至 18:00 每小时执行一次';
	if (second === '0' && /^\d+$/.test(minute) && /^\d+$/.test(hour) && dayOfMonth === 'L' && month === '*' && dayOfWeek === '?')
		return `每月最后一天 ${timeText(minute, hour)} 执行`;
	const nthWeekday = dayOfWeek.match(/^(SUN|MON|TUE|WED|THU|FRI|SAT)#([1-5])$/);
	if (second === '0' && /^\d+$/.test(minute) && /^\d+$/.test(hour) && dayOfMonth === '?' && month === '*' && nthWeekday) {
		const label = weekdayOptions.find((item) => item.value === nthWeekday[1])?.label || nthWeekday[1];
		return `每月第 ${nthWeekday[2]} 个${label} ${timeText(minute, hour)} 执行`;
	}
	return `按高级 Cron “${value}” 执行`;
};

const formatDateInTimezone = (date: Date, timezone: string) => {
	const formatter = new Intl.DateTimeFormat('zh-CN', {
		timeZone: timezone,
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
		second: '2-digit',
		hourCycle: 'h23',
	});
	const parts = Object.fromEntries(formatter.formatToParts(date).map((item) => [item.type, item.value]));
	return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second}`;
};

const cronStatus = computed(() => {
	clock.value;
	if (simpleError.value) return { error: simpleError.value, nextTime: '' };
	const value = expression.value.trim();
	if (!value) return { error: '请配置定时规则', nextTime: '' };
	if (value.split(/\s+/).length !== 6) return { error: 'Cron 表达式格式不正确，请检查秒、分、时、日、月、周六个字段', nextTime: '' };
	try {
		const interval = CronExpressionParser.parse(value, { currentDate: new Date(), tz: props.timezone });
		return { error: '', nextTime: formatDateInTimezone(interval.next().toDate(), props.timezone) };
	} catch {
		return { error: 'Cron 表达式格式不正确，请检查秒、分、时、日、月、周六个字段', nextTime: '' };
	}
});

const cronDescription = computed(() => describeCron(expression.value));
const validate = () => !cronStatus.value.error;

watch(
	() => props.modelValue,
	(value) => {
		if ((value || '').trim() === expression.value) return;
		hydrateExpression(value);
	}
);

onMounted(() => {
	hydrateExpression(props.modelValue);
	clockTimer = setInterval(() => {
		clock.value = Date.now();
	}, 30000);
});

onBeforeUnmount(() => {
	if (clockTimer) clearInterval(clockTimer);
});

defineExpose({ validate });
</script>

<style scoped>
.cron-schedule-builder {
	display: flex;
	width: 100%;
	flex-direction: column;
	gap: 14px;
	padding: 14px;
	border: 1px solid var(--el-border-color-light);
	border-radius: 6px;
}

.config-row {
	display: flex;
	align-items: center;
	gap: 12px;
}

.config-row-start {
	align-items: flex-start;
}

.config-label {
	width: 72px;
	flex: none;
	color: var(--el-text-color-regular);
}

.time-list {
	display: flex;
	flex: 1;
	flex-direction: column;
	align-items: flex-start;
	gap: 8px;
}

.time-row {
	display: flex;
	align-items: center;
	gap: 8px;
}

.config-help {
	color: var(--el-text-color-secondary);
	font-size: 12px;
	line-height: 20px;
}

.advanced-panel {
	display: flex;
	flex-direction: column;
	gap: 8px;
}

.advanced-examples {
	display: flex;
	align-items: center;
	flex-wrap: wrap;
	color: var(--el-text-color-secondary);
}

.cron-result {
	padding: 12px 14px;
	border-radius: 4px;
	background: var(--el-color-success-light-9);
	color: var(--el-text-color-regular);
	line-height: 24px;
}

.cron-result.is-error {
	background: var(--el-color-danger-light-9);
	color: var(--el-color-danger);
}

.cron-expression {
	color: var(--el-text-color-secondary);
	font-family: monospace;
}
</style>
