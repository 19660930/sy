import type { LayeredTaskRunStatus, LayeredTaskStatus, LayeredTaskType, WarehouseLayer } from '/@/types/dataPlatform/layeredTask';

export const layerOptions: Array<{ value: WarehouseLayer; label: string; shortLabel: string; tagType: string }> = [
	{ value: 'ODS', label: '操作数据层', shortLabel: 'ODS任务', tagType: 'primary' },
	{ value: 'DIM', label: '维度层', shortLabel: 'DIM任务', tagType: 'success' },
	{ value: 'DWD', label: '明细数据层', shortLabel: 'DWD任务', tagType: 'info' },
	{ value: 'DWS', label: '汇总数据层', shortLabel: 'DWS任务', tagType: 'warning' },
	{ value: 'ADS', label: '应用数据层', shortLabel: 'ADS任务', tagType: 'danger' },
];

export const taskTypeOptions: Array<{ value: LayeredTaskType; label: string }> = [
	{ value: 'SOURCE_SYNC', label: '源表同步' },
	{ value: 'DIM_BUILD', label: '维度构建' },
	{ value: 'DWD_PROCESS', label: '明细加工' },
	{ value: 'FACT_BUILD', label: '事实表构建' },
	{ value: 'AGG_BUILD', label: '汇总表构建' },
	{ value: 'MODEL_BUILD', label: '模型构建' },
	{ value: 'MODEL_REFRESH', label: '模型刷新' },
];

export const runStatusOptions: Array<{ value: LayeredTaskRunStatus; label: string }> = [
	{ value: 'SUBMITTED', label: '已提交' },
	{ value: 'RUNNING', label: '运行中' },
	{ value: 'SUCCESS', label: '成功' },
	{ value: 'FAILURE', label: '失败' },
	{ value: 'STOPPED', label: '已停止' },
];

export const layerText = (layer?: WarehouseLayer) => layerOptions.find((item) => item.value === layer)?.label || layer || '--';

export const layerTagType = (layer?: WarehouseLayer) => layerOptions.find((item) => item.value === layer)?.tagType || 'info';

export const taskTypeText = (taskType?: LayeredTaskType) => taskTypeOptions.find((item) => item.value === taskType)?.label || taskType || '--';

const taskStatusLabels: Record<string, string> = { DRAFT: '草稿', PUBLISHED: '已上线', OFFLINE: '已下线' };
const taskStatusTagTypes: Record<string, string> = { DRAFT: 'warning', PUBLISHED: 'success', OFFLINE: 'info' };

export const taskStatusText = (status?: LayeredTaskStatus) => taskStatusLabels[status || ''] || status || '--';

export const taskStatusTagType = (status?: LayeredTaskStatus) => taskStatusTagTypes[status || ''] || 'info';

export const runStatusText = (status?: LayeredTaskRunStatus) => runStatusOptions.find((item) => item.value === status)?.label || status || '--';

export const runStatusTagType = (status?: LayeredTaskRunStatus) => {
	if (status === 'SUCCESS') return 'success';
	if (status === 'FAILURE') return 'danger';
	if (status === 'STOPPED') return 'warning';
	return status === 'RUNNING' || status === 'SUBMITTED' ? 'primary' : 'info';
};

export const syncModeText = (syncMode?: string) =>
	({ FULL: '全量同步', INCREMENTAL: '增量同步', FULL_THEN_INCREMENTAL: '首次全量后增量' }[syncMode || ''] || syncMode || '--');

export const triggerTypeText = (triggerType?: string) =>
	({ MANUAL: '手动触发', SCHEDULE: '定时调度', DEPENDENCY: '依赖触发' }[triggerType || ''] || triggerType || '--');

export const isActiveRunStatus = (status?: LayeredTaskRunStatus) => ['SUBMITTED', 'RUNNING'].includes(status || '');

export const formatRows = (rows?: string | number | null) => {
	if (rows === undefined || rows === null) return '--';
	const value = String(rows);
	const [integer, decimal] = value.split('.');
	const formattedInteger = integer.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return decimal === undefined ? formattedInteger : `${formattedInteger}.${decimal}`;
};

export const formatDuration = (seconds?: number) => {
	if (seconds === undefined || seconds === null) return '--';
	if (seconds < 60) return `${seconds}秒`;
	if (seconds < 3600) return `${Math.floor(seconds / 60)}分${seconds % 60}秒`;
	return `${Math.floor(seconds / 3600)}小时${Math.floor((seconds % 3600) / 60)}分`;
};
