<template>
	<el-drawer v-model="visible" title="任务详情" size="900px" :close-on-click-modal="false">
		<div v-loading="loading" class="task-detail">
			<el-tabs v-if="task" v-model="activeTab" @tab-change="handleTabChange">
				<el-tab-pane label="基本信息" name="basic">
					<el-descriptions :column="2" border>
						<el-descriptions-item label="任务编号">{{ task.taskCode || '--' }}</el-descriptions-item>
						<el-descriptions-item label="任务名称">{{ task.taskName || '--' }}</el-descriptions-item>
						<el-descriptions-item label="数仓层级">
							<el-tag :type="layerTagType(task.warehouseLayer)">{{ layerText(task.warehouseLayer) }}</el-tag>
						</el-descriptions-item>
						<el-descriptions-item label="任务类型">{{ taskTypeText(task.taskType) }}</el-descriptions-item>
						<el-descriptions-item label="生命周期">
							<el-tag :type="taskStatusTagType(task.status)">{{ taskStatusText(task.status) }}</el-tag>
						</el-descriptions-item>
						<el-descriptions-item label="调度状态">{{ scheduleStatusText(task) }}</el-descriptions-item>
						<el-descriptions-item label="当前版本">{{ task.currentVersionNo ? `V${task.currentVersionNo}` : '--' }}</el-descriptions-item>
						<el-descriptions-item label="版本状态">{{ task.versionStatus || '--' }}</el-descriptions-item>
						<el-descriptions-item label="已发布版本">{{ task.publishedVersionNo ? `V${task.publishedVersionNo}` : '--' }}</el-descriptions-item>
						<el-descriptions-item label="活动运行">
							<span v-if="!task.hasActiveRun">无</span>
							<el-tag v-else type="primary"
								>{{ runStatusText(task.activeRunStatus || undefined) }}{{ task.activeRunId ? ` · ${task.activeRunId}` : '' }}</el-tag
							>
						</el-descriptions-item>
						<el-descriptions-item label="业务系统">{{ task.businessSystemName || task.businessSystemId || '--' }}</el-descriptions-item>
						<el-descriptions-item label="业务域">{{ task.businessDomainName || task.businessDomainId || '--' }}</el-descriptions-item>
						<template v-if="isDimTask">
							<el-descriptions-item label="数据来源">平台维度值</el-descriptions-item>
							<el-descriptions-item label="关联模型">{{ task.relatedModelName || task.relatedModelId || '--' }}</el-descriptions-item>
							<el-descriptions-item label="ENTITY表">{{ task.entityTableName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="目标数据源">{{
								task.targetDatasourceName || datasourceName(task.targetDatasourceId)
							}}</el-descriptions-item>
							<el-descriptions-item label="数据库">{{ task.databaseName || '--' }}</el-descriptions-item>
							<el-descriptions-item label="物理表">{{ task.physicalName || task.targetTable || '--' }}</el-descriptions-item>
							<el-descriptions-item label="SCD策略">{{ task.scdType || '--' }}</el-descriptions-item>
							<el-descriptions-item label="写入策略">按 key 覆盖写入（{{ task.writeStrategy || 'REPLACE' }}）</el-descriptions-item>
						</template>
						<template v-else-if="isDwdTask">
							<el-descriptions-item label="关联明细模型">{{ task.relatedModelName || task.relatedModelId || '--' }}</el-descriptions-item>
							<el-descriptions-item label="冻结模型版本 ID">{{ task.dwdVersionId || '--' }}</el-descriptions-item>
							<el-descriptions-item label="目标数据源">{{ task.targetDatasourceName || datasourceName(task.targetDatasourceId) }}</el-descriptions-item>
							<el-descriptions-item label="目标表">{{ task.targetTable || '--' }}</el-descriptions-item>
						</template>
						<template v-else>
							<el-descriptions-item label="源数据源">{{ task.sourceDatasourceName || datasourceName(task.sourceDatasourceId) }}</el-descriptions-item>
							<el-descriptions-item label="目标数据源">{{
								task.targetDatasourceName || datasourceName(task.targetDatasourceId)
							}}</el-descriptions-item>
							<el-descriptions-item label="源表">{{ task.sourceTable || '--' }}</el-descriptions-item>
							<el-descriptions-item label="目标表">{{ task.targetTable || '--' }}</el-descriptions-item>
							<el-descriptions-item label="目标表处理">{{
								task.targetTableMode === 'RECREATE_ON_PUBLISH' ? '发布时重建' : '追加写入'
							}}</el-descriptions-item>
						</template>
						<el-descriptions-item label="任务描述" :span="2">{{ task.description || '--' }}</el-descriptions-item>
						<el-descriptions-item v-if="task.publishErrorSummary" label="发布错误" :span="2">
							<span class="error-text">{{ task.publishErrorSummary }}</span>
						</el-descriptions-item>
					</el-descriptions>

					<template v-if="isDimTask">
						<el-divider content-position="left">已发布执行快照</el-divider>
						<el-alert v-if="task.publishedSnapshotError" :title="task.publishedSnapshotError" type="error" :closable="false" show-icon class="mb20" />
						<el-empty v-else-if="!task.publishedSnapshot" description="尚无已发布维度执行快照" :image-size="64" />
						<el-descriptions v-else :column="2" border>
							<el-descriptions-item label="快照标识" :span="2">{{ task.publishedSnapshot.snapshotIdentity || '--' }}</el-descriptions-item>
							<el-descriptions-item label="快照格式">{{ task.publishedSnapshot.schemaVersion ?? '--' }}</el-descriptions-item>
							<el-descriptions-item label="冻结模型">{{ snapshotModelText }}</el-descriptions-item>
							<el-descriptions-item label="冻结输出表">{{ snapshotOutputTable }}</el-descriptions-item>
							<el-descriptions-item label="冻结目标数据源">{{
								task.publishedSnapshot.outputBinding?.targetDatasourceId || '--'
							}}</el-descriptions-item>
							<el-descriptions-item label="键模型">{{ task.publishedSnapshot.outputBinding?.keyModel || '--' }}</el-descriptions-item>
							<el-descriptions-item label="键字段">{{ task.publishedSnapshot.outputBinding?.keyColumns?.join(', ') || '--' }}</el-descriptions-item>
							<el-descriptions-item label="执行策略">{{ snapshotExecutionPolicy }}</el-descriptions-item>
							<el-descriptions-item label="输入策略">{{ task.publishedSnapshot.inputDataPolicy || '--' }}</el-descriptions-item>
						</el-descriptions>
					</template>

					<template v-else-if="task.taskType === 'SOURCE_SYNC'">
						<el-divider content-position="left">关联 ODS 模型</el-divider>
						<el-empty v-if="!relatedModel" description="尚未关联模型；同步成功后后端会再次尝试匹配" :image-size="64" />
						<el-descriptions v-else :column="2" border>
							<el-descriptions-item label="模型ID">{{ relatedModel.id }}</el-descriptions-item>
							<el-descriptions-item label="来源表">{{ relatedModel.sourceTable || '--' }}</el-descriptions-item>
							<el-descriptions-item label="目标表">{{ relatedModel.targetTable || '--' }}</el-descriptions-item>
							<el-descriptions-item label="表类型">{{ relatedModel.objectType || '--' }}</el-descriptions-item>
							<el-descriptions-item label="同步状态">
								<el-tag v-if="relatedModel.syncStatus" :type="syncStatusTagType(relatedModel.syncStatus)">
									{{ syncStatusLabel(relatedModel.syncStatus) }}
								</el-tag>
								<span v-else>--</span>
							</el-descriptions-item>
							<el-descriptions-item label="数据量">{{ relatedModel.rowCount ?? '--' }}</el-descriptions-item>
						</el-descriptions>
					</template>
				</el-tab-pane>

				<el-tab-pane label="同步配置" name="sync">
					<el-descriptions v-if="isDimTask" :column="2" border>
						<el-descriptions-item label="输入数据">平台维度值最新状态</el-descriptions-item>
						<el-descriptions-item label="同步模式">全量物化（FULL）</el-descriptions-item>
						<el-descriptions-item label="SCD策略">{{ task.scdType || '--' }}</el-descriptions-item>
						<el-descriptions-item label="写入策略">按 key 覆盖写入（{{ task.writeStrategy || 'REPLACE' }}）</el-descriptions-item>
						<el-descriptions-item label="批次大小">{{ task.batchSize ?? '--' }}</el-descriptions-item>
					</el-descriptions>
					<el-descriptions v-else-if="isDwdTask" :column="2" border>
						<el-descriptions-item label="模型版本 ID">{{ task.dwdVersionId || '--' }}</el-descriptions-item>
						<el-descriptions-item label="同步模式">{{ syncModeText(task.syncMode) }}</el-descriptions-item>
						<el-descriptions-item label="批次大小">{{ task.batchSize ?? '--' }}</el-descriptions-item>
							<el-descriptions-item label="暂存数据库">{{ task.replicaDatabase || '--' }}</el-descriptions-item>
					</el-descriptions>
					<el-descriptions v-else :column="2" border>
						<el-descriptions-item label="同步模式">{{ syncModeText(task.syncMode) }}</el-descriptions-item>
						<el-descriptions-item label="增量字段">{{ incrementalColumnText(task) }}</el-descriptions-item>
						<el-descriptions-item label="字段类型">{{ task.incrementalColumnType || '--' }}</el-descriptions-item>
						<el-descriptions-item label="增量策略">{{ incrementalStrategyText(task.incrementalStrategy) }}</el-descriptions-item>
						<el-descriptions-item label="首次增量值">{{ task.incrementalStartValue || '--' }}</el-descriptions-item>
						<el-descriptions-item label="源端物理删除处理">{{ sourceDeleteStrategyText(task.sourceDeleteStrategy) }}</el-descriptions-item>
						<template v-if="task.sourceDeleteStrategy === 'MARK_DELETED'">
							<el-descriptions-item label="全量对账间隔">{{ valueWithUnit(task.reconciliationIntervalMinutes, '分钟') }}</el-descriptions-item>
							<el-descriptions-item label="单次最大标记数">{{ valueWithUnit(task.reconciliationMaxDeleteRows, '条') }}</el-descriptions-item>
							<el-descriptions-item label="最近一次对账">{{ task.lastReconciliationTime || '尚未执行' }}</el-descriptions-item>
							<el-descriptions-item label="最近一次对账尝试">{{ task.lastReconciliationAttemptTime || '尚未执行' }}</el-descriptions-item>
						</template>
						<el-descriptions-item label="水位存储">{{ task.watermarkStorage || '--' }}</el-descriptions-item>
						<el-descriptions-item label="最近成功读取边界" :span="2">{{ task.lastSuccessCheckpoint || '--' }}</el-descriptions-item>
						<el-descriptions-item label="批次大小">{{ task.batchSize ?? '--' }}</el-descriptions-item>
					</el-descriptions>
				</el-tab-pane>

				<el-tab-pane label="调度配置" name="schedule">
					<el-descriptions :column="2" border>
						<el-descriptions-item label="调度方式">{{ task.scheduleType === 'CRON' ? '定时调度' : '手动执行' }}</el-descriptions-item>
						<el-descriptions-item label="Cron表达式">{{ task.cronExpression || '--' }}</el-descriptions-item>
						<el-descriptions-item label="时区">{{ task.timezone || '--' }}</el-descriptions-item>
						<el-descriptions-item label="重试次数">{{ task.retryTimes ?? '--' }}</el-descriptions-item>
						<el-descriptions-item label="重试间隔">{{ valueWithUnit(task.retryIntervalMinutes, '分钟') }}</el-descriptions-item>
						<el-descriptions-item label="DS档案">{{ task.dsProfileName || task.dsProfileId || '--' }}</el-descriptions-item>
						<el-descriptions-item v-if="!isDimTask" label="SeaTunnel档案">{{
							task.seatunnelProfileName || task.seatunnelProfileId || '--'
						}}</el-descriptions-item>
						<el-descriptions-item label="DS流程编码" :span="2">{{ task.dsProcessDefinitionCode || '--' }}</el-descriptions-item>
					</el-descriptions>
				</el-tab-pane>

				<el-tab-pane label="版本历史" name="versions">
					<el-table v-loading="versionLoading" :data="versions" border max-height="470" empty-text="暂无版本记录">
						<el-table-column label="版本" width="90">
							<template #default="{ row }">{{ row.versionNo ? `V${row.versionNo}` : '--' }}</template>
						</el-table-column>
						<el-table-column label="版本ID" min-width="190" show-overflow-tooltip>
							<template #default="{ row }">{{ row.versionId || row.id || '--' }}</template>
						</el-table-column>
						<el-table-column v-if="isDwdTask" label="DWD冻结版本ID" min-width="175" show-overflow-tooltip>
							<template #default="{ row }">{{ row.dwdVersionId || '--' }}</template>
						</el-table-column>
						<el-table-column label="状态" width="130">
							<template #default="{ row }">{{ row.versionStatus || row.status || '--' }}</template>
						</el-table-column>
						<el-table-column prop="updateTime" label="更新时间" width="175" show-overflow-tooltip />
						<el-table-column prop="publishErrorSummary" label="发布错误" min-width="220" show-overflow-tooltip />
					</el-table>
				</el-tab-pane>

				<el-tab-pane label="执行历史" name="executions">
					<el-table v-loading="runLoading" :data="runs" border max-height="470" empty-text="暂无执行记录">
						<el-table-column type="index" label="#" width="55" />
						<el-table-column label="触发方式" min-width="100">
							<template #default="{ row }">{{ triggerTypeText(row.triggerType) }}</template>
						</el-table-column>
						<el-table-column label="状态" width="100">
							<template #default="{ row }"
								><el-tag :type="runStatusTagType(row.runStatus)">{{ runStatusText(row.runStatus) }}</el-tag></template
							>
						</el-table-column>
						<el-table-column prop="startTime" label="开始时间" min-width="165" show-overflow-tooltip />
						<el-table-column prop="endTime" label="结束时间" min-width="165" show-overflow-tooltip />
						<el-table-column label="绑定版本" min-width="180" show-overflow-tooltip>
							<template #default="{ row }">{{ runVersionText(row) }}</template>
						</el-table-column>
						<el-table-column label="耗时" width="100">
							<template #default="{ row }">{{ formatDuration(runDuration(row)) }}</template>
						</el-table-column>
						<el-table-column :label="isDimTask ? '候选物化数量' : '读取/写入'" width="140">
							<template #default="{ row }">{{
								isDimTask ? formatRows(row.rowsWritten) : `${formatRows(row.rowsRead)} / ${formatRows(row.rowsWritten)}`
							}}</template>
						</el-table-column>
						<el-table-column label="操作" width="100" fixed="right">
							<template #default="{ row }">
								<el-button v-auth="'dp_sync_run_view'" text type="primary" icon="Document" @click="emit('openExecution', row.id, task?.taskType)"
									>详情</el-button
								>
							</template>
						</el-table-column>
					</el-table>
					<pagination
						:current="runPage.current"
						:size="runPage.size"
						:total="runPage.total"
						@current-change="handleRunCurrentChange"
						@size-change="handleRunSizeChange"
					/>
				</el-tab-pane>
			</el-tabs>
		</div>
	</el-drawer>
</template>

<script setup lang="ts" name="LayeredTaskDetailDrawer">
import { fetchDatasourceReferences } from '/@/api/dataPlatform/datasourceAsset';
import { fetchSyncRunPage, fetchSyncTaskVersions, getLayeredTask, getSyncTaskRelatedModel } from '/@/api/dataPlatform/layeredTask';
import { useMessage } from '/@/hooks/message';
import type { DatasourceReference } from '/@/types/dataPlatform/datasourceAsset';
import type { LayeredTaskDetail, PageResult, RelatedModel, SyncRunRecord, SyncTaskVersion } from '/@/types/dataPlatform/layeredTask';
import { syncStatusLabel, syncStatusTagType } from '/@/views/gen/warehouse/ods/tableModel/status';
import {
	formatDuration,
	formatRows,
	layerTagType,
	layerText,
	runStatusTagType,
	runStatusText,
	syncModeText,
	taskStatusTagType,
	taskStatusText,
	taskTypeText,
	triggerTypeText,
} from './constants';

const emit = defineEmits<{ openExecution: [runId: string, taskType?: string] }>();
const visible = ref(false);
const loading = ref(false);
const runLoading = ref(false);
const versionLoading = ref(false);
const activeTab = ref('basic');
const taskId = ref('');
const task = ref<LayeredTaskDetail>();
const relatedModel = ref<RelatedModel>();
const datasourceReferences = ref<DatasourceReference[]>([]);
const runs = ref<SyncRunRecord[]>([]);
const versions = ref<SyncTaskVersion[]>([]);
const runLoaded = ref(false);
const versionLoaded = ref(false);
const runPage = reactive({ current: 1, size: 10, total: '0' });
const isDimTask = computed(() => task.value?.taskType === 'DIM_BUILD');
const isDwdTask = computed(() => task.value?.taskType === 'DWD_PROCESS');
const snapshotModelText = computed(() => {
	const snapshot = task.value?.publishedSnapshot;
	if (!snapshot?.modelId) return '--';
	return snapshot.modelVersion === undefined || snapshot.modelVersion === null ? snapshot.modelId : `${snapshot.modelId} / ${snapshot.modelVersion}`;
});
const snapshotOutputTable = computed(() => {
	const output = task.value?.publishedSnapshot?.outputBinding;
	if (!output) return '--';
	return [output.database, output.physicalName].filter(Boolean).join('.') || output.tableId || '--';
});
const snapshotExecutionPolicy = computed(() => {
	const policy = task.value?.publishedSnapshot?.executionPolicy;
	if (!policy) return '--';
	return (
		[policy.syncMode, policy.scdType, policy.writeStrategy, policy.batchSize ? `批次 ${policy.batchSize}` : ''].filter(Boolean).join(' / ') || '--'
	);
});

const valueWithUnit = (value: number | undefined, unit: string) => (value === undefined || value === null ? '--' : `${value}${unit}`);
const incrementalStrategyText = (value?: string) =>
	({ APPEND: '追加', UPSERT: '更新插入', MERGE: 'MERGE（已停止支持）' }[value || ''] || value || '--');
const sourceDeleteStrategyText = (value?: string) => ({ IGNORE: '忽略', MARK_DELETED: '定期对账并标记删除' }[value || ''] || value || '忽略');
const scheduleStatusText = (detail: LayeredTaskDetail) => {
	if (detail.status === 'OFFLINE') return '已下线';
	if (detail.status === 'DRAFT') return '草稿';
	if (detail.scheduleType !== 'CRON') return '手动触发';
	return detail.schedulePaused ? '已暂停' : '定时运行中';
};
const incrementalColumnText = (detail: LayeredTaskDetail) => {
	if (Array.isArray(detail.incrementalColumns))
		return detail.incrementalColumns.map((item) => item.name).join(', ') || detail.incrementalColumn || '--';
	return detail.incrementalColumns?.split(',').join(', ') || detail.incrementalColumn || '--';
};
const datasourceName = (id?: string) => {
	if (!id) return '--';
	const item = datasourceReferences.value.find((datasource) => datasource.id === String(id));
	return item?.displayName || item?.name || String(id);
};
const runDuration = (run: SyncRunRecord) => {
	if (!run.startTime || !run.endTime) return undefined;
	const seconds = Math.floor((new Date(run.endTime).getTime() - new Date(run.startTime).getTime()) / 1000);
	return Number.isFinite(seconds) && seconds >= 0 ? seconds : undefined;
};
const runVersionText = (run: SyncRunRecord) => {
	if (!run.taskVersionId) return '--';
	return `${run.taskVersionId}${run.taskVersionId === task.value?.publishedVersionId ? '（当前发布）' : ''}`;
};

const normalizeRun = (run: SyncRunRecord): SyncRunRecord => ({
	...run,
	id: String(run.id),
	taskId: String(run.taskId),
	taskVersionId: run.taskVersionId ? String(run.taskVersionId) : undefined,
	dsProcessInstanceId: run.dsProcessInstanceId ? String(run.dsProcessInstanceId) : undefined,
	dsTaskInstanceId: run.dsTaskInstanceId ? String(run.dsTaskInstanceId) : undefined,
});

const loadRuns = async () => {
	if (!taskId.value) return;
	try {
		runLoading.value = true;
		const res = await fetchSyncRunPage({ current: runPage.current, size: runPage.size, taskId: taskId.value });
		const result = (res.data || {}) as PageResult<SyncRunRecord>;
		runs.value = Array.isArray(result.records) ? result.records.map(normalizeRun) : [];
		runPage.total = result.total ?? '--';
		runLoaded.value = true;
	} catch (error: any) {
		runs.value = [];
		useMessage().error(error?.msg || '查询执行历史失败');
	} finally {
		runLoading.value = false;
	}
};

const loadVersions = async () => {
	if (!taskId.value) return;
	try {
		versionLoading.value = true;
		const res = await fetchSyncTaskVersions(taskId.value);
		const data = res.data as SyncTaskVersion[] | PageResult<SyncTaskVersion>;
		const records = Array.isArray(data) ? data : data?.records || [];
		versions.value = records.map((item) => ({
			...item,
			id: item.id ? String(item.id) : undefined,
			versionId: item.versionId ? String(item.versionId) : undefined,
			dwdVersionId: item.dwdVersionId ? String(item.dwdVersionId) : null,
		}));
		versionLoaded.value = true;
	} catch (error: any) {
		versions.value = [];
		useMessage().error(error?.msg || '查询版本历史失败');
	} finally {
		versionLoading.value = false;
	}
};

const handleTabChange = (name: string | number) => {
	if (name === 'executions' && !runLoaded.value) loadRuns();
	if (name === 'versions' && !versionLoaded.value) loadVersions();
};
const handleRunCurrentChange = (current: number) => {
	runPage.current = current;
	loadRuns();
};
const handleRunSizeChange = (size: number) => {
	runPage.size = size;
	runPage.current = 1;
	loadRuns();
};

const openDrawer = async (id: string, initialTab = 'basic') => {
	taskId.value = String(id);
	visible.value = true;
	activeTab.value = initialTab;
	task.value = undefined;
	relatedModel.value = undefined;
	runs.value = [];
	versions.value = [];
	runLoaded.value = false;
	versionLoaded.value = false;
	runPage.current = 1;
	try {
		loading.value = true;
		const [detailResult, modelResult, datasourceResult] = await Promise.allSettled([
			getLayeredTask(taskId.value),
			getSyncTaskRelatedModel(taskId.value),
			fetchDatasourceReferences(),
		]);
		if (detailResult.status === 'rejected') throw detailResult.reason;
		const detail = detailResult.value.data as LayeredTaskDetail;
		task.value = {
			...detail,
			id: String(detail.id),
			warehouseLayer: detail.warehouseLayer || (detail as any).layer,
			sourceDatasourceId: String(detail.sourceDatasourceId || ''),
			targetDatasourceId: String(detail.targetDatasourceId || ''),
			dwdVersionId: detail.dwdVersionId ? String(detail.dwdVersionId) : null,
			currentVersionId: detail.currentVersionId ? String(detail.currentVersionId) : undefined,
			publishedVersionId: detail.publishedVersionId ? String(detail.publishedVersionId) : undefined,
			entityTableId: detail.entityTableId ? String(detail.entityTableId) : null,
			activeRunId: detail.activeRunId ? String(detail.activeRunId) : null,
			hasActiveRun: Boolean(detail.hasActiveRun),
		};
		if (modelResult.status === 'fulfilled' && modelResult.value.data) {
			relatedModel.value = { ...modelResult.value.data, id: String(modelResult.value.data.id) } as RelatedModel;
		}
		if (datasourceResult.status === 'fulfilled') {
			datasourceReferences.value = (datasourceResult.value.data || []).map((item: DatasourceReference) => ({ ...item, id: String(item.id) }));
		}
		if (initialTab === 'executions') loadRuns();
		if (initialTab === 'versions') loadVersions();
	} catch (error: any) {
		visible.value = false;
		useMessage().error(error?.msg || '加载任务详情失败');
	} finally {
		loading.value = false;
	}
};

defineExpose({ openDrawer, loadRuns });
</script>

<style scoped>
.task-detail {
	min-height: 260px;
}

.error-text {
	color: var(--el-color-danger);
}
</style>
