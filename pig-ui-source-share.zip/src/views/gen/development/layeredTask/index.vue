<template>
	<div class="layered-task-page layout-padding">
		<el-card shadow="never" class="page-card">
			<div class="page-heading">
				<div>
					<div class="page-title">分层任务运维</div>
					<div class="page-description">创建、发布和运维 ODS、DIM、DWD、DWS、ADS 各层数据任务。</div>
				</div>
						<el-button v-auth="'dp_sync_task_add'" type="primary" icon="Plus" @click="taskFormRef?.openDrawer(undefined, selectedLayer === 'DWD' ? 'DWD' : 'ODS')">新建任务</el-button>
			</div>

			<div class="task-workspace">
				<aside class="layer-sidebar">
					<el-input v-model="layerKeyword" placeholder="分类名称" clearable prefix-icon="Search" />
					<div class="layer-title">
						<span
							><el-icon><FolderOpened /></el-icon>任务分类</span
						>
					</div>
					<div
						v-for="item in layerMenus"
						:key="item.value"
						v-show="!layerKeyword || item.label.includes(layerKeyword.toUpperCase())"
						class="layer-item"
						:class="{ active: selectedLayer === item.value }"
						@click="handleLayerChange(item.value)"
					>
						<span>{{ item.label }}</span>
						<span class="layer-count">{{ item.count }}</span>
					</div>
				</aside>

				<section class="task-content">
					<div class="query-panel">
						<el-form :model="query" inline @submit.prevent>
							<el-form-item label="任务名称">
								<el-input v-model="query.keyword" placeholder="请输入任务名称或编号" clearable @keyup.enter="handleQuery" />
							</el-form-item>
							<el-form-item label="生命周期">
								<el-select v-model="query.status" placeholder="全部状态" clearable style="width: 150px">
									<el-option label="草稿" value="DRAFT" />
									<el-option label="已上线" value="PUBLISHED" />
									<el-option label="已下线" value="OFFLINE" />
								</el-select>
							</el-form-item>
							<el-form-item label="启用状态">
								<el-select v-model="query.enabled" placeholder="全部状态" clearable style="width: 150px">
									<el-option label="已启用" :value="true" />
									<el-option label="已停用" :value="false" />
								</el-select>
							</el-form-item>
							<el-form-item>
								<el-button type="primary" icon="Search" @click="handleQuery">查询</el-button>
								<el-button icon="Refresh" @click="handleReset">重置</el-button>
							</el-form-item>
						</el-form>
					</div>

					<div class="list-toolbar">
						<div class="list-title">任务列表（{{ page.total }}）</div>
						<el-button icon="Refresh" :loading="loading" @click="refreshAll">刷新</el-button>
					</div>

					<el-table v-loading="loading" :data="tasks" border stripe height="530" empty-text="暂无分层任务">
						<el-table-column prop="taskCode" label="任务编号" min-width="150" show-overflow-tooltip />
						<el-table-column prop="taskName" label="任务名称" min-width="180" show-overflow-tooltip />
						<el-table-column label="层级" width="88">
							<template #default="{ row }"
								><el-tag :type="layerTagType(row.warehouseLayer)">{{ row.warehouseLayer }}</el-tag></template
							>
						</el-table-column>
						<el-table-column label="数据流向" min-width="260" show-overflow-tooltip>
							<template #default="{ row }">{{ taskFlowText(row) }}</template>
						</el-table-column>
						<el-table-column label="数据源" min-width="210" show-overflow-tooltip>
							<template #default="{ row }">{{ datasourceFlowText(row) }}</template>
						</el-table-column>
						<el-table-column label="同步模式" min-width="125">
								<template #default="{ row }">{{ taskSyncModeText(row) }}</template>
						</el-table-column>
						<el-table-column label="调度" min-width="160" show-overflow-tooltip>
							<template #default="{ row }">{{ scheduleText(row) }}</template>
						</el-table-column>
						<el-table-column label="当前版本" width="105">
							<template #default="{ row }">{{ row.currentVersionNo ? `V${row.currentVersionNo}` : '--' }}</template>
						</el-table-column>
						<el-table-column label="生命周期" width="100">
							<template #default="{ row }"
								><el-tag :type="taskStatusTagType(row.status)">{{ taskStatusText(row.status) }}</el-tag></template
							>
						</el-table-column>
						<el-table-column label="调度状态" width="105">
							<template #default="{ row }">
								<el-tag :type="scheduleStatusType(row)" effect="plain">{{ scheduleStatusText(row) }}</el-tag>
							</template>
						</el-table-column>
						<el-table-column prop="updateTime" label="更新时间" width="175" show-overflow-tooltip />
						<el-table-column label="操作" width="410" fixed="right">
							<template #default="{ row }">
								<div class="operation-actions">
									<el-button v-auth="'dp_sync_task_view'" text type="primary" icon="View" @click="detailDrawerRef?.openDrawer(row.id)"
										>查看</el-button
									>
									<el-button
										v-auth="'dp_sync_task_edit'"
										text
										type="primary"
										icon="Edit"
										:disabled="row.status === 'PUBLISHED'"
										:title="row.status === 'PUBLISHED' ? '请先下线任务再编辑' : ''"
										@click="taskFormRef?.openDrawer(row.id)"
									>
										编辑
									</el-button>
									<el-button
										v-auth="'dp_sync_task_publish'"
										text
										type="success"
										icon="Promotion"
										:disabled="!canPublish(row)"
										:loading="publishLoadingId === row.id"
										@click="handlePublish(row)"
									>
										发布
									</el-button>
									<el-button
										v-auth="'dp_sync_task_run'"
										text
										type="primary"
										icon="VideoPlay"
										:disabled="!canRun(row)"
										:title="runDisabledReason(row)"
										:loading="runLoadingId === row.id"
										@click="handleRun(row)"
									>
										立即执行
									</el-button>
									<el-button
										v-if="row.status === 'PUBLISHED' || row.status === 'OFFLINE'"
										v-auth="'dp_sync_task_edit'"
										text
										:type="row.status === 'PUBLISHED' ? 'danger' : 'success'"
										icon="SwitchButton"
										:loading="lifecycleLoadingId === row.id"
										@click="handleTaskLifecycle(row)"
									>
										{{ row.status === 'PUBLISHED' ? '下线' : '上线' }}
									</el-button>
									<el-button
										v-if="row.status === 'PUBLISHED' && isCronTask(row)"
										v-auth="'dp_sync_task_edit'"
										text
										:type="row.schedulePaused ? 'success' : 'warning'"
										icon="Timer"
										:loading="scheduleLoadingId === row.id"
										@click="handleScheduleLifecycle(row)"
									>
										{{ row.schedulePaused ? '定时上线' : '定时下线' }}
									</el-button>
									<el-button
										v-if="row.status !== 'PUBLISHED'"
										v-auth="'dp_sync_task_edit'"
										text
										type="danger"
										icon="Delete"
										:loading="deleteLoadingId === row.id"
										@click="handleDelete(row)"
									>
										删除
									</el-button>
								</div>
							</template>
						</el-table-column>
					</el-table>

					<pagination
						:current="page.current"
						:size="page.size"
						:total="page.total"
						@current-change="handleCurrentChange"
						@size-change="handleSizeChange"
					/>
				</section>
			</div>
		</el-card>

		<el-dialog v-model="publishDialogVisible" title="发布前检查" width="680px" :close-on-click-modal="false">
			<template v-if="publishPrecheckResult">
				<el-alert
					v-if="publishPrecheckCanProceed"
					:title="publishConfirmationText"
					type="warning"
					:closable="false"
					show-icon
					class="publish-confirmation"
				/>
				<SchemaPrecheckResult :result="publishPrecheckResult" />
			</template>
			<template #footer>
				<el-button @click="publishDialogVisible = false">{{ publishPrecheckCanProceed ? '取消' : '关闭' }}</el-button>
				<el-button v-if="publishPrecheckCanProceed" type="primary" :loading="Boolean(publishLoadingId)" @click="confirmPublish"> 确认发布 </el-button>
			</template>
		</el-dialog>

		<TaskFormDrawer ref="taskFormRef" @saved="refreshAll" />
		<TaskDetailDrawer ref="detailDrawerRef" @open-execution="openExecution" />
		<ExecutionDrawer ref="executionDrawerRef" @refresh="refreshAll" />
	</div>
</template>

<script setup lang="ts" name="DataPlatformLayeredTask">
import { fetchDatasourceReferences } from '/@/api/dataPlatform/datasourceAsset';
import {
	deleteSyncTask,
	fetchLayeredTaskPage,
	fetchLayeredTaskStatistics,
	getLayeredTask,
	offlineLayeredTask,
	offlineLayeredTaskSchedule,
	onlineLayeredTask,
	onlineLayeredTaskSchedule,
	precheckSyncTaskSchema,
	publishSyncTask,
	runLayeredTask,
} from '/@/api/dataPlatform/layeredTask';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type { DatasourceReference } from '/@/types/dataPlatform/datasourceAsset';
import type {
	LayeredTaskQuery,
	LayeredTaskStatistics,
	LayeredTaskSummary,
	PageResult,
	SchemaPrecheckRequest,
	SchemaPrecheckResult as SchemaPrecheckResultType,
	WarehouseLayer,
} from '/@/types/dataPlatform/layeredTask';
import { layerOptions, layerTagType, syncModeText, taskStatusTagType, taskStatusText } from './constants';
import TaskDetailDrawer from './detailDrawer.vue';
import ExecutionDrawer from './executionDrawer.vue';
import SchemaPrecheckResult from './schemaPrecheckResult.vue';
import TaskFormDrawer from './taskFormDrawer.vue';

type LayerFilter = WarehouseLayer | '';

const loading = ref(false);
const runLoadingId = ref('');
const publishLoadingId = ref('');
const lifecycleLoadingId = ref('');
const scheduleLoadingId = ref('');
const deleteLoadingId = ref('');
const publishDialogVisible = ref(false);
const publishTargetTask = ref<LayeredTaskSummary>();
const publishPrecheckResult = ref<SchemaPrecheckResultType>();
const layerKeyword = ref('');
const selectedLayer = ref<LayerFilter>('');
const tasks = ref<LayeredTaskSummary[]>([]);
const statistics = ref<LayeredTaskStatistics>({});
const datasourceReferences = ref<DatasourceReference[]>([]);
const detailDrawerRef = ref<InstanceType<typeof TaskDetailDrawer>>();
const executionDrawerRef = ref<InstanceType<typeof ExecutionDrawer>>();
const taskFormRef = ref<InstanceType<typeof TaskFormDrawer>>();
const page = reactive({ current: 1, size: 10, total: '0' });
const query = reactive<LayeredTaskQuery>({ current: 1, size: 10, keyword: '', status: '', enabled: undefined });

const countByLayer = (layer: WarehouseLayer) => {
	const lowerLayer = layer.toLowerCase() as Lowercase<WarehouseLayer>;
	const value = statistics.value[lowerLayer] ?? statistics.value[layer] ?? statistics.value[`${lowerLayer}Count` as keyof LayeredTaskStatistics];
	return value === undefined || value === null ? '--' : value;
};
const layerMenus = computed(() => [
	{
		value: '' as LayerFilter,
		label: '全部任务',
		count: statistics.value.total ?? statistics.value.ALL ?? '--',
	},
	...layerOptions.map((item) => ({ value: item.value as LayerFilter, label: item.shortLabel, count: countByLayer(item.value) })),
]);

const cleanParams = <T extends Record<string, unknown>>(params: T): Partial<T> =>
	Object.fromEntries(Object.entries(params).filter(([, value]) => value !== '' && value !== undefined && value !== null)) as Partial<T>;

const normalizeTask = (task: LayeredTaskSummary): LayeredTaskSummary => ({
	...task,
	id: String(task.id),
	warehouseLayer: task.warehouseLayer || (task as any).layer,
	businessSystemId: task.businessSystemId ? String(task.businessSystemId) : undefined,
	businessDomainId: task.businessDomainId ? String(task.businessDomainId) : undefined,
	relatedModelId: task.relatedModelId ? String(task.relatedModelId) : null,
	entityTableId: task.entityTableId ? String(task.entityTableId) : null,
	sourceDatasourceId: String(task.sourceDatasourceId || ''),
	targetDatasourceId: String(task.targetDatasourceId || ''),
	targetTableMode: task.taskType === 'SOURCE_SYNC' ? task.targetTableMode || 'APPEND' : undefined,
	dwdVersionId: task.dwdVersionId ? String(task.dwdVersionId) : null,
	currentVersionId: task.currentVersionId ? String(task.currentVersionId) : undefined,
	publishedVersionId: task.publishedVersionId ? String(task.publishedVersionId) : undefined,
	activeRunId: task.activeRunId ? String(task.activeRunId) : null,
	hasActiveRun: Boolean(task.hasActiveRun),
	schedulePaused: Boolean(task.schedulePaused),
});

const buildQueryParams = (): LayeredTaskQuery =>
	cleanParams({ ...query, current: page.current, size: page.size, layer: selectedLayer.value || undefined }) as LayeredTaskQuery;

const loadTasks = async () => {
	try {
		loading.value = true;
		const res = await fetchLayeredTaskPage(buildQueryParams());
		const result = (res.data || {}) as PageResult<LayeredTaskSummary>;
		tasks.value = Array.isArray(result.records) ? result.records.map(normalizeTask) : [];
		page.total = result.total ?? '--';
	} catch (error: any) {
		tasks.value = [];
		useMessage().error(error?.msg || '查询分层任务失败');
	} finally {
		loading.value = false;
	}
};

const loadStatistics = async () => {
	try {
		const res = await fetchLayeredTaskStatistics();
		statistics.value = (res.data || {}) as LayeredTaskStatistics;
	} catch {
		statistics.value = {};
	}
};

const loadDatasourceReferences = async () => {
	try {
		const res = await fetchDatasourceReferences();
		datasourceReferences.value = (res.data || []).map((item: DatasourceReference) => ({ ...item, id: String(item.id) }));
	} catch {
		datasourceReferences.value = [];
	}
};

const datasourceName = (id?: string) => {
	if (!id) return '--';
	const datasource = datasourceReferences.value.find((item) => item.id === String(id));
	return datasource?.displayName || datasource?.name || String(id);
};

const taskFlowText = (task: LayeredTaskSummary) => {
	if (task.taskType === 'DIM_BUILD')
		return `${task.relatedModelName || '--'} → ${task.entityTableName || task.physicalName || task.targetTable || '--'}`;
	if (task.taskType === 'DWD_PROCESS')
		return `${task.relatedModelName || task.relatedModelId || '明细模型'} → ${task.targetTable || task.physicalName || '--'}`;
	return `${task.sourceTable || '--'} → ${task.targetTable || '--'}`;
};

const taskSyncModeText = (task: LayeredTaskSummary) => {
	if (task.taskType === 'DIM_BUILD') return '全量物化';
	if (task.taskType === 'DWD_PROCESS' && task.syncMode === 'FULL') return '全量加工';
	if (task.taskType === 'DWD_PROCESS' && task.syncMode === 'INCREMENTAL') return '增量加工';
	return syncModeText(task.syncMode);
};

const datasourceFlowText = (task: LayeredTaskSummary) => {
	if (task.taskType === 'DIM_BUILD') return `平台维度值 → ${task.targetDatasourceName || datasourceName(task.targetDatasourceId)}`;
	if (task.taskType === 'DWD_PROCESS') return `DWD模型来源 → ${task.targetDatasourceName || datasourceName(task.targetDatasourceId)}`;
	return `${task.sourceDatasourceName || datasourceName(task.sourceDatasourceId)} → ${
		task.targetDatasourceName || datasourceName(task.targetDatasourceId)
	}`;
};

const isCronTask = (task: LayeredTaskSummary) => task.scheduleType === 'CRON';
const scheduleText = (task: LayeredTaskSummary) => (isCronTask(task) ? task.cycleName || task.cronExpression || '定时调度' : '手动执行');
const scheduleStatusText = (task: LayeredTaskSummary) => {
	if (task.status === 'OFFLINE') return '已下线';
	if (task.status === 'DRAFT') return '草稿';
	if (!isCronTask(task)) return '手动触发';
	return task.schedulePaused ? '已暂停' : '定时运行中';
};
const scheduleStatusType = (task: LayeredTaskSummary) => {
	if (task.status === 'OFFLINE') return 'info';
	if (task.status === 'DRAFT' || task.schedulePaused) return 'warning';
	if (!isCronTask(task)) return 'info';
	return 'success';
};
const canPublish = (task: LayeredTaskSummary) => ['DRAFT', 'FAILED'].includes(task.versionStatus || '');
const canRun = (task: LayeredTaskSummary) =>
	task.status === 'PUBLISHED' && task.enabled === true && task.publishedVersionId != null && !task.hasActiveRun;
const runDisabledReason = (task: LayeredTaskSummary) => {
	if (task.hasActiveRun)
		return `任务已有${task.activeRunStatus === 'SUBMITTED' ? '已提交' : '运行中'}的执行${task.activeRunId ? `（${task.activeRunId}）` : ''}`;
	if (task.status !== 'PUBLISHED') return '仅已发布任务可以执行';
	if (!task.enabled) return '任务已停用';
	if (!task.publishedVersionId) return '任务尚无已发布版本';
	return '';
};
const publishPrecheckCanProceed = computed(() =>
	Boolean(publishPrecheckResult.value && publishPrecheckResult.value.action !== 'BLOCK' && publishPrecheckResult.value.canPublish !== false)
);
const publishConfirmationText = computed(() => {
	const task = publishTargetTask.value;
	const result = publishPrecheckResult.value;
	if (!task || !result) return '';
	const targetTable = task.targetTable.includes('.') ? task.targetTable : `public.${task.targetTable}`;
	if (task.targetTableMode === 'RECREATE_ON_PUBLISH' || result.action === 'RECREATE') {
		return result.targetTableExists
			? `目标表 ${targetTable} 已存在，本次发布将删除并按源表结构重建。`
			: `目标表 ${targetTable} 不存在，本次发布将按源表结构创建。`;
	}
	if (result.action === 'CREATE') return `目标表 ${targetTable} 不存在，发布时将自动创建，并追加写入源表全量数据。`;
	if (result.action === 'APPEND') return `目标表 ${targetTable} 已存在，将保留现有数据和目标端额外字段，并继续追加写入。`;
	return result.summary;
});

const buildSchemaPrecheckRequest = (task: LayeredTaskSummary): SchemaPrecheckRequest | undefined => {
	if (!task.sourceDatasourceId || !task.sourceTable || !task.targetDatasourceId || !task.targetTable) return undefined;
	return {
		sourceDatasourceId: task.sourceDatasourceId,
		sourceTable: task.sourceTable,
		targetDatasourceId: task.targetDatasourceId,
		targetTable: task.targetTable,
		targetTableMode: task.targetTableMode || 'APPEND',
	};
};

const refreshAll = () => Promise.all([loadTasks(), loadStatistics()]);
const handleQuery = () => {
	page.current = 1;
	loadTasks();
};
const handleReset = () => {
	Object.assign(query, { keyword: '', status: '', enabled: undefined });
	selectedLayer.value = '';
	page.current = 1;
	refreshAll();
};
const handleLayerChange = (layer: LayerFilter) => {
	selectedLayer.value = layer;
	page.current = 1;
	loadTasks();
};
const handleCurrentChange = (current: number) => {
	page.current = current;
	loadTasks();
};
const handleSizeChange = (size: number) => {
	page.size = size;
	page.current = 1;
	loadTasks();
};
const openExecution = (runId: string, taskType?: string) => executionDrawerRef.value?.openDrawer(String(runId), taskType);

const handleTaskLifecycle = async (task: LayeredTaskSummary) => {
	const goingOnline = task.status === 'OFFLINE';
	const actionText = goingOnline ? '上线' : '下线';
	try {
		await useMessageBox().confirm(
			goingOnline
				? `确认上线任务“${task.taskName}”吗？上线后将恢复工作流及定时调度。`
				: `确认下线任务“${task.taskName}”吗？下线后工作流和定时调度都会停止。`
		);
	} catch {
		return;
	}
	try {
		lifecycleLoadingId.value = task.id;
		await (goingOnline ? onlineLayeredTask(task.id) : offlineLayeredTask(task.id));
		useMessage().success(`任务已${actionText}`);
		await refreshAll();
	} catch (error: any) {
		useMessage().error(error?.msg || `任务${actionText}失败`);
	} finally {
		lifecycleLoadingId.value = '';
	}
};

const handleScheduleLifecycle = async (task: LayeredTaskSummary) => {
	const goingOnline = Boolean(task.schedulePaused);
	const actionText = goingOnline ? '定时上线' : '定时下线';
	try {
		await useMessageBox().confirm(
			goingOnline ? `确认恢复任务“${task.taskName}”的 Cron 定时触发吗？` : `确认暂停任务“${task.taskName}”的 Cron 定时触发吗？手动立即执行仍可使用。`
		);
	} catch {
		return;
	}
	try {
		scheduleLoadingId.value = task.id;
		await (goingOnline ? onlineLayeredTaskSchedule(task.id) : offlineLayeredTaskSchedule(task.id));
		useMessage().success(`${actionText}成功`);
		await refreshAll();
	} catch (error: any) {
		useMessage().error(error?.msg || `${actionText}失败`);
	} finally {
		scheduleLoadingId.value = '';
	}
};

const handleDelete = async (task: LayeredTaskSummary) => {
	try {
		await useMessageBox().confirm(`确认删除任务“${task.taskName}”吗？任务配置、版本、依赖和水位信息将被删除；历史运行记录仍会保留用于审计。`);
	} catch {
		return;
	}
	try {
		deleteLoadingId.value = task.id;
		await deleteSyncTask(task.id);
		useMessage().success('任务删除成功');
		if (tasks.value.length === 1 && page.current > 1) page.current -= 1;
		await refreshAll();
	} catch (error: any) {
		useMessage().error(error?.msg || '任务删除失败');
	} finally {
		deleteLoadingId.value = '';
	}
};

const handlePublish = async (task: LayeredTaskSummary) => {
	try {
		publishLoadingId.value = task.id;
		const detailRes = await getLayeredTask(task.id);
		const publishTask = normalizeTask({ ...task, ...(detailRes.data as LayeredTaskSummary), id: task.id });
		if (publishTask.taskType === 'DIM_BUILD' || publishTask.taskType === 'DWD_PROCESS') {
			try {
				await useMessageBox().confirm(
					publishTask.taskType === 'DWD_PROCESS'
						? `确认发布明细加工任务“${publishTask.taskName}”的当前任务版本吗？发布后执行将使用该版本绑定的 DWD 冻结模型版本。`
						: `确认发布维度物化任务“${publishTask.taskName}”吗？发布后将冻结本次模型与输出配置。`
				);
			} catch {
				return;
			}
			await publishSyncTask(publishTask.id);
			useMessage().success('任务发布成功');
			await refreshAll();
			return;
		}
		const request = buildSchemaPrecheckRequest(publishTask);
		if (!request) {
			useMessage().warning('任务的数据源、源表或目标表信息不完整，请先编辑并保存任务');
			return;
		}
		const res = await precheckSyncTaskSchema(request);
		publishTargetTask.value = publishTask;
		publishPrecheckResult.value = res.data as SchemaPrecheckResultType;
		publishDialogVisible.value = true;
	} catch (error: any) {
		useMessage().error(error?.msg || '发布前检查失败，请稍后重试');
	} finally {
		publishLoadingId.value = '';
	}
};

const confirmPublish = async () => {
	const task = publishTargetTask.value;
	if (!task || !publishPrecheckCanProceed.value) return;
	if (task.targetTableMode === 'RECREATE_ON_PUBLISH') {
		const targetTable = task.targetTable.includes('.') ? task.targetTable : `public.${task.targetTable}`;
		const confirmation = publishPrecheckResult.value?.targetTableExists
			? `发布将删除并重建目标表 ${targetTable}。现有数据、额外字段和自定义索引将被删除，确认继续吗？`
			: `发布将按源表结构创建目标表 ${targetTable}，并将任务保存为“发布时重建”模式，确认继续吗？`;
		try {
			await useMessageBox().confirm(confirmation);
		} catch {
			return;
		}
	}
	try {
		publishLoadingId.value = task.id;
		await publishSyncTask(task.id);
		useMessage().success('任务发布成功');
		publishDialogVisible.value = false;
		await refreshAll();
	} catch (error: any) {
		useMessage().error(error?.msg || '任务发布失败');
	} finally {
		publishLoadingId.value = '';
	}
};

const handleRun = async (task: LayeredTaskSummary) => {
	if (task.taskType === 'DWD_PROCESS') {
		try {
			const res = await getLayeredTask(task.id);
			const dependencies = (res.data as LayeredTaskSummary & { dependencyTaskIds?: string[] }).dependencyTaskIds || [];
			if (dependencies.length) {
				useMessage().warning('带前置依赖的明细加工任务请通过调度工作流执行');
				return;
			}
		} catch (error: any) {
			useMessage().error(error?.msg || '检查任务依赖失败');
			return;
		}
	}
	try {
		await useMessageBox().confirm(
			task.taskType === 'DWD_PROCESS'
				? `确认立即执行明细加工任务“${task.taskName}”吗？提交后请在执行记录中查看最终状态；存在冻结上游依赖时服务端会拒绝手动执行。`
				: `确认立即执行任务“${task.taskName}”吗？`
		);
	} catch {
		return;
	}
	try {
		runLoadingId.value = task.id;
		const res = await runLayeredTask(task.id);
		const runId = String((res.data as any)?.runId ?? res.data ?? '');
		task.hasActiveRun = true;
		task.activeRunId = runId || null;
		task.activeRunStatus = 'SUBMITTED';
		useMessage().success('任务已提交执行');
		if (runId) openExecution(runId, task.taskType);
	} catch (error: any) {
		useMessage().error(error?.msg || '提交执行失败');
	} finally {
		runLoadingId.value = '';
	}
};

onMounted(() => {
	loadDatasourceReferences();
	refreshAll();
});
</script>

<style scoped lang="scss">
.layered-task-page {
	.page-card {
		height: 100%;
	}

	:deep(.page-card > .el-card__body) {
		height: 100%;
		padding: 0;
	}
}

.page-heading {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 18px 20px;
	border-bottom: 1px solid var(--el-border-color-light);
}

.page-title {
	font-size: 18px;
	font-weight: 600;
	color: var(--el-text-color-primary);
}

.page-description {
	margin-top: 6px;
	color: var(--el-text-color-secondary);
}

.task-workspace {
	display: grid;
	grid-template-columns: 190px minmax(0, 1fr);
	gap: 16px;
	padding: 16px;
}

.layer-sidebar {
	padding: 12px;
	background: var(--el-fill-color-extra-light);
	border: 1px solid var(--el-border-color-light);
	border-radius: 4px;
}

.layer-title {
	padding: 18px 8px 10px;
	font-weight: 600;
}

.layer-title span {
	display: flex;
	gap: 6px;
	align-items: center;
}

.layer-item {
	display: flex;
	align-items: center;
	justify-content: space-between;
	padding: 10px 12px;
	margin-bottom: 4px;
	cursor: pointer;
	border-radius: 4px;
}

.layer-item:hover,
.layer-item.active {
	color: var(--el-color-primary);
	background: var(--el-color-primary-light-9);
}

.layer-count {
	color: var(--el-color-primary);
}

.task-content {
	min-width: 0;
}

.query-panel {
	padding: 14px 14px 0;
	background: var(--el-fill-color-extra-light);
	border: 1px solid var(--el-border-color-light);
	border-radius: 4px;
}

.list-toolbar {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin: 14px 0 10px;
}

.list-title {
	font-size: 16px;
	font-weight: 600;
}

.operation-actions {
	display: flex;
	align-items: center;
	justify-content: flex-start;
	gap: 8px;
	width: 100%;
	white-space: nowrap;
}

.operation-actions :deep(.el-button + .el-button) {
	margin-left: 0;
}

.publish-confirmation {
	margin-bottom: 12px;
}
</style>
