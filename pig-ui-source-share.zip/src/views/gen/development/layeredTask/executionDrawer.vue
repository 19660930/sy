<template>
	<el-drawer v-model="visible" title="执行记录详情" size="780px" :close-on-click-modal="false">
		<div v-loading="loading" class="execution-detail">
			<el-descriptions v-if="execution" :column="2" border>
				<el-descriptions-item label="运行ID">{{ execution.id }}</el-descriptions-item>
				<el-descriptions-item label="执行状态">
					<el-tag :type="runStatusTagType(execution.runStatus)" :effect="execution.runStatus === 'RUNNING' ? 'dark' : 'light'">
						{{ runStatusText(execution.runStatus) }}
					</el-tag>
				</el-descriptions-item>
				<el-descriptions-item label="任务名称">{{ execution.taskName || '--' }}</el-descriptions-item>
				<el-descriptions-item label="触发方式">{{ triggerTypeText(execution.triggerType) }}</el-descriptions-item>
				<el-descriptions-item label="绑定任务版本" :span="2">{{ execution.taskVersionId || '--' }}</el-descriptions-item>
				<el-descriptions-item label="开始时间">{{ execution.startTime || '--' }}</el-descriptions-item>
				<el-descriptions-item label="结束时间">{{ execution.endTime || '--' }}</el-descriptions-item>
				<template v-if="isDimTask">
					<el-descriptions-item label="候选物化数量" :span="2">{{ formatRows(execution.rowsWritten) }}</el-descriptions-item>
				</template>
				<template v-else>
					<el-descriptions-item label="读取行数">{{ formatRows(execution.rowsRead) }}</el-descriptions-item>
					<el-descriptions-item label="写入行数">{{ formatRows(execution.rowsWritten) }}</el-descriptions-item>
					<el-descriptions-item label="执行前水位">{{ execution.checkpointBefore || '--' }}</el-descriptions-item>
					<el-descriptions-item label="本次读取上界">{{ execution.checkpointAfter || '--' }}</el-descriptions-item>
				</template>
				<el-descriptions-item label="DS流程实例">{{ execution.dsProcessInstanceId || '--' }}</el-descriptions-item>
				<el-descriptions-item label="DS任务实例">{{ execution.dsTaskInstanceId || '--' }}</el-descriptions-item>
				<el-descriptions-item v-if="execution.errorSummary" label="错误摘要" :span="2">
					<span class="error-text">{{ execution.errorSummary }}</span>
				</el-descriptions-item>
			</el-descriptions>

			<div class="log-header">
				<div class="log-title">执行详情</div>
				<div>
					<el-link v-if="logUrl" :href="logUrl" target="_blank" type="primary" class="mr10">在 DolphinScheduler 中查看</el-link>
					<el-button icon="Refresh" :loading="loading" @click="loadExecution(true, true)">刷新</el-button>
					<el-button
						v-if="isActiveRunStatus(execution?.runStatus)"
						v-auth="'dp_sync_task_stop'"
						type="danger"
						icon="VideoPause"
						:loading="stopping"
						@click="handleStop"
					>
						停止执行
					</el-button>
				</div>
			</div>
			<el-collapse class="log-collapse">
				<el-collapse-item title="原始日志" name="logs">
					<pre class="log-content">{{ logs || '暂无执行日志' }}</pre>
				</el-collapse-item>
			</el-collapse>
		</div>
	</el-drawer>
</template>

<script setup lang="ts" name="LayeredTaskExecutionDrawer">
import { getSyncRun, getSyncRunLogs, stopSyncRun } from '/@/api/dataPlatform/layeredTask';
import { useMessage, useMessageBox } from '/@/hooks/message';
import type { SyncRunLogs, SyncRunRecord } from '/@/types/dataPlatform/layeredTask';
import { formatRows, isActiveRunStatus, runStatusTagType, runStatusText, triggerTypeText } from './constants';

const emit = defineEmits<{ refresh: [] }>();
const visible = ref(false);
const loading = ref(false);
const stopping = ref(false);
const runId = ref('');
const taskType = ref('');
const execution = ref<SyncRunRecord>();
const logs = ref('');
const logUrl = ref('');
let pollingTimer: ReturnType<typeof setTimeout> | undefined;
const isDimTask = computed(() => taskType.value === 'DIM_BUILD');

const normalizeExecution = (record: SyncRunRecord): SyncRunRecord => ({
	...record,
	id: String(record.id),
	taskId: String(record.taskId),
	taskVersionId: record.taskVersionId ? String(record.taskVersionId) : undefined,
	dsProcessInstanceId: record.dsProcessInstanceId ? String(record.dsProcessInstanceId) : undefined,
	dsTaskInstanceId: record.dsTaskInstanceId ? String(record.dsTaskInstanceId) : undefined,
});

const clearPolling = () => {
	if (pollingTimer) clearTimeout(pollingTimer);
	pollingTimer = undefined;
};

const loadLogs = async () => {
	const logRes = await getSyncRunLogs(runId.value);
	if (typeof logRes.data === 'string') {
		logs.value = logRes.data;
		logUrl.value = execution.value?.logUrl || '';
		return;
	}
	const logData = (logRes.data || {}) as SyncRunLogs;
	logs.value = logData.logs || '';
	logUrl.value = logData.logUrl || execution.value?.logUrl || '';
};

const schedulePolling = () => {
	clearPolling();
	if (!visible.value || !isActiveRunStatus(execution.value?.runStatus)) return;
	pollingTimer = setTimeout(() => loadExecution(false, false), 3000);
};

const loadExecution = async (showLoading = true, includeLogs = true) => {
	if (!runId.value) return;
	const wasActive = isActiveRunStatus(execution.value?.runStatus);
	try {
		if (showLoading) loading.value = true;
		const detailRes = await getSyncRun(runId.value);
		execution.value = normalizeExecution(detailRes.data as SyncRunRecord);
		if (includeLogs || (wasActive && !isActiveRunStatus(execution.value.runStatus))) await loadLogs();
		if (!isActiveRunStatus(execution.value.runStatus)) emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || '加载执行记录失败');
	} finally {
		if (showLoading) loading.value = false;
		schedulePolling();
	}
};

const openDrawer = (id: string, currentTaskType?: string) => {
	clearPolling();
	runId.value = String(id);
	taskType.value = currentTaskType || '';
	visible.value = true;
	execution.value = undefined;
	logs.value = '';
	logUrl.value = '';
	loadExecution(true, true);
};

const handleStop = async () => {
	try {
		await useMessageBox().confirm('确认停止本次任务执行吗？');
	} catch {
		return;
	}
	try {
		stopping.value = true;
		await stopSyncRun(runId.value);
		useMessage().success('停止请求已提交');
		await loadExecution(false, true);
		emit('refresh');
	} catch (error: any) {
		useMessage().error(error?.msg || '停止执行失败');
	} finally {
		stopping.value = false;
	}
};

watch(visible, (value) => {
	if (!value) clearPolling();
});
onBeforeUnmount(clearPolling);

defineExpose({ openDrawer });
</script>

<style scoped>
.execution-detail {
	min-height: 240px;
}

.log-header {
	display: flex;
	align-items: center;
	justify-content: space-between;
	margin: 24px 0 12px;
}

.log-title {
	font-size: 16px;
	font-weight: 600;
}

.log-content {
	height: calc(100vh - 430px);
	min-height: 260px;
	margin: 0;
	padding: 16px;
	overflow: auto;
	color: #d8dee9;
	font-family: Consolas, Monaco, monospace;
	font-size: 13px;
	line-height: 1.65;
	white-space: pre-wrap;
	word-break: break-all;
	background: #1f2329;
	border-radius: 4px;
}

.log-collapse {
	border-top: 0;
}

.error-text {
	color: var(--el-color-danger);
}
</style>
