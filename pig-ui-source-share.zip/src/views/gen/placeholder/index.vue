<template>
	<div class="layout-padding">
		<div class="layout-padding-auto layout-padding-view"></div>
	</div>
</template>

<script setup lang="ts" name="DataPlatformPlaceholder"></script>
