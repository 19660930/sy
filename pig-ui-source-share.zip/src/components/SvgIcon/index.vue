<template>
	<i v-if="isShowIconSvg" class="el-icon" :style="setIconSvgStyle">
		<component :is="getIconName" />
	</i>
	<div v-else-if="isShowIconImg" :class="[svgClass, { 'menu-image-icon': isMenuImageIcon }]" :style="setIconImgOutStyle">
		<img :src="getIconName" :style="setIconSvgInsStyle" />
	</div>
	<svg v-else-if="isShowLocalSvg" :class="svgClass" :style="setIconImgOutStyle">
		<use :href="`#${getIconName}`" :fill="color" />
	</svg>
	<i v-else :class="getIconName" :style="setIconSvgStyle" />
</template>

<script setup lang="ts" name="svgIcon">
import { computed } from 'vue';

// 定义父组件传过来的值
const props = defineProps({
	// svg 图标组件名字
	name: {
		type: String,
	},
	// svg 大小
	size: {
		type: Number,
		default: () => 14,
	},
	// svg 颜色
	color: {
		type: String,
	},
	// svg 自定义类名
	className: {
		type: String,
		default: '',
	},
});

// 在线链接、本地引入地址前缀
const linesString = ['https', 'http', '/src', '/assets', 'data:image', import.meta.env.VITE_PUBLIC_PATH];

// 获取 icon 图标名称
const getIconName = computed(() => props.name);
// 用于判断 element plus 自带 svg 图标的显示、隐藏
const isShowIconSvg = computed(() => props.name?.startsWith('ele-'));
// 用于判断在线链接、本地引入等图标显示、隐藏
const isShowIconImg = computed(() => linesString.find((str) => props.name?.startsWith(str)));
const isMenuImageIcon = computed(() => props.name?.startsWith('/menu-icons/'));

const isShowLocalSvg = computed(() => props.name?.startsWith('local-'));
// 设置图标样式
const setIconSvgStyle = computed(() => {
	return `font-size: ${props.size}px;color: ${props.color};`;
});
// 设置图片样式
const setIconImgOutStyle = computed(() => {
	return `width: ${props.size}px;height: ${props.size}px;display: inline-block;overflow: hidden;`;
});
// 设置图片样式
const setIconSvgInsStyle = computed(() => {
	const filterStyle: string[] = [];
	const compatibles: string[] = ['-webkit', '-ms', '-o', '-moz'];
	const iconColor = props.color || 'currentColor';
	compatibles.forEach((j) => filterStyle.push(`${j}-filter: drop-shadow(${props.size}px 0 ${iconColor});`));
	filterStyle.push(`filter: drop-shadow(${props.size}px 0 ${iconColor});`);
	return `width: ${props.size}px;height: ${props.size}px;object-fit: contain;position: relative;left: -${props.size}px;${filterStyle.join('')}`;
});
// 设置 svg 的 class
const svgClass = computed(() => {
	return props.className ? `svg-icon icon ${props.className}` : 'svg-icon icon';
});
</script>

<style scoped>
.svg-icon {
	fill: currentColor;
	overflow: hidden;
	vertical-align: middle;
}

.menu-image-icon {
	transform: translateX(3px);
}
</style>
