import request from '/@/utils/request';

export type DatasourceParserPlugins = Record<string, boolean>;

const datasourceBaseUrl = '/data-platform/dsconf';

export function fetchList(query?: Object) {
	return request({
		url: `${datasourceBaseUrl}/page`,
		method: 'get',
		params: query,
	});
}

export function list(query?: Object) {
	return request({
		url: `${datasourceBaseUrl}/list`,
		method: 'get',
		params: query,
	});
}

export function listTable(query?: Object) {
	return request({
		url: `${datasourceBaseUrl}/table/list`,
		method: 'get',
		params: query,
	});
}

export function getParserPlugins() {
	return request({
		url: `${datasourceBaseUrl}/parser-plugins`,
		method: 'get',
	});
}

export function testConnection(obj?: Object) {
	return request({
		url: `${datasourceBaseUrl}/test`,
		method: 'post',
		data: obj,
	});
}

export function addObj(obj?: Object) {
	return request({
		url: datasourceBaseUrl,
		method: 'post',
		data: obj,
	});
}

export function getObj(id?: string) {
	return request({
		url: `${datasourceBaseUrl}/${id}`,
		method: 'get',
	});
}

export function delObj(ids?: Object) {
	return request({
		url: datasourceBaseUrl,
		method: 'delete',
		data: ids,
	});
}

export function deleteDatasource(id: string | number) {
	return request({
		url: `${datasourceBaseUrl}/${id}`,
		method: 'delete',
	});
}

export function putObj(obj?: Object) {
	return request({
		url: datasourceBaseUrl,
		method: 'put',
		data: obj,
	});
}
