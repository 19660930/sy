import request from '/@/utils/request';
import type { DwdPage } from '/@/types/dataPlatform/dwd';

export type DwdOperationKind =
	| 'quality-result'
	| 'governance-audit'
	| 'partition-maintenance-event'
	| 'watermark'
	| 'compute-replica'
	| 'event-application';

export type DwdOperationRecord = Record<string, unknown> & { id: string };

export interface DwdOperationQuery {
	current: number;
	size: number;
	[key: string]: string | number | undefined;
}

const operationUrl = (kind: DwdOperationKind) => `/data-platform/dwd/${kind}`;

export const fetchDwdOperationPage = (kind: DwdOperationKind, params: DwdOperationQuery) =>
	request<DwdPage<DwdOperationRecord>>({ url: `${operationUrl(kind)}/page`, method: 'get', params });

export const getDwdOperation = (kind: DwdOperationKind, id: string) =>
	request<DwdOperationRecord>({ url: `${operationUrl(kind)}/${id}`, method: 'get' });
