import request from '/@/utils/request';
import type { DatasourcePhysicalTableQuery, DatasourceTableConfigurationSaveRequest } from '/@/types/dataPlatform/datasourceTableConfiguration';

const datasourceBaseUrl = '/data-platform/datasources';
const metadataBaseUrl = '/data-platform/datasource-metadata/tables';

export function fetchDatasourceTableConfigurations(datasourceId: string) {
	return request({
		url: `${datasourceBaseUrl}/${datasourceId}/table-configurations`,
		method: 'get',
	});
}

export function saveDatasourceTableConfigurations(datasourceId: string, data: DatasourceTableConfigurationSaveRequest) {
	return request({
		url: `${datasourceBaseUrl}/${datasourceId}/table-configurations`,
		method: 'post',
		data,
	});
}

export function fetchDatasourcePhysicalTablePage(datasourceId: string, query: DatasourcePhysicalTableQuery) {
	return request({
		url: `${metadataBaseUrl}/page`,
		method: 'get',
		params: { datasourceId, ...query },
	});
}
