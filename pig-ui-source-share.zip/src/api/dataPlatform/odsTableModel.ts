import request from '/@/utils/request';
import type { OdsTableDataPreviewQuery, OdsTableModelBatchDeleteResult, OdsTableModelQuery } from '/@/types/dataPlatform/odsTableModel';

const baseUrl = '/data-platform/ods/table-models';

export function fetchOdsTableModelPage(query?: OdsTableModelQuery) {
	return request({
		url: `${baseUrl}/page`,
		method: 'get',
		params: query,
	});
}

export function getOdsTableModel(id: string) {
	return request({
		url: `${baseUrl}/${id}`,
		method: 'get',
	});
}

export function fetchOdsTableModelColumns(id: string) {
	return request({
		url: `${baseUrl}/${id}/columns`,
		method: 'get',
	});
}

export function fetchOdsTableModelData(id: string, query?: OdsTableDataPreviewQuery) {
	return request({
		url: `${baseUrl}/${id}/data`,
		method: 'get',
		params: query,
	});
}

export function deleteOdsTableModels(ids: Array<string | number>) {
	return request<OdsTableModelBatchDeleteResult>({
		url: `${baseUrl}/batch`,
		method: 'delete',
		data: { ids },
	});
}
