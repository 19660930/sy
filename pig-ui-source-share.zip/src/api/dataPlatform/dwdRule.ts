import request from '/@/utils/request';
import type { DwdPage } from '/@/types/dataPlatform/dwd';
import type { DwdRule, DwdRuleKind, DwdRuleQuery, DwdRuleSaveRequest } from '/@/types/dataPlatform/dwdRule';

const resource: Record<DwdRuleKind, string> = {
	clean: 'clean-rule',
	transform: 'transform-rule',
	mask: 'mask-rule',
	quality: 'quality-rule',
};
const url = (kind: DwdRuleKind) => `/data-platform/dwd/${resource[kind]}`;

export const fetchDwdRulePage = (kind: DwdRuleKind, params: DwdRuleQuery) =>
	request<DwdPage<DwdRule>>({ url: `${url(kind)}/page`, method: 'get', params });
export const getDwdRule = (kind: DwdRuleKind, id: string) => request<DwdRule>({ url: `${url(kind)}/${id}`, method: 'get' });
export const createDwdRule = (kind: DwdRuleKind, data: DwdRuleSaveRequest) => request<string>({ url: url(kind), method: 'post', data });
export const updateDwdRule = (kind: DwdRuleKind, id: string, data: DwdRuleSaveRequest) => request({ url: `${url(kind)}/${id}`, method: 'put', data });
export const deleteDwdRule = (kind: DwdRuleKind, id: string) => request({ url: `${url(kind)}/${id}`, method: 'delete' });
export const setDwdRuleEnabled = (kind: DwdRuleKind, id: string, enabled: boolean) =>
	request({ url: `${url(kind)}/${id}/enabled/${enabled}`, method: 'put' });
