import request from '/@/utils/request';
import type {
	DataQueryColumn,
	DataQueryDatabase,
	DataQueryDatasource,
	DataQueryExecuteRequest,
	DataQueryExecuteResult,
	DataQueryPageRequest,
	DataQueryPageResult,
	DataQueryTable,
	DataQueryTableQuery,
} from '/@/types/dataPlatform/dataQuery';

const baseUrl = '/data-platform/data-query';

export function fetchDataQueryDatasources() {
	return request<DataQueryDatasource[]>({
		url: `${baseUrl}/datasources`,
		method: 'get',
		params: { category: 'RELATIONAL' },
	});
}

export function fetchDataQuerySchemas(datasourceId: string) {
	return request<string[]>({
		url: `${baseUrl}/datasources/${datasourceId}/schemas`,
		method: 'get',
	});
}

export function fetchDataQueryDatabases(datasourceId: string) {
	return request<DataQueryDatabase[]>({
		url: `${baseUrl}/datasources/${datasourceId}/databases`,
		method: 'get',
	});
}

export function fetchDataQueryTables(datasourceId: string, query: DataQueryTableQuery) {
	return request<DataQueryTable[]>({
		url: `${baseUrl}/datasources/${datasourceId}/tables`,
		method: 'get',
		params: query,
	});
}

export function fetchDataQueryColumns(datasourceId: string, schema: string | undefined, tableName: string) {
	return request<DataQueryColumn[]>({
		url: `${baseUrl}/datasources/${datasourceId}/columns`,
		method: 'get',
		params: { schema, tableName },
	});
}

export function executeDataQuery(data: DataQueryExecuteRequest) {
	return request<DataQueryExecuteResult>({
		url: `${baseUrl}/execute`,
		method: 'post',
		data,
	});
}

export function executeDataQueryPage(data: DataQueryPageRequest) {
	return request<DataQueryPageResult>({
		url: `${baseUrl}/execute/page`,
		method: 'post',
		data,
	});
}

export function exportDataQuery(data: DataQueryExecuteRequest) {
	return request({
		url: `${baseUrl}/export`,
		method: 'post',
		data,
		responseType: 'blob',
	});
}
