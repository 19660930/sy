import request from '/@/utils/request';
import type { DwdSyncTaskSaveRequest, LayeredTaskQuery, SchemaPrecheckRequest, SyncRunQuery, SyncTaskSaveRequest } from '/@/types/dataPlatform/layeredTask';
import type { EngineType } from '/@/types/dataPlatform/engineProfile';

const taskBaseUrl = '/data-platform/sync-tasks';
const runBaseUrl = '/data-platform/sync-runs';
const syncEnumBaseUrl = '/data-platform/sync-enums';

export function fetchLayeredTaskPage(params: LayeredTaskQuery) {
	return request({
		url: `${taskBaseUrl}/layered/page`,
		method: 'get',
		params,
	});
}

export function fetchSyncTaskPage(params: Omit<LayeredTaskQuery, 'layer'>) {
	return request({
		url: `${taskBaseUrl}/page`,
		method: 'get',
		params,
	});
}

export function fetchLayeredTaskStatistics(params?: Omit<LayeredTaskQuery, 'current' | 'size' | 'layer'>) {
	return request({
		url: `${taskBaseUrl}/statistics/by-layer`,
		method: 'get',
		params,
	});
}

export function getLayeredTask(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}`,
		method: 'get',
	});
}

export function createSyncTask(data: SyncTaskSaveRequest | DwdSyncTaskSaveRequest) {
	return request({
		url: taskBaseUrl,
		method: 'post',
		data,
	});
}

export function updateSyncTask(taskId: string, data: SyncTaskSaveRequest | DwdSyncTaskSaveRequest) {
	return request({
		url: `${taskBaseUrl}/${taskId}`,
		method: 'put',
		data,
	});
}

export function deleteSyncTask(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}`,
		method: 'delete',
	});
}

export function precheckSyncTaskSchema(data: SchemaPrecheckRequest) {
	return request({
		url: `${taskBaseUrl}/schema-precheck`,
		method: 'post',
		data,
	});
}

export function publishSyncTask(taskId: string) {
	return request({
		url: `${taskBaseUrl}/task/${taskId}/publish`,
		method: 'post',
	});
}

export function fetchSyncTaskVersions(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}/versions`,
		method: 'get',
	});
}

export function getSyncTaskRelatedModel(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}/related-model`,
		method: 'get',
	});
}

export function offlineLayeredTask(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}/offline`,
		method: 'post',
	});
}

export function onlineLayeredTask(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}/online`,
		method: 'post',
	});
}

export function offlineLayeredTaskSchedule(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}/schedule/offline`,
		method: 'post',
	});
}

export function onlineLayeredTaskSchedule(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}/schedule/online`,
		method: 'post',
	});
}

export function runLayeredTask(taskId: string) {
	return request({
		url: `${taskBaseUrl}/${taskId}/run`,
		method: 'post',
	});
}

export function fetchSyncRunPage(params: SyncRunQuery) {
	return request({
		url: `${runBaseUrl}/page`,
		method: 'get',
		params,
	});
}

export function getSyncRun(runId: string) {
	return request({
		url: `${runBaseUrl}/${runId}`,
		method: 'get',
	});
}

export function getSyncRunLogs(runId: string) {
	return request({
		url: `${runBaseUrl}/${runId}/logs`,
		method: 'get',
	});
}

export function stopSyncRun(runId: string) {
	return request({
		url: `${runBaseUrl}/${runId}/stop`,
		method: 'post',
	});
}

export function fetchDatasourceMetadataTables(datasourceId: string, keyword?: string) {
	return request({
		url: '/data-platform/datasource-metadata/tables',
		method: 'get',
		params: { datasourceId, keyword },
	});
}

export function fetchDatasourceMetadataColumns(datasourceId: string, tableName: string) {
	return request({
		url: '/data-platform/datasource-metadata/columns',
		method: 'get',
		params: { datasourceId, tableName },
	});
}

export function fetchSyncTaskDatasourceOptions(role: 'SOURCE' | 'TARGET') {
	return request({
		url: `${taskBaseUrl}/options/datasources`,
		method: 'get',
		params: { role },
	});
}

export function fetchSyncTaskEngineProfileOptions(engineType: EngineType) {
	return request({
		url: `${taskBaseUrl}/options/engine-profiles`,
		method: 'get',
		params: { engineType },
	});
}

export function fetchSyncTaskSourceTables(datasourceId: string, keyword?: string, currentTaskId?: string) {
	return request({
		url: `${taskBaseUrl}/datasources/${datasourceId}/tables`,
		method: 'get',
		params: { keyword, currentTaskId },
	});
}

export function fetchSyncTaskSourceTableColumns(datasourceId: string, tableName: string, eligibleOnly?: boolean) {
	return request({
		url: `${taskBaseUrl}/datasources/${datasourceId}/tables/${encodeURIComponent(tableName)}/columns`,
		method: 'get',
		params: { eligibleOnly },
	});
}

export function fetchBusinessSystems() {
	return request({
		url: '/data-platform/options/business-systems',
		method: 'get',
	});
}

export function fetchBusinessDomains(systemId: string) {
	return request({
		url: '/data-platform/options/business-domains',
		method: 'get',
		params: { systemId },
	});
}

/** 生成目标表名：数仓层级 + 业务系统编码 + 源表名 */
export function generateTargetTableName(params: { warehouseLayer: string; businessSystemId: string; sourceTable: string }) {
	return request<string>({
		url: '/data-platform/options/generate-target-table-name',
		method: 'get',
		params,
	});
}

export function fetchIncrementalStrategies() {
	return request({
		url: `${syncEnumBaseUrl}/incremental-strategies`,
		method: 'get',
	});
}

export function fetchSourceDeleteStrategies() {
	return request({
		url: `${syncEnumBaseUrl}/source-delete-strategies`,
		method: 'get',
	});
}
