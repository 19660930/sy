import request from '/@/utils/request';
import type {
	MetadataColumn,
	MetadataGraphQuery,
	MetadataGraphResult,
	MetadataObjectDetail,
	MetadataOptions,
	MetadataSearchQuery,
	MetadataSearchResult,
	MetadataSuggestion,
} from '/@/types/dataPlatform/metadata';

const metadataBaseUrl = '/data-platform/metadata';

export function fetchMetadataOptions() {
	return request<MetadataOptions>({
		url: `${metadataBaseUrl}/options`,
		method: 'get',
	});
}

export function fetchMetadataSearchPage(params: MetadataSearchQuery) {
	return request<MetadataSearchResult>({
		url: `${metadataBaseUrl}/search/page`,
		method: 'get',
		params,
	});
}

export function fetchMetadataSearchSuggestions(keyword: string) {
	return request<MetadataSuggestion[]>({
		url: `${metadataBaseUrl}/search/suggestions`,
		method: 'get',
		params: { keyword },
	});
}

export function getMetadataObject(objectId: string) {
	return request<MetadataObjectDetail>({
		url: `${metadataBaseUrl}/objects/${objectId}`,
		method: 'get',
	});
}

export function fetchMetadataObjectColumns(objectId: string) {
	return request<MetadataColumn[]>({
		url: `${metadataBaseUrl}/objects/${objectId}/columns`,
		method: 'get',
	});
}

export function fetchMetadataGraph(params: MetadataGraphQuery) {
	return request<MetadataGraphResult>({
		url: `${metadataBaseUrl}/map/graph`,
		method: 'get',
		params,
	});
}
