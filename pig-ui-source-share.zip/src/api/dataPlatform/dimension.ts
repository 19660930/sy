import request from '/@/utils/request';
import type {
	DimensionAttributeSaveRequest,
	DimensionLevelSaveRequest,
	DimensionMappingSaveRequest,
	DimensionAttribute,
	DimensionModelGeneratePage,
	DimensionModelQuery,
	DimensionModelSaveRequest,
	DimensionOptions,
	DimensionSourceOption,
	DimensionStrategyQuery,
	DimensionStrategySaveRequest,
	DimensionTableGenerateRequest,
	DimensionTableGenerateResult,
	DimensionTableMaintenanceConfirmRequest,
	DimensionTableMaintenancePreview,
	DimensionTableQuery,
	DimensionTableSaveRequest,
	DimensionTableStructureUpdateResult,
	DimensionValueQuery,
	DimensionValueSaveRequest,
	MaterializedDimensionValuePage,
} from '/@/types/dataPlatform/dimension';
import type { DataQueryDatabase } from '/@/types/dataPlatform/dataQuery';

const dimensionBaseUrl = '/data-platform/dim';
const modelBaseUrl = `${dimensionBaseUrl}/models`;

export function fetchDimensionOptions() {
	return request<DimensionOptions>({
		url: `${dimensionBaseUrl}/options`,
		method: 'get',
	});
}

export function fetchDimensionSourceTables(params: { businessSystemId: string; businessDomainId: string }) {
	return request<DimensionSourceOption[]>({
		url: `${dimensionBaseUrl}/options/source-tables`,
		method: 'get',
		params,
	});
}

export function fetchDimensionSourceColumns(tableId: string) {
	return request<DimensionSourceOption[]>({
		url: `${dimensionBaseUrl}/options/source-columns`,
		method: 'get',
		params: { tableId },
	});
}

export function fetchDimensionModelPage(params: DimensionModelQuery) {
	return request({
		url: `${modelBaseUrl}/page`,
		method: 'get',
		params,
	});
}

export function getDimensionModel(id: string) {
	return request({
		url: `${modelBaseUrl}/${id}`,
		method: 'get',
	});
}

export function createDimensionModel(data: DimensionModelSaveRequest) {
	return request({
		url: modelBaseUrl,
		method: 'post',
		data,
	});
}

export function updateDimensionModel(id: string, data: DimensionModelSaveRequest) {
	return request({
		url: `${modelBaseUrl}/${id}`,
		method: 'put',
		data,
	});
}

export function setDimensionModelEnabled(id: string, enabled: boolean) {
	return request({
		url: `${modelBaseUrl}/${id}/enabled`,
		method: 'put',
		params: { enabled },
	});
}

export function deleteDimensionModel(id: string) {
	return request({
		url: `${modelBaseUrl}/${id}`,
		method: 'delete',
	});
}

export function fetchDimensionAttributes(modelId: string) {
	return request<DimensionAttribute[]>({
		url: `${modelBaseUrl}/${modelId}/attributes`,
		method: 'get',
	});
}

export function createDimensionAttribute(modelId: string, data: DimensionAttributeSaveRequest) {
	return request({
		url: `${modelBaseUrl}/${modelId}/attributes`,
		method: 'post',
		data,
	});
}

export function updateDimensionAttribute(modelId: string, attributeId: string, data: DimensionAttributeSaveRequest) {
	return request({
		url: `${modelBaseUrl}/${modelId}/attributes/${attributeId}`,
		method: 'put',
		data,
	});
}

export function deleteDimensionAttribute(modelId: string, attributeId: string) {
	return request({
		url: `${modelBaseUrl}/${modelId}/attributes/${attributeId}`,
		method: 'delete',
	});
}

export function fetchDimensionLevels(modelId: string) {
	return request({
		url: `${modelBaseUrl}/${modelId}/levels`,
		method: 'get',
	});
}

export function createDimensionLevel(modelId: string, data: DimensionLevelSaveRequest) {
	return request({
		url: `${modelBaseUrl}/${modelId}/levels`,
		method: 'post',
		data,
	});
}

export function updateDimensionLevel(modelId: string, levelId: string, data: DimensionLevelSaveRequest) {
	return request({
		url: `${modelBaseUrl}/${modelId}/levels/${levelId}`,
		method: 'put',
		data,
	});
}

export function deleteDimensionLevel(modelId: string, levelId: string) {
	return request({
		url: `${modelBaseUrl}/${modelId}/levels/${levelId}`,
		method: 'delete',
	});
}

export function fetchDimensionModelVersions(modelId: string) {
	return request({
		url: `${modelBaseUrl}/${modelId}/versions`,
		method: 'get',
	});
}

export function fetchDimensionMappings(modelId: string) {
	return request({
		url: `${modelBaseUrl}/${modelId}/mappings`,
		method: 'get',
	});
}

export function createDimensionMapping(modelId: string, data: DimensionMappingSaveRequest) {
	return request({
		url: `${modelBaseUrl}/${modelId}/mappings`,
		method: 'post',
		data,
	});
}

export function updateDimensionMapping(mappingId: string, data: DimensionMappingSaveRequest) {
	return request({
		url: `${dimensionBaseUrl}/mappings/${mappingId}`,
		method: 'put',
		data,
	});
}

export function setDimensionMappingEnabled(mappingId: string, enabled: boolean) {
	return request({
		url: `${dimensionBaseUrl}/mappings/${mappingId}/enabled`,
		method: 'put',
		params: { enabled },
	});
}

export function deleteDimensionMapping(mappingId: string) {
	return request({
		url: `${dimensionBaseUrl}/mappings/${mappingId}`,
		method: 'delete',
	});
}

export function fetchDimensionModelOptions() {
	return request({
		url: `${modelBaseUrl}/options`,
		method: 'get',
	});
}

export function fetchDimensionModelsForGenerate() {
	return request<DimensionModelGeneratePage>({
		url: modelBaseUrl,
		method: 'get',
		params: { page: 1, size: 100 },
	});
}

export function fetchDimensionTableOptions() {
	return request({
		url: `${dimensionBaseUrl}/tables/options`,
		method: 'get',
	});
}

const strategyBaseUrl = `${dimensionBaseUrl}/strategies`;

export function fetchDimensionStrategyPage(params: DimensionStrategyQuery) {
	return request({
		url: `${strategyBaseUrl}/page`,
		method: 'get',
		params,
	});
}

export function createDimensionStrategy(data: DimensionStrategySaveRequest) {
	return request({
		url: strategyBaseUrl,
		method: 'post',
		data,
	});
}

export function updateDimensionStrategy(id: string, data: DimensionStrategySaveRequest) {
	return request({
		url: `${strategyBaseUrl}/${id}`,
		method: 'put',
		data,
	});
}

export function setDimensionStrategyEnabled(id: string, enabled: boolean) {
	return request({
		url: `${strategyBaseUrl}/${id}/enabled`,
		method: 'put',
		params: { enabled },
	});
}

export function deleteDimensionStrategy(id: string) {
	return request({
		url: `${strategyBaseUrl}/${id}`,
		method: 'delete',
	});
}

const tableBaseUrl = `${dimensionBaseUrl}/tables`;

export function fetchDimensionTablePage(params: DimensionTableQuery) {
	return request({
		url: `${tableBaseUrl}/page`,
		method: 'get',
		params,
	});
}

export function getDimensionTable(id: string) {
	return request({
		url: `${tableBaseUrl}/${id}`,
		method: 'get',
	});
}

export function createDimensionTable(data: DimensionTableSaveRequest) {
	return request({
		url: tableBaseUrl,
		method: 'post',
		data,
	});
}

export function generateDimensionTable(data: DimensionTableGenerateRequest) {
	return request<DimensionTableGenerateResult>({
		url: `${tableBaseUrl}/generate`,
		method: 'post',
		data,
	});
}

export function fetchDimensionTableVersions(id: string) {
	return request({
		url: `${tableBaseUrl}/${id}/versions`,
		method: 'get',
	});
}

export function setDimensionTableEnabled(id: string, enabled: boolean) {
	return request({
		url: `${tableBaseUrl}/${id}/enabled`,
		method: 'put',
		data: { enabled },
	});
}

export function deployDimensionTable(id: string, scheduleCron = '') {
	return request({
		url: `${tableBaseUrl}/${id}/deploy`,
		method: 'post',
		data: { scheduleCron },
	});
}

export function previewDimensionTableMaintenance(id: string) {
	return request<DimensionTableMaintenancePreview>({
		url: `${tableBaseUrl}/${id}/maintenance-preview`,
		method: 'get',
	});
}

export function updateDimensionTableStructure(id: string, data: DimensionTableMaintenanceConfirmRequest) {
	return request<DimensionTableStructureUpdateResult>({
		url: `${tableBaseUrl}/${id}/structure-update`,
		method: 'post',
		data,
	});
}

export function deleteDimensionTable(id: string) {
	return request({
		url: `${tableBaseUrl}/${id}`,
		method: 'delete',
	});
}

export function deleteDimensionTablePhysical(id: string, data: DimensionTableMaintenanceConfirmRequest) {
	return request({
		url: `${tableBaseUrl}/${id}/physical-delete`,
		method: 'post',
		data,
	});
}

export function fetchDimensionDatabaseOptions(datasourceId: string) {
	return request<DataQueryDatabase[]>({
		url: `${dimensionBaseUrl}/options/databases`,
		method: 'get',
		params: { datasourceId },
	});
}

const valueBaseUrl = `${dimensionBaseUrl}/values`;
const materializedValueBaseUrl = `${dimensionBaseUrl}/materialized-values`;

export function fetchDimensionValueTree(modelId: string, tableId = '') {
	return request({
		url: `${valueBaseUrl}/tree`,
		method: 'get',
		params: { modelId, ...(tableId ? { tableId } : {}) },
	});
}

export function fetchDimensionValuePage(params: DimensionValueQuery) {
	return request({
		url: `${valueBaseUrl}/page`,
		method: 'get',
		params,
	});
}

export function fetchMaterializedDimensionValuePage(params: Pick<DimensionValueQuery, 'modelId' | 'current' | 'size'>) {
	return request<MaterializedDimensionValuePage>({
		url: `${materializedValueBaseUrl}/page`,
		method: 'post',
		data: params,
	});
}

export function getDimensionValue(id: string) {
	return request({
		url: `${valueBaseUrl}/${id}`,
		method: 'get',
	});
}

export function createDimensionValue(data: DimensionValueSaveRequest) {
	return request({
		url: valueBaseUrl,
		method: 'post',
		data,
	});
}

export function updateDimensionValue(id: string, data: DimensionValueSaveRequest) {
	return request({
		url: `${valueBaseUrl}/${id}`,
		method: 'put',
		data,
	});
}

export function setDimensionValueEnabled(id: string, enabled: boolean) {
	return request({
		url: `${valueBaseUrl}/${id}/enabled`,
		method: 'put',
		params: { enabled },
	});
}

export function deleteDimensionValue(id: string) {
	return request({
		url: `${valueBaseUrl}/${id}`,
		method: 'delete',
	});
}

export function importDimensionValues(file: File, modelId: string, tableId = '', parentId = '') {
	const data = new FormData();
	data.append('file', file);
	data.append('modelId', modelId);
	if (tableId) data.append('tableId', tableId);
	if (parentId) data.append('parentId', parentId);
	return request({
		url: `${valueBaseUrl}/import`,
		method: 'post',
		data,
		headers: { 'Enc-Flag': 'false' },
	});
}

export function exportDimensionValues(params: { modelId: string; tableId?: string; parentId?: string }) {
	return request({
		url: `${valueBaseUrl}/export`,
		method: 'get',
		params,
		responseType: 'blob',
	});
}
