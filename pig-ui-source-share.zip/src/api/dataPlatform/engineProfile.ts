import request from '/@/utils/request';
import type { EngineProfileQuery, EngineProfileSaveRequest } from '/@/types/dataPlatform/engineProfile';

const baseUrl = '/data-platform/engine-profiles';

export function fetchEngineProfiles(query?: EngineProfileQuery) {
	return request({
		url: baseUrl,
		method: 'get',
		params: query,
	});
}

export function getEngineProfile(id: string) {
	return request({
		url: `${baseUrl}/${id}`,
		method: 'get',
	});
}

export function addEngineProfile(data: EngineProfileSaveRequest) {
	return request({
		url: baseUrl,
		method: 'post',
		data,
	});
}

export function updateEngineProfile(id: string, data: EngineProfileSaveRequest) {
	return request({
		url: `${baseUrl}/${id}`,
		method: 'put',
		data,
	});
}

export function deleteEngineProfile(id: string) {
	return request({
		url: `${baseUrl}/${id}`,
		method: 'delete',
	});
}

export function testEngineProfile(id: string) {
	return request({
		url: `${baseUrl}/${id}/test`,
		method: 'post',
	});
}
