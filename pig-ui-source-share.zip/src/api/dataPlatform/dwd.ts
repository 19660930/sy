import request from '/@/utils/request';
import type {
	DwdField,
	DwdFrozenVersion,
	DwdModel,
	DwdModelQuery,
	DwdModelReference,
	DwdMetadataTable,
	DwdModelSaveRequest,
	DwdOption,
	DwdOptions,
	DwdPage,
	DwdPartition,
	DwdSource,
	DwdSqlResult,
	DwdVersion,
	DwdValidationResult,
} from '/@/types/dataPlatform/dwd';

const base = '/data-platform/dwd/models';

export const fetchDwdOptions = () => request<DwdOptions>({ url: '/data-platform/dwd/options', method: 'get' });
export const fetchDwdModelPage = (params: DwdModelQuery) => request<DwdPage<DwdModel>>({ url: `${base}/page`, method: 'get', params });
export const fetchDwdModelOptions = () => request<DwdOption[]>({ url: `${base}/options`, method: 'get' });
export const getDwdModel = (id: string) => request<DwdModel>({ url: `${base}/${id}`, method: 'get' });
export const createDwdModel = (data: DwdModelSaveRequest) => request<string>({ url: base, method: 'post', data });
export const updateDwdModel = (id: string, data: DwdModelSaveRequest) => request({ url: `${base}/${id}`, method: 'put', data });
export const deleteDwdModel = (id: string) => request({ url: `${base}/${id}`, method: 'delete' });
export const fetchDwdModelReferences = (id: string) => request<DwdModelReference[]>({ url: `${base}/${id}/references`, method: 'get' });

export const fetchDwdSources = (id: string) => request<DwdSource[]>({ url: `${base}/${id}/sources`, method: 'get' });
export const saveDwdSources = (id: string, data: DwdSource[]) => request({ url: `${base}/${id}/sources`, method: 'put', data });
export const fetchDwdFields = (id: string) => request<DwdField[]>({ url: `${base}/${id}/mappings`, method: 'get' });
export const saveDwdFields = (id: string, data: DwdField[]) => request({ url: `${base}/${id}/mappings`, method: 'put', data });
export const fetchDwdPartition = (id: string) => request<DwdPartition | null>({ url: `${base}/${id}/partition`, method: 'get' });
export const saveDwdPartition = (id: string, data: DwdPartition) => request({ url: `${base}/${id}/partition`, method: 'put', data });
export const fetchDwdSql = (id: string) => request<DwdSqlResult>({ url: `${base}/${id}/sql`, method: 'get' });
export const fetchDwdVersions = (id: string) => request<DwdVersion[]>({ url: `${base}/${id}/versions`, method: 'get' });
export const getDwdVersion = (id: string, versionId: string) => request<DwdFrozenVersion>({ url: `${base}/${id}/versions/${versionId}`, method: 'get' });
export const fetchDwdDraftRevision = (id: string) => request<string>({ url: `${base}/${id}/draft-revision`, method: 'get' });
export const validateDwdModel = (id: string, revision: string) => request<DwdValidationResult>({ url: `${base}/${id}/validation`, method: 'get', params: { revision } });
export const freezeDwdVersion = (id: string, data: { expectedRevision: string; changelog?: string }) =>
	request<DwdFrozenVersion>({ url: `${base}/${id}/freeze`, method: 'post', data });

// 数据源配置为分页接口；下拉需加载全部页，不能只显示第一页。
export const fetchDwdDatasources = async () => {
	const rows: unknown[] = [];
	let current = 1;
	let total = 0;
	do {
		const response = await request<DwdPage<unknown>>({ url: '/data-platform/dsconf/page', method: 'get', params: { current, size: 100 } });
		const pageRows = Array.isArray(response.data?.records) ? response.data.records : [];
		rows.push(...pageRows);
		total = Number(response.data?.total ?? rows.length);
		if (!pageRows.length) break;
		current += 1;
	} while (rows.length < total);
	return { data: rows };
};
export const fetchDwdTableColumns = (id: string) => request<unknown>({ url: `/data-platform/metadata/tables/${id}/columns`, method: 'get' });

export const fetchDwdOdsTablePage = (datasourceId: string, current: number, size: number) =>
	request<DwdPage<DwdMetadataTable>>({
		url: '/data-platform/metadata/tables/page',
		method: 'get',
		params: { datasourceId, warehouseLayer: 'ODS', current, size },
	});
