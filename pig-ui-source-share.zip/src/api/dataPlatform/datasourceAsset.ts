import request from '/@/utils/request';
import type { DatasourceAssetQuery, DatasourceAssetSaveRequest, DatasourceReference } from '/@/types/dataPlatform/datasourceAsset';

const assetBaseUrl = '/data-platform/datasource-assets';

export function fetchDatasourceReferences() {
	return request<DatasourceReference[]>({
		url: '/data-platform/datasource-references',
		method: 'get',
	});
}

export function fetchDatasourceAssetPage(query?: DatasourceAssetQuery) {
	return request({
		url: `${assetBaseUrl}/page`,
		method: 'get',
		params: query,
	});
}

export function getDatasourceAsset(id: string) {
	return request({
		url: `${assetBaseUrl}/${id}`,
		method: 'get',
	});
}

export function addDatasourceAsset(data: DatasourceAssetSaveRequest) {
	return request({
		url: assetBaseUrl,
		method: 'post',
		data,
	});
}

export function updateDatasourceAsset(id: string, data: DatasourceAssetSaveRequest) {
	return request({
		url: `${assetBaseUrl}/${id}`,
		method: 'put',
		data,
	});
}
