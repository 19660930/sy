import request from '/@/utils/request';
import type { ManualSyncBatchQuery, ManualSyncDatasourceKind, ManualSyncSubmitRequest } from '/@/types/dataPlatform/odsManualSync';

const baseUrl = '/data-platform/ods/manual-sync';

export function fetchManualSyncDatasources(kind: ManualSyncDatasourceKind) {
	return request({
		url: `${baseUrl}/datasources`,
		method: 'get',
		params: { kind },
	});
}

export function fetchManualSyncSeaTunnelProfiles() {
	return request({
		url: `${baseUrl}/seatunnel-profiles`,
		method: 'get',
	});
}

export function fetchManualSyncSourceTables(sourceDatasourceId: string, keyword?: string) {
	return request({
		url: `${baseUrl}/source-tables`,
		method: 'get',
		params: { sourceDatasourceId, keyword },
	});
}

export function submitManualSync(data: ManualSyncSubmitRequest) {
	return request({
		url: baseUrl,
		method: 'post',
		data,
	});
}

export function fetchManualSyncBatchPage(query?: ManualSyncBatchQuery) {
	return request({
		url: `${baseUrl}/page`,
		method: 'get',
		params: query,
	});
}

export function getManualSyncBatch(batchId: string) {
	return request({
		url: `${baseUrl}/${batchId}`,
		method: 'get',
	});
}
